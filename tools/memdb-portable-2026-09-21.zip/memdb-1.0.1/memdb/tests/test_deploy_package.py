"""`mem install` deploys the running package in interpreter form.

Field finding 2026-09-21: `python -P -m memdb` imported a hand-copied
package from user site-packages that reported the same `1.0.1` as the
repository build while lacking lifecycle.py and similar.py. Install
compared version strings only and never copied anything, so the drift was
invisible and permanent.
"""
import os

import pytest

from memdb import config, install, paths


def write(root, rel, text):
    path = os.path.join(root, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)


@pytest.fixture
def source(tmp_path):
    root = str(tmp_path / "src" / "memdb")
    write(root, "__init__.py", "__version__ = '9.9.9'\n")
    write(root, "mem.py", "def main(): pass\n")
    write(root, "lifecycle.py", "NEW = True\n")
    write(root, "templates/skill.md", "# skill\n")
    write(root, "tests/test_x.py", "never deployed\n")
    write(root, "__pycache__/mem.cpython-314.pyc", "junk")
    return root


@pytest.fixture
def stale(tmp_path):
    root = str(tmp_path / "site" / "memdb")
    write(root, "__init__.py", "__version__ = '9.9.9'\n")
    write(root, "mem.py", "def main(): OLD\n")
    write(root, "gone.py", "removed upstream\n")
    return root


def cfg_for(form=config.FORM_INTERPRETER):
    return {"command_form": form, "interpreter": "python", "safe_path": True}


@pytest.fixture(autouse=True)
def deploy_allowed(monkeypatch):
    """These tests point deploy at temp dirs, so the suite-wide guard is lifted here."""
    monkeypatch.delenv("MEMDB_NO_PACKAGE_DEPLOY", raising=False)


def test_suite_guard_skips_deploy(source, stale, monkeypatch):
    monkeypatch.setenv("MEMDB_NO_PACKAGE_DEPLOY", "1")
    monkeypatch.setattr(install, "package_dir", lambda: source)
    monkeypatch.setattr(install, "resolved_package_dir", lambda cfg: stale)
    rec = install.deploy_package(cfg_for(), check=False)
    assert rec["changed"] is False and rec["skipped"] == "MEMDB_NO_PACKAGE_DEPLOY"


def test_fingerprint_ignores_caches_and_tests(source):
    before = install.package_fingerprint(source)
    write(source, "tests/test_y.py", "still not deployed\n")
    write(source, "__pycache__/other.pyc", "more junk")
    assert install.package_fingerprint(source) == before
    write(source, "mem.py", "def main(): CHANGED\n")
    assert install.package_fingerprint(source) != before


def test_check_reports_the_drift_and_writes_nothing(db, source, stale, monkeypatch):
    monkeypatch.setattr(install, "package_dir", lambda: source)
    monkeypatch.setattr(install, "resolved_package_dir", lambda cfg: stale)
    rec = install.deploy_package(cfg_for(), check=True)
    assert rec["changed"] and rec["applied"] is False and rec["action"] == "replace"
    assert rec["path"] == stale and rec["source"] == source
    assert set(rec["differing"]) == {"+ lifecycle.py", "+ templates/skill.md",
                                     "- gone.py", "~ mem.py"}
    with open(os.path.join(stale, "mem.py"), encoding="utf-8") as f:
        assert "OLD" in f.read()


def test_apply_replaces_the_stale_build_and_keeps_a_backup(db, source, stale, monkeypatch):
    monkeypatch.setattr(install, "package_dir", lambda: source)
    monkeypatch.setattr(install, "resolved_package_dir", lambda cfg: stale)
    rec = install.deploy_package(cfg_for(), check=False)
    assert rec["changed"] and rec["applied"] is True
    assert install.package_fingerprint(stale) == install.package_fingerprint(source)
    assert not os.path.exists(os.path.join(stale, "gone.py"))
    assert not os.path.exists(os.path.join(stale, "tests"))
    assert not os.path.exists(os.path.join(stale, "__pycache__"))
    assert os.path.isfile(os.path.join(rec["backup"], "gone.py"))
    assert rec["backup"].startswith(paths.install_backups_dir())
    again = install.deploy_package(cfg_for(), check=False)
    assert again["changed"] is False


def test_nothing_resolved_deploys_into_user_site(db, source, tmp_path, monkeypatch):
    target_root = str(tmp_path / "usersite")
    monkeypatch.setattr(install, "package_dir", lambda: source)
    monkeypatch.setattr(install, "resolved_package_dir", lambda cfg: None)
    monkeypatch.setattr(install.site, "getusersitepackages", lambda: target_root)
    rec = install.deploy_package(cfg_for(), check=False)
    assert rec["action"] == "copy" and rec["resolved"] is None
    assert os.path.isfile(os.path.join(target_root, "memdb", "lifecycle.py"))


def test_same_tree_or_other_forms_are_no_ops(db, source, monkeypatch):
    monkeypatch.setattr(install, "package_dir", lambda: source)
    monkeypatch.setattr(install, "resolved_package_dir", lambda cfg: source)
    assert install.deploy_package(cfg_for(), check=True)["changed"] is False
    assert install.deploy_package(cfg_for(config.FORM_PYZ), check=True)["changed"] is False

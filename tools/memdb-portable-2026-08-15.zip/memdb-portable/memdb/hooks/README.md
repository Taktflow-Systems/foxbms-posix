# memdb harness hooks

## SessionStart digest injection

Add to the consuming project's `.claude/settings.json`:

```json
{
  "hooks": {
    "SessionStart": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "bash \"$CLAUDE_PROJECT_DIR\"/memdb/hooks/session_start.sh"
          }
        ]
      }
    ]
  }
}
```

If memdb lives outside the consuming project, replace
`"$CLAUDE_PROJECT_DIR"/memdb` with the absolute path to the memdb checkout.

Environment knobs (all optional):

- `MEMDB_PATH` - DB location (default `~/.claude/memory/mem.db`)
- `MEMDB_PROJECT` - project slug (default: basename of session cwd)
- `MEMDB_PART` - part slug filter (default: none = whole project)
- `MEMDB_BUDGET` - digest token budget (default 1500)

Failure behavior: the hook exits 0 with no output on ANY error (missing DB,
missing python, broken schema). A broken memory layer never blocks session
start.

## Failure visibility

The hook never blocks session start (exit 0 always), but failure and
emptiness are visible marker lines in the injected context instead of
silence: `[memdb UNAVAILABLE - run: ... doctor]` when the digest cannot
render, `[memdb: no records for project X ...]` when the scope is empty.

## End-of-job flow

At the end of a job the agent runs, as its final-response step:

```sh
python3 memdb/mem.py record-episode \
    --project <project-slug> --part <part-slug> --task <task-slug> \
    --json episode.json [--session-id <id>] [--transcript <path>]
bash memdb/sync/memdb_sync.sh
```

`episode.json` carries the handoff shape as JSON: `date`, `achievement`,
`decisions_with_rationale` (list of `{decision, rationale}`),
`current_state` (`{summary, files_touched, status}`), `blockers`,
`next_steps`. The journal event is the record; the DB is a rebuildable
projection; handoff YAML is rendered only on explicit request
(`render-handoff <episode-id-or-uid> --out <path>`).

Capture is full-fidelity: journals and DB are the PRIVATE memory domain
(user-owned machines + self-hosted hub), so real paths and hostnames are
allowed and preserved. Redaction guards the publish boundary instead:
anything leaving the private domain must pass
`python3 memdb/mem.py redact-check <file>` (exit 2 on hits).

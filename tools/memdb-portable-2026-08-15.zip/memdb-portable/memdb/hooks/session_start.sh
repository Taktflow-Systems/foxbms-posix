#!/usr/bin/env bash
# SessionStart hook: inject the memory digest as additional context.
# Contract: NEVER block session start (always exit 0) - but failure and
# emptiness are VISIBLE states, not silence. A broken memory layer must
# not be indistinguishable from an empty one.
set -u

MEMDB_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

INPUT="$(cat 2>/dev/null || true)"
CWD="$(printf '%s' "$INPUT" | python3 -c '
import json, sys
try:
    print(json.load(sys.stdin).get("cwd", ""))
except Exception:
    print("")' 2>/dev/null || true)"
[ -n "$CWD" ] || CWD="$PWD"

PROJECT="${MEMDB_PROJECT:-$(basename "$CWD")}"
PART_ARGS=()
[ -n "${MEMDB_PART:-}" ] && PART_ARGS=(--part "$MEMDB_PART")

DIGEST="$(python3 "$MEMDB_ROOT/mem.py" digest --project "$PROJECT" \
    "${PART_ARGS[@]}" ${MEMDB_BUDGET:+--budget-tokens "$MEMDB_BUDGET"} \
    2>/dev/null)"
STATUS=$?

if [ $STATUS -ne 0 ]; then
    DIGEST="[memdb UNAVAILABLE - run: python3 $MEMDB_ROOT/mem.py doctor]"
elif [ -z "$(printf '%s' "$DIGEST" | sed -n '2,$p')" ]; then
    # digest emitted only its header line -> no records in scope
    DIGEST="[memdb: no records for project $PROJECT - it may need backfill
or the project slug may differ; try: python3 $MEMDB_ROOT/mem.py search]"
fi

DIGEST="$DIGEST" python3 - <<'EOF' 2>/dev/null || true
import json, os
print(json.dumps({"hookSpecificOutput": {
    "hookEventName": "SessionStart",
    "additionalContext": os.environ["DIGEST"]}}))
EOF
exit 0

#!/usr/bin/env python3
"""mem - log-first memory for agent harnesses.

The per-host append-only journal (journal.py) is the system of record.
The SQLite DB is a derived projection: every write command appends an
event, then applies it; `rebuild` reproduces the DB from journals alone;
`verify` proves the live DB matches a canonical replay and that every
journal's hash chain is intact.

One table (records) holds episodic and semantic memory, distinguished by
`kind`. Files (handoff YAML, digest markdown) are rendered views only.
Records have a stable cross-host identity `uid` = "<host>:<seq>" of the
creating event ("<host>:<seq>/<n>" for episode children); CLI commands
accept either a uid or a local integer id.

Python 3 stdlib only. DB path: $MEMDB_PATH, default
~/.claude/memory/mem.db. Journal root: $MEMDB_JOURNAL, default
~/.claude/memory/journal. Host identity: $MEMDB_HOST or
~/.claude/memory/host-id.

Redaction note: journals and DB live in the PRIVATE memory domain
(user-owned machines + self-hosted remote) and store full fidelity.
Anything published outside that domain must pass `redact-check`.
"""
import argparse
import json
import math
import os
import re
import sqlite3
import sys
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import journal  # noqa: E402
from redact import check_text  # noqa: E402

SCHEMA_VERSION = 2
SCHEMA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "schema.sql")
DEFAULT_DB = os.path.join(os.path.expanduser("~"), ".claude", "memory", "mem.db")
KINDS = ("episode", "decision", "blocker", "state", "preference", "goal", "constraint")
ANCHOR_KINDS = ("goal", "constraint")
CHARS_PER_TOKEN = 3.5
DEMOTE_AFTER_DAYS = 90


class MissingRef(Exception):
    """An event references a uid not present in the projection (yet)."""


def db_path():
    return os.environ.get("MEMDB_PATH", DEFAULT_DB)


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def connect(path=None):
    path = path or db_path()
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_schema(conn):
    with open(SCHEMA_FILE, "r", encoding="utf-8") as f:
        conn.executescript(f.read())
    version = conn.execute("PRAGMA user_version").fetchone()[0]
    if version == 0:
        conn.execute("PRAGMA user_version = {}".format(SCHEMA_VERSION))
    elif version != SCHEMA_VERSION:
        raise SystemExit(
            "init: DB has schema version {} but this tool expects {}. "
            "The DB is a projection - move it aside and run `mem rebuild` "
            "(or re-record genesis episodes) instead of migrating in place."
            .format(version, SCHEMA_VERSION))
    conn.commit()


def norm_body(text):
    return re.sub(r"\s+", " ", text.strip().lower()).rstrip(".")


def slug(text, maxlen=60):
    s = re.sub(r"[^a-z0-9]+", "-", text.strip().lower()).strip("-")
    return s[:maxlen].rstrip("-")


def row_to_dict(row):
    return {k: row[k] for k in row.keys()}


def est_tokens(text):
    return math.ceil(len(text) / CHARS_PER_TOKEN)


def fts_query(natural):
    tokens = re.findall(r"[A-Za-z0-9_]+", natural)
    if not tokens:
        raise SystemExit("search: query has no indexable tokens")
    return " OR ".join('"{}"'.format(t) for t in tokens)


def local_id(conn, ref):
    """Resolve a uid string or integer-like local id to a local id."""
    row = conn.execute("SELECT id FROM records WHERE uid=?",
                       (str(ref),)).fetchone()
    if row:
        return row["id"]
    if str(ref).lstrip("-").isdigit():
        row = conn.execute("SELECT id FROM records WHERE id=?",
                           (int(ref),)).fetchone()
        if row:
            return row["id"]
    return None


def uid_of(conn, rid):
    row = conn.execute("SELECT uid FROM records WHERE id=?", (rid,)).fetchone()
    return row["uid"] if row else None


# ---------------------------------------------------------------- init

def cmd_init(args):
    conn = connect()
    init_schema(conn)
    conn.close()
    print(json.dumps({"db": db_path(), "schema_version": SCHEMA_VERSION}))


# ------------------------------------------------------ event appliers

def gated_insert(conn, kind, project, part, subject, body, uid_alloc,
                 rationale=None, confidence="confirmed", status="open",
                 session_id=None, source_record=None, payload=None,
                 created_at=None):
    """Write-gated insert. Returns (action, record_id).

    Same (project, kind, subject) open match with same normalized body ->
    bump last_confirmed_at. Different body -> insert new, supersede all
    open matches. No match -> plain insert. `uid_alloc` is called only
    when a row is actually inserted, keeping uid assignment deterministic
    under replay.
    """
    ts = created_at or now_iso()
    matches = conn.execute(
        "SELECT * FROM records WHERE project=? AND kind=? AND subject=? "
        "AND status='open' ORDER BY id", (project, kind, subject)).fetchall()
    for m in matches:
        if norm_body(m["body"]) == norm_body(body):
            conn.execute(
                "UPDATE records SET last_confirmed_at=?, confidence=? "
                "WHERE id=?",
                (ts, "confirmed" if confidence == "confirmed" else m["confidence"],
                 m["id"]))
            return "confirmed", m["id"]
    cur = conn.execute(
        "INSERT INTO records (uid, kind, project, part, subject, body, "
        "rationale, status, confidence, created_at, last_confirmed_at, "
        "source_record, session_id, payload) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (uid_alloc(), kind, project, part, subject, body, rationale, status,
         confidence, ts, ts, source_record, session_id, payload))
    new_id = cur.lastrowid
    for m in matches:
        conn.execute(
            "UPDATE records SET status='superseded', superseded_by=? WHERE id=?",
            (new_id, m["id"]))
        conn.execute(
            "INSERT OR IGNORE INTO links (from_id, to_id, relation) "
            "VALUES (?,?,'supersedes')", (new_id, m["id"]))
    return ("superseded" if matches else "added"), new_id


def apply_add(conn, ev):
    p = ev["payload"]
    uid = "{}:{}".format(ev["host"], ev["seq"])
    action, rid = gated_insert(
        conn, p["kind"], p["project"], p["part"], p["subject"], p["body"],
        uid_alloc=lambda: uid, rationale=p.get("rationale"),
        confidence=p.get("confidence", "confirmed"),
        session_id=p.get("session_id"), created_at=p["ts"])
    return {"action": action, "id": rid, "uid": uid_of(conn, rid)}


def apply_episode(conn, ev):
    p = ev["payload"]
    doc = p["doc"]
    base_uid = "{}:{}".format(ev["host"], ev["seq"])
    ts = p["ts"]
    session_id = p.get("session_id")
    project, part, task = p["project"], p["part"], p["task"]

    state = doc.get("current_state") or {}
    body = state.get("summary") or (doc.get("achievement") or ["(no summary)"])[0]
    # Episodes carry their full raw text in the FTS index (low rank weight)
    # so prose that never became a structured child row stays findable.
    fulltext = doc.get("raw_markdown") or doc.get("raw_yaml") \
        or json.dumps(doc, sort_keys=True)
    episode_payload = dict(doc)
    if p.get("transcript"):
        episode_payload["_transcript"] = p["transcript"]
    cur = conn.execute(
        "INSERT INTO records (uid, kind, project, part, subject, body, status, "
        "confidence, created_at, last_confirmed_at, session_id, payload, "
        "fulltext) VALUES (?,'episode',?,?,?,?,'closed','confirmed',?,?,?,?,?)",
        (base_uid, project, part, task, body, ts, ts, session_id,
         json.dumps(episode_payload, sort_keys=True), fulltext))
    episode_id = cur.lastrowid

    child_n = [0]

    def next_uid():
        child_n[0] += 1
        return "{}/{}".format(base_uid, child_n[0])

    counts = {"decision": 0, "blocker": 0, "state": 0}
    new_blocker_ids = set()

    def item_fields(item, text_keys):
        """Accept plain strings or dicts; dicts may pin an explicit subject
        so reworded facts still supersede their predecessors."""
        if isinstance(item, dict):
            text = next((item[k] for k in text_keys if k in item), None)
            if text is None:
                text = json.dumps(item, sort_keys=True)
            return text, item.get("subject") or slug(text), item.get("rationale")
        return str(item), slug(str(item)), None

    for d in doc.get("decisions_with_rationale") or []:
        text, subject, rationale = item_fields(d, ("decision",))
        gated_insert(conn, "decision", project, part, subject, text,
                     uid_alloc=next_uid, rationale=rationale,
                     source_record=episode_id, session_id=session_id,
                     created_at=ts)
        counts["decision"] += 1
    for b in doc.get("blockers") or []:
        text, subject, _ = item_fields(b, ("blocker", "text"))
        action, rid = gated_insert(
            conn, "blocker", project, part, subject, text,
            uid_alloc=next_uid, source_record=episode_id,
            session_id=session_id, created_at=ts)
        new_blocker_ids.add(rid)
        counts["blocker"] += 1
    for s in state.get("status") or []:
        text, subject, _ = item_fields(s, ("state", "text"))
        gated_insert(conn, "state", project, part, subject, text,
                     uid_alloc=next_uid, source_record=episode_id,
                     session_id=session_id, created_at=ts)
        counts["state"] += 1

    # Close prior open blockers whose subject is named by this episode's
    # achievements / current state. Project-wide, not part-scoped: a job in
    # one part can resolve a blocker opened by another part, and the
    # resolution text names the blocker explicitly.
    resolution_items = (doc.get("achievement") or []) \
        + (state.get("status") or []) + [state.get("summary") or ""]
    resolution_text = " ".join(
        item_fields(x, ("state", "text"))[0] for x in resolution_items)
    resolution_slug = slug(resolution_text, maxlen=100000)
    closed = []
    for row in conn.execute(
            "SELECT id, subject FROM records WHERE project=? "
            "AND kind='blocker' AND status='open'", (project,)).fetchall():
        if row["id"] in new_blocker_ids:
            continue
        if row["subject"] and row["subject"] in resolution_slug:
            conn.execute("UPDATE records SET status='closed' WHERE id=?",
                         (row["id"],))
            closed.append(row["id"])
    return {"episode_id": episode_id, "uid": base_uid, "children": counts,
            "closed_blockers": closed}


def apply_close(conn, ev):
    rid = local_id(conn, ev["payload"]["uid"])
    if rid is None:
        raise MissingRef(ev["payload"]["uid"])
    conn.execute("UPDATE records SET status='closed' WHERE id=?", (rid,))
    return {"action": "closed", "id": rid, "uid": ev["payload"]["uid"]}


def apply_supersede(conn, ev):
    p = ev["payload"]
    old_rid = local_id(conn, p["old_uid"])
    new_rid = local_id(conn, p["by_uid"])
    if old_rid is None or new_rid is None:
        raise MissingRef(p["old_uid"] if old_rid is None else p["by_uid"])
    conn.execute("UPDATE records SET status='superseded', superseded_by=? "
                 "WHERE id=?", (new_rid, old_rid))
    conn.execute("INSERT OR IGNORE INTO links (from_id, to_id, relation) "
                 "VALUES (?,?,'supersedes')", (new_rid, old_rid))
    return {"action": "superseded", "id": old_rid, "by": new_rid,
            "uid": p["old_uid"], "by_uid": p["by_uid"]}


def apply_consolidate(conn, ev):
    p = ev["payload"]
    for m in p.get("merged") or []:
        kept = local_id(conn, m["kept_uid"])
        if kept is None:
            raise MissingRef(m["kept_uid"])
        for u in m["superseded_uids"]:
            rid = local_id(conn, u)
            if rid is None:
                raise MissingRef(u)
            conn.execute("UPDATE records SET status='superseded', "
                         "superseded_by=? WHERE id=?", (kept, rid))
            conn.execute("INSERT OR IGNORE INTO links (from_id, to_id, "
                         "relation) VALUES (?,?,'supersedes')", (kept, rid))
    for a_uid, b_uid in p.get("contradictions") or []:
        a, b = local_id(conn, a_uid), local_id(conn, b_uid)
        if a is None or b is None:
            raise MissingRef(a_uid if a is None else b_uid)
        conn.execute("INSERT OR IGNORE INTO links (from_id, to_id, relation) "
                     "VALUES (?,?,'contradicts')", (a, b))
    for u in p.get("demoted") or []:
        rid = local_id(conn, u)
        if rid is None:
            raise MissingRef(u)
        conn.execute("UPDATE records SET status='closed' WHERE id=?", (rid,))
    return {"applied": True}


APPLIERS = {"add": apply_add, "episode": apply_episode, "close": apply_close,
            "supersede": apply_supersede, "consolidate": apply_consolidate}


def apply_event(conn, ev):
    applier = APPLIERS.get(ev["type"])
    if applier is None:
        raise SystemExit("apply: unknown event type {!r}".format(ev["type"]))
    return applier(conn, ev)


def write_event(etype, payload):
    """Append to this host's journal, then apply to the live projection."""
    ev = journal.append_event(journal.host_id(), etype, payload, payload["ts"])
    conn = connect()
    result = apply_event(conn, ev)
    conn.commit()
    conn.close()
    return result


# ----------------------------------------------------- write commands

def cmd_add(args):
    payload = {"kind": args.kind, "project": args.project, "part": args.part,
               "subject": args.subject, "body": args.body,
               "rationale": args.rationale, "confidence": args.confidence,
               "session_id": args.session_id, "ts": now_iso()}
    print(json.dumps(write_event("add", payload)))


def cmd_record_episode(args):
    raw = sys.stdin.read() if args.json == "-" else open(args.json, encoding="utf-8").read()
    doc = json.loads(raw)
    date = args.date or doc.get("date") or now_iso()[:10]
    ts = date + "T00:00:00+00:00" if len(date) == 10 else date
    payload = {"project": args.project, "part": args.part, "task": args.task,
               "session_id": args.session_id, "doc": doc, "ts": ts}
    if args.transcript:
        entry = {"path": args.transcript}
        if os.path.exists(args.transcript):
            import hashlib
            with open(args.transcript, "rb") as f:
                entry["sha256"] = hashlib.sha256(f.read()).hexdigest()
        payload["transcript"] = entry
    print(json.dumps(write_event("episode", payload)))


def cmd_close(args):
    conn = connect()
    rid = local_id(conn, args.id)
    if rid is None:
        raise SystemExit("close: no record {}".format(args.id))
    uid = uid_of(conn, rid)
    if uid is None:
        raise SystemExit("close: record {} has no uid (pre-journal row); "
                         "rebuild first".format(args.id))
    conn.close()
    print(json.dumps(write_event("close", {"uid": uid, "ts": now_iso()})))


def cmd_supersede(args):
    conn = connect()
    old_rid = local_id(conn, args.old_id)
    new_rid = local_id(conn, args.by)
    if old_rid is None or new_rid is None:
        raise SystemExit("supersede: no record {}".format(
            args.old_id if old_rid is None else args.by))
    old_uid, by_uid = uid_of(conn, old_rid), uid_of(conn, new_rid)
    if old_uid is None or by_uid is None:
        raise SystemExit("supersede: pre-journal row without uid; rebuild first")
    conn.close()
    print(json.dumps(write_event(
        "supersede", {"old_uid": old_uid, "by_uid": by_uid, "ts": now_iso()})))


def compute_consolidate(conn):
    """Pure computation of consolidation outcomes (no writes)."""
    outcome = {"merged": [], "contradictions": [], "demoted": []}
    groups = {}
    for row in conn.execute(
            "SELECT * FROM records WHERE status='open' AND kind != 'episode' "
            "ORDER BY id"):
        groups.setdefault((row["project"], row["kind"], row["subject"]),
                          []).append(row)
    for key, rows in groups.items():
        if len(rows) < 2:
            continue
        partitions = {}
        for r in rows:
            partitions.setdefault(norm_body(r["body"]), []).append(r)
        survivors = []
        for body_norm, dupes in partitions.items():
            keep = dupes[0]  # oldest id
            survivors.append(keep)
            if len(dupes) > 1:
                outcome["merged"].append(
                    {"kept_uid": keep["uid"],
                     "superseded_uids": [d["uid"] for d in dupes[1:]]})
        if len(survivors) > 1:
            for a, b in zip(survivors, survivors[1:]):
                outcome["contradictions"].append([a["uid"], b["uid"]])
    cutoff = (datetime.now(timezone.utc)
              - timedelta(days=DEMOTE_AFTER_DAYS)).isoformat()
    for row in conn.execute(
            "SELECT uid FROM records WHERE status='open' AND "
            "confidence='unverified' AND last_confirmed_at < ?",
            (cutoff,)).fetchall():
        outcome["demoted"].append(row["uid"])
    return outcome


def cmd_consolidate(args):
    conn = connect()
    outcome = compute_consolidate(conn)
    conn.close()
    report = dict(outcome)
    report["dry_run"] = bool(args.dry_run)
    if not args.dry_run and (outcome["merged"] or outcome["contradictions"]
                             or outcome["demoted"]):
        outcome["ts"] = now_iso()
        write_event("consolidate", outcome)
    print(json.dumps(report))


# ----------------------------------------------------- get/search/etc.

def cmd_get(args):
    conn = connect()
    rid = local_id(conn, args.id)
    if rid is None:
        raise SystemExit("get: no record {}".format(args.id))
    row = conn.execute("SELECT * FROM records WHERE id=?", (rid,)).fetchone()
    conn.close()
    print(json.dumps(row_to_dict(row), sort_keys=True))


def snip(text, maxlen=160):
    s = re.sub(r"\s+", " ", (text or "").strip())
    return s if len(s) <= maxlen else s[:maxlen].rstrip() + "..."


def cmd_search(args):
    conn = connect()
    # bm25 column weights: subject 5x, body/rationale 1x, fulltext 0.5x
    sql = ("SELECT r.*, bm25(records_fts, 5.0, 1.0, 1.0, 0.5) AS rank "
           "FROM records_fts JOIN records r ON r.id = records_fts.rowid "
           "WHERE records_fts MATCH ?")
    params = [fts_query(args.query)]
    for field in ("project", "part", "kind", "status"):
        val = getattr(args, field)
        if val:
            sql += " AND r.{}=?".format(field)
            params.append(val)
    sql += " ORDER BY rank LIMIT ?"
    params.append(args.limit)
    for row in conn.execute(sql, params):
        if args.full:
            print(json.dumps(row_to_dict(row), sort_keys=True))
            continue
        # Two-mode flow: default output is a scannable summary line.
        # Expand a promising hit with `get <uid>` (or rerun with --full).
        d = row_to_dict(row)
        out = {"uid": d["uid"], "id": d["id"], "kind": d["kind"],
               "project": d["project"], "part": d["part"],
               "status": d["status"], "subject": d["subject"],
               "summary": snip(d["body"])}
        if d.get("rationale"):
            out["why"] = snip(d["rationale"], 100)
        print(json.dumps(out, sort_keys=True))
    conn.close()


# ------------------------------------------------------- handoff render

def yaml_scalar(value):
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    s = str(value)
    ambiguous = (re.match(r"^-?\d", s)
                 or s.lower() in ("true", "false", "null", "yes", "no",
                                  "on", "off", "~", ""))
    if (not ambiguous
            and re.match(r"^[A-Za-z0-9][A-Za-z0-9 _./()-]*$", s)
            and not s.endswith(" ")):
        return s
    return json.dumps(s)


def yaml_dump(value, indent=0):
    pad = "  " * indent
    lines = []
    if isinstance(value, dict):
        for k, v in value.items():
            if isinstance(v, (dict, list)) and v:
                lines.append("{}{}:".format(pad, k))
                lines.extend(yaml_dump(v, indent + 1))
            elif isinstance(v, (dict, list)):
                lines.append("{}{}: {}".format(pad, k, "{}" if isinstance(v, dict) else "[]"))
            else:
                lines.append("{}{}: {}".format(pad, k, yaml_scalar(v)))
    elif isinstance(value, list):
        for item in value:
            if isinstance(item, dict):
                first = True
                for k, v in item.items():
                    prefix = "{}- ".format(pad) if first else "{}  ".format(pad)
                    if isinstance(v, (dict, list)) and v:
                        lines.append("{}{}:".format(prefix, k))
                        lines.extend(yaml_dump(v, indent + 2))
                    else:
                        lines.append("{}{}: {}".format(prefix, k, yaml_scalar(v)))
                    first = False
            elif isinstance(item, list):
                lines.append("{}-".format(pad))
                lines.extend(yaml_dump(item, indent + 1))
            else:
                lines.append("{}- {}".format(pad, yaml_scalar(item)))
    return lines


HANDOFF_KEY_ORDER = ["date", "project", "part", "task", "achievement",
                     "decisions_with_rationale", "current_state", "blockers",
                     "next_steps"]


def cmd_render_handoff(args):
    conn = connect()
    rid = local_id(conn, args.episode_id)
    row = None
    if rid is not None:
        row = conn.execute(
            "SELECT * FROM records WHERE id=? AND kind='episode'",
            (rid,)).fetchone()
    if row is None:
        raise SystemExit("render-handoff: no episode {}".format(args.episode_id))
    doc = json.loads(row["payload"])
    doc.pop("_transcript", None)
    doc.setdefault("date", row["created_at"][:10])
    doc.setdefault("project", row["project"])
    doc.setdefault("part", row["part"])
    doc.setdefault("task", row["subject"])
    conn.close()
    ordered = {k: doc[k] for k in HANDOFF_KEY_ORDER if k in doc}
    ordered.update({k: v for k, v in doc.items() if k not in ordered})
    text = "\n".join(yaml_dump(ordered)) + "\n"
    # Publish-boundary advisory: rendered files may leave the private
    # memory domain. Warn (never block) so the caller can redact first.
    hits = check_text(text)
    if hits:
        print("WARNING: rendered handoff contains private data "
              "({} span(s)); run redact-check before publishing"
              .format(len(hits)), file=sys.stderr)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(text)
        print(json.dumps({"episode_id": rid, "out": args.out}))
    else:
        sys.stdout.write(text)


# -------------------------------------------------------------- digest

def digest_lines(conn, project, part=None, budget=1500):
    def scoped(sql, params):
        if part:
            sql += " AND part=?"
            params.append(part)
        return conn.execute(sql, params).fetchall()

    # Anchors include project 'global': machine-wide constraints must pin
    # in EVERY project's digest, not only their own scope.
    anchors = conn.execute(
        "SELECT * FROM records WHERE project IN (?, 'global') AND "
        "status='open' AND kind IN ('goal','constraint') "
        "ORDER BY kind, project!='global', id", (project,)).fetchall()
    blockers = scoped(
        "SELECT * FROM records WHERE project=? AND kind='blocker' "
        "AND status='open' ORDER BY created_at DESC", [project])
    decisions = scoped(
        "SELECT * FROM records WHERE project=? AND kind='decision' "
        "AND status='open' ORDER BY last_confirmed_at DESC", [project])
    states = scoped(
        "SELECT * FROM records WHERE project=? AND kind='state' "
        "AND status='open' ORDER BY last_confirmed_at DESC", [project])
    episodes = scoped(
        "SELECT * FROM records WHERE project=? AND kind='episode' "
        "ORDER BY created_at DESC LIMIT 3", [project])

    def fmt(row, with_rationale=False):
        line = "- ({}{}) {}".format(row["kind"][0], row["id"], row["body"])
        if with_rationale and row["rationale"]:
            line += " -- why: {}".format(row["rationale"])
        return line

    header = ["# Memory digest: {}{}".format(project, "/" + part if part else "")]
    anchor_sec = ["", "## Goals and constraints (always in force)"] + \
        [fmt(r) for r in anchors] if anchors else []

    sections = []
    if blockers:
        sections.append((["", "## Open blockers"], [fmt(r) for r in blockers]))
    if decisions:
        sections.append((["", "## Live decisions"],
                         [fmt(r, True) for r in decisions]))
    if states:
        sections.append((["", "## Current state"], [fmt(r) for r in states]))
    if episodes:
        sections.append((["", "## Recent episodes"],
                         ["- (e{}) {} ({})".format(r["id"], r["subject"],
                                                   r["created_at"][:10])
                          for r in episodes]))

    fixed = header + anchor_sec
    used = est_tokens("\n".join(fixed))
    out = list(fixed)
    omitted = 0
    trim_reserve = est_tokens("[digest trimmed: 9999 records omitted - use mem search]")
    for head, items in sections:
        head_cost = est_tokens("\n".join(head))
        if used + head_cost + trim_reserve > budget:
            omitted += len(items)
            continue
        added_head = False
        for item in items:
            cost = est_tokens(item) + (head_cost if not added_head else 0)
            if used + cost + trim_reserve > budget:
                omitted += 1
                continue
            if not added_head:
                out.extend(head)
                used += head_cost
                added_head = True
            out.append(item)
            used += est_tokens(item)
    if omitted:
        out.extend(["", "[digest trimmed: {} records omitted - use mem search]"
                    .format(omitted)])
    return out


def cmd_digest(args):
    conn = connect()
    lines = digest_lines(conn, args.project, args.part, args.budget_tokens)
    conn.close()
    print("\n".join(lines))


# -------------------------------------------------------------- export

def cmd_export(args):
    conn = connect()
    with open(args.jsonl, "w", encoding="utf-8") as f:
        for row in conn.execute("SELECT * FROM records ORDER BY id"):
            d = {"table": "records"}
            d.update(row_to_dict(row))
            f.write(json.dumps(d, sort_keys=True) + "\n")
        for row in conn.execute(
                "SELECT * FROM links ORDER BY from_id, to_id, relation"):
            d = {"table": "links"}
            d.update(row_to_dict(row))
            f.write(json.dumps(d, sort_keys=True) + "\n")
    conn.close()
    print(json.dumps({"out": args.jsonl}))


# ----------------------------------------------- rebuild/verify/doctor

def replay(events, target_path):
    """Replay events into a fresh DB at target_path; returns stats."""
    if os.path.exists(target_path):
        os.remove(target_path)
    conn = connect(target_path)
    init_schema(conn)
    pending = []
    applied = 0
    for ev in events:
        try:
            apply_event(conn, ev)
            applied += 1
        except MissingRef:
            pending.append(ev)
    still_missing = []
    for ev in pending:
        try:
            apply_event(conn, ev)
            applied += 1
        except MissingRef as e:
            still_missing.append({"host": ev["host"], "seq": ev["seq"],
                                  "missing": str(e)})
    conn.commit()
    conn.close()
    return {"events": len(events), "applied": applied,
            "unresolved": still_missing}


def normalized_dump(path):
    """Projection content keyed by uid (local ids mapped out) for
    order-independent comparison."""
    conn = connect(path)
    id_to_uid = {r["id"]: r["uid"] for r in
                 conn.execute("SELECT id, uid FROM records")}
    rows = []
    for r in conn.execute("SELECT * FROM records"):
        d = row_to_dict(r)
        d.pop("id")
        d["superseded_by"] = id_to_uid.get(d["superseded_by"])
        d["source_record"] = id_to_uid.get(d["source_record"])
        rows.append(d)
    rows.sort(key=lambda d: (d["uid"] or "", d["created_at"]))
    links = sorted(
        [id_to_uid.get(l["from_id"]), id_to_uid.get(l["to_id"]), l["relation"]]
        for l in conn.execute("SELECT * FROM links"))
    conn.close()
    return json.dumps({"records": rows, "links": links}, sort_keys=True)


def cmd_rebuild(args):
    events = journal.all_events()
    stats = replay(events, db_path() + ".rebuild")
    if stats["unresolved"]:
        os.remove(db_path() + ".rebuild")
        raise SystemExit("rebuild: unresolved references: {}".format(
            json.dumps(stats["unresolved"])))
    if os.path.exists(db_path()):
        os.replace(db_path(), db_path() + ".prev")
    os.replace(db_path() + ".rebuild", db_path())
    conn = connect()
    stats["records"] = conn.execute(
        "SELECT count(*) FROM records").fetchone()[0]
    stats["db"] = db_path()
    conn.close()
    print(json.dumps(stats))


def cmd_verify(args):
    report = {"ok": True, "chains": {}, "projection_match": None,
              "unresolved": []}
    for host in journal.list_hosts():
        ok, err = journal.verify_chain(journal.host_file(host))
        report["chains"][host] = err if err else "ok"
        if not ok:
            report["ok"] = False
    tmp = db_path() + ".verify"
    stats = replay(journal.all_events(), tmp)
    report["unresolved"] = stats["unresolved"]
    if stats["unresolved"]:
        report["ok"] = False
    if os.path.exists(db_path()):
        report["projection_match"] = (normalized_dump(tmp)
                                      == normalized_dump(db_path()))
        if not report["projection_match"]:
            report["ok"] = False
    if os.path.exists(tmp):
        os.remove(tmp)
    print(json.dumps(report))
    if not report["ok"]:
        raise SystemExit(1)


def cmd_doctor(args):
    report = {"ok": True, "checks": {}}

    def check(name, ok, detail):
        report["checks"][name] = {"ok": bool(ok), "detail": detail}
        if not ok:
            report["ok"] = False

    try:
        host = journal.host_id()
        check("host_id", True, host)
    except SystemExit as e:
        check("host_id", False, str(e))
    root = journal.journal_root()
    check("journal_root", os.path.isdir(os.path.join(root, "journal")),
          root)
    for h in journal.list_hosts():
        ok, err = journal.verify_chain(journal.host_file(h))
        check("chain:{}".format(h), ok, err or "ok")
    heads = journal.heads()
    check("heads", True, heads)
    if os.path.exists(db_path()):
        conn = connect()
        version = conn.execute("PRAGMA user_version").fetchone()[0]
        check("schema_version", version == SCHEMA_VERSION, version)
        counts = {r["kind"]: r["n"] for r in conn.execute(
            "SELECT kind, count(*) AS n FROM records GROUP BY kind")}
        check("record_counts", True, counts)
        try:
            conn.execute("BEGIN")
            conn.execute(
                "INSERT INTO records (uid, kind, project, part, subject, "
                "body, status, confidence, created_at, last_confirmed_at) "
                "VALUES ('_doctor:0','state','_doctor','_doctor','probe',"
                "'fts probe','open','confirmed','1970-01-01','1970-01-01')")
            hit = conn.execute(
                "SELECT rowid FROM records_fts WHERE records_fts MATCH "
                "'\"probe\"'").fetchone()
            conn.rollback()
            check("fts_probe", hit is not None, "insert+match+rollback")
        except sqlite3.Error as e:
            conn.rollback()
            check("fts_probe", False, str(e))
        newest = conn.execute(
            "SELECT project, max(created_at) AS ts FROM records "
            "WHERE kind='episode' GROUP BY project").fetchall()
        check("newest_episode", True,
              {r["project"]: r["ts"] for r in newest})
        conn.close()
    else:
        check("db", False, "missing: {} (run: mem rebuild)".format(db_path()))
    print(json.dumps(report))
    if not report["ok"]:
        raise SystemExit(1)


# -------------------------------------------------------- redact-check

def cmd_redact_check(args):
    text = sys.stdin.read() if args.file == "-" \
        else open(args.file, encoding="utf-8").read()
    hits = check_text(text)
    for h in hits:
        print("[{}] chars {}-{}: {}".format(
            h["pattern"], h["start"], h["end"], h["excerpt"]), file=sys.stderr)
    print(json.dumps({"hits": len(hits)}))
    if hits:
        raise SystemExit(2)


# ----------------------------------------------------------------- cli

def build_parser():
    p = argparse.ArgumentParser(prog="mem", description=__doc__)
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("init").set_defaults(func=cmd_init)

    a = sub.add_parser("add")
    a.add_argument("--kind", required=True, choices=[k for k in KINDS if k != "episode"])
    a.add_argument("--project", required=True)
    a.add_argument("--part", required=True)
    a.add_argument("--subject", required=True)
    a.add_argument("--body", required=True)
    a.add_argument("--rationale")
    a.add_argument("--confidence", default="confirmed",
                   choices=["confirmed", "unverified"])
    a.add_argument("--session-id")
    a.set_defaults(func=cmd_add)

    g = sub.add_parser("get")
    g.add_argument("id")
    g.set_defaults(func=cmd_get)

    s = sub.add_parser("search")
    s.add_argument("--query", required=True)
    s.add_argument("--project")
    s.add_argument("--part")
    s.add_argument("--kind", choices=KINDS)
    s.add_argument("--status", choices=["open", "closed", "superseded"])
    s.add_argument("--limit", type=int, default=10)
    s.add_argument("--full", action="store_true",
                   help="emit complete records instead of summary lines")
    s.set_defaults(func=cmd_search)

    sp = sub.add_parser("supersede")
    sp.add_argument("old_id")
    sp.add_argument("--by", required=True)
    sp.set_defaults(func=cmd_supersede)

    c = sub.add_parser("close")
    c.add_argument("id")
    c.set_defaults(func=cmd_close)

    e = sub.add_parser("record-episode")
    e.add_argument("--project", required=True)
    e.add_argument("--part", required=True)
    e.add_argument("--task", required=True)
    e.add_argument("--json", required=True, help="JSON file path or - for stdin")
    e.add_argument("--date", help="ISO date override (default: doc date or today)")
    e.add_argument("--session-id")
    e.add_argument("--transcript",
                   help="session transcript path; stored with sha256 as provenance")
    e.set_defaults(func=cmd_record_episode)

    r = sub.add_parser("render-handoff")
    r.add_argument("episode_id")
    r.add_argument("--out")
    r.set_defaults(func=cmd_render_handoff)

    d = sub.add_parser("digest")
    d.add_argument("--project", required=True)
    d.add_argument("--part")
    d.add_argument("--budget-tokens", type=int, default=1500)
    d.set_defaults(func=cmd_digest)

    x = sub.add_parser("export")
    x.add_argument("--jsonl", required=True)
    x.set_defaults(func=cmd_export)

    k = sub.add_parser("consolidate")
    k.add_argument("--dry-run", action="store_true")
    k.set_defaults(func=cmd_consolidate)

    sub.add_parser("rebuild").set_defaults(func=cmd_rebuild)
    sub.add_parser("verify").set_defaults(func=cmd_verify)
    sub.add_parser("doctor").set_defaults(func=cmd_doctor)

    rc = sub.add_parser("redact-check")
    rc.add_argument("file", help="file path or - for stdin")
    rc.set_defaults(func=cmd_redact_check)
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()

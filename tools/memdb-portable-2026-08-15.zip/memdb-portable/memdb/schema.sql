-- Memory DB layer: single-table memory with kind attribute.
-- Schema version is tracked in PRAGMA user_version (set by mem.py init).

CREATE TABLE IF NOT EXISTS records (
    id INTEGER PRIMARY KEY,
    uid TEXT UNIQUE,   -- stable cross-host identity: "<host>:<seq>[/<n>]"
    kind TEXT NOT NULL CHECK (kind IN
        ('episode','decision','blocker','state','preference','goal','constraint')),
    project TEXT NOT NULL,
    part TEXT NOT NULL,
    subject TEXT NOT NULL,
    body TEXT NOT NULL,
    rationale TEXT,
    status TEXT NOT NULL DEFAULT 'open' CHECK (status IN
        ('open','closed','superseded')),
    confidence TEXT NOT NULL DEFAULT 'confirmed' CHECK (confidence IN
        ('confirmed','unverified')),
    created_at TEXT NOT NULL,
    last_confirmed_at TEXT NOT NULL,
    superseded_by INTEGER REFERENCES records(id),
    source_record INTEGER REFERENCES records(id),
    session_id TEXT,
    payload TEXT,
    fulltext TEXT      -- searchable raw text (episodes); never rendered in digests
);

CREATE INDEX IF NOT EXISTS idx_records_scope
    ON records (project, part, kind, status);
CREATE INDEX IF NOT EXISTS idx_records_subject
    ON records (project, kind, subject);

CREATE TABLE IF NOT EXISTS links (
    from_id INTEGER NOT NULL REFERENCES records(id),
    to_id INTEGER NOT NULL REFERENCES records(id),
    relation TEXT NOT NULL CHECK (relation IN
        ('relates','contradicts','supersedes')),
    PRIMARY KEY (from_id, to_id, relation)
);

CREATE VIRTUAL TABLE IF NOT EXISTS records_fts USING fts5(
    subject, body, rationale, fulltext,
    content='records', content_rowid='id'
);

CREATE TRIGGER IF NOT EXISTS records_ai AFTER INSERT ON records BEGIN
    INSERT INTO records_fts(rowid, subject, body, rationale, fulltext)
    VALUES (new.id, new.subject, new.body, coalesce(new.rationale, ''),
            coalesce(new.fulltext, ''));
END;

CREATE TRIGGER IF NOT EXISTS records_ad AFTER DELETE ON records BEGIN
    INSERT INTO records_fts(records_fts, rowid, subject, body, rationale, fulltext)
    VALUES ('delete', old.id, old.subject, old.body,
            coalesce(old.rationale, ''), coalesce(old.fulltext, ''));
END;

CREATE TRIGGER IF NOT EXISTS records_au AFTER UPDATE ON records BEGIN
    INSERT INTO records_fts(records_fts, rowid, subject, body, rationale, fulltext)
    VALUES ('delete', old.id, old.subject, old.body,
            coalesce(old.rationale, ''), coalesce(old.fulltext, ''));
    INSERT INTO records_fts(rowid, subject, body, rationale, fulltext)
    VALUES (new.id, new.subject, new.body, coalesce(new.rationale, ''),
            coalesce(new.fulltext, ''));
END;

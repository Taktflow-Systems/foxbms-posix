import json
import os
import sys

import pytest

MEMDB_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, MEMDB_DIR)

import mem  # noqa: E402


@pytest.fixture
def db(tmp_path, monkeypatch):
    """Fresh initialized DB + journal root + host identity; returns DB path."""
    path = str(tmp_path / "mem.db")
    monkeypatch.setenv("MEMDB_PATH", path)
    monkeypatch.setenv("MEMDB_JOURNAL", str(tmp_path / "journal-root"))
    monkeypatch.setenv("MEMDB_HOST", "testhost")
    mem.main(["init"])
    return path


@pytest.fixture
def run(capsys):
    """Run a mem CLI command, return parsed JSON lines from stdout."""
    def _run(argv):
        mem.main(argv)
        out = capsys.readouterr().out.strip()
        if not out:
            return []
        return [json.loads(line) for line in out.splitlines()]
    return _run


@pytest.fixture
def run_text(capsys):
    """Run a mem CLI command, return raw stdout text."""
    def _run(argv):
        mem.main(argv)
        return capsys.readouterr().out
    return _run

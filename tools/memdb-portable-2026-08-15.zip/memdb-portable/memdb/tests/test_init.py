import sqlite3

import mem


def test_fresh_init_creates_schema(db):
    conn = sqlite3.connect(db)
    tables = {r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type IN ('table','view')")}
    assert "records" in tables
    assert "links" in tables
    assert "records_fts" in tables
    assert conn.execute("PRAGMA user_version").fetchone()[0] == mem.SCHEMA_VERSION


def test_reinit_is_noop(db, run):
    out1 = run(["init"])
    out2 = run(["init"])
    assert out1 == out2 == [{"db": db, "schema_version": mem.SCHEMA_VERSION}]


def test_fts_triggers_sync(db):
    conn = mem.connect(db)
    ts = mem.now_iso()
    conn.execute(
        "INSERT INTO records (kind, project, part, subject, body, status, "
        "confidence, created_at, last_confirmed_at) "
        "VALUES ('state','p1','core','perf-note','widget runs fast',"
        "'open','confirmed',?,?)", (ts, ts))
    conn.commit()

    hit = conn.execute("SELECT rowid FROM records_fts WHERE records_fts "
                       "MATCH 'widget'").fetchall()
    assert len(hit) == 1

    conn.execute("UPDATE records SET body='gadget runs slow' WHERE id=?",
                 (hit[0][0],))
    conn.commit()
    assert conn.execute("SELECT count(*) FROM records_fts WHERE records_fts "
                        "MATCH 'gadget'").fetchone()[0] == 1
    assert conn.execute("SELECT count(*) FROM records_fts WHERE records_fts "
                        "MATCH 'widget'").fetchone()[0] == 0

    conn.execute("DELETE FROM records WHERE id=?", (hit[0][0],))
    conn.commit()
    assert conn.execute("SELECT count(*) FROM records_fts WHERE records_fts "
                        "MATCH 'gadget'").fetchone()[0] == 0

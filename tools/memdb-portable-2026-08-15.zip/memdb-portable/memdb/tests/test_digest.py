import mem


def seed(run, n_state=0):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship-v1", "--body", "ship v1 with passing gate A3"])
    run(["add", "--kind", "constraint", "--project", "p1", "--part", "core",
         "--subject", "no-heap", "--body", "no dynamic allocation in firmware"])
    run(["add", "--kind", "blocker", "--project", "p1", "--part", "core",
         "--subject", "hil-rig", "--body", "hil rig offline"])
    run(["add", "--kind", "decision", "--project", "p1", "--part", "core",
         "--subject", "storage", "--body", "use sqlite",
         "--rationale", "stdlib only"])
    for i in range(n_state):
        run(["add", "--kind", "state", "--project", "p1", "--part", "core",
             "--subject", "channel-{}".format(i),
             "--body", "channel {} calibrated with offset table revision {} "
                       "applied and verified against the reference "
                       "bench".format(i, i)])


def test_digest_contains_all_sections(db, run, run_text):
    seed(run, n_state=3)
    text = run_text(["digest", "--project", "p1"])
    assert "Goals and constraints" in text
    assert "ship v1" in text
    assert "no dynamic allocation" in text
    assert "hil rig offline" in text
    assert "use sqlite -- why: stdlib only" in text
    assert "channel 0 calibrated" in text


def test_budget_respected_and_anchors_survive(db, run, run_text):
    seed(run, n_state=500)
    budget = 400
    text = run_text(["digest", "--project", "p1",
                     "--budget-tokens", str(budget)])
    assert mem.est_tokens(text) <= budget
    # anchors never trimmed
    assert "ship v1" in text
    assert "no dynamic allocation" in text
    # trim notice present, no silent truncation
    assert "digest trimmed:" in text
    assert "use mem search" in text


def test_untrimmed_digest_has_no_notice(db, run, run_text):
    seed(run, n_state=2)
    text = run_text(["digest", "--project", "p1"])
    assert "digest trimmed" not in text


def test_empty_scope_digest_is_valid(db, run_text):
    text = run_text(["digest", "--project", "nothing-here"])
    assert text.startswith("# Memory digest: nothing-here")


def test_superseded_and_closed_rows_excluded(db, run, run_text):
    seed(run)
    run(["add", "--kind", "decision", "--project", "p1", "--part", "core",
         "--subject", "storage", "--body", "use postgres",
         "--rationale", "changed mind"])
    blocker_id = None
    import json
    for line in run(["search", "--query", "hil rig", "--kind", "blocker"]):
        blocker_id = line["id"]
    run(["close", str(blocker_id)])

    text = run_text(["digest", "--project", "p1"])
    assert "use postgres" in text
    assert "use sqlite" not in text  # superseded
    assert "hil rig offline" not in text  # closed

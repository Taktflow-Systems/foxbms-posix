import json

import yaml  # test-only dependency; runtime code stays stdlib

import mem

EPISODE_1 = {
    "date": "2026-08-01",
    "achievement": ["created negotiation workspace"],
    "decisions_with_rationale": [
        {"decision": "keep live negotiation outside frozen contract baseline",
         "rationale": "preserves authority boundary"},
        {"decision": "use yaml for episode records",
         "rationale": "human auditable"},
    ],
    "current_state": {
        "summary": "negotiation workspace exists and is usable",
        "files_touched": ["notes/negotiation.md"],
        "status": ["contract baseline unchanged"],
    },
    "blockers": ["draft schema does not match official matrix"],
    "next_steps": ["expand routing to normative rows"],
}

EPISODE_2 = {
    "date": "2026-08-05",
    "achievement": [
        "fixed: draft schema does not match official matrix"],
    "decisions_with_rationale": [],
    "current_state": {"summary": "schema aligned", "files_touched": [],
                      "status": []},
    "blockers": [],
    "next_steps": [],
}


def record(run, tmp_path, doc, task):
    p = tmp_path / (task + ".json")
    p.write_text(json.dumps(doc))
    return run(["record-episode", "--project", "p1", "--part", "core",
                "--task", task, "--json", str(p)])[0]


def test_episode_ingest_extracts_children(db, run, tmp_path):
    out = record(run, tmp_path, EPISODE_1, "bootstrap")
    assert out["children"] == {"decision": 2, "blocker": 1, "state": 1}
    assert out["closed_blockers"] == []

    conn = mem.connect(db)
    ep = conn.execute("SELECT * FROM records WHERE id=?",
                      (out["episode_id"],)).fetchone()
    assert ep["kind"] == "episode"
    assert ep["created_at"].startswith("2026-08-01")
    assert json.loads(ep["payload"]) == EPISODE_1

    kids = conn.execute("SELECT kind, count(*) FROM records WHERE "
                        "source_record=? GROUP BY kind",
                        (out["episode_id"],)).fetchall()
    assert dict(kids) == {"decision": 2, "blocker": 1, "state": 1}


def test_blocker_closed_by_later_episode(db, run, tmp_path):
    record(run, tmp_path, EPISODE_1, "bootstrap")
    out2 = record(run, tmp_path, EPISODE_2, "schema-fix")
    assert len(out2["closed_blockers"]) == 1

    conn = mem.connect(db)
    blk = conn.execute("SELECT * FROM records WHERE kind='blocker'").fetchone()
    assert blk["status"] == "closed"


def test_render_handoff_round_trip(db, run, run_text, tmp_path):
    out = record(run, tmp_path, EPISODE_1, "bootstrap")
    text = run_text(["render-handoff", str(out["episode_id"])])
    doc = yaml.safe_load(text)

    for key in ["date", "project", "part", "task", "achievement",
                "decisions_with_rationale", "current_state", "blockers",
                "next_steps"]:
        assert key in doc, "missing handoff key: " + key
    assert doc["project"] == "p1"
    assert doc["part"] == "core"
    assert doc["task"] == "bootstrap"
    for key in EPISODE_1:
        assert doc[key] == EPISODE_1[key], "round-trip mismatch on " + key


def test_render_handoff_to_file(db, run, tmp_path):
    out = record(run, tmp_path, EPISODE_1, "bootstrap")
    dest = tmp_path / "handoff.yaml"
    run(["render-handoff", str(out["episode_id"]), "--out", str(dest)])
    assert yaml.safe_load(dest.read_text())["task"] == "bootstrap"

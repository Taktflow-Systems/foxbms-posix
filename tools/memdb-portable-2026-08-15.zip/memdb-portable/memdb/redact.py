"""Private-data detection for memory writes.

Pattern classes follow the global never-commit-private-data rule:
private IP ranges, emails, home-directory paths, 24-hex hardware
serials, 64-hex hashes. check_text() reports hits; redact_text()
replaces hits with angle-bracket placeholders (used only by callers
that operate in explicit redact mode, e.g. the benchmark importer).
"""
import re

PATTERNS = [
    ("private-ip", re.compile(
        r"(?<![\d.])(?:192\.168|10(?:\.\d{1,3})|172\.(?:1[6-9]|2\d|3[01]))"
        r"\.\d{1,3}\.\d{1,3}(?![\d.])")),
    ("email", re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")),
    ("home-path", re.compile(
        r"(?:/home/[A-Za-z_][A-Za-z0-9_-]*|[A-Za-z]:\\Users\\[A-Za-z0-9_.-]+|H:\\)")),
    ("hex-serial-24", re.compile(r"\b[0-9a-fA-F]{24}\b")),
    ("hex-hash-64", re.compile(r"\b[0-9a-fA-F]{64}\b")),
]

PLACEHOLDERS = {
    "private-ip": "<private-ip>",
    "email": "<email>",
    "home-path": "<home-path>",
    "hex-serial-24": "<hw-serial>",
    "hex-hash-64": "<build-sha256>",
}


def check_text(text):
    """Return a list of {pattern, start, end, excerpt} hits in text."""
    hits = []
    for name, rx in PATTERNS:
        for m in rx.finditer(text):
            hits.append({
                "pattern": name,
                "start": m.start(),
                "end": m.end(),
                "excerpt": m.group(0),
            })
    hits.sort(key=lambda h: h["start"])
    return hits


def redact_text(text):
    """Return (redacted_text, hits). Hits describe the original text."""
    hits = check_text(text)
    for name, rx in PATTERNS:
        text = rx.sub(PLACEHOLDERS[name], text)
    return text, hits

#!/usr/bin/env bash
# memdb sync: replicate this host's journal to the hub and ingest every
# other host's journal, then canonically rebuild and verify.
#
# Design (lossless by construction):
#  - the journal repo has ONE branch per host: <host>/journal; each host
#    commits ONLY its own journal/<host>/ files (multi-host rules H1-H3)
#  - other hosts' journals are read from origin refs, never merged
#  - after ingest: `mem rebuild` (canonical replay) + `mem verify`
#    (hash chains + projection match) - sync FAILS LOUDLY, never silently
#
# Exit 0 only when push, fetch, rebuild, and verify all succeeded.
set -u

ROOT="${MEMDB_JOURNAL:-$HOME/.claude/memory/journal}"
MEMDB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="${MEMDB_PYTHON:-python3}"
FAIL=0

HOST="${MEMDB_HOST:-}"
[ -n "$HOST" ] || HOST="$(cat "$HOME/.claude/memory/host-id" 2>/dev/null || true)"
if [ -z "$HOST" ]; then
    echo "memdb-sync: FAIL no host identity (MEMDB_HOST or ~/.claude/memory/host-id)"
    exit 1
fi

cd "$ROOT" 2>/dev/null || { echo "memdb-sync: FAIL no journal root $ROOT"; exit 1; }
[ -d .git ] || { echo "memdb-sync: FAIL journal root is not a git repo"; exit 1; }

# 1. commit own journal on own branch
git checkout -q "$HOST/journal" 2>/dev/null || git checkout -qb "$HOST/journal"
git add "journal/$HOST" 2>/dev/null
if ! git diff --cached --quiet 2>/dev/null; then
    git commit -qm "$HOST: journal sync" || { echo "memdb-sync: commit failed"; FAIL=1; }
fi

# 2. push own branch to the hub
if git remote get-url origin >/dev/null 2>&1; then
    git push -q origin "$HOST/journal" || { echo "memdb-sync: push failed"; FAIL=1; }
    # 3. fetch and materialize every other host's journal from origin refs
    git fetch -qp origin || { echo "memdb-sync: fetch failed"; FAIL=1; }
    for ref in $(git for-each-ref --format='%(refname:short)' \
                 'refs/remotes/origin/*/journal'); do
        h="${ref#origin/}"; h="${h%/journal}"
        [ "$h" = "$HOST" ] && continue
        mkdir -p "journal/$h"
        if ! git show "$ref:journal/$h/events.jsonl" \
                > "journal/$h/events.jsonl.tmp" 2>/dev/null; then
            rm -f "journal/$h/events.jsonl.tmp"
            continue
        fi
        mv "journal/$h/events.jsonl.tmp" "journal/$h/events.jsonl"
    done
else
    echo "memdb-sync: no origin remote configured"; FAIL=1
fi

# 4. canonical rebuild + verify (loud on any loss signal)
"$PY" "$MEMDB_DIR/mem.py" rebuild >/dev/null || { echo "memdb-sync: rebuild failed"; FAIL=1; }
"$PY" "$MEMDB_DIR/mem.py" verify || { echo "memdb-sync: VERIFY FAILED"; FAIL=1; }

if [ $FAIL -ne 0 ]; then
    echo "memdb-sync: FAIL (host=$HOST root=$ROOT)"
    exit 1
fi
echo "memdb-sync: ok (host=$HOST)"

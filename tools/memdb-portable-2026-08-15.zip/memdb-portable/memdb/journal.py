"""Append-only, hash-chained per-host event journal - the system of record.

The SQLite DB is a derived projection: `mem rebuild` reproduces it from
journals alone, so the DB is disposable on every machine. Journal files
live at <journal-root>/journal/<host>/events.jsonl and replicate between
machines via git (one branch per host, per multi-host rules H1-H3).

Events are immutable. Every state change is a new event. Each event
carries (host, seq) - a per-host monotonic counter, no wall-clock
dependency - and `prev`, the SHA-256 of the previous event's canonical
line on the same host. Truncation, reordering, or mutation of a journal
is therefore mechanically detectable (see verify_chain).

Canonical total order across hosts is (ts, host, seq). Replay in that
order is the definition of truth; `mem verify` compares the live DB to a
canonical rebuild.
"""
import hashlib
import json
import os

DEFAULT_ROOT = os.path.join(os.path.expanduser("~"), ".claude", "memory",
                            "journal")
HOST_ID_FILE = os.path.join(os.path.expanduser("~"), ".claude", "memory",
                            "host-id")


def journal_root():
    return os.environ.get("MEMDB_JOURNAL", DEFAULT_ROOT)


def host_id():
    h = os.environ.get("MEMDB_HOST")
    if h:
        return h.strip()
    if os.path.exists(HOST_ID_FILE):
        with open(HOST_ID_FILE, encoding="utf-8") as f:
            h = f.read().strip()
        if h:
            return h
    raise SystemExit(
        "memdb: host identity unset - set MEMDB_HOST or write a slug to "
        + HOST_ID_FILE)


def host_file(host, root=None):
    return os.path.join(root or journal_root(), "journal", host,
                        "events.jsonl")


def list_hosts(root=None):
    jdir = os.path.join(root or journal_root(), "journal")
    if not os.path.isdir(jdir):
        return []
    return sorted(h for h in os.listdir(jdir)
                  if os.path.isfile(host_file(h, root)))


def canonical_line(ev):
    return json.dumps(ev, sort_keys=True, separators=(",", ":"))


def line_hash(line):
    return hashlib.sha256(line.encode("utf-8")).hexdigest()


def read_events(path):
    """Return [(event_dict, raw_line), ...] for one host file."""
    out = []
    if not os.path.exists(path):
        return out
    with open(path, encoding="utf-8") as f:
        for ln in f:
            ln = ln.strip("\r\n")
            if ln:
                out.append((json.loads(ln), ln))
    return out


def verify_chain(path):
    """Return (ok, error_message_or_None) for one host journal file."""
    prev = None
    last_seq = 0
    for ev, line in read_events(path):
        if ev.get("seq") != last_seq + 1:
            return False, "seq gap: expected {} got {}".format(
                last_seq + 1, ev.get("seq"))
        if ev.get("prev") != prev:
            return False, "hash chain break at seq {}".format(ev.get("seq"))
        prev = line_hash(line)
        last_seq = ev["seq"]
    return True, None


def append_event(host, etype, payload, ts, root=None):
    """Append one event to this host's journal; returns the event dict."""
    path = host_file(host, root)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    events = read_events(path)
    if events:
        prev = line_hash(events[-1][1])
        seq = events[-1][0]["seq"] + 1
    else:
        prev, seq = None, 1
    ev = {"v": 1, "host": host, "seq": seq, "ts": ts, "type": etype,
          "prev": prev, "payload": payload}
    line = canonical_line(ev)
    with open(path, "a", encoding="utf-8", newline="\n") as f:
        f.write(line + "\n")
        f.flush()
        os.fsync(f.fileno())
    return ev


def all_events(root=None):
    """All hosts' events in canonical order (ts, host, seq)."""
    evs = []
    for host in list_hosts(root):
        evs.extend(ev for ev, _ in read_events(host_file(host, root)))
    evs.sort(key=lambda e: (e["ts"], e["host"], e["seq"]))
    return evs


def heads(root=None):
    """{host: {seq, ts, hash}} for every host journal present."""
    out = {}
    for host in list_hosts(root):
        events = read_events(host_file(host, root))
        if events:
            ev, line = events[-1]
            out[host] = {"seq": ev["seq"], "ts": ev["ts"],
                         "hash": line_hash(line)}
    return out

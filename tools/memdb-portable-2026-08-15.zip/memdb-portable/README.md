# memdb portable package

Log-first, lossless memory layer for AI agent harnesses (Claude Code,
Codex, or similar). Python 3 stdlib + git + bash; no other dependencies.

- System of record: per-host append-only hash-chained event journals,
  optionally replicated between machines via a git hub (per-host
  branches). SQLite is a rebuildable projection; `mem verify` proves
  nothing was lost or tampered with.
- `install/AGENT_INSTALL.md` - self-install guide written for the AI
  agent on the target system.
- `install/PROMPT.txt` - the short prompt the human pastes to start it.
- `install/memory-persistence-rule.template.md` - the harness rule block
  the installer adapts and places into CLAUDE.md / AGENTS.md.
- `memdb/` - the tool (mem.py, journal.py, redact.py, schema.sql,
  hooks/, sync/, tests/).

Origin: Taktflow memory-orchestration workspace, 2026-08-15. Benchmarked
at 22/22 targets: session-start digest flat at ~1.5k tokens from 60 to
6000 records, recall hit@5 1.0 vs grep 0.1-0.33, verify chain+projection
green, search p50 3.2 ms at 6k records.

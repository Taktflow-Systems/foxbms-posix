# Global End-of-Job Memory Persistence Rule (memdb)

At the end of every completed user job that produces actual work product,
record the job as an episode in the memory database. YAML handoff files
and ad-hoc memory notes are NOT written by default; they are rendered
views generated from the database on explicit request only. This rule is
global and applies across projects unless the user explicitly says not to
record the episode.

## The Memory Layer (log-first)

- The SYSTEM OF RECORD is the per-host append-only, hash-chained event
  journal at `~/.claude/memory/journal/journal/{{HOST_SLUG}}/events.jsonl`.
  The SQLite DB (`MEMDB_PATH`, default `~/.claude/memory/mem.db`) is a
  DISPOSABLE projection - `mem rebuild` reproduces it from journals
  alone; `mem verify` proves chain integrity and projection match. Never
  edit journal files or the DB by hand.
- Tool: `python3 {{MEM_PY}}`. Python 3 stdlib only. Subcommands: `init`,
  `add`, `get`, `search`, `supersede`, `close`, `record-episode`,
  `render-handoff`, `digest`, `export`, `consolidate`, `rebuild`,
  `verify`, `doctor`, `redact-check`.
- Host identity: `~/.claude/memory/host-id` (this machine:
  `{{HOST_SLUG}}`); writes refuse to run without it.
- Records have a stable cross-host uid `<host>:<seq>` (children
  `<host>:<seq>/<n>`); commands accept uid or local integer id.

## End Of Job: Record An Episode

Record after any meaningful task that produced durable output or
workspace change (code, docs, config, analysis with findings). Skip only
pure question-and-answer turns, or when the user says not to record.

1. Write episode JSON to a temp/scratchpad file (NOT the project tree):

```json
{
  "date": "YYYY-MM-DD",
  "achievement": ["what actually got done"],
  "decisions_with_rationale": [{"decision": "...", "rationale": "..."}],
  "current_state": {
    "summary": "...",
    "files_touched": ["paths"],
    "status": ["what is true now vs still pending"]
  },
  "blockers": [],
  "next_steps": ["concrete and short"]
}
```

2. `python3 {{MEM_PY}} record-episode --project <project-slug>
   --part <part-slug> --task <task-slug> --json <episode.json>`
   (optionally `--session-id <id> --transcript <path>` for provenance).
   Slug rules: project = real workspace/repo name; part = narrowest
   meaningful work area (`cross-cutting` if it truly spans several);
   short, stable, filesystem-safe.
3. Mention the printed episode uid in your final response when relevant.
4. Replicate: `bash {{SYNC_SH}}`. If sync fails, report it - the local
   journal still holds the event; never skip recording because sync
   might fail.

## Task Start: Readback

1. `python3 {{MEM_PY}} digest --project <slug> [--part <slug>]` -
   token-budgeted context; open goal/constraint records always pinned.
2. Specific priors: `python3 {{MEM_PY}} search --query "..."
   [--project ...] [--kind ...] [--status open]`.
   Search returns SUMMARY lines (uid, subject, ~160-char snippet, why).
   Scan summaries first; expand only the promising hits with
   `get <uid>` (or rerun with `--full`). Never default to `--full`.
3. When the user states a durable goal/constraint/preference mid-job,
   record it immediately with `add --kind goal|constraint|preference`.
   Close finished items with `close <uid>`; never delete - supersede.

## Privacy Model

Journals and DB are the PRIVATE memory domain (user-owned machines and
user-owned hub). Capture is LOSSLESS - real paths and hostnames are
allowed; do NOT pre-redact memory content. Anything LEAVING the private
domain (files for repos with third-party remotes, published docs) must
pass `python3 {{MEM_PY}} redact-check <file>` and be redacted first.

## Failure Behavior

Broken DB -> `mem rebuild` (always safe). Broken journal/tool -> stop,
report, and write a legacy-format note the user can find, then say the
journal event is missing. `verify`/`doctor` failures are loss signals -
surface them to the user immediately. A broken memory layer must never
silently drop a job record.

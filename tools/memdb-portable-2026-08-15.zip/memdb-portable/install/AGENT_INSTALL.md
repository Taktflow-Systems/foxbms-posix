# memdb Self-Install Guide (for the AI agent on the target system)

You are an AI agent (Claude Code, Codex, or similar) on a NEW system. The
user has unzipped this package and asked you to install memdb - a
log-first, lossless memory layer for agent harnesses. Follow these steps
exactly. Where a step needs a value only the user can provide, use the
values from the user's install prompt; if one is missing, ASK - never
guess.

## What you are installing (context)

memdb replaces end-of-job "handoff files" and ad-hoc memory notes with:
- an append-only, hash-chained per-host EVENT JOURNAL as the system of
  record (`~/.claude/memory/journal/journal/<host>/events.jsonl`);
- a SQLite projection (`~/.claude/memory/mem.db`) that `mem rebuild`
  reproduces from journals alone - the DB is disposable;
- `mem verify` proving chain integrity + projection match (loss is
  detectable, never silent);
- optional multi-machine sync through a git hub (per-host branches);
- a global rule block for the harness so agents record an episode at the
  end of every job and read memory (`digest`/`search`) at task start.

Records get stable uids `<host>:<seq>` (children `<host>:<seq>/<n>`).
Memory content is FULL-FIDELITY (private domain); redaction applies only
to artifacts leaving the private domain (`mem redact-check`).

## Parameters (from the user's prompt)

- HOST_SLUG: one short word identifying this machine (e.g. workstation,
  laptop, office-pc). The HUMAN chooses it. Never invent one.
- HUB: one of
  - `join <ssh-spec>` - an existing hub (bare repos `memdb.git` and
    `memory-journal.git` already exist there),
  - `new <ssh-spec>` - create bare repos on that SSH host,
  - `standalone` - no sync; local journal only (can be joined later).
- CLEANUP: `yes` or `no` - whether you may replace existing legacy
  memory/handoff rules in the system's global agent instructions.

## Install steps

1. **Preflight.** Verify `python3 --version` (3.8+), `git --version`,
   and a bash (on Windows: Git Bash). Report versions.
2. **Place the tree.** Move/copy the unzipped `memdb/` directory to
   `~/memdb/memdb` (i.e. repo-style root `~/memdb`), unless the user
   named another location. Nothing else in this package needs to be on
   the target path.
3. **Prove the tool works BEFORE wiring anything** (gates-proven rule):
   `cd ~/memdb/memdb && python3 -m pytest tests/ -q` - all tests must
   pass. If pytest is unavailable: `pip install --user pytest` (its only
   dependency; mem.py itself is stdlib-only). Do not continue on red.
4. **Identity.** Write HOST_SLUG (exactly, no newline padding) to
   `~/.claude/memory/host-id` (create directories).
5. **Journal repo.** `mkdir -p ~/.claude/memory/journal && cd
   ~/.claude/memory/journal && git init -b <HOST_SLUG>/journal`.
   If HUB is not standalone:
   - `new`: first run `ssh <hub-host> "mkdir -p ~/git && git init --bare
     -b main ~/git/memdb.git && git init --bare -b main
     ~/git/memory-journal.git"`.
   - both: `git remote add origin <ssh-spec>:git/memory-journal.git`.
   - If this repo will be pushed from multiple machines later, also set
     `git config --local agent.host-id <HOST_SLUG>`.
6. **Init + health.** `python3 ~/memdb/memdb/mem.py init` then
   `python3 ~/memdb/memdb/mem.py doctor` - doctor must exit 0 (it will
   note zero records; that is healthy).
7. **First sync (skip if standalone).**
   `bash ~/memdb/memdb/sync/memdb_sync.sh`.
   KNOWN QUIRK: on a fresh host the FIRST sync fails its push leg with an
   unborn-branch error because `<HOST_SLUG>/journal` has no commit until
   the first event exists. That is expected; it self-heals at step 9.
   If joining an existing hub, this sync already pulls every other
   host's journal and rebuilds the full shared memory - verify with
   `python3 ~/memdb/memdb/mem.py search --query "memory" --limit 3`.
8. **Install the rule block.** Open
   `install/memory-persistence-rule.template.md` from this package and
   replace the placeholders: `{{MEM_PY}}` -> absolute path of mem.py,
   `{{SYNC_SH}}` -> absolute path of memdb_sync.sh (or the literal text
   `(standalone - no sync step)` if no hub), `{{HOST_SLUG}}` -> the slug.
   Then place it into the system's global agent instructions:
   - Claude Code: `~/.claude/CLAUDE.md`
   - Codex: `~/.codex/AGENTS.md` or a file it includes
   - If CLEANUP=yes and those files contain a legacy end-of-job handoff
     rule, memory rule, or an older memory-persistence block: COPY the
     original file to `~/.claude/memory/install-backups/<date>-<name>.bak`
     first, then replace ONLY the legacy rule section with the adapted
     template, preserving everything else byte-for-byte. List every
     replaced section in your final report.
   - If CLEANUP=no or nothing legacy exists: append the block (or write
     it as a new rules file the instructions include) and report any
     legacy rules you found WITHOUT touching them.
9. **Record the install episode.** Build an episode JSON (shape is
   documented inside the rule block) describing this installation, then:
   `python3 ~/memdb/memdb/mem.py record-episode --project memdb
   --part install --task install-<HOST_SLUG> --json <file>` and, if not
   standalone, run the sync script - it must now print
   `memdb-sync: ok (host=<HOST_SLUG>)`.
10. **Final verification.** `python3 ~/memdb/memdb/mem.py verify` must
    print `"ok": true`. Optional per-project digest injection: paste the
    SessionStart snippet from `memdb/hooks/README.md` into a project's
    `.claude/settings.json`.

## Safety rules (binding)

- Never delete or overwrite user files: back up, then modify; report
  every changed path.
- Never guess HOST_SLUG or the hub URL; ask.
- Memory content is private-domain: never commit journals or the DB to
  any third-party remote, and never point origin at one without the
  user's explicit say-so.
- If any step fails, stop, report the exact error, and leave the system
  in the state it was in - a half-install must be visible, not hidden.

## Final report checklist

Report to the user: tool path; pytest result; HOST_SLUG; hub mode and
remote; doctor output; first-sync outcome (including the expected
unborn-branch note); rule files changed with backup paths; install
episode uid; verify output.

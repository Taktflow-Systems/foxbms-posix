#!/usr/bin/env python3
"""Fixture tests for progress_state.py (hook state writer) and progress_statusline.py (renderer).

Run:  python ~/.claude/hooks/tests/test_progress.py
Each case pipes a hook payload into the writer with HOME pointed at a temp dir, then checks
the state file and the rendered status line. Nothing here touches the real ~/.claude/progress.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time

HOOKS = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WRITER = os.path.join(HOOKS, "progress_state.py")
RENDER = os.path.join(HOOKS, "progress_statusline.py")
WATCH = os.path.join(HOOKS, "progress_watch.py")
SESSION = "test-session-0001"
TMP = tempfile.mkdtemp(prefix="progress-test-")
SCRATCH = os.path.join(TMP, "proj", SESSION, "scratchpad")
TASKS = os.path.join(TMP, "proj", SESSION, "tasks")
STATE = os.path.join(TMP, ".claude", "progress", SESSION + ".json")
ENV = dict(os.environ, HOME=TMP, USERPROFILE=TMP, PROGRESS_ASCII="1")
ENV.pop("PROGRESS_TRACE", None)

results = []


def check(name, ok, detail=""):
    results.append((bool(ok), name, detail))


def run(script, payload, env=None):
    text = payload if isinstance(payload, str) else json.dumps(payload)
    p = subprocess.run([sys.executable, script], input=text, capture_output=True, text=True,
                       env=env or ENV, encoding="utf-8")
    return p.returncode, p.stdout, p.stderr


def hook(event, **fields):
    payload = {"session_id": SESSION, "hook_event_name": event, "scratchpad_dir": SCRATCH,
               "cwd": TMP, "transcript_path": os.path.join(TMP, "t.jsonl")}
    payload.update(fields)
    code, out, err = run(WRITER, payload)
    check(f"{event}: exit 0, silent stdout", code == 0 and out == "", f"code={code} out={out!r} err={err!r}")
    return state()


def state():
    try:
        with open(STATE, encoding="utf-8") as fh:
            return json.load(fh)
    except OSError:
        return None


def render(session_state_id=SESSION, **status):
    payload = {"session_id": session_state_id, "model": {"display_name": "Fable"},
               "context_window": {"used_percentage": 42.0}, "cost": {"total_cost_usd": 1.5, "total_duration_ms": 65000}}
    payload.update(status)
    code, out, err = run(RENDER, payload)
    check("render: exit 0", code == 0, err)
    return out


def writer_cases():
    os.makedirs(SCRATCH, exist_ok=True)
    os.makedirs(TASKS, exist_ok=True)
    s = hook("UserPromptSubmit", prompt="do things")
    check("prompt: turn active", s and s["turn"]["active"])

    s = hook("PreToolUse", tool_name="Bash", tool_use_id="toolu_1",
             tool_input={"command": "ninja -C build", "description": "Build firmware"})
    check("pre: tool recorded with description label",
          s and s["tools"].get("toolu_1", {}).get("label") == "Build firmware", json.dumps(s))
    s = hook("PreToolUse", tool_name="Read", tool_use_id="toolu_2", tool_input={"file_path": "H:/x/y/main.c"})
    check("pre: read label is basename", s["tools"]["toolu_2"]["label"] == "main.c")
    s = hook("PostToolUse", tool_name="Read", tool_use_id="toolu_2", tool_input={"file_path": "H:/x/y/main.c"},
             tool_response={"type": "text", "text": "..."})
    check("post: read removed, bash kept", "toolu_2" not in s["tools"] and "toolu_1" in s["tools"])
    check("history: finished read remembered ok", s["history"][-1]["tool"] == "Read" and s["history"][-1]["label"] == "main.c"
          and s["history"][-1]["ok"] is True, json.dumps(s["history"]))
    s = hook("PostToolUseFailure", tool_name="Bash", tool_use_id="toolu_1",
             tool_input={"command": "ninja -C build"}, error={"type": "execution_error", "message": "exit 1"})
    check("post failure: tool removed", not s["tools"])
    check("history: failed bash remembered with ok false", s["history"][-1]["tool"] == "Bash" and s["history"][-1]["ok"] is False)

    s = hook("PreToolUse", tool_name="Bash", tool_use_id="toolu_bg",
             tool_input={"command": "make all", "description": "Long build", "run_in_background": True})
    check("pre: background tool flagged bg", s["tools"]["toolu_bg"]["bg"] is True)
    s = hook("PostToolUse", tool_name="Bash", tool_use_id="toolu_bg",
             tool_input={"command": "make all", "description": "Long build", "run_in_background": True},
             tool_response={"type": "text", "text": f"Background task started with PID {os.getpid()}"})
    job = s["jobs"].get("toolu_bg", {})
    check("post bg: job recorded with pid and tasks_dir",
          job.get("pid") == os.getpid() and os.path.normcase(job.get("tasks_dir", "")) == os.path.normcase(TASKS),
          json.dumps(job))
    check("post bg: tool entry cleared", "toolu_bg" not in s["tools"])
    check("history: background job start not remembered as finished", s["history"][-1]["tool"] != "Bash" or s["history"][-1]["label"] != "Long build")
    s = hook("PostToolUse", tool_name="Bash", tool_use_id="toolu_bg2",
             tool_input={"command": "x", "run_in_background": True},
             tool_response={"text": "started PID 4242, output: H:\\tmp\\claude\\p\\s\\tasks\\b1abc.output"})
    check("post bg: explicit output path captured", s["jobs"]["toolu_bg2"]["log"].endswith("b1abc.output"),
          json.dumps(s["jobs"]["toolu_bg2"]))
    s = hook("PostToolUse", tool_name="TaskOutput", tool_use_id="toolu_to",
             tool_input={"task_id": "b1abc"}, tool_response={"text": "done"})
    check("TaskOutput prunes matching job", "toolu_bg2" not in s["jobs"] and "toolu_bg" in s["jobs"])
    s = hook("PostToolUse", tool_name="PowerShell", tool_use_id="toolu_bg3",
             tool_input={"command": "build.ps1", "description": "PS build", "run_in_background": True},
             tool_response={"stdout": "", "stderr": "", "backgroundTaskId": "bg123"})
    job = s["jobs"].get("toolu_bg3", {})
    check("post bg: backgroundTaskId maps to tasks/<id>.output",
          job.get("task_id") == "bg123" and os.path.normcase(job.get("log", "")) == os.path.normcase(os.path.join(TASKS, "bg123.output")),
          json.dumps(job))

    s = hook("SubagentStart", agent_id="agent_a", agent_type="Explore", task="look")
    s = hook("SubagentStart", agent_id="agent_b", agent_type="general-purpose", task="do")
    check("subagent start: two agents", set(s["agents"]) == {"agent_a", "agent_b"})
    s = hook("SubagentStop", agent_id="agent_a", agent_type="Explore", stop_reason="end_turn")
    check("subagent stop: one left", set(s["agents"]) == {"agent_b"})
    check("history: finished agent remembered", s["history"][-1]["tool"] == "Agent" and s["history"][-1]["label"] == "Explore")
    s = hook("SubagentStop", agent_id="unknown")
    check("subagent stop unknown id: pops oldest", not s["agents"])

    for i in range(3):
        s = hook("TaskCreated", task_id=f"task_{i}", task_input={"description": f"step {i}"})
    check("tasks: three open", len(s["tasks"]["open"]) == 3)
    s = hook("TaskCompleted", task_id="task_1", task_result={"status": "completed"})
    check("tasks: one done two open", s["tasks"]["done"] == ["task_1"] and len(s["tasks"]["open"]) == 2)
    s = hook("TaskCreated", task_id="task_1")
    check("tasks: completed id not re-added", len(s["tasks"]["open"]) == 2)
    todos = [{"content": "alpha", "status": "completed"}, {"content": "beta", "status": "in_progress"},
             {"content": "gamma", "status": "pending"}]
    s = hook("PostToolUse", tool_name="TodoWrite", tool_use_id="toolu_todo", tool_input={"todos": todos},
             tool_response={"oldTodos": [], "newTodos": todos})
    check("todowrite: newTodos replace task counts", s["tasks"] == {"open": ["beta", "gamma"], "done": ["alpha"]},
          json.dumps(s["tasks"]))
    s = hook("PreToolUse", tool_name="Grep", tool_use_id="toolu_denied", tool_input={"pattern": "x"})
    s = hook("PermissionDenied", tool_name="Grep", tool_use_id="toolu_denied", tool_input={"pattern": "x"})
    check("permission denied: tool entry removed", "toolu_denied" not in s["tools"])
    s = hook("PreToolUse", tool_name="Grep", tool_use_id="toolu_ghost", tool_input={"pattern": "y"})
    s = hook("PostToolBatch", tool_calls=[{"tool_use_id": "toolu_ghost", "tool_name": "Grep", "tool_input": {},
                                          "tool_response": "PreToolUse:Grep hook error: BLOCKED"},
                                         {"tool_use_id": "toolu_none", "tool_name": "Read", "tool_input": {}}])
    check("post batch (tool_calls): blocked tool ghost removed", "toolu_ghost" not in s["tools"])
    check("history: blocked tool remembered with ok false", s["history"][-1]["tool"] == "Grep" and s["history"][-1]["ok"] is False)
    s = hook("PreToolUse", tool_name="Grep", tool_use_id="toolu_ghost2", tool_input={"pattern": "z"})
    s = hook("PostToolBatch", tool_uses=[{"tool_use_id": "toolu_ghost2", "tool_name": "Grep", "tool_input": {}}])
    check("post batch (tool_uses): ghost removed", "toolu_ghost2" not in s["tools"])

    s = hook("Stop", last_assistant_message="done")
    check("stop without background_tasks: turn inactive, tools cleared, jobs kept",
          not s["turn"]["active"] and not s["tools"] and set(s["jobs"]) == {"toolu_bg", "toolu_bg3"})
    s = hook("Stop", last_assistant_message="done", background_tasks=[{"id": "other"}])
    check("stop with background_tasks: finished task pruned, pid-only job kept",
          set(s["jobs"]) == {"toolu_bg"}, json.dumps(s["jobs"]))
    check("history: pruned job remembered as Job", s["history"][-1]["tool"] == "Job" and s["history"][-1]["label"] == "PS build")
    for i in range(15):
        s = hook("PostToolUse", tool_name="Read", tool_use_id=f"toolu_h{i}", tool_input={"file_path": f"f{i}.c"}, tool_response={})
    check("history: capped at 12 newest", len(s["history"]) == 12 and s["history"][-1]["label"] == "f14.c")
    s = hook("PreToolUse", tool_name="Skill", tool_input={"skill": "build"})
    check("pre without tool_use_id: hashed key", any(k.startswith("Skill:") for k in s["tools"]))

    code, out, err = run(WRITER, "{not json")
    check("bad json: exit 0 silent", code == 0 and out == "", f"{code} {out!r}")
    code, out, err = run(WRITER, {"session_id": SESSION, "hook_event_name": "Bogus"})
    check("unknown event: exit 0 silent, state untouched", code == 0 and out == "" and state() is not None)
    code, out, err = run(WRITER, {"hook_event_name": "PreToolUse", "tool_name": "Bash", "tool_input": {}})
    check("missing session id: exit 0", code == 0 and out == "")

    trace_path = os.path.join(TMP, ".claude", "progress", "trace.jsonl")
    run(WRITER, {"session_id": SESSION, "hook_event_name": "Stop"}, env=dict(ENV, PROGRESS_TRACE="1"))
    check("trace env: raw payload appended", os.path.exists(trace_path))


def renderer_cases():
    out = render()
    check("render: line count is 2", out.count("\n") == 2, repr(out))
    line1, line2 = out.splitlines()[:2]
    check("render line1: model, ctx, cost, duration", all(x in line1 for x in ("Fable", "42%", "$1.50", "1m05s")), line1)
    check("render line2: job shown as spinner without log", "Long build" in line2, line2)
    check("render line2: task bar 1/3", "tasks" in line2 and "1/3" in line2, line2)
    check("render: no ANSI codes leak into ASCII bar", "[" not in line2.replace("\033[", ""), line2)

    log = os.path.join(TASKS, "job1.output")
    with open(log, "w", encoding="utf-8") as fh:
        fh.write("[1/40] compiling a.c\n[12/40] compiling b.c\n")
    line2 = render().splitlines()[1]
    check("render: job percentage from newest tasks log", " 30%" in line2 and "####" in line2, line2)
    with open(log, "a", encoding="utf-8") as fh:
        fh.write("tests: 7 of 10 passed so far\n")
    line2 = render().splitlines()[1]
    check("render: 'n of m' overrides earlier bracket", " 70%" in line2, line2)
    with open(log, "a", encoding="utf-8") as fh:
        fh.write("Progress [ 95%] almost\n")
    line2 = render().splitlines()[1]
    check("render: pytest style percent", " 95%" in line2, line2)
    with open(log, "a", encoding="utf-8") as fh:
        fh.write("no progress on this line\n")
    line2 = render().splitlines()[1]
    check("render: last parseable line wins over trailing noise", " 95%" in line2, line2)

    s = state()
    s["jobs"]["toolu_bg"]["pid"] = 999999
    with open(STATE, "w", encoding="utf-8") as fh:
        json.dump(s, fh)
    line2 = render().splitlines()[1]
    check("render: dead pid hides job", "Long build" not in line2, line2)
    s["jobs"]["toolu_bg"]["pid"] = os.getpid()
    with open(STATE, "w", encoding="utf-8") as fh:
        json.dump(s, fh)
    line2 = render().splitlines()[1]
    check("render: live pid shows job again", "Long build" in line2, line2)
    with open(log, "a", encoding="utf-8") as fh:
        fh.write("\n[exited with code 0]\n")
    line2 = render().splitlines()[1]
    check("render: exit marker in log hides job", "Long build" not in line2, line2)

    hook("UserPromptSubmit", prompt="again")
    hook("PreToolUse", tool_name="Bash", tool_use_id="toolu_9", tool_input={"command": "sleep 5"})
    line2 = render().splitlines()[1]
    check("render: working + running tool", "working" in line2 and "sleep 5" in line2, line2)
    hook("Stop")
    s = state()
    s["tasks"] = {"open": [], "done": []}
    s["jobs"] = {}
    with open(STATE, "w", encoding="utf-8") as fh:
        json.dump(s, fh)
    line2 = render().splitlines()[1]
    check("render: idle when nothing runs", "idle" in line2, line2)
    line2 = render(session_state_id="nope").splitlines()[1]
    check("render: unknown session says no state", "no state" in line2, line2)
    code, out, err = run(RENDER, "{not json")
    check("render: bad stdin still prints 2 lines", code == 0 and out.count("\n") == 2, repr(out))
    env = dict(ENV)
    env.pop("PROGRESS_ASCII")
    code, out, err = run(RENDER, {"session_id": SESSION, "model": {"display_name": "M"}}, env=env)
    check("render: unicode mode exits 0", code == 0, err)

    hook("PreToolUse", tool_name="Bash", tool_use_id="toolu_w", tool_input={"command": "make", "description": "Watch me"},
         transcript_path=os.path.join(TMP, ".claude", "projects", "j--HeroesOlden", SESSION + ".jsonl"))
    p = subprocess.run([sys.executable, WATCH, "--once"], capture_output=True, text=True, env=ENV, encoding="utf-8")
    check("watcher --once: project name label from transcript folder and running tool",
          p.returncode == 0 and "Watch me" in p.stdout and "HeroesOlden" in p.stdout, p.stdout + p.stderr)
    check("watcher --once: three history lines with ago and duration", p.stdout.count(" ago") == 3 and "(0s)" in p.stdout, p.stdout)
    p = subprocess.run([sys.executable, WATCH, "--once", "--history", "0"], capture_output=True, text=True, env=ENV, encoding="utf-8")
    check("watcher --once --history 0: no history lines", " ago" not in p.stdout, p.stdout)
    s = hook("Stop", transcript_path=os.path.join(TMP, ".claude", "projects", "h--", SESSION + ".jsonl"))
    check("project name: bare drive folder decodes to H:\\", s.get("project") == "H:\\", json.dumps(s.get("project")))
    s = hook("Stop", transcript_path=os.path.join(TMP, ".claude", "projects", "d--openbsw", SESSION + ".jsonl"))
    check("project name: drive prefix stripped", s.get("project") == "openbsw", json.dumps(s.get("project")))
    p = subprocess.run([sys.executable, WATCH, "--once", "--session", "zzz"], capture_output=True, text=True,
                       env=ENV, encoding="utf-8")
    check("watcher --once: unknown session prefix reports none", "no live" in p.stdout, p.stdout)
    hook("SessionEnd", end_reason="logout")
    check("session end: state file removed", not os.path.exists(STATE))


def usage_cases():
    sys.path.insert(0, HOOKS)
    os.environ["PROGRESS_ASCII"] = "1"
    import progress_tokens as pt
    import progress_watch as pw
    proj = os.path.join(TMP, ".claude", "projects", "j--HeroesOlden")
    sub = os.path.join(proj, SESSION, "subagents")
    os.makedirs(sub, exist_ok=True)
    transcript = os.path.join(proj, SESSION + ".jsonl")
    ts = "2026-09-16T14:02:33.768Z"
    usage1 = {"input_tokens": 10, "output_tokens": 100, "cache_read_input_tokens": 0, "cache_creation_input_tokens": 1000,
              "cache_creation": {"ephemeral_5m_input_tokens": 0, "ephemeral_1h_input_tokens": 1000}}
    usage2 = {"input_tokens": 5, "output_tokens": 50, "cache_read_input_tokens": 1000, "cache_creation_input_tokens": 0,
              "cache_creation": {"ephemeral_5m_input_tokens": 0, "ephemeral_1h_input_tokens": 0}}
    lines = [
        {"type": "user", "message": {"role": "user"}},
        {"type": "assistant", "message": {"id": "m1", "usage": usage1}, "timestamp": ts},
        {"type": "assistant", "message": {"id": "m1", "usage": usage1}, "timestamp": ts},
        {"type": "assistant", "message": {"id": "m2", "usage": usage2}, "timestamp": "2026-09-16T14:03:00.000Z"},
    ]
    with open(transcript, "w", encoding="utf-8") as fh:
        for rec in lines:
            fh.write(json.dumps(rec) + "\n")
    with open(os.path.join(sub, "agent-a.jsonl"), "w", encoding="utf-8") as fh:
        fh.write(json.dumps({"type": "assistant", "message": {"id": "s1", "usage": usage2}, "timestamp": ts}) + "\n")
    su = pt.SessionUsage(transcript, sub)
    su.update()
    now = pt.parse_ts("2026-09-16T14:33:00.000Z")
    t = su.totals(now)
    check("usage: streamed chunks deduped by message id, subagent included",
          t["requests"] == 3 and t["output"] == 200 and t["cache_read"] == 2000 and t["cache_write"] == 1000, json.dumps(t))
    check("usage: hit ratio of last main request", t["hit"] is not None and abs(t["hit"] - 99.5) < 0.1, json.dumps(t))
    check("usage: 1h ttl remembered, 30 min left", t["ttl"] == 3600 and abs(t["warm_left"] - 1800) < 2, json.dumps(t))
    t = su.totals(pt.parse_ts("2026-09-16T16:00:00.000Z"))
    check("usage: cold after ttl", t["warm_left"] == 0)
    with open(transcript, "a", encoding="utf-8") as fh:
        fh.write(json.dumps({"type": "assistant", "message": {"id": "m3", "usage": usage2}, "timestamp": ts}) + "\n")
    su.update()
    check("usage: incremental append picked up", su.totals(now)["requests"] == 4)
    check("usage: find_transcript locates session file",
          os.path.normcase(pt.find_transcript(SESSION, os.path.join(TMP, ".claude", "projects"))) == os.path.normcase(transcript))
    text = "\033[33mBash\033[0m " + "x" * 50 + " \033[2m3s\033[0m"
    check("watch: clip keeps width and resets colour", pw.visible_len(pw.clip(text, 20)) == 20 and pw.clip(text, 20).endswith("~"),
          repr(pw.clip(text, 20)))
    check("watch: pad measures visible chars only", pw.visible_len(pw.pad("\033[1mab\033[0m", 5)) == 5)
    check("watch: clip leaves short text alone", pw.clip("abc", 10) == "abc")
    check("watch: pad right-aligns numbers", pw.pad("12k", 7, ">") == "    12k")
    head = pw.header()
    check("watch: header names every column", all(t in head for t in ("PROJECT", "SESSION", "IN", "OUT", "HIT", "CACHE", "ACTIVITY")), head)
    cells = pw.usage_cells(su.totals(now))
    check("watch: usage cells in/out/hit/cache", cells[0] == "4k" and cells[1] == "250" and cells[2] == "100%" and "warm" in cells[3], repr(cells))
    check("watch: usage cells without requests are dashes", pw.usage_cells({"requests": 0})[0] == "-")
    check("watch: fmt_tokens", pt.fmt_tokens(950) == "950" and pt.fmt_tokens(12_400) == "12k" and pt.fmt_tokens(2_340_000) == "2.3M")


def timing_case():
    t0 = time.perf_counter()
    for _ in range(5):
        run(WRITER, {"session_id": SESSION, "hook_event_name": "PreToolUse", "tool_name": "Read",
                     "tool_use_id": "t", "tool_input": {"file_path": "a"}})
    per_call = (time.perf_counter() - t0) / 5
    check(f"timing: writer {per_call * 1000:.0f} ms per call (< 400 ms)", per_call < 0.4)


def main():
    try:
        writer_cases()
        renderer_cases()
        usage_cases()
        timing_case()
    finally:
        shutil.rmtree(TMP, ignore_errors=True)
    fails = [r for r in results if not r[0]]
    for ok, name, detail in results:
        print(f"{'PASS' if ok else 'FAIL'} [{name}]")
        if not ok and detail:
            print(f"      {detail[:400]}")
    print(f"\n{len(results) - len(fails)}/{len(results)} passed")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())

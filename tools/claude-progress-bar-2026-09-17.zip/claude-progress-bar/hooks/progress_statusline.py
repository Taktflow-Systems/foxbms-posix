#!/usr/bin/env python3
"""Status line renderer: reads Claude Code's status JSON on stdin plus the per-session progress
state written by progress_state.py, prints two lines. Runs outside the model: zero tokens.

Line 1: model, context %, cost, session time. Line 2: running tools, background jobs with a
percentage parsed from their log, agents, task steps. Set PROGRESS_ASCII=1 for ASCII bars.
"""
import json
import os
import re
import sys
import time

STATE_DIR = os.path.join(os.path.expanduser("~"), ".claude", "progress")
BAR_WIDTH = 12
STALE_TOOL_S = 3600
STALE_JOB_S = 6 * 3600
LOG_TAIL_BYTES = 8192
EXIT_MARKER = "[exited with code"
ASCII = bool(os.environ.get("PROGRESS_ASCII"))
FULL, EMPTY = ("#", "-") if ASCII else (chr(0x2588), chr(0x2591))
DOT = "|" if ASCII else chr(0xB7)
BRAILLE = (0x280B, 0x2819, 0x2839, 0x2838, 0x283C, 0x2834, 0x2826, 0x2827, 0x2807, 0x280F)
SPINNER = "|/-\\" if ASCII else "".join(chr(c) for c in BRAILLE)
DIM, BOLD, GREEN, YELLOW, CYAN, RESET = "\033[2m", "\033[1m", "\033[32m", "\033[33m", "\033[36m", "\033[0m"

PCT_PATTERNS = [
    re.compile(r"\[\s*(\d+)\s*/\s*(\d+)\s*\]"),
    re.compile(r"\b(\d+)\s+of\s+(\d+)\b"),
    re.compile(r"\[\s*(\d{1,3})%\s*\]"),
    re.compile(r"(?<![\d.])(\d{1,3})%(?!\d)"),
]


def fmt_duration(seconds):
    seconds = max(0, int(seconds))
    if seconds < 60:
        return f"{seconds}s"
    if seconds < 3600:
        return f"{seconds // 60}m{seconds % 60:02d}s"
    return f"{seconds // 3600}h{(seconds % 3600) // 60:02d}m"


def bar(pct, width=BAR_WIDTH):
    pct = max(0.0, min(100.0, float(pct)))
    filled = int(round(width * pct / 100.0))
    return FULL * filled + EMPTY * (width - filled)


def spinner(now):
    return SPINNER[int(now * 4) % len(SPINNER)]


def parse_pct(text):
    for line in reversed(text.splitlines()):
        for pattern in PCT_PATTERNS:
            match = pattern.search(line)
            if not match:
                continue
            if len(match.groups()) == 2:
                done, total = int(match.group(1)), int(match.group(2))
                if total > 0 and done <= total:
                    return 100.0 * done / total
            else:
                value = int(match.group(1))
                if value <= 100:
                    return float(value)
    return None


def log_progress(path):
    try:
        size = os.path.getsize(path)
        with open(path, "rb") as fh:
            fh.seek(max(0, size - LOG_TAIL_BYTES))
            tail = fh.read().decode("utf-8", "replace")
        return parse_pct(tail), EXIT_MARKER in tail
    except OSError:
        return None, False


def pid_alive(pid):
    if not pid:
        return None
    if os.name == "nt":
        import ctypes

        kernel32 = ctypes.windll.kernel32
        handle = kernel32.OpenProcess(0x1000, False, int(pid))
        if not handle:
            return False
        code = ctypes.c_ulong()
        ok = kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
        kernel32.CloseHandle(handle)
        return bool(ok) and code.value == 259
    try:
        os.kill(int(pid), 0)
        return True
    except OSError:
        return False


def find_job_log(job):
    if job.get("log"):
        return job["log"]
    folder, start = job.get("tasks_dir") or "", job.get("start") or 0
    if not folder or not os.path.isdir(folder):
        return ""
    candidates = []
    for name in os.listdir(folder):
        if not name.endswith(".output"):
            continue
        path = os.path.join(folder, name)
        try:
            created = os.path.getctime(path)
        except OSError:
            continue
        if created >= start - 2:
            candidates.append((created, path))
    return min(candidates)[1] if candidates else ""


def load_state(session_id):
    safe = re.sub(r"[^A-Za-z0-9_.-]", "_", session_id or "unknown")
    try:
        with open(os.path.join(STATE_DIR, safe + ".json"), encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return None


def join(parts):
    return f" {DIM}{DOT}{RESET} ".join(parts)


def render_line1(status):
    model = status.get("model") or {}
    name = model.get("display_name") or model.get("id") or "claude"
    ctx = status.get("context_window") or {}
    used = ctx.get("used_percentage")
    cost = (status.get("cost") or {}).get("total_cost_usd")
    duration = (status.get("cost") or {}).get("total_duration_ms")
    parts = [f"{BOLD}{name}{RESET}"]
    if used is not None:
        colour = GREEN if used < 60 else YELLOW
        parts.append(f"ctx {colour}{bar(used, 8)}{RESET} {used:.0f}%")
    if cost is not None:
        parts.append(f"${cost:.2f}")
    if duration:
        parts.append(fmt_duration(duration / 1000.0))
    return join(parts)


def render_line2(state, now):
    if not state:
        return f"{DIM}progress: no state yet{RESET}"
    parts = []
    turn = state.get("turn") or {}
    if turn.get("active"):
        parts.append(f"{CYAN}{spinner(now)}{RESET} working {fmt_duration(now - turn.get('start', now))}")
    for entry in (state.get("tools") or {}).values():
        age = now - entry.get("start", now)
        if age > STALE_TOOL_S or entry.get("bg"):
            continue
        label = entry.get("label") or ""
        parts.append(f"{YELLOW}{entry.get('tool', '?')}{RESET} {label} {DIM}{fmt_duration(age)}{RESET}")
    for entry in (state.get("jobs") or {}).values():
        age = now - entry.get("start", now)
        if age > STALE_JOB_S or pid_alive(entry.get("pid")) is False:
            continue
        pct, exited = log_progress(find_job_log(entry))
        if exited:
            continue
        label = entry.get("label") or "job"
        if pct is None:
            parts.append(f"{CYAN}{spinner(now)}{RESET} {label} {DIM}{fmt_duration(age)}{RESET}")
        else:
            parts.append(f"{label} {GREEN}{bar(pct)}{RESET} {pct:3.0f}% {DIM}{fmt_duration(age)}{RESET}")
    agents = state.get("agents") or {}
    if agents:
        oldest = min(entry.get("start", now) for entry in agents.values())
        noun = "agent" if len(agents) == 1 else "agents"
        parts.append(f"{CYAN}{spinner(now)}{RESET} {len(agents)} {noun} {DIM}{fmt_duration(now - oldest)}{RESET}")
    tasks = state.get("tasks") or {}
    done, open_ = len(tasks.get("done") or []), len(tasks.get("open") or [])
    if done + open_:
        pct = 100.0 * done / (done + open_)
        parts.append(f"tasks {GREEN}{bar(pct, 8)}{RESET} {done}/{done + open_}")
    if not parts:
        return f"{DIM}idle{RESET}"
    return join(parts)


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace", newline="\n")
    except Exception:
        pass
    try:
        status = json.load(sys.stdin)
    except Exception:
        status = {}
    now = time.time()
    state = load_state(status.get("session_id") or os.environ.get("CLAUDE_SESSION_ID", ""))
    print(render_line1(status))
    print(render_line2(state, now))
    return 0


if __name__ == "__main__":
    sys.exit(main())

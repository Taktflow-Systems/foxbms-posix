#!/usr/bin/env python3
"""Progress watcher for hosts without a status line (VS Code extension, desktop app).

Run in any terminal:  python ~/.claude/hooks/progress_watch.py [--session <id-prefix>] [--once]
Redraws one row per live Claude Code session every second from ~/.claude/progress/*.json.
Zero tokens: it only reads the state files the hooks already write. Ctrl+C to quit.
"""
import argparse
import json
import os
import re
import shutil
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import progress_statusline as sl  # noqa: E402
import progress_tokens as pt  # noqa: E402
from progress_state import project_name  # noqa: E402

STALE_SESSION_S = 12 * 3600
HOME_CLEAR = "\033[H\033[J"
ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")
COLUMNS = [("PROJECT", 18, "<"), ("SESSION", 8, "<"), ("IN", 7, ">"), ("OUT", 6, ">"), ("HIT", 4, ">"),
           ("CACHE", 11, "<")]
GAP = "  "
USAGE = {}


def visible_len(text):
    return len(ANSI_RE.sub("", text))


def pad(text, width, align="<"):
    fill = " " * max(0, width - visible_len(text))
    return fill + text if align == ">" else text + fill


def clip(text, width):
    if width <= 0:
        return ""
    if visible_len(text) <= width:
        return text
    out, seen, limit = [], 0, max(0, width - 1)
    for token in re.split(r"(\x1b\[[0-9;]*m)", text):
        if ANSI_RE.fullmatch(token):
            out.append(token)
            continue
        room = limit - seen
        out.append(token[:room])
        seen += min(len(token), room)
        if seen >= limit:
            break
    return "".join(out) + sl.RESET + ("~" if sl.ASCII else chr(0x2026))


def columns():
    return shutil.get_terminal_size((130, 12)).columns


def usage_for(state):
    sid = state.get("session_id") or ""
    tracker = USAGE.get(sid)
    if tracker is None:
        transcript = state.get("transcript") or pt.find_transcript(sid)
        subagents = state.get("subagents_dir") or pt.subagents_dir_for(transcript, sid)
        tracker = USAGE[sid] = pt.SessionUsage(transcript, subagents)
        if transcript and not state.get("project"):
            state["project"] = project_name(transcript)
    elif not state.get("project") and tracker.transcript:
        state["project"] = project_name(tracker.transcript)
    tracker.update()
    return tracker.totals()


def usage_cells(sums):
    if not sums["requests"]:
        return ["-", "-", "-", f"{sl.DIM}-{sl.RESET}"]
    hit = f"{sums['hit']:.0f}%" if sums["hit"] is not None else "-"
    if sums["warm_left"] > 0:
        cache = f"{sl.GREEN}warm{sl.RESET} {sl.fmt_duration(sums['warm_left'])}"
    else:
        cache = f"{sl.YELLOW}cold{sl.RESET}"
    return [pt.fmt_tokens(sums["input"] + sums["cache_read"] + sums["cache_write"]),
            pt.fmt_tokens(sums["output"]), hit, cache]


def project_cell(state):
    cwd = state.get("cwd") or ""
    name = state.get("project") or os.path.basename(cwd.rstrip("\\/")) or cwd or "(unknown)"
    return f"{sl.BOLD}{name[:COLUMNS[0][1]]}{sl.RESET}"


def row(cells, activity):
    head = GAP.join(pad(clip(cell, width), width, align) for cell, (_, width, align) in zip(cells, COLUMNS))
    fixed = sum(width for _, width, _ in COLUMNS) + len(GAP) * len(COLUMNS)
    return head + GAP + clip(activity, columns() - fixed - 1)


def header():
    titles = [f"{sl.DIM}{title}{sl.RESET}" for title, _, _ in COLUMNS]
    return row(titles, f"{sl.DIM}ACTIVITY{sl.RESET}")


def sessions(prefix=""):
    rows = []
    try:
        names = sorted(os.listdir(sl.STATE_DIR))
    except OSError:
        return rows
    for name in names:
        if not name.endswith(".json") or not name.startswith(prefix):
            continue
        try:
            with open(os.path.join(sl.STATE_DIR, name), encoding="utf-8") as fh:
                state = json.load(fh)
        except Exception:
            continue
        rows.append(state)
    return rows


def history_lines(state, now, count):
    lines = []
    for item in reversed((state.get("history") or [])[-count:] if count else []):
        ago = sl.fmt_duration(now - float(item.get("end") or now))
        took = sl.fmt_duration(float(item.get("end") or 0) - float(item.get("start") or 0))
        mark = f"{sl.GREEN}ok{sl.RESET}" if item.get("ok", True) else f"{sl.YELLOW}x{sl.RESET}"
        text = f"{sl.DIM}{ago:>6} ago{sl.RESET}  {mark} {item.get('tool', '?')} {item.get('label', '')} {sl.DIM}({took}){sl.RESET}"
        lines.append(row([""] * len(COLUMNS), text))
    return lines


def frame(prefix, now, history=3):
    lines = [header()]
    for state in sessions(prefix):
        if now - float(state.get("updated") or 0) > STALE_SESSION_S:
            continue
        sums = usage_for(state)
        sid = f"{sl.DIM}{(state.get('session_id') or '')[:COLUMNS[1][1]]}{sl.RESET}"
        lines.append(row([project_cell(state), sid] + usage_cells(sums), sl.render_line2(state, now)))
        lines.extend(history_lines(state, now, history))
    if len(lines) == 1:
        lines.append(f"{sl.DIM}no live Claude Code sessions{sl.RESET}")
    return lines


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--session", default="", help="only sessions whose id starts with this")
    parser.add_argument("--once", action="store_true", help="print one frame and exit")
    parser.add_argument("--interval", type=float, default=1.0)
    parser.add_argument("--history", type=int, default=3, help="finished actions to list under each session")
    args = parser.parse_args()
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace", newline="\n")
    except Exception:
        pass
    if os.name == "nt":
        os.system("")
    try:
        while True:
            lines = frame(args.session, time.time(), args.history)
            if args.once:
                print("\n".join(lines))
                return 0
            sys.stdout.write(HOME_CLEAR + "\n".join(lines) + "\n")
            sys.stdout.flush()
            time.sleep(args.interval)
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    sys.exit(main())

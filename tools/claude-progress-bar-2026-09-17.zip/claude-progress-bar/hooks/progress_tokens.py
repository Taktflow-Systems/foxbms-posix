#!/usr/bin/env python3
"""Zero-token usage reader: sums per-message usage from a session's transcript JSONL files.

Reads incrementally (remembers the byte offset per file), dedupes streamed chunks by message id,
and reports totals plus prompt-cache state (hit ratio of the last request, TTL warm time left).
"""
import datetime
import json
import os
import time

TTL_1H = 3600
TTL_5M = 300


class Transcript:
    def __init__(self, path):
        self.path = path
        self.offset = 0
        self.buffer = b""
        self.usage = {}
        self.last_ts = 0.0
        self.last_id = None
        self.ttl = TTL_5M

    def update(self):
        try:
            size = os.path.getsize(self.path)
        except OSError:
            return
        if size < self.offset:
            self.offset, self.buffer = 0, b""
        if size == self.offset:
            return
        with open(self.path, "rb") as fh:
            fh.seek(self.offset)
            data = fh.read(size - self.offset)
        self.offset = size
        data = self.buffer + data
        lines = data.split(b"\n")
        self.buffer = lines.pop()
        for line in lines:
            self.ingest(line)

    def ingest(self, line):
        try:
            record = json.loads(line)
        except Exception:
            return
        if record.get("type") != "assistant":
            return
        message = record.get("message") or {}
        usage = message.get("usage")
        if not isinstance(usage, dict):
            return
        msg_id = message.get("id") or record.get("uuid")
        self.usage[msg_id] = usage
        created = usage.get("cache_creation") or {}
        if int(created.get("ephemeral_1h_input_tokens") or 0) > 0:
            self.ttl = TTL_1H
        elif int(created.get("ephemeral_5m_input_tokens") or 0) > 0:
            self.ttl = TTL_5M
        ts = parse_ts(record.get("timestamp"))
        if ts >= self.last_ts:
            self.last_ts, self.last_id = ts, msg_id


def parse_ts(value):
    if not value:
        return 0.0
    try:
        return datetime.datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()
    except Exception:
        return 0.0


class SessionUsage:
    def __init__(self, transcript, subagents_dir=""):
        self.files = {}
        self.transcript = transcript
        self.subagents_dir = subagents_dir

    def paths(self):
        found = [self.transcript] if self.transcript else []
        if self.subagents_dir and os.path.isdir(self.subagents_dir):
            for name in os.listdir(self.subagents_dir):
                if name.endswith(".jsonl"):
                    found.append(os.path.join(self.subagents_dir, name))
        return found

    def update(self):
        for path in self.paths():
            entry = self.files.get(path)
            if entry is None:
                entry = self.files[path] = Transcript(path)
            entry.update()

    def totals(self, now=None):
        now = now or time.time()
        sums = {"input": 0, "output": 0, "cache_read": 0, "cache_write": 0}
        main = self.files.get(self.transcript)
        for entry in self.files.values():
            for usage in entry.usage.values():
                sums["input"] += int(usage.get("input_tokens") or 0)
                sums["output"] += int(usage.get("output_tokens") or 0)
                sums["cache_read"] += int(usage.get("cache_read_input_tokens") or 0)
                sums["cache_write"] += int(usage.get("cache_creation_input_tokens") or 0)
        sums["total"] = sums["input"] + sums["output"] + sums["cache_read"] + sums["cache_write"]
        sums["requests"] = sum(len(entry.usage) for entry in self.files.values())
        sums["last_ts"] = main.last_ts if main else 0.0
        sums["hit"] = None
        sums["ttl"] = main.ttl if main else TTL_5M
        sums["warm_left"] = 0
        last_usage = main.usage.get(main.last_id) if main else None
        if last_usage:
            read = int(last_usage.get("cache_read_input_tokens") or 0)
            write = int(last_usage.get("cache_creation_input_tokens") or 0)
            fresh = int(last_usage.get("input_tokens") or 0)
            prompt = read + write + fresh
            sums["hit"] = (100.0 * read / prompt) if prompt else None
            sums["warm_left"] = max(0.0, sums["ttl"] - (now - main.last_ts)) if main.last_ts else 0.0
        return sums


def find_transcript(session_id, projects_dir=None):
    projects_dir = projects_dir or os.path.join(os.path.expanduser("~"), ".claude", "projects")
    try:
        names = os.listdir(projects_dir)
    except OSError:
        return ""
    for name in names:
        candidate = os.path.join(projects_dir, name, session_id + ".jsonl")
        if os.path.isfile(candidate):
            return candidate
    return ""


def subagents_dir_for(transcript, session_id):
    return os.path.join(os.path.dirname(transcript), session_id, "subagents") if transcript else ""


def fmt_tokens(n):
    n = int(n)
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.0f}k"
    return str(n)

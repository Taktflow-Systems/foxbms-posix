#!/usr/bin/env python3
"""Zero-token progress state writer: every hook event updates ~/.claude/progress/<session_id>.json.

Registered on PreToolUse, PostToolUse, PostToolUseFailure, PermissionDenied, PostToolBatch,
SubagentStart/Stop, TaskCreated/Completed, UserPromptSubmit, Stop, SessionEnd. Silent stdout,
always exits 0 (fails open) so it can never block a tool or inject context.
Set PROGRESS_TRACE=1 or create <state dir>/.trace to append raw payloads to trace.jsonl.
"""
import hashlib
import json
import os
import re
import sys
import time

STATE_DIR = os.path.join(os.path.expanduser("~"), ".claude", "progress")
MAX_LABEL = 48
HISTORY_MAX = 12
OUTPUT_FILE_RE = re.compile(r"[A-Za-z]:[\\/][^\s\"']*?tasks[\\/][^\s\"']+\.output|/[^\s\"']*?/tasks/[^\s\"']+\.output")
PID_RE = re.compile(r"\bPID\s*[:=]?\s*(\d+)", re.IGNORECASE)


def empty_state(session_id):
    return {
        "session_id": session_id,
        "updated": 0,
        "turn": {"active": False, "start": 0},
        "tools": {},
        "jobs": {},
        "agents": {},
        "tasks": {"open": [], "done": []},
        "history": [],
    }


def remember(state, tool, label, start, ok=True):
    now = time.time()
    state.setdefault("history", []).append({
        "tool": tool, "label": label, "start": start or now, "end": now, "ok": ok,
    })
    del state["history"][:-HISTORY_MAX]


def state_path(session_id):
    safe = re.sub(r"[^A-Za-z0-9_.-]", "_", session_id or "unknown")
    return os.path.join(STATE_DIR, safe + ".json")


def load(session_id):
    try:
        with open(state_path(session_id), encoding="utf-8") as fh:
            data = json.load(fh)
        base = empty_state(session_id)
        base.update(data)
        return base
    except Exception:
        return empty_state(session_id)


def save(state):
    state["updated"] = time.time()
    os.makedirs(STATE_DIR, exist_ok=True)
    path = state_path(state["session_id"])
    tmp = f"{path}.{os.getpid()}.tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(state, fh)
    os.replace(tmp, path)


def trace(payload):
    enabled = os.environ.get("PROGRESS_TRACE") or os.path.exists(os.path.join(STATE_DIR, ".trace"))
    if not enabled:
        return
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(os.path.join(STATE_DIR, "trace.jsonl"), "a", encoding="utf-8") as fh:
            fh.write(json.dumps({"ts": time.time(), "payload": payload}) + "\n")
    except OSError:
        pass


def project_name(transcript_path):
    folder = os.path.basename(os.path.dirname(transcript_path))
    match = re.match(r"^([A-Za-z])--(.*)$", folder)
    if not match:
        return folder
    drive, rest = match.group(1).upper(), match.group(2)
    return rest if rest else f"{drive}:\\"


def tool_key(payload):
    key = payload.get("tool_use_id")
    if key:
        return str(key)
    raw = json.dumps(payload.get("tool_input"), sort_keys=True, default=str)
    return payload.get("tool_name", "?") + ":" + hashlib.sha1(raw.encode()).hexdigest()[:10]


def tool_label(name, tool_input):
    tool_input = tool_input or {}
    if name in ("Bash", "PowerShell"):
        text = tool_input.get("description") or tool_input.get("command") or ""
    elif name == "Agent":
        text = tool_input.get("description") or tool_input.get("subagent_type") or ""
    elif name == "Skill":
        text = tool_input.get("skill") or ""
    else:
        text = tool_input.get("file_path") or tool_input.get("pattern") or tool_input.get("url") or ""
        text = os.path.basename(str(text)) if name in ("Read", "Write", "Edit") else str(text)
    text = " ".join(str(text).split())
    return text[:MAX_LABEL]


def response_text(response):
    return response if isinstance(response, str) else json.dumps(response, default=str)


def find_output_file(response):
    match = OUTPUT_FILE_RE.search(response_text(response).replace("\\\\", "\\"))
    return match.group(0) if match else None


def find_pid(response):
    match = PID_RE.search(response_text(response))
    return int(match.group(1)) if match else None


def tasks_dir(payload):
    scratch = payload.get("scratchpad_dir") or ""
    return os.path.join(os.path.dirname(scratch), "tasks") if scratch else ""


def on_pre_tool(state, payload):
    name = payload.get("tool_name", "?")
    tool_input = payload.get("tool_input") or {}
    state["tools"][tool_key(payload)] = {
        "tool": name,
        "label": tool_label(name, tool_input),
        "start": time.time(),
        "bg": bool(tool_input.get("run_in_background")),
    }


def on_post_tool(state, payload):
    key = tool_key(payload)
    entry = state["tools"].pop(key, None)
    name = payload.get("tool_name", "?")
    tool_input = payload.get("tool_input") or {}
    event = payload.get("hook_event_name")
    bg_start = name in ("Bash", "PowerShell") and bool(tool_input.get("run_in_background")) and not payload.get("error")
    if not bg_start:
        remember(state, name, (entry or {}).get("label") or tool_label(name, tool_input),
                 (entry or {}).get("start"), ok=event == "PostToolUse")
    if bg_start:
        response = payload.get("tool_response")
        task_id = str((response or {}).get("backgroundTaskId") or "") if isinstance(response, dict) else ""
        folder = tasks_dir(payload)
        log = find_output_file(response) or ""
        if not log and task_id and folder:
            log = os.path.join(folder, task_id + ".output")
        state["jobs"][key] = {
            "label": (entry or {}).get("label") or tool_label(name, tool_input),
            "task_id": task_id,
            "log": log,
            "pid": find_pid(response),
            "tasks_dir": folder,
            "start": (entry or {}).get("start") or time.time(),
        }
    if name == "TodoWrite":
        response = payload.get("tool_response")
        todos = response.get("newTodos") if isinstance(response, dict) else None
        if todos is None:
            todos = tool_input.get("todos") or []
        state["tasks"] = {
            "open": [str(t.get("content", "")) for t in todos if t.get("status") != "completed"],
            "done": [str(t.get("content", "")) for t in todos if t.get("status") == "completed"],
        }
    if name == "TaskOutput" or name == "TaskStop":
        task_id = str(tool_input.get("task_id") or "")
        for job_key in list(state["jobs"]):
            if task_id and task_id in state["jobs"][job_key].get("log", ""):
                state["jobs"].pop(job_key, None)


def on_post_batch(state, payload):
    for use in (payload.get("tool_calls") or payload.get("tool_uses") or []):
        if not isinstance(use, dict):
            continue
        entry = state["tools"].pop(str(use.get("tool_use_id") or ""), None)
        if entry:
            remember(state, entry.get("tool", "?"), entry.get("label", ""), entry.get("start"), ok=False)


def on_subagent_start(state, payload):
    agent_id = str(payload.get("agent_id") or payload.get("tool_use_id") or len(state["agents"]))
    state["agents"][agent_id] = {"type": payload.get("agent_type") or "agent", "start": time.time()}


def on_subagent_stop(state, payload):
    agent_id = str(payload.get("agent_id") or payload.get("tool_use_id") or "")
    if agent_id not in state["agents"] and state["agents"]:
        agent_id = next(iter(state["agents"]))
    entry = state["agents"].pop(agent_id, None)
    if entry:
        remember(state, "Agent", entry.get("type", "agent"), entry.get("start"))


def on_task_created(state, payload):
    task_id = str(payload.get("task_id") or payload.get("task_subject") or len(state["tasks"]["open"]))
    if task_id not in state["tasks"]["open"] and task_id not in state["tasks"]["done"]:
        state["tasks"]["open"].append(task_id)


def on_task_completed(state, payload):
    task_id = str(payload.get("task_id") or payload.get("task_subject") or "")
    if task_id in state["tasks"]["open"]:
        state["tasks"]["open"].remove(task_id)
    elif state["tasks"]["open"]:
        task_id = state["tasks"]["open"].pop(0)
    if task_id and task_id not in state["tasks"]["done"]:
        state["tasks"]["done"].append(task_id)


def on_prompt(state, payload):
    state["turn"] = {"active": True, "start": time.time()}
    state["tools"] = {}
    if not state["tasks"]["open"]:
        state["tasks"] = {"open": [], "done": []}


def running_task_ids(payload):
    ids = set()
    for item in payload.get("background_tasks") or []:
        if isinstance(item, dict):
            ids.add(str(item.get("id") or item.get("task_id") or item.get("taskId") or ""))
        else:
            ids.add(str(item))
    return ids


def on_stop(state, payload):
    state["turn"]["active"] = False
    state["tools"] = {}
    if "background_tasks" in payload:
        alive = running_task_ids(payload)
        for key, job in list(state["jobs"].items()):
            if job.get("task_id") and job["task_id"] not in alive:
                state["jobs"].pop(key)
                remember(state, "Job", job.get("label", ""), job.get("start"))


HANDLERS = {
    "PreToolUse": on_pre_tool,
    "PostToolUse": on_post_tool,
    "PostToolUseFailure": on_post_tool,
    "PermissionDenied": on_post_tool,
    "PostToolBatch": on_post_batch,
    "SubagentStart": on_subagent_start,
    "SubagentStop": on_subagent_stop,
    "TaskCreated": on_task_created,
    "TaskCompleted": on_task_completed,
    "UserPromptSubmit": on_prompt,
    "Stop": on_stop,
}


def handle(payload):
    event = payload.get("hook_event_name") or (sys.argv[1] if len(sys.argv) > 1 else "")
    session_id = payload.get("session_id") or "unknown"
    if event == "SessionEnd":
        try:
            os.remove(state_path(session_id))
        except OSError:
            pass
        return
    handler = HANDLERS.get(event)
    if handler is None:
        return
    state = load(session_id)
    if payload.get("cwd"):
        state["cwd"] = payload["cwd"]
    project = project_name(payload.get("transcript_path") or "")
    if project:
        state["project"] = project
    if payload.get("transcript_path"):
        state["transcript"] = payload["transcript_path"]
    if payload.get("agent_transcript_path"):
        state["subagents_dir"] = os.path.dirname(payload["agent_transcript_path"])
    handler(state, payload)
    save(state)


def main() -> int:
    try:
        payload = json.load(sys.stdin)
    except Exception:
        return 0
    try:
        trace(payload)
        handle(payload)
    except Exception as exc:
        print(f"progress_state: {exc}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())

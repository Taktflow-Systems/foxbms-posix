# Claude Code zero-token progress bar (snapshot 2026-09-17)

Live per-session progress bar for Claude Code, driven only by silent hooks
(zero tokens, always exit 0).

## Contents

- `hooks/progress_state.py` - hook entry point; writes
  `~/.claude/progress/<session_id>.json` from the hook events listed below.
- `hooks/progress_tokens.py` - token / cache accounting helpers.
- `hooks/progress_statusline.py` - renders the state file as the CLI statusLine.
- `hooks/progress_watch.py` - console watcher, one row per session
  (VS Code / desktop surface; `--history N` shows the last N actions).
- `hooks/tests/test_progress.py` - test suite
  (`python ~/.claude/hooks/tests/test_progress.py`).
- `desktop/claude-progress-watch.cmd` - launcher for the watcher console;
  registered as a logon scheduled task named `ClaudeProgressWatch`.

## Install

1. Copy `hooks/*` to `~/.claude/hooks/` (keep the `tests/` subfolder).
2. Wire `progress_state.py` into `~/.claude/settings.json` with a
   matcher-less entry (`"type": "command"`, `"timeout": 5`) under each of:
   PreToolUse, PostToolUse, PostToolUseFailure, SubagentStart, SubagentStop,
   TaskCreated, TaskCompleted, UserPromptSubmit, Stop, SessionEnd,
   PostToolBatch, PermissionDenied.
3. Set the statusLine in `settings.json`:

```json
"statusLine": {
  "type": "command",
  "command": "\"<python>\" ~/.claude/hooks/progress_statusline.py",
  "refreshInterval": 1
}
```

4. Optional watcher at logon: copy `desktop/claude-progress-watch.cmd`
   and register it as a scheduled task (`ClaudeProgressWatch`, trigger: logon).
5. Run the tests: `python ~/.claude/hooks/tests/test_progress.py`.

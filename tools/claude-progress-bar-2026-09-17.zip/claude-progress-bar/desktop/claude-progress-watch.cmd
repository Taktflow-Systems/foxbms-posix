@echo off
REM ============================================================
REM  Claude Code - Progress Watch DAEMON (self-restarting)
REM
REM  Shows one live row per Claude Code session (running tool,
REM  background job percentage, agents, todo steps) in this
REM  console, refreshed every second. Zero tokens: it only reads
REM  %USERPROFILE%\.claude\progress\*.json written by the hooks.
REM  Started automatically at logon by the Windows scheduled task
REM  "ClaudeProgressWatch"; relaunches 10s after any exit.
REM
REM  Watcher script: %USERPROFILE%\.claude\hooks\progress_watch.py
REM  Companion of claude-remote-control-daemon.cmd (same pattern).
REM ============================================================

set "WATCHER=%USERPROFILE%\.claude\hooks\progress_watch.py"
set "PY=C:\Python314\python.exe"

title Claude Progress Watch (daemon)
mode con: cols=130 lines=24

if not exist "%WATCHER%" (
  echo [ERROR] watcher not found: "%WATCHER%"
  timeout /t 30 /nobreak >nul
  exit /b 1
)

:loop
"%PY%" "%WATCHER%"
echo [%date% %time%] watcher exited (code %errorlevel%); restarting in 10s ...
timeout /t 10 /nobreak >nul
goto loop

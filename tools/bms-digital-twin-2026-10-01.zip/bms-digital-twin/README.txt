BMS Digital Twin - standalone web animation
===========================================

What it is
----------
An animated 3D model of a high-voltage battery system: pack, shunt, service
disconnect, fuse, precharge contactors and resistor, main contactors, DC link,
energy storage inverter, BMS controller, isolation monitor, HV interlock loop,
LV supply and comms. A built-in simulation drives the HV connection and
precharge state machines, so the model moves on its own.

How to open
-----------
1. Unzip the folder anywhere.
2. Double-click index.html. It opens in your default browser.
   Chrome, Edge, Firefox or Safari (any recent version with WebGL) work.

Nothing else is needed: no server, no installation, no internet connection.
The page never loads anything from the network.

Using it
--------
- The model spins slowly; chips label every part. Click a chip (or a name in
  the Component Inspector) to list that part's live signals.
- Request CLOSE starts a precharge and closes the main contactors; Request
  OPEN disconnects again.
- The red fault buttons inject faults (welded contactor, HVIL open, isolation
  low, overcurrent, fuse trigger, ...). Clear faults removes them. Safety lock
  reset works only while HV_DISCONNECTED. ECU reset reboots the controller.
- The Control Center sliders set the load power, SOC, ambient temperature and
  isolation resistance of the simulated plant.
- Labels: auto keeps chips clear of the model; Labels: all shows every chip.

Notes
-----
- All names, states and parameter values are generic and illustrative. They
  describe no specific product.
- The page embeds the three.js library (MIT licence, copyright 2010-2024
  Three.js Authors); its licence header is kept inside index.html.

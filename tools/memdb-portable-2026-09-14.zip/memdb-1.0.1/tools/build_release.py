#!/usr/bin/env python3
"""Build a memdb release: the .pyz, the portable zip, the wheel, SHA256SUMS.

Source: `git archive HEAD` exported into a temp directory, never the
working tree, so every artifact corresponds to a commit. The build refuses
to start while tracked files under memdb/, install/ or pyproject.toml
differ from HEAD (`--allow-dirty` overrides, and the artifacts still come
from HEAD). Untracked files never block a build and never ship.
`--worktree` builds from the working tree instead; the test suite uses it
to package the code under test, and a release never does.

Both zips are reproducible: sorted entries, one fixed timestamp, fixed
permissions, LF line endings as committed. The same commit gives the same
bytes and the same SHA256SUMS. The wheel is optional (pip and setuptools
must be present); the .pyz is not.

Usage:
    python tools/build_release.py [--out DIR] [--no-wheel] [--allow-dirty]

Prints one JSON report: version, commit, every artifact with its size and
sha256, and whether the wheel was built.
"""
import argparse
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import zipfile

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHIPPED = ("memdb", "install", "pyproject.toml")
# Also in the portable zip, so an unpacked tree can rebuild and read its history.
OPTIONAL = ("LICENSE", "CHANGELOG.md", "tools/build_release.py")
PYZ_EXCLUDED = ("memdb/tests/", "memdb/bench/", "memdb/docs/")
ZIP_TIME = (1980, 1, 1, 0, 0, 0)
SHEBANG = b"#!/usr/bin/env python3\n"
PYZ_MAIN = b"# -*- coding: utf-8 -*-\nimport memdb.mem\nmemdb.mem.main()\n"
WORKTREE_SKIP = ("__pycache__", ".pytest_cache", "work", "build", "dist")


def git(repo, *args, **kwargs):
    return subprocess.run(["git", *args], cwd=repo, capture_output=True,
                          timeout=300, **kwargs)


def dirty_paths(repo):
    """Tracked files under the shipped paths that differ from HEAD."""
    p = git(repo, "status", "--porcelain=v1", "--untracked-files=no", "--",
            *SHIPPED, text=True)
    if p.returncode != 0:
        raise SystemExit("build: git status failed: " + p.stderr.strip())
    return sorted(line[3:] for line in p.stdout.splitlines() if line.strip())


def export_head(repo, target):
    """Extract the shipped paths of HEAD into target; returns the commit."""
    names = list(SHIPPED) + [n for n in OPTIONAL
                             if git(repo, "cat-file", "-e",
                                    "HEAD:" + n).returncode == 0]
    # The committed blob bytes, whatever this checkout's line-ending conversion.
    p = git(repo, "-c", "core.autocrlf=false", "archive", "--format=tar", "HEAD",
            "--", *names)
    if p.returncode != 0:
        raise SystemExit("build: git archive failed: " + p.stderr.decode(
            "utf-8", "replace").strip())
    with tarfile.open(fileobj=io.BytesIO(p.stdout)) as tar:
        for member in tar.getmembers():
            if member.name.startswith("/") or ".." in member.name.split("/"):
                raise SystemExit("build: unsafe path in archive: " + member.name)
        tar.extractall(target)
    return git(repo, "rev-parse", "HEAD", text=True).stdout.strip()


def export_worktree(repo, target):
    """Copy the shipped paths of the working tree into target (tests only)."""
    for name in SHIPPED + OPTIONAL:
        src = os.path.join(repo, name)
        if os.path.isdir(src):
            shutil.copytree(src, os.path.join(target, name),
                            ignore=shutil.ignore_patterns(*WORKTREE_SKIP))
        elif os.path.isfile(src):
            os.makedirs(os.path.dirname(os.path.join(target, name)), exist_ok=True)
            shutil.copyfile(src, os.path.join(target, name))
    return "worktree"


def read_version(src):
    with open(os.path.join(src, "memdb", "__init__.py"), encoding="utf-8") as f:
        m = re.search(r"^__version__\s*=\s*[\"']([^\"']+)[\"']", f.read(), re.M)
    if not m:
        raise SystemExit("build: no __version__ in memdb/__init__.py")
    return m.group(1)


def tree_entries(root, prefix=""):
    """[(archive name, bytes)] for every file under root, CRLF normalised to LF."""
    entries = []
    for base, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in WORKTREE_SKIP)
        for name in files:
            full = os.path.join(base, name)
            rel = os.path.relpath(full, root).replace(os.sep, "/")
            with open(full, "rb") as f:
                data = f.read()
            if b"\0" not in data:       # text: a CRLF checkout must not change the bytes
                data = data.replace(b"\r\n", b"\n")
            entries.append((prefix + rel, data))
    return entries


def write_zip(target, entries, head=b""):
    """A deterministic zip: sorted names, fixed time and mode."""
    with open(target, "wb") as f:
        f.write(head)
        with zipfile.ZipFile(f, "w", zipfile.ZIP_DEFLATED) as z:
            for name, data in sorted(entries):
                info = zipfile.ZipInfo(name, ZIP_TIME)
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                info.external_attr = 0o644 << 16
                z.writestr(info, data)


def build_pyz(src, target):
    entries = [(name, data) for name, data in tree_entries(src)
               if name.startswith("memdb/") and not name.startswith(PYZ_EXCLUDED)]
    entries.append(("__main__.py", PYZ_MAIN))
    write_zip(target, entries, SHEBANG)


def build_portable(src, pyz, target, version):
    top = "memdb-{}/".format(version)
    entries = tree_entries(src, top)
    with open(pyz, "rb") as f:
        entries.append((top + os.path.basename(pyz), f.read()))
    write_zip(target, entries)


def build_wheel(src, out, commit_time):
    """(built, detail): pip wheel without network or build isolation."""
    probe = subprocess.run([sys.executable, "-c", "import pip, setuptools"],
                           capture_output=True, text=True)
    if probe.returncode != 0:
        return False, "pip or setuptools not available: " + probe.stderr.strip()[-300:]
    work = tempfile.mkdtemp(prefix="memdb-wheel-")
    try:
        tree = os.path.join(work, "src")
        shutil.copytree(src, tree)
        env = dict(os.environ, SOURCE_DATE_EPOCH=str(commit_time))
        p = subprocess.run([sys.executable, "-m", "pip", "wheel", tree, "--no-deps",
                            "--no-build-isolation", "-w", os.path.join(work, "whl")],
                           capture_output=True, text=True, env=env, timeout=600)
        if p.returncode != 0:
            return False, "pip wheel failed: " + (p.stderr or p.stdout).strip()[-500:]
        built = sorted(os.listdir(os.path.join(work, "whl")))
        if len(built) != 1:
            return False, "expected one wheel, got {}".format(built)
        shutil.copyfile(os.path.join(work, "whl", built[0]),
                        os.path.join(out, built[0]))
        return True, built[0]
    finally:
        shutil.rmtree(work, ignore_errors=True)


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--out", default=os.path.join(REPO, "dist"))
    ap.add_argument("--no-wheel", action="store_true")
    ap.add_argument("--allow-dirty", action="store_true",
                    help="build HEAD even though tracked shipped files changed")
    ap.add_argument("--worktree", action="store_true",
                    help="package the working tree (tests only, never a release)")
    args = ap.parse_args(argv)

    dirty = [] if args.worktree else dirty_paths(REPO)
    if dirty and not args.allow_dirty:
        raise SystemExit("build: tracked changes under the shipped paths; commit "
                         "them or pass --allow-dirty (artifacts come from HEAD): "
                         + ", ".join(dirty))
    out = os.path.abspath(args.out)
    os.makedirs(out, exist_ok=True)
    work = tempfile.mkdtemp(prefix="memdb-release-")
    try:
        src = os.path.join(work, "src")
        os.makedirs(src)
        commit = (export_worktree if args.worktree else export_head)(REPO, src)
        version = read_version(src)
        commit_time = 315532800
        if not args.worktree:
            commit_time = int(git(REPO, "log", "-1", "--format=%ct", "HEAD",
                                  text=True).stdout.strip())
        pyz = os.path.join(out, "memdb-{}.pyz".format(version))
        portable = os.path.join(out, "memdb-portable-{}.zip".format(version))
        build_pyz(src, pyz)
        build_portable(src, pyz, portable, version)
        names = [os.path.basename(pyz), os.path.basename(portable)]
        wheel = {"built": False, "detail": "--no-wheel"}
        if not args.no_wheel:
            built, detail = build_wheel(src, out, commit_time)
            wheel = {"built": built, "detail": detail}
            if built:
                names.append(detail)
    finally:
        shutil.rmtree(work, ignore_errors=True)

    artifacts = [{"name": n, "bytes": os.path.getsize(os.path.join(out, n)),
                  "sha256": sha256(os.path.join(out, n))} for n in sorted(names)]
    with open(os.path.join(out, "SHA256SUMS"), "w", encoding="utf-8",
              newline="\n") as f:
        for a in artifacts:
            f.write("{}  {}\n".format(a["sha256"], a["name"]))
    print(json.dumps({"version": version, "commit": commit, "dirty": dirty,
                      "out": out, "artifacts": artifacts, "wheel": wheel},
                     indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())

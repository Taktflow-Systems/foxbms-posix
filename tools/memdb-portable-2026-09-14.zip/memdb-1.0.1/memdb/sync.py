"""memdb sync: replicate this host's journal to the hub and ingest every
other host's journal, then rebuild and verify.

Design (lossless by construction):
 - the journal repo has ONE branch per host, <host>/journal; each host
   commits ONLY its own journal/<host>/ files (multi-host rules H1-H3)
 - other hosts' journals are read from origin refs, never merged
 - every remote ref must be a FAST-FORWARD of the last ref this clone
   saw: with one writer per branch a non-FF push is impossible in normal
   operation, so observing one means a rewritten journal or a second
   writer claiming the same host id - an INTEGRITY EVENT that stops the
   sync, never something to auto-resolve
 - shallow clones cannot verify a hash chain below their boundary and
   are refused outright
 - after ingest: rebuild --verify (snapshot fast path + suffix chains +
   witness checkpoints); on a cadence (weekly, or forced via
   MEMDB_FULL_VERIFY=1) the FULL oracle runs instead
 - sync FAILS LOUDLY, never silently

This is the Python form of the retired memdb_sync.sh; every message text
is unchanged, because sync.log readers and the guard tests match on them.
Hub-side requirements live in docs/hub-config.md. Exit 0 only when every
step succeeded.
"""
import contextlib
import datetime
import io
import json
import os
import platform
import subprocess
import sys
import time

try:
    from . import config, journal, mem, paths
except ImportError:                     # loose script: python memdb/mem.py
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import config  # noqa: E402
    import journal  # noqa: E402
    import mem  # noqa: E402
    import paths  # noqa: E402

DEFAULT_FULL_VERIFY_EVERY_S = 604800    # 7 days
JOURNAL_FILES = ("events.jsonl", "witness-heads.json")


class Sync:
    """One sync run: collects failures, prints as it goes, exits at the end."""

    def __init__(self, out=None):
        self.out = out or sys.stdout
        self.fail = False

    def say(self, *lines):
        for line in lines:
            self.out.write(line + "\n")
        self.out.flush()

    def failed(self, *lines):
        self.say(*lines)
        self.fail = True


# ------------------------------------------------------------------ git

def git(root, *args, **kwargs):
    """Run git in the journal root; returns the CompletedProcess."""
    try:
        return subprocess.run(["git", *args], cwd=root, capture_output=True,
                              text=True, timeout=kwargs.get("timeout", 1800))
    except (OSError, subprocess.SubprocessError) as e:
        return subprocess.CompletedProcess(args, 1, "", str(e))


def git_ok(root, *args, **kwargs):
    return git(root, *args, **kwargs).returncode == 0


def has_origin(root):
    return git_ok(root, "remote", "get-url", "origin")


# ------------------------------------------------------------- identity

def resolve_host(s):
    """This host's slug, refusing an env override that forks another journal."""
    env = (os.environ.get("MEMDB_HOST") or "").strip()
    path = journal.host_id_file()
    from_file = ""
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            from_file = f.read().strip()
    if env and from_file and env != from_file \
            and os.environ.get("MEMDB_HOST_OVERRIDE") != "1":
        s.failed("memdb-sync: FAIL MEMDB_HOST={} conflicts with the host-id "
                 "file ({})".format(env, from_file),
                 "  unset MEMDB_HOST, or set MEMDB_HOST_OVERRIDE=1 for tests "
                 "and benches only")
        return None
    host = env or from_file
    if not host:
        s.failed("memdb-sync: FAIL no host identity (MEMDB_HOST or "
                 "~/.claude/memory/host-id)")
        return None
    return host


# --------------------------------------------------------------- ingest

def head_of_file(path):
    """{seq, hash} of a journal file's last event, or None when unreadable."""
    try:
        with open(path, "rb") as f:
            return journal.head_of_bytes(f.read(), path)
    except (OSError, journal.TornTail, ValueError):
        return None


def head_of_ref(root, ref, host):
    """{seq, hash} of a host's journal at an origin ref, or None."""
    p = subprocess.run(["git", "show", "{}:journal/{}/events.jsonl".format(
        ref, host)], cwd=root, capture_output=True, timeout=1800)
    if p.returncode != 0:
        return None
    try:
        return journal.head_of_bytes(p.stdout, ref)
    except (journal.TornTail, ValueError):
        return None


def materialise(s, root, ref, host):
    """Write one host's journal files from an origin ref; True when ingested."""
    ingested = True
    folder = os.path.join(root, "journal", host)
    os.makedirs(folder, exist_ok=True)
    for name in JOURNAL_FILES:
        p = subprocess.run(["git", "show", "{}:journal/{}/{}".format(
            ref, host, name)], cwd=root, capture_output=True, timeout=1800)
        if p.returncode != 0:
            if name == "events.jsonl":
                ingested = False
            continue
        tmp = os.path.join(folder, name + ".tmp")
        try:
            with open(tmp, "wb") as f:
                f.write(p.stdout)
            os.replace(tmp, os.path.join(folder, name))
        except OSError:
            with contextlib.suppress(OSError):
                os.remove(tmp)
            s.failed("memdb-sync: FAIL could not replace journal/{}/{}; "
                     "last-seen ref for {} not advanced".format(host, name,
                                                                host))
            ingested = False
    return ingested


def ingest_others(s, root, host):
    """Fetch, then materialise every other host's journal, fast-forward only."""
    if not git_ok(root, "fetch", "-qp", "origin"):
        s.failed("memdb-sync: fetch failed")
    seen_dir = os.path.join(git(root, "rev-parse", "--git-dir").stdout.strip()
                            or ".git", "memdb-last-seen")
    if not os.path.isabs(seen_dir):
        seen_dir = os.path.join(root, seen_dir)
    os.makedirs(seen_dir, exist_ok=True)
    refs = git(root, "for-each-ref", "--format=%(refname:short)",
               "refs/remotes/origin/*/journal").stdout.split()
    for ref in refs:
        other = ref[len("origin/"):].rsplit("/journal", 1)[0]
        if other == host:
            continue
        new = git(root, "rev-parse", ref).stdout.strip()
        seen_file = os.path.join(seen_dir, other)
        if os.path.exists(seen_file):
            with open(seen_file, encoding="utf-8") as f:
                old = f.read().strip()
            if not git_ok(root, "merge-base", "--is-ancestor", old, new):
                s.failed(
                    "memdb-sync: INTEGRITY non-fast-forward on {}".format(ref),
                    "  last seen {}, now {} - a per-host journal branch".format(
                        old, new),
                    "  must only ever advance; this looks like a rewritten",
                    "  journal or two writers sharing host id '{}'.".format(other),
                    "  NOT ingesting. Investigate before syncing again.")
                continue
        local_path = os.path.join(root, "journal", other, "events.jsonl")
        if os.path.exists(local_path):
            local, origin = head_of_file(local_path), head_of_ref(root, ref, other)
            if local is None or origin is None:
                s.failed("memdb-sync: INTEGRITY cannot read the journal head "
                         "for {} (local {}, origin {})".format(
                             other, json.dumps(local), json.dumps(origin)),
                         "  NOT ingesting {}. Investigate before syncing "
                         "again.".format(other))
                continue
            if local["seq"] > origin["seq"] or (
                    local["seq"] == origin["seq"]
                    and local["hash"] != origin["hash"]):
                s.failed(
                    "memdb-sync: INTEGRITY local journal for {} is ahead of "
                    "origin".format(other),
                    "  local seq {} hash {}, origin seq {} hash {}.".format(
                        local["seq"], local["hash"], origin["seq"],
                        origin["hash"]),
                    "  NOT overwriting the local file. Investigate before "
                    "syncing again.")
                continue
        if materialise(s, root, ref, other):
            tmp = seen_file + ".tmp"
            with open(tmp, "w", encoding="utf-8", newline="\n") as f:
                f.write(new + "\n")
            os.replace(tmp, seen_file)


# ------------------------------------------------------ rebuild + verify

def run_mem(argv):
    """Call a mem command in-process, capturing stdout; (ok, text)."""
    buf = io.StringIO()
    keep = sys.stdout
    sys.stdout = buf
    try:
        mem.main(argv)
        ok = True
    except SystemExit as e:
        ok = not e.code
    except Exception as e:                              # pragma: no cover
        buf.write("{}: {}\n".format(type(e).__name__, e))
        ok = False
    finally:
        sys.stdout = keep
    return ok, buf.getvalue()


def rebuild_verify(s, full):
    """rebuild --verify (optionally --full); True when it came back green."""
    argv = ["rebuild", "--verify"] + (["--full"] if full else [])
    ok, text = run_mem(argv)
    if text.strip():
        s.say(text.rstrip("\n"))
    if '"record_regression": true' in text:
        s.say("memdb-sync: RECORD REGRESSION rebuilt projection is behind "
              "the live DB (see record_regression_detail)")
    return ok


def full_verify_due(root):
    """(due, stamp_path): the weekly oracle cadence, or MEMDB_FULL_VERIFY=1."""
    git_dir = git(root, "rev-parse", "--git-dir").stdout.strip() or ".git"
    if not os.path.isabs(git_dir):
        git_dir = os.path.join(root, git_dir)
    stamp = os.path.join(git_dir, "memdb-last-full-verify")
    if os.environ.get("MEMDB_FULL_VERIFY") == "1":
        return True, stamp
    try:
        every = int(os.environ.get("MEMDB_FULL_VERIFY_EVERY_S")
                    or DEFAULT_FULL_VERIFY_EVERY_S)
    except ValueError:
        every = DEFAULT_FULL_VERIFY_EVERY_S
    try:
        with open(stamp, encoding="utf-8") as f:
            last = int(f.read().strip() or 0)
    except (OSError, ValueError):
        return True, stamp
    return (time.time() - last) >= every, stamp


# ------------------------------------------------------------------ run

def commit_own(s, root, host):
    """Commit this host's journal files; True when a commit was made."""
    git(root, "add", "journal/" + host)
    if git(root, "diff", "--cached", "--quiet").returncode == 0:
        return False
    p = git(root, "commit", "-qm", "{}: journal sync".format(host))
    if p.returncode != 0:
        reason = [line for line in (p.stderr or p.stdout or "").splitlines() if line.strip()]
        s.failed("memdb-sync: commit failed", *["  git: " + line for line in reason[-3:]])
        return False
    return True


def push_own(s, root, host):
    """Push this host's branch; an unborn branch is a notice, not a failure."""
    if git(root, "rev-parse", "--verify", "-q",
           "refs/heads/{}/journal".format(host)).returncode != 0:
        s.say("memdb-sync: nothing to push yet (no commit on {}/journal)"
              .format(host))
        return
    if not git_ok(root, "push", "-q", "origin", "{}/journal".format(host)):
        s.failed("memdb-sync: push failed")


def run(full_verify=False, out=None):
    """One complete sync; returns the process exit code."""
    s = Sync(out)
    host = resolve_host(s)
    if host is None:
        return 1
    root = journal.journal_root()
    if not os.path.isdir(root):
        s.say("memdb-sync: FAIL no journal root {}".format(root))
        return 1
    if not os.path.isdir(os.path.join(root, ".git")):
        s.say("memdb-sync: FAIL journal root is not a git repo")
        return 1
    if git(root, "rev-parse", "--is-shallow-repository").stdout.strip() != "false":
        s.say("memdb-sync: FAIL shallow clone - a shallow journal repo cannot",
              "  verify chains below its boundary; re-clone with full history")
        return 1

    branch = "{}/journal".format(host)
    if not (git_ok(root, "checkout", "-q", branch)
            or git_ok(root, "checkout", "-qb", branch)):
        s.say("memdb-sync: FAIL cannot check out branch {} in {}".format(
            branch, root))
        return 1

    hub = hub_state(root)
    if hub == "drift":
        return drift_failure(s, root, host)

    flush_drafts(s)
    commit_own(s, root, host)

    if hub == "standalone":
        s.say("memdb-sync: standalone (no hub): push and fetch skipped")
    elif has_origin(root):
        push_own(s, root, host)
        ingest_others(s, root, host)
    else:
        s.failed("memdb-sync: no origin remote configured")

    need_full, stamp = full_verify_due(root)
    need_full = need_full or full_verify
    rebuilt = rebuild_verify(s, need_full)
    if rebuilt and need_full:
        with open(stamp, "w", encoding="utf-8", newline="\n") as f:
            f.write(str(int(time.time())))
    if not rebuilt:
        s.failed("memdb-sync: {}REBUILD/VERIFY FAILED".format(
            "FULL " if need_full else ""))

    if need_full and rebuilt:
        days = os.environ.get("MEMDB_EXPIRE_STATES_DAYS") or "30"
        ok, text = run_mem(["consolidate", "--expire-states", days])
        if text.strip():
            s.say(text.rstrip("\n"))
        if not ok:
            s.failed("memdb-sync: consolidate --expire-states failed")

    if rebuilt:
        with journal.lock():
            mem.write_own_witness()
        # The witness carries this host's memdb version: publish it in this run.
        if commit_own(s, root, host) and hub != "standalone" and has_origin(root):
            push_own(s, root, host)
        for line in mem.version_warnings(host):
            s.say("memdb-sync: " + line)

    if rebuilt:
        ok, text = run_mem(["render-core", "--out", paths.core_rules_file()])
        if not ok:
            s.say("memdb-sync: render-core failed (view only, sync not failed)")

    if s.fail:
        s.say("memdb-sync: FAIL (host={} root={})".format(host, root))
        return 1
    s.say("memdb-sync: ok (host={})".format(host))
    return 0


def origin_url(root):
    p = git(root, "remote", "get-url", "origin")
    return p.stdout.strip() if p.returncode == 0 and p.stdout.strip() else None


def hub_state(root):
    """'hub', 'standalone' or 'drift': git origin checked against config.json."""
    if not config.exists():
        return "hub"                    # pre-package host: origin is the truth
    hub = config.load().get("hub") or {}
    origin = origin_url(root)
    if hub.get("mode") == "standalone":
        return "standalone" if origin is None else "drift"
    want = config.hub_journal_url(hub.get("url") or "")
    return "hub" if origin and config.same_remote(origin, want) else "drift"


def drift_failure(s, root, host):
    hub = config.load().get("hub") or {}
    s.say("memdb-sync: FAIL origin {} differs from the configured hub {} ({})"
          .format(origin_url(root) or "(none)",
                  config.hub_journal_url(hub.get("url") or "") or "standalone",
                  paths.config_path()),
          "  nothing was committed, pushed or fetched; re-run mem install "
          "--hub ... --check to reconcile",
          "memdb-sync: FAIL (host={} root={})".format(host, root))
    return 1


def flush_drafts(s):
    """Journal any session that ended without an episode (S-MQ-03)."""
    if not hasattr(mem, "cmd_flush_drafts"):
        return
    ok, text = run_mem(["flush-drafts"])
    if text.strip():
        s.say(text.rstrip("\n"))


# ------------------------------------------------------------ scheduled

def scheduled(full_verify=False):
    """One sync wrapped in the timestamp header and exit line of sync.log."""
    log = os.environ.get("MEMDB_SYNC_LOG") or paths.sync_log()
    os.makedirs(os.path.dirname(log) or ".", exist_ok=True)
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime(
        "%Y-%m-%dT%H:%M:%SZ")
    buf = io.StringIO()
    buf.write("== {} scheduled sync on {} ==\n".format(stamp,
                                                       platform.node()))
    code = run(full_verify=full_verify, out=buf)
    buf.write("== exit {} ==\n".format(code))
    with open(log, "a", encoding="utf-8", newline="\n") as f:
        f.write(buf.getvalue())
    # pythonw.exe and a headless task have no usable stdout; the log is the record.
    if sys.stdout is not None and sys.stdout.isatty():
        sys.stdout.write(buf.getvalue())
    return code


def cmd_sync(args):
    if args.scheduled:
        raise SystemExit(scheduled(args.full_verify))
    raise SystemExit(run(full_verify=args.full_verify))

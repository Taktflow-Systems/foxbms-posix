#!/usr/bin/env bash
# TRANSITION WRAPPER (one release). The sync itself is Python:
#   mem sync   ==   python -m memdb sync
#
# It exists because the cron lines on the existing hosts and the old
# scheduled task still name this path, set no environment, and run from a
# foreign working directory. `mem install` re-registers the Python form and
# this file goes away. A sync may fail loudly (exit 1); a hook may not.
set -u

SRC="${BASH_SOURCE[0]//\\//}"
HERE="${SRC%/*}"
[ "$HERE" = "$SRC" ] && HERE="."
ROOT="$(cd "$HERE/../.." 2>/dev/null && { pwd -W 2>/dev/null || pwd; })"
if [ -z "${ROOT:-}" ]; then
    echo "memdb-sync: FAIL cannot locate the memdb checkout"
    exit 1
fi

pick_python() {
    if [ -n "${MEMDB_PYTHON:-}" ]; then
        printf '%s' "$MEMDB_PYTHON"
        return 0
    fi
    for cand in python3 python; do
        if command -v "$cand" >/dev/null 2>&1 \
                && "$cand" -c 'import sqlite3' >/dev/null 2>&1; then
            printf '%s' "$cand"
            return 0
        fi
    done
    if command -v py >/dev/null 2>&1 \
            && py -3 -c 'import sqlite3' >/dev/null 2>&1; then
        printf '%s' 'py -3'
        return 0
    fi
    return 1
}

if ! PY="$(pick_python)"; then
    echo "memdb-sync: FAIL no python interpreter"
    exit 1
fi

# Windows interpreters need ';' and a drive-letter path; pwd -W gave us one.
SEP=":"
case "$ROOT" in [A-Za-z]:*) SEP=";" ;; esac
export PYTHONPATH="$ROOT${PYTHONPATH:+$SEP$PYTHONPATH}"

exec $PY -m memdb sync "$@"

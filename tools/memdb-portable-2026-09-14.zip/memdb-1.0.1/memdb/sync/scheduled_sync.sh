#!/usr/bin/env bash
# TRANSITION WRAPPER (one release) for the scheduled entry point:
#   mem sync --scheduled   ==   python -m memdb sync --scheduled
# The Python form appends the timestamp header and exit line to sync.log.
# Same interpreter resolution and PYTHONPATH rule as memdb_sync.sh.
set -u

LOG="${MEMDB_SYNC_LOG:-${MEMDB_HOME:-$HOME/.claude/memory}/sync.log}"
SRC="${BASH_SOURCE[0]//\\//}"
HERE="${SRC%/*}"
[ "$HERE" = "$SRC" ] && HERE="."
ROOT="$(cd "$HERE/../.." 2>/dev/null && { pwd -W 2>/dev/null || pwd; })"

fail() {
    echo "$1"
    { echo "== scheduled sync (transition wrapper) =="; echo "$1"; echo "== exit 1 =="; } \
        >> "$LOG" 2>/dev/null
    exit 1
}

[ -n "${ROOT:-}" ] || fail "memdb-sync: FAIL cannot locate the memdb checkout"

pick_python() {
    if [ -n "${MEMDB_PYTHON:-}" ]; then
        printf '%s' "$MEMDB_PYTHON"
        return 0
    fi
    for cand in python3 python; do
        if command -v "$cand" >/dev/null 2>&1 \
                && "$cand" -c 'import sqlite3' >/dev/null 2>&1; then
            printf '%s' "$cand"
            return 0
        fi
    done
    if command -v py >/dev/null 2>&1 \
            && py -3 -c 'import sqlite3' >/dev/null 2>&1; then
        printf '%s' 'py -3'
        return 0
    fi
    return 1
}

PY="$(pick_python)" || fail "memdb-sync: FAIL no python interpreter"

SEP=":"
case "$ROOT" in [A-Za-z]:*) SEP=";" ;; esac
export PYTHONPATH="$ROOT${PYTHONPATH:+$SEP$PYTHONPATH}"

exec $PY -m memdb sync --scheduled "$@"

"""Truncated journal tails (audit 2026-09-13 F-01, plan S-AUD-01).

A journal that ends below a seq it provably reached before - the saved
verified anchor (read raw, even when stale), another host's witness entry,
or the snapshot manifest - must fail every verify path, refuse appends,
and never be swapped in or persisted as the new head.
"""
import json
import os

import pytest

from memdb import journal
from memdb import mem


def truncate(path, n):
    with open(path, "rb") as f:
        lines = f.readlines()
    with open(path, "wb") as f:
        f.writelines(lines[:-n])


def seed_cli(run, n, start=0):
    for i in range(start, start + n):
        run(["add", "--kind", "state", "--project", "p1", "--part", "core",
             "--subject", "s%d" % i, "--body", "body %d" % i])


def seed_raw(root, host, n):
    for i in range(n):
        journal.append_event(
            host, "add",
            {"kind": "state", "project": "p", "part": "x",
             "subject": "s%d" % i, "body": "b" * 40,
             "ts": "2026-01-01T00:00:00+00:00"},
            "2026-01-01T00:00:00.%06dZ" % i, root=root)


def last_report(capsys):
    return json.loads(capsys.readouterr().out.strip().splitlines()[-1])


def anchor_seq():
    path = journal.derived_path("testhost", "verified-head.json")
    with open(path, encoding="utf-8") as f:
        return json.load(f)["seq"]


# (a)
def test_verify_full_fails_on_truncated_tail(db, run, capsys):
    seed_cli(run, 6)
    assert run(["verify", "--full"])[0]["ok"] is True
    truncate(journal.host_file("testhost"), 3)
    with pytest.raises(SystemExit):
        mem.main(["verify", "--full"])
    msg = last_report(capsys)["chains"]["testhost"]
    assert "tail truncated" in msg
    assert "testhost ends at seq 3" in msg and "reached seq 6" in msg


# (b)
def test_suffix_verify_with_anchor_fails_on_truncated_tail(db, run, capsys):
    seed_cli(run, 6)
    run(["rebuild", "--full"])                  # snapshot + manifest at seq 6
    seed_cli(run, 3, start=6)
    assert run(["verify"])[0]["ok"] is True     # anchor advances to seq 9
    path = journal.host_file("testhost")
    truncate(path, 2)                           # manifest anchor stays valid
    raw = json.load(open(journal.derived_path(
        "testhost", "verified-head.json"), encoding="utf-8"))
    ok, err = journal.verify_chain(path, anchor=raw,
                                   floor_seq=journal.floor_for("testhost"))
    assert ok is False and "ends at seq 7" in err and "reached seq 9" in err
    with pytest.raises(SystemExit):
        mem.main(["verify"])
    report = last_report(capsys)
    assert report["snapshot"] == "chain damage"
    assert "tail truncated" in report["chains"]["testhost"]


# (c)
@pytest.mark.parametrize("with_snapshot", [False, True])
def test_rebuild_verify_refuses_and_keeps_live_db(db, run, with_snapshot):
    seed_cli(run, 6)
    if with_snapshot:
        run(["rebuild", "--full"])
    run(["verify", "--full"])
    truncate(journal.host_file("testhost"), 3)
    before = open(db, "rb").read()
    with pytest.raises(SystemExit) as e:
        mem.main(["rebuild", "--verify"])
    assert e.value.code == 1
    assert open(db, "rb").read() == before


def test_plain_rebuild_refuses_truncated_journal(db, run, capsys):
    seed_cli(run, 6)
    run(["verify", "--full"])
    truncate(journal.host_file("testhost"), 3)
    before = open(db, "rb").read()
    with pytest.raises(SystemExit):
        mem.main(["rebuild", "--full"])
    assert "tail truncated" in last_report(capsys)["chains"]["testhost"]
    assert open(db, "rb").read() == before


# (d)
def test_anchor_never_lowered(db, run):
    seed_cli(run, 6)
    run(["verify", "--full"])
    assert anchor_seq() == 6
    truncate(journal.host_file("testhost"), 3)
    with pytest.raises(SystemExit):
        mem.main(["verify", "--full"])
    assert anchor_seq() == 6
    with pytest.raises(SystemExit, match="refusing to lower"):
        journal.save_anchor("testhost")
    assert anchor_seq() == 6


# (e)
def test_append_refused_on_truncated_journal(db, run):
    seed_cli(run, 6)
    run(["verify", "--full"])
    path = journal.host_file("testhost")
    truncate(path, 3)
    size = os.path.getsize(path)
    with pytest.raises(SystemExit, match="refusing to append"):
        seed_cli(run, 1, start=99)
    assert os.path.getsize(path) == size


# (f)
def test_foreign_truncation_below_witness_without_anchor(tmp_path):
    root = str(tmp_path / "jr")
    seed_raw(root, "hosta", 10)
    seed_raw(root, "hostb", 1)
    with journal.lock(root):
        heads = journal.heads(root)
    journal.write_witness("hostb", {"hosta": heads["hosta"]}, root)
    patha = journal.host_file("hosta", root)
    truncate(patha, 4)
    assert journal.load_anchor("hosta", root) is None
    floor = journal.floor_for("hosta", root)
    assert floor == 10
    ok, err = journal.verify_chain(
        patha, checkpoints=journal.witness_checkpoints("hosta", root),
        floor_seq=floor)
    assert ok is False
    assert "hosta ends at seq 6" in err and "reached seq 10" in err


# (g)
def test_new_host_without_anchor_or_witness_verifies(tmp_path):
    root = str(tmp_path / "jr")
    seed_raw(root, "fresh", 3)
    assert journal.floor_for("fresh", root) == 0
    ok, err = journal.verify_chain(journal.host_file("fresh", root),
                                   floor_seq=journal.floor_for("fresh", root))
    assert ok, err


def test_new_host_cli_verify_and_rebuild_stay_green(db, run):
    seed_cli(run, 2)
    assert run(["verify", "--full"])[0]["ok"] is True
    out = run(["rebuild", "--verify"])[0]
    assert out["ok"] is True and out["record_regression"] is False


def test_doctor_reports_truncation(db, run, capsys):
    seed_cli(run, 6)
    run(["verify", "--full"])
    truncate(journal.host_file("testhost"), 1)
    with pytest.raises(SystemExit):
        mem.main(["doctor"])
    check = last_report(capsys)["checks"]["chain:testhost"]
    assert check["ok"] is False and "tail truncated" in check["detail"]


def test_manifest_seq_is_a_floor(db, run):
    seed_cli(run, 4)
    run(["rebuild", "--full"])
    manifest = json.load(open(mem.snapshot_manifest_path(), encoding="utf-8"))
    entry = manifest["hosts"]["testhost"]
    os.remove(journal.derived_path("testhost", "verified-head.json"))
    assert journal.floor_for("testhost") == 0
    assert journal.floor_for("testhost", manifest_entry=entry) == 4


# record_regression: journal lost events but every floor is gone too
def drop_floors():
    for name in ("verified-head.json", "head.json"):
        p = journal.derived_path("testhost", name)
        if os.path.exists(p):
            os.remove(p)
    for p in (mem.snapshot_manifest_path(), mem.snapshot_db_path()):
        if os.path.exists(p):
            os.remove(p)


def test_record_regression_blocks_swap(db, run, capsys):
    seed_cli(run, 6)
    run(["verify", "--full"])
    truncate(journal.host_file("testhost"), 2)
    drop_floors()
    before = open(db, "rb").read()
    with pytest.raises(SystemExit) as e:
        mem.main(["rebuild", "--verify"])
    assert e.value.code == 1
    report = last_report(capsys)
    assert report["record_regression"] is True and report["ok"] is False
    detail = report["record_regression_detail"]
    assert detail["records"] == {"live": 6, "rebuilt": 4}
    assert detail["hosts"]["testhost"] == {"live": 6, "journal": 4}
    assert open(db, "rb").read() == before


def test_accept_shrink_overrides_and_is_echoed(db, run):
    seed_cli(run, 6)
    truncate(journal.host_file("testhost"), 2)
    drop_floors()
    out = run(["rebuild", "--verify", "--accept-shrink"])[0]
    assert out["ok"] is True
    assert out["record_regression"] is True and out["accept_shrink"] is True
    assert out["records"] == 4

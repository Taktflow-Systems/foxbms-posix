"""S-PKG-02: one command installs memdb, and running it again changes nothing.

Every test redirects HOME, USERPROFILE and MEMDB_HOME into tmp_path, so
the user's real harness files and store are never touched. The OS
scheduler is faked (schedule._run) or refused (MEMDB_NO_OS_SCHEDULE).
"""
import io
import json
import os
import subprocess
import sys
import zipapp

import pytest

from memdb import config, harness, install, journal, mem, paths, schedule
from memdb.harness import claude_code

MEMDB_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_ROOT = os.path.dirname(MEMDB_DIR)

# The shape of a real user settings.json, personal paths replaced.
EXISTING_SETTINGS = {
    "model": "opusplan",
    "statusLine": {"type": "command", "command": "bash ~/.claude/status.sh"},
    "permissions": {"allow": ["Bash(git status:*)"], "deny": []},
    "hooks": {
        "PreToolUse": [
            {"matcher": "Write|Edit",
             "hooks": [{"type": "command",
                        "command": "python3 ~/.claude/hooks/limit.py"}]}
        ],
        "SessionStart": [
            {"matcher": "startup|clear|compact",
             "hooks": [{"type": "command",
                        "command": 'bash "/checkout/memdb/hooks/session_start.sh"',
                        "timeout": 20}]}
        ],
    },
}

GIT_ENV = {"GIT_AUTHOR_NAME": "memdb-test", "GIT_AUTHOR_EMAIL": "memdb-test",
           "GIT_COMMITTER_NAME": "memdb-test",
           "GIT_COMMITTER_EMAIL": "memdb-test"}


@pytest.fixture
def home(tmp_path, monkeypatch):
    """A private HOME + MEMDB_HOME with a deterministic command form."""
    root = tmp_path / "home"
    (root / ".claude").mkdir(parents=True)
    monkeypatch.setenv("HOME", str(root))
    monkeypatch.setenv("USERPROFILE", str(root))
    monkeypatch.setenv("MEMDB_HOME", str(root / ".claude" / "memory"))
    monkeypatch.setenv("PYTHONPATH", REPO_ROOT)
    for key, value in GIT_ENV.items():
        monkeypatch.setenv(key, value)
    for key in ("MEMDB_PATH", "MEMDB_JOURNAL", "MEMDB_HOST",
                "MEMDB_HOST_OVERRIDE", "MEMDB_CORE_RULES",
                "CLAUDE_CODE_SESSION_ID"):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setattr(config, "detect_command_form",
                        lambda pyz=None: ((config.FORM_PYZ, pyz) if pyz else
                                          (config.FORM_INTERPRETER,
                                           sys.executable)))
    # selftest costs seconds per install; test_install_runs_the_selftest runs it for real.
    monkeypatch.setattr(install, "selftest_result",
                        lambda: {"ran": False, "detail": "stubbed in unit tests"})
    # The real check runs whatever memdb this interpreter has installed; the preflight tests restore it.
    monkeypatch.setattr(install, "command_form_runs",
                        lambda cfg: (True, "stubbed in unit tests"))
    return root


REAL_COMMAND_FORM_RUNS = install.command_form_runs


class FakeScheduler:
    """Records every scheduler call and keeps a crontab; nothing reaches the OS."""

    def __init__(self, query_stdout="", query_rc=1):
        self.calls = []
        self.query_stdout, self.query_rc = query_stdout, query_rc
        self.crontab = query_stdout

    def __call__(self, argv, input=None):
        self.calls.append(list(argv))
        if argv[0] == "schtasks" and "/Query" in argv:
            return subprocess.CompletedProcess(argv, self.query_rc,
                                               self.query_stdout, "")
        if argv[:2] == ["crontab", "-l"]:
            return subprocess.CompletedProcess(argv, 0, self.crontab, "")
        if argv[:2] == ["crontab", "-"]:
            self.crontab = input or ""
        return subprocess.CompletedProcess(argv, 0, "", "")

    def mutating(self):
        return [c for c in self.calls
                if not ("/Query" in c or c[:2] == ["crontab", "-l"])]


class Args:
    def __init__(self, **kw):
        self.host = kw.get("host", "testbox")
        self.hub = kw.get("hub", "standalone")
        self.harness = kw.get("harness", "claude-code")
        self.schedule = kw.get("schedule", "none")
        self.pyz = kw.get("pyz")
        self.embed = kw.get("embed", "off")
        self.check = kw.get("check", False)
        self.yes = kw.get("yes", True)
        self.keep_data = kw.get("keep_data", True)
        self.purge_data = kw.get("purge_data", False)


def report_of(capsys):
    """The install report: the last top-level JSON object (generic prints the skill first)."""
    out = "\n" + capsys.readouterr().out
    return json.loads(out[out.rindex("\n{\n") + 1:])


def bare_hub(tmp_path, name="hub.git"):
    hub = tmp_path / name
    subprocess.run(["git", "init", "--bare", "-q", "-b", "main", str(hub)],
                   check=True, capture_output=True)
    return str(hub).replace("\\", "/")


def journal_lines():
    path = journal.host_file("testbox")
    if not os.path.exists(path):
        return 0
    with open(path, encoding="utf-8") as f:
        return sum(1 for _ in f)


def changes_by_kind(report, kind):
    return [c for c in report["changes"] if c.get("kind") == kind]


# ------------------------------------------------------------- installing

def test_install_creates_every_file(home, capsys):
    install.cmd_install(Args())
    report = report_of(capsys)
    assert report["applied"] is True
    assert report["host"] == "testbox"
    assert os.path.exists(paths.host_id_file())
    assert os.path.exists(paths.config_path())
    assert os.path.exists(mem.db_path())
    assert os.path.isdir(os.path.join(paths.journal_root(), ".git"))
    skill = claude_code.paths_for()["skill"]
    rule = claude_code.paths_for()["rule"]
    assert os.path.exists(skill) and os.path.exists(rule)
    settings = json.load(open(claude_code.paths_for()["settings"],
                              encoding="utf-8"))
    assert settings["autoMemoryEnabled"] is False
    cmds = [h["command"] for g in settings["hooks"]["SessionStart"]
            for h in g["hooks"]]
    assert cmds == [config.hook_command_text("session-start")]
    assert report["episode"]["uid"].startswith("testbox:")


def test_install_runs_the_selftest():
    """The real selftest: children run in their own temp home, so no fixture is needed."""
    result = install.selftest_result()
    assert result["ran"] is True and result["ok"] is True, result
    assert json.loads(result["detail"])["steps"][-1]["step"] == \
        "hook session-start"


def test_a_failing_selftest_stops_the_install_before_any_write(home,
                                                               monkeypatch):
    monkeypatch.setattr(install, "selftest_result",
                        lambda: {"ran": True, "ok": False, "detail": "boom"})
    with pytest.raises(SystemExit, match="selftest failed"):
        install.cmd_install(Args())
    assert not os.path.exists(paths.home())


def test_bare_install_writes_nothing(home, capsys):
    """Neither --check nor --yes: a look, never an apply (field test [1])."""
    settings_path = claude_code.paths_for()["settings"]
    with open(settings_path, "w", encoding="utf-8") as f:
        json.dump(EXISTING_SETTINGS, f, indent=2)
    before = open(settings_path, "rb").read()
    install.cmd_install(Args(yes=False, check=False))
    report = report_of(capsys)
    assert report["applied"] is False and report["check"] is True
    assert open(settings_path, "rb").read() == before
    assert not os.path.exists(paths.home())
    assert not os.path.exists(claude_code.paths_for()["skill"])


def test_bare_uninstall_writes_nothing(home, capsys):
    install.cmd_install(Args())
    capsys.readouterr()
    settings_path = claude_code.paths_for()["settings"]
    before = open(settings_path, "rb").read()
    install.cmd_uninstall(Args(yes=False))
    capsys.readouterr()
    assert open(settings_path, "rb").read() == before


def test_second_install_changes_nothing_and_journals_nothing(home, capsys):
    install.cmd_install(Args())
    capsys.readouterr()
    before = {p: open(p, "rb").read() for p in (
        claude_code.paths_for()["skill"], claude_code.paths_for()["rule"],
        claude_code.paths_for()["settings"], paths.host_id_file(),
        paths.config_path())}
    lines = journal_lines()
    install.cmd_install(Args())
    report = report_of(capsys)
    assert report["changed_files"] == []
    assert report["episode"] == {"recorded": False,
                                 "detail": "nothing changed"}
    assert journal_lines() == lines
    for path, data in before.items():
        assert open(path, "rb").read() == data


def test_install_finishes_with_verify_and_doctor(home, capsys):
    install.cmd_install(Args())
    report = report_of(capsys)
    assert report["verify"]["ok"] is True, report["verify"]
    assert report["doctor"]["ok"] is True, report["doctor"]
    assert report["doctor"]["warnings"] == []


def test_check_writes_nothing_and_shows_the_diff(home, capsys):
    settings_path = claude_code.paths_for()["settings"]
    with open(settings_path, "w", encoding="utf-8") as f:
        json.dump(EXISTING_SETTINGS, f, indent=2)
    before = open(settings_path, "rb").read()
    install.cmd_install(Args(check=True))
    captured = capsys.readouterr()
    report = json.loads(captured.out[captured.out.index("{\n"):])
    assert report["applied"] is False
    assert settings_path in report["changed_files"]
    assert "session_start.sh" in captured.err       # the old line, removed
    assert "-m memdb" in captured.err               # the new one
    assert open(settings_path, "rb").read() == before
    assert not os.path.exists(paths.host_id_file())


def test_check_lists_every_side_effect(home, tmp_path, capsys, monkeypatch):
    fake = FakeScheduler()
    monkeypatch.setattr(schedule, "_run", fake)
    hub = bare_hub(tmp_path)
    install.cmd_install(Args(check=True, hub="join " + hub,
                             schedule="09:30"))
    captured = capsys.readouterr()
    report = json.loads(captured.out[captured.out.index("{\n"):])
    files = [c["path"] for c in changes_by_kind(report, "file")]
    assert paths.config_path() in files and paths.host_id_file() in files
    assert mem.db_path() in files
    git = {c["path"]: c for c in changes_by_kind(report, "git")}
    assert git["journal-repo"]["changed"] is True
    assert git["origin"]["to"] == hub and git["origin"]["from"] is None
    assert git["agent.host-id"]["to"] == "testbox"
    runs = {c["path"]: c for c in changes_by_kind(report, "run")}
    assert set(runs) >= {"sync", "install-episode", "verify", "doctor"}
    assert all(r["would_run"] and not r.get("applied") for r in runs.values())
    sched = changes_by_kind(report, "schedule")
    assert len(sched) == 1 and sched[0]["changed"] is True
    assert sched[0]["path"] + " (memdb)" in captured.err
    assert "sync --scheduled" in captured.err
    assert fake.mutating() == []
    assert not os.path.exists(paths.home())


def test_check_reports_a_schedule_change_against_the_current_task(
        home, tmp_path, capsys, monkeypatch):
    if os.name != "nt":
        pytest.skip("windows task form")
    current = ("<Task><Triggers><CalendarTrigger><StartBoundary>"
               "2026-01-01T12:00:00</StartBoundary></CalendarTrigger>"
               "</Triggers><Actions><Exec><Command>conhost.exe</Command>"
               "<Arguments>--headless &quot;C:\\Git\\bin\\bash.exe&quot; -l "
               "&quot;/x/scheduled_sync.sh&quot;</Arguments></Exec>"
               "</Actions></Task>")
    monkeypatch.setattr(schedule, "_run", FakeScheduler(current, 0))
    install.cmd_install(Args(check=True, hub="join " + bare_hub(tmp_path),
                             schedule="12:00"))
    captured = capsys.readouterr()
    report = json.loads(captured.out[captured.out.index("{\n"):])
    sched = changes_by_kind(report, "schedule")[0]
    assert sched["changed"] is True
    diff = captured.err[captured.err.index(sched["path"] + " (current)"):]
    assert "-command: conhost.exe" in diff and "scheduled_sync.sh" in diff
    assert "-m memdb sync --scheduled" in diff


def test_harness_auto_detection_is_reported(home, capsys, monkeypatch):
    monkeypatch.setattr(claude_code, "cli_on_path", lambda: None)
    (home / ".claude" / "settings.json").write_text("{}", encoding="utf-8")
    (home / ".codex").mkdir()
    install.cmd_install(Args(check=True, harness=None))
    report = report_of(capsys)
    assert report["harnesses"] == ["claude-code", "codex"]
    assert report["harness_source"].startswith("auto-detected")


def test_a_claude_dir_holding_only_memdb_files_is_not_claude_code(home, capsys,
                                                                  monkeypatch):
    """A host with no agent harness has ~/.claude/memory and rules only because memdb wrote them."""
    monkeypatch.setattr(claude_code, "cli_on_path", lambda: None)
    (home / ".claude" / "memory").mkdir()
    (home / ".claude" / "rules").mkdir()
    install.cmd_install(Args(check=True, harness=None))
    report = report_of(capsys)
    assert report["harnesses"] == ["generic"], report["harness_source"]
    monkeypatch.setattr(claude_code, "cli_on_path", lambda: "/usr/bin/claude")
    install.cmd_install(Args(check=True, harness=None))
    assert report_of(capsys)["harnesses"] == ["claude-code"]


def test_the_diff_is_written_as_utf8(home, capsys, monkeypatch):
    rule_path = claude_code.paths_for()["rule"]
    with open(rule_path, "w", encoding="utf-8") as f:
        f.write("# Rules\n\nkeep \u2014 this \u2192 arrow\n")
    raw = io.BytesIO()
    monkeypatch.setattr(sys, "stderr", io.TextIOWrapper(raw, encoding="cp1252",
                                                        errors="backslashreplace"))
    install.cmd_install(Args(check=True))
    sys.stderr.flush()
    assert "\u2014".encode("utf-8") in raw.getvalue()
    assert b"\\u2192" not in raw.getvalue()


def test_settings_merge_keeps_unrelated_keys_and_order(home, capsys):
    settings_path = claude_code.paths_for()["settings"]
    with open(settings_path, "w", encoding="utf-8") as f:
        json.dump(EXISTING_SETTINGS, f, indent=2)
    install.cmd_install(Args())
    capsys.readouterr()
    after = json.load(open(settings_path, encoding="utf-8"))
    for key in ("model", "statusLine", "permissions"):
        assert after[key] == EXISTING_SETTINGS[key]
    assert list(after)[:3] == list(EXISTING_SETTINGS)[:3]
    assert after["hooks"]["PreToolUse"] == EXISTING_SETTINGS["hooks"]["PreToolUse"]
    cmds = [h["command"] for g in after["hooks"]["SessionStart"]
            for h in g["hooks"]]
    assert len(cmds) == 1 and "session_start.sh" not in cmds[0]


def test_user_files_are_backed_up_before_a_rewrite(home, capsys):
    rule_path = claude_code.paths_for()["rule"]
    with open(rule_path, "w", encoding="utf-8") as f:
        f.write("# My rules\n\nkeep me\n")
    install.cmd_install(Args())
    capsys.readouterr()
    backups = os.listdir(paths.install_backups_dir())
    assert any(b.endswith("CLAUDE.md.bak") for b in backups), backups
    assert "keep me" in open(rule_path, encoding="utf-8").read()


def test_rule_block_replaces_a_legacy_block_instead_of_stacking(home, capsys):
    rule_path = claude_code.paths_for()["rule"]
    legacy = ("# STRICT MODE\n\ndo exactly what I ask\n\n"
              "# Memory Persistence Rule (memdb)\n\n"
              "old text naming /checkout/memdb/mem.py\n\n"
              "# Plan Writing\n\nload the skill\n")
    with open(rule_path, "w", encoding="utf-8") as f:
        f.write(legacy)
    install.cmd_install(Args())
    capsys.readouterr()
    text = open(rule_path, encoding="utf-8").read()
    assert text.count("# Memory Persistence Rule (memdb)") == 1
    assert "/checkout/memdb/mem.py" not in text
    assert "# STRICT MODE" in text and "# Plan Writing" in text


def test_rule_block_keeps_the_document_readable(home, capsys):
    rule_path = claude_code.paths_for()["rule"]
    with open(rule_path, "w", encoding="utf-8", newline="") as f:
        f.write("# A\n\ntext\n\n# Memory Persistence Rule (memdb)\n\nold\n\n# B\n\nmore\n")
    install.cmd_install(Args())
    capsys.readouterr()
    text = open(rule_path, encoding="utf-8", newline="").read()
    assert "<!-- /memory-persistence-rule -->\n\n# B" in text
    assert text.endswith("more\n")


def test_a_crlf_document_stays_crlf(home, capsys):
    rule_path = claude_code.paths_for()["rule"]
    with open(rule_path, "w", encoding="utf-8", newline="") as f:
        f.write("# A\r\n\r\ntext\r\n")
    install.cmd_install(Args())
    capsys.readouterr()
    raw = open(rule_path, "rb").read()
    assert raw.count(b"\r\n") > 5
    assert b"\n" not in raw.replace(b"\r\n", b"")


def test_each_user_file_is_written_once(home, capsys):
    install.cmd_install(Args())
    report = report_of(capsys)
    paths_written = [c["path"] for c in report["changes"] if c.get("changed")]
    assert len(paths_written) == len(set(paths_written)), paths_written


def test_an_undecodable_user_file_stops_the_install(home, capsys):
    rule_path = claude_code.paths_for()["rule"]
    with open(rule_path, "wb") as f:
        f.write(b"# rules\n\xff\xfe not utf-8\n")
    with pytest.raises(SystemExit, match="not valid UTF-8"):
        install.cmd_install(Args())
    assert open(rule_path, "rb").read().endswith(b"not utf-8\n")


def test_rendered_files_carry_no_checkout_path(home, capsys):
    install.cmd_install(Args())
    capsys.readouterr()
    for path in (claude_code.paths_for()["skill"],
                 claude_code.paths_for()["rule"]):
        text = open(path, encoding="utf-8").read()
        assert MEMDB_DIR.replace("\\", "/") not in text.replace("\\", "/")
        assert "mem.py" not in text
        assert "memdb_sync.sh" not in text
        assert "{{" not in text


def test_local_additions_survive_every_render(home, capsys):
    local = os.path.join(paths.home(), "local")
    os.makedirs(local)
    with open(os.path.join(local, "skill.md"), "w", encoding="utf-8") as f:
        f.write("## 8. Local additions\n\n- stopgap handoff folder: D:/handoff\n")
    install.cmd_install(Args())
    capsys.readouterr()
    skill = open(claude_code.paths_for()["skill"], encoding="utf-8").read()
    assert "- stopgap handoff folder: D:/handoff" in skill
    install.cmd_install(Args())
    assert report_of(capsys)["changed_files"] == []


def test_install_episode_has_its_own_session_and_relative_paths(
        home, capsys, monkeypatch):
    monkeypatch.setenv("CLAUDE_CODE_SESSION_ID", "parent-session")
    install.cmd_install(Args())
    uid = report_of(capsys)["episode"]["uid"]
    conn = mem.connect()
    try:
        row = conn.execute("SELECT * FROM records WHERE uid=?", (uid,)).fetchone()
    finally:
        conn.close()
    assert row["session_id"] == "install-testbox"
    touched = json.loads(row["payload"])["current_state"]["files_touched"]
    assert touched and all(not os.path.isabs(p) for p in touched), touched


# ----------------------------------------------------------------- hubs

def test_join_a_local_bare_hub_then_sync_twice(home, tmp_path, capsys):
    hub = bare_hub(tmp_path)
    install.cmd_install(Args(hub="join " + hub, schedule=None))
    report = report_of(capsys)
    assert report["sync"]["ok"] is True, report["sync"]
    assert report["schedule"]["kind"] == "none"
    origin = subprocess.run(["git", "-C", paths.journal_root(), "remote",
                             "get-url", "origin"], capture_output=True,
                            text=True).stdout.strip()
    assert origin == hub
    env = dict(os.environ)
    for _ in range(2):
        p = subprocess.run([sys.executable, "-m", "memdb", "sync"], env=env,
                           capture_output=True, text=True, timeout=300)
        assert p.returncode == 0, p.stdout + p.stderr
        assert p.stdout.strip().splitlines()[-1] == \
            "memdb-sync: ok (host=testbox)"
    p = subprocess.run([sys.executable, "-m", "memdb", "sync", "--scheduled"],
                       env=env, capture_output=True, text=True, timeout=300)
    assert p.returncode == 0, p.stdout + p.stderr
    log = open(paths.sync_log(), encoding="utf-8").read().splitlines()
    assert log[0].startswith("== ") and "scheduled sync on" in log[0]
    assert log[-2] == "memdb-sync: ok (host=testbox)"
    assert log[-1] == "== exit 0 =="


def test_new_local_hub_is_created(home, tmp_path, capsys):
    hub = str(tmp_path / "fresh-hub.git").replace("\\", "/")
    install.cmd_install(Args(hub="new " + hub, schedule=None))
    report = report_of(capsys)
    assert os.path.isfile(os.path.join(hub, "HEAD"))
    assert report["sync"]["ok"] is True, report["sync"]


def no_git_identity(monkeypatch, tmp_path):
    """git with no user name or email and no auto-detection, as under a redirected HOME."""
    for key in GIT_ENV:
        monkeypatch.delenv(key, raising=False)
    empty = tmp_path / "empty.gitconfig"
    empty.write_text("", encoding="utf-8")
    monkeypatch.setenv("GIT_CONFIG_GLOBAL", str(empty))
    monkeypatch.setenv("GIT_CONFIG_NOSYSTEM", "1")
    monkeypatch.setenv("GIT_CONFIG_COUNT", "1")
    monkeypatch.setenv("GIT_CONFIG_KEY_0", "user.useConfigOnly")
    monkeypatch.setenv("GIT_CONFIG_VALUE_0", "true")


def test_a_hub_install_without_a_git_identity_stops_before_any_write(
        home, tmp_path, monkeypatch):
    """Field test 2026-09-13: sync could never commit, and install still exited 0."""
    hub = bare_hub(tmp_path)
    no_git_identity(monkeypatch, tmp_path)
    with pytest.raises(SystemExit, match="git-identity") as e:
        install.cmd_install(Args(hub="join " + hub, schedule=None))
    assert not os.path.exists(paths.home())
    detail = next(c["detail"] for c in json.loads(str(e.value).split(": ", 2)[2])
                  if c["check"] == "git-identity")
    assert detail.startswith("git has no user.name/user.email for the journal repo: fatal:"), detail


def test_a_failed_first_sync_fails_the_install(home, tmp_path, capsys, monkeypatch):
    monkeypatch.setattr(install, "run_sync", lambda cfg: {
        "ran": True, "ok": False, "detail": "memdb-sync: FAIL (host=testbox)"})
    with pytest.raises(SystemExit) as e:
        install.cmd_install(Args(hub="join " + bare_hub(tmp_path), schedule=None))
    assert e.value.code == 1
    assert report_of(capsys)["sync"]["ok"] is False


def test_sync_says_why_a_commit_failed(home, tmp_path, monkeypatch):
    from memdb import sync
    root = str(tmp_path / "jr")
    subprocess.run(["git", "init", "-q", root], check=True, capture_output=True)
    os.makedirs(os.path.join(root, "journal", "testbox"))
    with open(os.path.join(root, "journal", "testbox", "events.jsonl"), "w") as f:
        f.write("{}\n")
    no_git_identity(monkeypatch, tmp_path)
    out = io.StringIO()
    s = sync.Sync(out)
    assert sync.commit_own(s, root, "testbox") is False
    lines = out.getvalue().splitlines()
    assert lines[0] == "memdb-sync: commit failed"
    assert len(lines) > 1 and lines[1].startswith("  git: "), lines


def test_join_an_unreachable_hub_stops_before_any_write(home, tmp_path):
    missing = str(tmp_path / "no-such-hub.git").replace("\\", "/")
    with pytest.raises(SystemExit, match="preflight failed"):
        install.cmd_install(Args(hub="join " + missing, schedule=None))
    assert not os.path.exists(paths.home())


def test_hub_url_forms():
    assert config.is_local_hub("X:/work/hub.git")
    assert config.is_local_hub("/srv/git/memory-journal.git")
    assert config.is_local_hub("file:///srv/git/hub.git")
    assert not config.is_local_hub("sil:git/memory-journal.git")
    assert not config.is_local_hub("ssh://me@host/git/hub.git")
    assert config.hub_journal_url("sil") == "sil:git/memory-journal.git"
    assert config.hub_journal_url("sil:git/memory-journal.git") == \
        "sil:git/memory-journal.git"
    assert config.hub_journal_url("X:/work/hub.git") == "X:/work/hub.git"


# ------------------------------------------------------------ pyz form

def build_pyz(tmp_path):
    """A .pyz of this checkout's package, the way the release build makes one."""
    import shutil
    src = tmp_path / "pyz-src"
    shutil.copytree(MEMDB_DIR, src / "memdb",
                    ignore=shutil.ignore_patterns("tests", "bench", "docs",
                                                  "__pycache__"))
    target = tmp_path / "dl" / "memdb-test.pyz"
    target.parent.mkdir()
    zipapp.create_archive(str(src), str(target), main="memdb.mem:main")
    return str(target)


def test_pyz_install_copies_the_artifact_and_never_renders_dash_m(
        home, tmp_path, capsys):
    pyz = build_pyz(tmp_path)
    install.cmd_install(Args(pyz=pyz))
    capsys.readouterr()
    cfg = config.load()
    stable = os.path.join(paths.bin_dir(), "memdb.pyz")
    versioned = os.path.join(paths.bin_dir(),
                             "memdb-{}.pyz".format(mem.__version__))
    assert cfg["command_form"] == config.FORM_PYZ
    assert cfg["pyz_path"] == stable
    for path in (stable, versioned):
        assert open(path, "rb").read() == open(pyz, "rb").read()
    assert config.command("sync") == [sys.executable, stable, "sync"]
    settings = json.load(open(claude_code.paths_for()["settings"],
                              encoding="utf-8"))
    command = settings["hooks"]["SessionStart"][0]["hooks"][0]["command"]
    assert "-m memdb" not in command and "memdb.pyz" in command
    for path in (claude_code.paths_for()["skill"],
                 claude_code.paths_for()["rule"]):
        assert "-m memdb" not in open(path, encoding="utf-8").read()


# -------------------------------------------------------------- harness

def test_codex_adapter_writes_its_own_locations(home, capsys):
    (home / ".codex").mkdir()
    install.cmd_install(Args(harness="codex"))
    capsys.readouterr()
    where = harness.get("codex").paths_for()
    assert os.path.exists(where["skill"])
    rule = open(where["rule"], encoding="utf-8").read()
    assert "Codex has no SessionStart hook" in rule
    assert harness.get("codex").INCLUDE_LINE in open(where["agents"],
                                                     encoding="utf-8").read()


def test_generic_adapter_advertises_no_missing_subcommand(home, capsys):
    install.cmd_install(Args(harness="generic"))
    out = capsys.readouterr().out
    assert "mcpServers" not in out
    assert "memdb mcp" not in out and " mcp" not in out.split("{\n")[0]


# ------------------------------------------------------------ uninstall

def test_uninstall_keeps_the_data(home, capsys):
    install.cmd_install(Args())
    capsys.readouterr()
    journal_root = paths.journal_root()
    install.cmd_uninstall(Args(keep_data=True))
    capsys.readouterr()
    settings = json.load(open(claude_code.paths_for()["settings"],
                              encoding="utf-8"))
    assert not settings.get("hooks", {}).get("SessionStart")
    rule = open(claude_code.paths_for()["rule"], encoding="utf-8").read()
    assert "Memory Persistence Rule" not in rule
    assert os.path.isdir(journal_root)
    assert os.path.exists(mem.db_path())


def test_uninstall_refuses_to_purge_without_yes(home, capsys):
    install.cmd_install(Args())
    capsys.readouterr()
    with pytest.raises(SystemExit, match="needs --yes"):
        install.cmd_uninstall(Args(purge_data=True, yes=False))
    assert os.path.isdir(paths.journal_root())


# ------------------------------------------------------------- schedule

def test_schedule_name_is_per_data_home(home, monkeypatch):
    other = schedule.name_for_home()
    assert other.startswith("memdb-sync-daily-") and len(other) == 25
    monkeypatch.delenv("MEMDB_HOME")
    assert schedule.name_for_home() == "memdb-sync-daily"


def test_non_default_home_never_touches_the_os_schedule_implicitly(
        home, tmp_path, capsys, monkeypatch):
    fake = FakeScheduler()
    monkeypatch.setattr(schedule, "_run", fake)
    install.cmd_install(Args(hub="join " + bare_hub(tmp_path), schedule=None))
    report = report_of(capsys)
    assert report["schedule"]["kind"] == "none"
    assert "explicit --schedule" in report["schedule"]["note"]
    assert fake.calls == []
    install.cmd_uninstall(Args())
    capsys.readouterr()
    assert fake.calls == []


def test_explicit_schedule_uses_the_home_specific_name(home, tmp_path, capsys,
                                                       monkeypatch):
    fake = FakeScheduler()
    monkeypatch.setattr(schedule, "_run", fake)
    install.cmd_install(Args(hub="join " + bare_hub(tmp_path),
                             schedule="09:30"))
    capsys.readouterr()
    name = schedule.name_for_home()
    assert config.load()["schedule"] == {"kind": schedule.kind_for_platform(),
                                         "name": name, "time": "09:30"}
    created = fake.mutating()
    if schedule.kind_for_platform() == "cron":     # the name lives in the crontab text
        assert created and fake.crontab.rstrip().endswith("# " + name), fake.crontab
    else:
        assert created and all(name in " ".join(c) for c in created), created
    fake.calls.clear()
    install.cmd_uninstall(Args())
    capsys.readouterr()
    removed = fake.mutating()
    if schedule.kind_for_platform() == "cron":
        assert removed and name not in fake.crontab, fake.crontab
    else:
        assert removed and all(name in " ".join(c) for c in removed), removed


def test_cron_install_and_remove_keep_foreign_lines(home, monkeypatch):
    """The Linux path, on every platform: only this home's line comes and goes."""
    foreign = "*/30 * * * * /opt/backup.sh # nightly backup\n"
    fake = FakeScheduler(foreign)
    monkeypatch.setattr(schedule, "_run", fake)
    cfg = dict(config.DEFAULTS, interpreter="/usr/bin/python3",
               command_form=config.FORM_PYZ, pyz_path="/opt/memdb/bin/memdb.pyz")
    name = schedule.name_for_home()
    schedule.install(cfg, "03:17", "cron", name)
    assert fake.crontab == foreign + (
        "17 3 * * * /usr/bin/python3 /opt/memdb/bin/memdb.pyz sync --scheduled "
        "# {}\n".format(name))
    assert schedule.current_text("cron", name) is not None
    schedule.remove("cron", name)
    assert fake.crontab == foreign


def test_remove_without_a_configured_kind_touches_nothing(home, monkeypatch):
    fake = FakeScheduler()
    monkeypatch.setattr(schedule, "_run", fake)
    out = schedule.remove(None, "memdb-sync-daily")
    assert out["removed"] is False and fake.calls == []


def test_schedule_install_command_refuses_a_non_default_home_without_time(
        home, monkeypatch):
    monkeypatch.setattr(schedule, "_run", FakeScheduler())

    class A:
        action, time, kind = "install", None, None
    with pytest.raises(SystemExit, match="--time"):
        schedule.cmd_schedule(A())


def test_cron_lines_strip_only_this_homes_entry():
    text = ("0 1 * * * backup.sh\n"
            "17 3 * * * bash /x/memdb/sync/memdb_sync.sh >> log 2>&1\n"
            "0 12 * * * py /x/memdb.pyz sync --scheduled # memdb-sync-daily\n"
            "0 9 * * * py /y/memdb.pyz sync --scheduled # memdb-sync-daily-0123abcd\n")
    other = schedule.cron_lines_without_memdb(text, "memdb-sync-daily-0123abcd",
                                              default_home=False)
    assert len(other) == 3 and "0123abcd" not in "\n".join(other)
    default = schedule.cron_lines_without_memdb(text, "memdb-sync-daily",
                                                default_home=True)
    assert default == ["0 1 * * * backup.sh",
                       "0 9 * * * py /y/memdb.pyz sync --scheduled "
                       "# memdb-sync-daily-0123abcd"]


def test_windows_task_is_windowless(home):
    cfg = dict(config.DEFAULTS, interpreter="C:/Py 3/python.exe",
               host_id="testbox")
    xml = schedule.task_xml(cfg, "12:00", "memdb-sync-daily")
    assert "<Command>conhost.exe</Command>" in xml
    assert "<Arguments>--headless &quot;C:/Py 3/python.exe&quot; -m memdb " \
           "sync --scheduled</Arguments>" in xml


def test_os_schedule_is_refused_under_the_test_guard(monkeypatch):
    monkeypatch.setenv("MEMDB_NO_OS_SCHEDULE", "1")
    with pytest.raises(SystemExit, match="MEMDB_NO_OS_SCHEDULE"):
        schedule._run(["schtasks", "/Create", "/TN", "x"])


# --------------------------------------------------------------- config

def test_command_forms(home):
    cfg = dict(config.DEFAULTS)
    cfg["interpreter"] = "/usr/bin/python3"
    cfg["command_form"] = config.FORM_MEM
    assert config.command("sync", cfg=cfg) == ["mem", "sync"]
    cfg["command_form"] = config.FORM_INTERPRETER
    assert config.command("digest", "--project", "p", cfg=cfg) == [
        "/usr/bin/python3", "-m", "memdb", "digest", "--project", "p"]
    cfg["command_form"] = config.FORM_PYZ
    cfg["pyz_path"] = "/opt/memdb 1/memdb.pyz"
    assert config.command_text("sync", cfg=cfg) == \
        '/usr/bin/python3 "/opt/memdb 1/memdb.pyz" sync'


@pytest.mark.skipif(sys.version_info < (3, 11), reason="python -P needs 3.11")
def test_the_interpreter_form_never_imports_memdb_from_the_working_directory(home, tmp_path):
    """Iteration 1 incident: hooks started in a memdb checkout ran that checkout's code on the real store."""
    cfg, _ = install.build_config(Args(), config.load())
    assert cfg["safe_path"] is True
    fake = tmp_path / "checkout" / "memdb"
    fake.mkdir(parents=True)
    (fake / "__init__.py").write_text("", encoding="utf-8")
    (fake / "__main__.py").write_text("print('memdb from the working directory')",
                                      encoding="utf-8")
    p = subprocess.run(config.command("--version", cfg=cfg), cwd=str(fake.parent),
                       capture_output=True, text=True, timeout=120)
    assert p.stdout.strip() == "memdb " + mem.__version__, p.stdout + p.stderr
    assert "-P" in config.hook_command_text("session-start", cfg=cfg)


def test_windows_command_lines_survive_git_bash_and_cmd(monkeypatch):
    """Claude Code on Windows runs hooks through Git Bash, which eats backslashes."""
    monkeypatch.setattr(config, "WINDOWS", True)
    cfg = dict(config.DEFAULTS, interpreter=r"C:\Python314\python.exe",
               command_form=config.FORM_INTERPRETER)
    assert config.hook_command_text("session-start", cfg=cfg) == \
        '"C:/Python314/python.exe" -m memdb hook session-start'
    cfg.update(command_form=config.FORM_PYZ, interpreter=r"D:\Py 3\python.exe",
               pyz_path=r"D:\memdb-home\bin\memdb.pyz")
    assert config.base_text(cfg) == '"D:/Py 3/python.exe" "D:/memdb-home/bin/memdb.pyz"'
    monkeypatch.setattr(config, "WINDOWS", False)
    cfg.update(interpreter="/usr/bin/python3", pyz_path="/opt/memdb 1/memdb.pyz")
    assert config.base_text(cfg) == '/usr/bin/python3 "/opt/memdb 1/memdb.pyz"'


@pytest.mark.skipif(os.name != "nt", reason="Windows shells")
def test_registered_hook_command_runs_under_git_bash_and_cmd(home, tmp_path, capsys):
    """Run the exact settings.json command through both shells a Windows harness may use."""
    import shutil as _shutil
    install.cmd_install(Args())
    capsys.readouterr()
    settings = json.load(open(claude_code.paths_for()["settings"], encoding="utf-8"))
    command = settings["hooks"]["SessionStart"][0]["hooks"][0]["command"]
    stdin = json.dumps({"session_id": "bash-check", "cwd": str(tmp_path),
                        "hook_event_name": "SessionStart"})
    git_bash, folder = None, os.path.dirname(_shutil.which("git") or "")
    for _ in range(4):                  # git.exe lives in cmd/, bin/ or mingw64/bin/
        candidate = os.path.join(folder, "bin", "bash.exe")
        if os.path.isfile(candidate):
            git_bash = candidate
            break
        folder = os.path.dirname(folder)
    if git_bash is None:
        pytest.skip("no Git Bash next to git")
    # cmd.exe gets the raw string (shell=True), as a harness would pass it.
    for argv, shell in ((command, True), ([git_bash, "-c", command], False)):
        p = subprocess.run(argv, shell=shell, input=stdin, capture_output=True,
                           text=True, timeout=120, cwd=str(tmp_path))
        assert p.returncode == 0, (argv, p.stderr)
        assert json.loads(p.stdout)["hookSpecificOutput"]["hookEventName"] == \
            "SessionStart", (argv, p.stdout)


def test_is_memdb_command_recognises_every_form():
    assert config.is_memdb_command('bash "/x/memdb/hooks/session_start.sh"')
    assert config.is_memdb_command('"C:\\py.exe" -m memdb hook session-start')
    assert config.is_memdb_command('python /x/memdb/memdb.pyz hook session-start')
    assert config.is_memdb_command("mem hook session-start")
    assert config.is_memdb_command(
        '"C:\\Program Files\\Py\\Scripts\\mem.exe" hook session-start')
    assert config.is_memdb_command("/opt/tools/bin/mem hook session-start")
    assert not config.is_memdb_command("memo hook session-start")
    assert not config.is_memdb_command("python3 ~/.claude/hooks/limit.py")
    assert not config.is_memdb_command("")


MEM_PATH = "/opt/tools/bin/mem"


def test_mem_form_names_the_absolute_mem_path(home, monkeypatch):
    """cron and Task Scheduler run with a minimal PATH: a bare `mem` is not found."""
    cfg = dict(config.DEFAULTS, command_form=config.FORM_MEM, mem_path=MEM_PATH)
    assert config.command("sync", cfg=cfg) == [MEM_PATH, "sync"]
    monkeypatch.setattr(config, "detect_command_form",
                        lambda pyz=None: (config.FORM_MEM, MEM_PATH))
    cfg, _ = install.build_config(Args(), config.load())
    assert cfg["mem_path"] == MEM_PATH
    assert "mem_path" in config.INSTALL_OWNED_KEYS


def test_rerun_in_the_mem_form_keeps_one_session_start_hook(home):
    cfg = dict(config.DEFAULTS, command_form=config.FORM_MEM, mem_path=MEM_PATH)
    once = claude_code.settings_with_hooks({}, cfg)
    twice = claude_code.settings_with_hooks(once, cfg)
    legacy = claude_code.settings_with_hooks(
        claude_code.settings_with_hooks({}, dict(cfg, mem_path="")), cfg)
    for data in (twice, legacy):
        hooks = [h for g in data["hooks"]["SessionStart"] for h in g["hooks"]]
        assert len(hooks) == 1, hooks


def test_new_ssh_hub_creates_the_repository_origin_points_at(monkeypatch):
    calls = []

    def fake_run(argv, **kwargs):
        calls.append(argv)
        probe = argv[-1].startswith("test -f")
        return subprocess.CompletedProcess(argv, 1 if probe else 0, "", "")
    monkeypatch.setattr(install, "run", fake_run)
    record = install.create_hub("myhub:srv/journal.git", check=False)
    assert record["changed"] is True
    assert calls[-1][0] == "ssh" and "myhub" in calls[-1]
    assert "srv/journal.git" in calls[-1][-1]
    assert "memory-journal.git" not in calls[-1][-1]
    calls.clear()
    install.create_hub("myhub", check=True)
    assert "git/memory-journal.git" in calls[-1][-1] and len(calls) == 1
    # ssh runs in the home directory; a quoted ~ would create a literal "~" folder.
    assert config.ssh_repo_path("myhub:~/git/j.git") == "git/j.git"
    assert config.ssh_repo_path("ssh://me@myhub/~/git/j.git") == "git/j.git"
    assert config.ssh_repo_path("ssh://me@myhub/srv/j.git") == "/srv/j.git"


def test_new_ssh_hub_that_exists_is_not_a_change(monkeypatch):
    calls = []

    def fake_run(argv, **kwargs):
        calls.append(argv)
        return subprocess.CompletedProcess(argv, 0, "", "")
    monkeypatch.setattr(install, "run", fake_run)
    record = install.create_hub("myhub", check=False)
    assert record["changed"] is False and len(calls) == 1


def test_preflight_refuses_a_command_form_that_cannot_run_elsewhere(
        home, monkeypatch):
    """An install from a bare checkout would register `python -m memdb` that no hook can import."""
    seen = []

    def fake_run(argv, cwd=None, timeout=300, check=False, env=None):
        seen.append((argv, cwd, env))
        return subprocess.CompletedProcess(argv, 1, "",
                                           "No module named memdb")
    monkeypatch.setattr(install, "run", fake_run)
    monkeypatch.setattr(install, "command_form_runs", REAL_COMMAND_FORM_RUNS)
    cfg = dict(config.DEFAULTS, command_form=config.FORM_INTERPRETER,
               interpreter=sys.executable)
    with pytest.raises(SystemExit, match="command-form"):
        install.preflight("standalone", "", None, cfg)
    argv, cwd, env = seen[-1]
    assert argv == [sys.executable, "-m", "memdb", "--version"]
    assert "PYTHONPATH" not in env
    assert os.path.normcase(os.path.abspath(cwd)) != os.path.normcase(REPO_ROOT)


def test_preflight_refuses_a_different_installed_version(home, monkeypatch):
    def fake_run(argv, cwd=None, timeout=300, check=False, env=None):
        return subprocess.CompletedProcess(argv, 0, "memdb 0.9.0\n", "")
    monkeypatch.setattr(install, "run", fake_run)
    monkeypatch.setattr(install, "command_form_runs", REAL_COMMAND_FORM_RUNS)
    cfg = dict(config.DEFAULTS, command_form=config.FORM_INTERPRETER,
               interpreter=sys.executable)
    with pytest.raises(SystemExit, match="0.9.0"):
        install.preflight("standalone", "", None, cfg)


def test_config_show_says_when_values_are_defaults(home, capsys):
    os.makedirs(paths.home())
    with open(paths.host_id_file(), "w", encoding="utf-8") as f:
        f.write("testbox\n")

    class A:
        action, key, value = "show", None, None
    config.cmd_config(A())
    captured = capsys.readouterr()
    shown = json.loads(captured.out)
    assert shown["source"] == "defaults"
    assert shown["path"] == paths.config_path()
    assert shown["host_id_file"] == "testbox"
    assert "not this host's settings" in captured.err


def test_config_set_refuses_keys_that_install_owns(home):
    class A:
        action, key, value = "set", "hub", '{"mode": "join", "url": "x"}'
    with pytest.raises(SystemExit, match="mem install"):
        config.cmd_config(A())


def test_doctor_expects_memdb_files_and_flags_a_host_without_config(
        home, capsys):
    os.makedirs(os.path.join(paths.home(), "bin"))
    os.makedirs(os.path.join(paths.home(), "local"))
    os.makedirs(os.path.join(paths.journal_root(), "journal"))
    with open(paths.host_id_file(), "w", encoding="utf-8") as f:
        f.write("testbox\n")
    mem.main(["init"])
    capsys.readouterr()
    mem.main(["doctor"])
    report = json.loads(capsys.readouterr().out)
    assert report["checks"]["memory_dir"]["detail"]["unexpected"] == []
    assert any("no config.json" in w for w in report.get("warnings", []))
    config.save(dict(config.DEFAULTS, host_id="testbox"))
    mem.main(["doctor"])
    report = json.loads(capsys.readouterr().out)
    assert report["checks"]["memory_dir"]["detail"]["unexpected"] == []
    assert report.get("warnings", []) == []


# -------------------------------------------------------------- paths

def test_data_home_paths_are_normalised(home, monkeypatch):
    monkeypatch.setenv("MEMDB_HOME", str(home).replace("\\", "/") + "/m/")
    assert paths.host_id_file() == os.path.join(os.path.normpath(
        str(home) + "/m"), "host-id")


def test_render_core_output_is_isolated_by_the_data_home(home, monkeypatch):
    assert paths.core_rules_file() == os.path.join(
        paths.home(), "rules", "memdb-core-global.md")
    os.makedirs(paths.home())
    config.save(dict(config.DEFAULTS, core_rules="/elsewhere/core.md"))
    assert paths.core_rules_file() == "/elsewhere/core.md"
    monkeypatch.setenv("MEMDB_CORE_RULES", "/env/core.md")
    assert paths.core_rules_file() == "/env/core.md"

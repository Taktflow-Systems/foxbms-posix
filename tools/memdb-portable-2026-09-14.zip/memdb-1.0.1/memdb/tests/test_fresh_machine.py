"""S-PKG-05: a machine that never saw the checkout runs memdb from the .pyz alone.

Slow and explicit: runs only with MEMDB_RUN_SLOW=1. The .pyz under test is
MEMDB_FRESH_PYZ when set (a released artifact on a target host), else a
--worktree build of this tree. Every command runs in a temp cwd with
HOME, USERPROFILE and MEMDB_HOME in a temp directory and PYTHONPATH
removed, so the .pyz is the only memdb code the interpreter can find.
"""
import json
import os
import shutil
import subprocess
import sys

import pytest

MEMDB_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_ROOT = os.path.dirname(MEMDB_DIR)
BUILD = os.path.join(REPO_ROOT, "tools", "build_release.py")

pytestmark = [
    pytest.mark.slow,
    pytest.mark.skipif(os.environ.get("MEMDB_RUN_SLOW") != "1",
                       reason="slow: set MEMDB_RUN_SLOW=1"),
    pytest.mark.skipif(not shutil.which("git"), reason="needs git"),
]

CLAUDE_STDIN = {"session_id": "fresh-session-1",
                "transcript_path": "/nowhere/fresh.jsonl",
                "hook_event_name": "SessionStart", "source": "startup"}


@pytest.fixture(scope="module")
def pyz(tmp_path_factory):
    given = os.environ.get("MEMDB_FRESH_PYZ")
    if given:
        return os.path.abspath(given)
    if not os.path.isfile(BUILD):
        pytest.skip("no MEMDB_FRESH_PYZ and no tools/build_release.py")
    out = tmp_path_factory.mktemp("dist")
    p = subprocess.run([sys.executable, BUILD, "--out", str(out), "--no-wheel",
                        "--worktree"], capture_output=True, text=True,
                       timeout=600)
    assert p.returncode == 0, p.stdout + p.stderr
    return str(next(out.glob("memdb-*.pyz")))


class Machine:
    """One simulated machine: its own HOME and data home, the .pyz only."""

    def __init__(self, root, pyz):
        self.root, self.pyz = root, pyz
        self.home = root / "home"
        (self.home / ".claude").mkdir(parents=True)
        self.work = root / "freshproj"
        self.work.mkdir()
        self.env = {k: v for k, v in os.environ.items()
                    if not k.upper().startswith("MEMDB_")
                    and k.upper() not in ("PYTHONPATH", "CLAUDE_CODE_SESSION_ID")}
        self.env.update(HOME=str(self.home), USERPROFILE=str(self.home),
                        MEMDB_HOME=str(self.home / ".claude" / "memory"),
                        MEMDB_NO_OS_SCHEDULE="1",
                        GIT_AUTHOR_NAME="memdb-fresh", GIT_AUTHOR_EMAIL="memdb-fresh",
                        GIT_COMMITTER_NAME="memdb-fresh",
                        GIT_COMMITTER_EMAIL="memdb-fresh")

    def mem(self, *argv, stdin=None, ok=True):
        p = subprocess.run([sys.executable, self.pyz] + list(argv),
                           cwd=str(self.work), env=self.env, input=stdin,
                           capture_output=True, text=True, timeout=900)
        if ok:
            assert p.returncode == 0, (argv, p.stdout, p.stderr)
        return p

    def report(self, p):
        return json.loads(p.stdout[p.stdout.index("{\n"):])

    def settings(self):
        with open(self.home / ".claude" / "settings.json", encoding="utf-8") as f:
            return json.load(f)


def test_fresh_machine_end_to_end(tmp_path, pyz):
    hub = str(tmp_path / "hub.git").replace("\\", "/")
    first = Machine(tmp_path / "first", pyz)

    p = first.mem("install", "--host", "fresh", "--hub", "new " + hub,
                  "--harness", "claude-code", "--yes")
    report = first.report(p)
    assert report["command_form"] == "pyz"
    assert report["selftest"]["ok"] is True
    assert report["sync"]["ok"] is True, report["sync"]
    assert report["verify"]["ok"] and report["doctor"]["ok"]
    assert report["doctor"]["warnings"] == []
    assert report["schedule"]["kind"] == "none"

    first.mem("add", "--kind", "constraint", "--project", "freshproj", "--part",
              "core-setup", "--subject", "fresh-rule", "--body",
              "fresh machine rule: artifacts only")
    episode = tmp_path / "episode.json"
    episode.write_text(json.dumps({"achievement": ["fresh machine alpha episode"],
                                   "blockers": []}), encoding="utf-8")
    uid = json.loads(first.mem("record-episode", "--project", "freshproj",
                               "--part", "work", "--task", "fresh", "--json",
                               str(episode)).stdout)["uid"]
    assert uid.startswith("fresh:")

    p = first.mem("sync")
    assert p.stdout.strip().splitlines()[-1] == "memdb-sync: ok (host=fresh)"
    assert json.loads(first.mem("verify", "--full").stdout)["ok"] is True

    # The hook exactly as the harness runs it: the registered command string.
    command = first.settings()["hooks"]["SessionStart"][0]["hooks"][0]["command"]
    assert "memdb.pyz" in command and "-m memdb" not in command
    hook = subprocess.run(command, shell=True, cwd=str(first.work),
                          env=first.env, capture_output=True, text=True,
                          input=json.dumps(dict(CLAUDE_STDIN,
                                                cwd=str(first.work))),
                          timeout=120)
    assert hook.returncode == 0, hook.stderr
    ctx = json.loads(hook.stdout)["hookSpecificOutput"]["additionalContext"]
    assert "fresh machine rule: artifacts only" in ctx

    p = first.mem("install", "--host", "fresh", "--hub", "new " + hub,
                  "--harness", "claude-code", "--yes")
    again = first.report(p)
    assert again["changed_files"] == []
    assert again["episode"] == {"recorded": False, "detail": "nothing changed"}

    first.mem("uninstall", "--keep-data", "--yes")
    assert not first.settings().get("hooks", {}).get("SessionStart")
    assert json.loads(first.mem("verify", "--full").stdout)["ok"] is True

    second = Machine(tmp_path / "second", pyz)
    p = second.mem("install", "--host", "second", "--hub", "join " + hub,
                   "--harness", "claude-code", "--yes")
    assert second.report(p)["sync"]["ok"] is True
    hits = [json.loads(line) for line in second.mem(
        "search", "--query", "alpha episode", "--project", "freshproj"
    ).stdout.splitlines() if line.strip()]
    assert uid in [h["uid"] for h in hits], hits
    doctor = json.loads(second.mem("doctor").stdout)
    assert doctor["checks"]["fleet"]["detail"]["second"] != "unknown"

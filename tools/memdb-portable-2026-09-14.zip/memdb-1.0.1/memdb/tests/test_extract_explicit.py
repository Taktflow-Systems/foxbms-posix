"""Explicit status extraction for episodes (audit F-08, plan S-AUD-06).

Events written by record-episode carry payload "extract": "explicit" and
turn only subject-keyed status items into state rows; events without the
field replay with the old rule, so history is unchanged.
"""
import copy
import json

import pytest

from memdb import journal
from memdb import mem

DOC = {"achievement": ["wired the thermistor table"],
       "decisions_with_rationale": [{"decision": "use a 64-entry table",
                                     "rationale": "fits in flash"}],
       "current_state": {"summary": "table wired",
                         "status": ["narrative line one", "narrative line two"]},
       "blockers": ["rig usb hub missing"]}


def doc_file(tmp_path, doc):
    p = tmp_path / "ep.json"
    p.write_text(json.dumps(doc), encoding="utf-8")
    return str(p)


def record(run, tmp_path, doc, task="t"):
    return run(["record-episode", "--project", "p1", "--part", "x", "--task",
                task, "--json", doc_file(tmp_path, doc)])[0]


def open_rows(kind):
    conn = mem.connect()
    try:
        return [(r["subject"], r["body"]) for r in conn.execute(
            "SELECT subject, body FROM records WHERE kind=? AND project='p1' "
            "AND status='open' ORDER BY id", (kind,))]
    finally:
        conn.close()


def test_legacy_event_without_extract_field_replays_every_status_item(db, run):
    ts = "2026-08-01T00:00:00+00:00"
    journal.append_event("testhost", "episode",
                         {"project": "p1", "part": "x", "task": "legacy",
                          "session_id": None, "doc": DOC, "ts": ts}, ts)
    run(["rebuild", "--full"])
    assert [b for _, b in open_rows("state")] == ["narrative line one",
                                                  "narrative line two"]
    assert run(["verify", "--full"])[0]["ok"] is True


def test_new_episode_is_explicit_and_plain_status_makes_no_rows(db, run, tmp_path):
    ep = record(run, tmp_path, DOC)
    assert ep["children"] == {"decision": 1, "blocker": 1, "state": 0}
    assert open_rows("state") == []
    assert [b for _, b in open_rows("decision")] == ["use a 64-entry table"]
    assert [b for _, b in open_rows("blocker")] == ["rig usb hub missing"]
    events = [ev for _, ev in journal.merged_events()]
    assert events[-1]["payload"]["extract"] == "explicit"


def test_subject_keyed_status_item_creates_one_row_and_replays(db, run, tmp_path):
    doc = copy.deepcopy(DOC)
    doc["current_state"]["status"].append(
        {"subject": "table-size", "state": "table has 64 entries"})
    ep = record(run, tmp_path, doc)
    assert ep["children"]["state"] == 1
    assert open_rows("state") == [("table-size", "table has 64 entries")]
    run(["rebuild", "--full"])
    assert open_rows("state") == [("table-size", "table has 64 entries")]
    assert run(["verify", "--full"])[0]["ok"] is True


def test_plain_status_makes_no_row_while_resolves_closes(db, run, tmp_path):
    run(["add", "--kind", "blocker", "--project", "p1", "--part", "x",
         "--subject", "usb-hub-missing", "--body", "usb hub missing"])
    doc = {"achievement": ["bench rebuilt"], "resolves": ["usb-hub-missing"],
           "current_state": {"summary": "bench up", "status": [
               "usb hub missing is resolved, a new hub is fitted"]}}
    ep = record(run, tmp_path, doc)
    assert ep["children"]["state"] == 0
    assert len(ep["closed_blockers"]) == 1


def test_subject_item_without_state_text_is_rejected(db, tmp_path, capsys):
    doc = {"current_state": {"status": [{"subject": "k"}]}}
    with pytest.raises(SystemExit) as exc:
        mem.main(["record-episode", "--project", "p1", "--part", "x", "--task",
                  "t", "--json", doc_file(tmp_path, doc)])
    assert exc.value.code == 2
    assert "current_state.status[0]" in capsys.readouterr().err

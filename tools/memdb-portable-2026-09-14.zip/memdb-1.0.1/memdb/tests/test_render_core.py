"""Static global rules file and core-setup lint (audit F-06/F-09, plan
S-AUD-04).

render-core writes the open global goal/constraint/preference rows and
global runbooks as a deterministic, capped rules file that every session
loads, so project digests no longer repeat them (--no-global). core-lint
is a read-only proposal for cleaning the core-setup layer.
"""
import hashlib
import json

import pytest

from memdb import mem


def add(run, project, subject, body, kind="constraint", part="core-setup"):
    return run(["add", "--kind", kind, "--project", project, "--part", part,
                "--subject", subject, "--body", body])[0]


def render(tmp_path, capsys, name="core.md"):
    out = tmp_path / name
    mem.main(["render-core", "--out", str(out)])
    return out, json.loads(capsys.readouterr().out)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_render_core_contents_and_order(db, run, tmp_path, capsys):
    add(run, "global", "zeta", "last constraint")
    add(run, "global", "alpha", "first constraint")
    add(run, "global", "pref", "a preference", kind="preference")
    add(run, "global", "deploy", "bash deploy.sh --check", kind="runbook",
        part="ops")
    add(run, "p1", "local", "project row stays out")
    capsys.readouterr()
    out, report = render(tmp_path, capsys)
    text = out.read_text(encoding="utf-8")
    lines = text.splitlines()
    assert lines[0] == mem.CORE_RULES_HEADER
    assert text.index("first constraint") < text.index("last constraint") \
        < text.index("a preference") < text.index("deploy.sh")
    assert "- first constraint [testhost:2]" in lines
    assert "- [deploy] bash deploy.sh --check [testhost:4]" in lines
    assert "project row stays out" not in text
    assert report["rows"] == 4 and report["changed"] is True


def test_render_core_is_byte_identical_on_unchanged_db(db, run, tmp_path,
                                                       capsys):
    add(run, "global", "a", "one")
    add(run, "global", "b", "two", kind="preference")
    capsys.readouterr()
    out, _ = render(tmp_path, capsys)
    first = sha(out)
    _, report = render(tmp_path, capsys)
    assert sha(out) == first and report["changed"] is False
    other, _ = render(tmp_path, capsys, name="other.md")
    assert sha(other) == first


def test_render_core_excludes_closed_and_superseded(db, run, tmp_path, capsys):
    add(run, "global", "keep", "kept row")
    closed = add(run, "global", "gone", "closed row")
    add(run, "global", "moved", "old wording")
    add(run, "global", "moved", "new wording")          # supersedes
    run(["close", closed["uid"]])
    capsys.readouterr()
    out, _ = render(tmp_path, capsys)
    text = out.read_text(encoding="utf-8")
    assert "kept row" in text and "new wording" in text
    assert "closed row" not in text and "old wording" not in text


def test_render_core_cap_refuses_and_lists_longest(db, run, tmp_path, capsys,
                                                   monkeypatch):
    for i in range(60):
        add(run, "global", "rule-%02d" % i, ("rule %02d " % i) + "x" * 470)
    capsys.readouterr()
    out = tmp_path / "core.md"
    with pytest.raises(SystemExit) as e:
        mem.main(["render-core", "--out", str(out)])
    assert e.value.code == 2
    err = capsys.readouterr().err
    assert "exceeds the cap" in err
    assert err.count(" chars: rule-") == 10
    assert not out.exists()


def test_render_core_line_cap(db, run, tmp_path, capsys, monkeypatch):
    monkeypatch.setattr(mem, "CORE_RULES_MAX_LINES", 5)
    for i in range(6):
        add(run, "global", "r%d" % i, "short %d" % i)
    capsys.readouterr()
    with pytest.raises(SystemExit):
        mem.main(["render-core", "--out", str(tmp_path / "core.md")])


def test_no_global_digest_is_the_anchor_set_minus_global(db, run, run_text):
    add(run, "global", "g1", "global rule one")
    add(run, "global", "g2", "global rule two", kind="preference")
    add(run, "p1", "l1", "project rule one")
    add(run, "p1", "l2", "project rule two", kind="goal")
    add(run, "global", "rb", "global command", kind="runbook", part="ops")
    full = run_text(["digest", "--project", "p1", "--part", "core-setup"])
    lean = run_text(["digest", "--project", "p1", "--part", "core-setup",
                     "--no-global"])
    pinned = lambda t: {l for l in t.splitlines() if l.startswith("- (")}  # noqa: E731
    global_lines = {l for l in pinned(full)
                    if "global" in l and "project" not in l}
    assert len(global_lines) == 3
    assert pinned(lean) == pinned(full) - global_lines


def test_core_lint_reports_all_three_problem_classes(db, run, run_text,
                                                     monkeypatch):
    monkeypatch.setenv("MEMDB_CORE_BODY_MAX", "5000")
    long_body = ("Always run the bench check first. " + "Evidence line. " * 60)
    add(run, "FO4RE", "long-rule", long_body)
    for i in range(3):
        add(run, "FO4RE", "filler-%d" % i, "canonical spelling row %d" % i,
            part="other")
    add(run, "fo4re", "lower-rule", "written under the minority spelling")
    run(["add", "--kind", "state", "--project", "FO4RE", "--part",
         "core-setup", "--subject", "stray", "--body", "a stray state row"])
    run(["add", "--kind", "decision", "--project", "FO4RE", "--part",
         "core-setup", "--subject", "chosen", "--body", "a stray decision"])
    monkeypatch.delenv("MEMDB_CORE_BODY_MAX")
    report = json.loads(run_text(["core-lint", "--format", "json"]))
    actions = {i["subject"]: i for i in report["disallowed"]}
    assert set(actions) == {"stray", "chosen"}
    assert actions["stray"]["action"] == "close"
    assert actions["chosen"]["action"] == "re-add"
    assert actions["chosen"]["target_part"] == "general"
    over = report["over_cap"]
    assert [i["subject"] for i in over] == ["long-rule"]
    body = over[0]["new_body"]
    assert body.startswith("Always run the bench check first. Evidence line.")
    assert mem.SPLIT_MIN_BODY <= len(body) <= 500 and body.endswith(".")
    assert over[0]["new_rationale"].startswith("Evidence line.")
    assert body + " " + over[0]["new_rationale"] == mem._one_line(long_body)
    split = report["case_split"]
    assert [(i["project"], i["target_project"]) for i in split] == \
        [("fo4re", "FO4RE")]
    md = run_text(["core-lint"])
    assert md.startswith("# core-setup lint")
    assert "Totals: 2 disallowed, 1 over cap, 1 case-split" in md


def test_split_body_keeps_brackets_whole_and_moves_migration_tags():
    body = ("[migrated 2026-08-22 from auto-memory x/memory/y.md; kept] "
            "Bench hosts (verified 2026-04-19; see notes) are pinned. "
            + "More detail follows here. " * 30)
    short, rest = mem.split_body(body, 500)
    assert short.startswith("Bench hosts (verified 2026-04-19; see notes) "
                            "are pinned.")
    assert "[migrated" not in short and rest.endswith("kept]")


def test_split_body_skips_abbreviations():
    body = "Use the bench incl. the probe rig for every run. " + "x " * 400
    short, _ = mem.split_body(body, 500, min_len=10)
    assert short == "Use the bench incl. the probe rig for every run."


def test_split_body_cuts_at_a_word_boundary_when_no_sentence_fits():
    body = "word " * 200
    short, rest = mem.split_body(body, 100)
    assert len(short) <= 100 and short.endswith("...")
    assert rest and (short[:-3] + " " + rest).split() == body.split()

"""S-PKG-03: the SessionStart hook in Python, its markers and its budget.

Every case runs against a throwaway MEMDB_HOME (and HOME where the
user-level settings matter), never the real store.
"""
import io
import json
import os
import subprocess
import sys
import time

from memdb import config, hooks, mem

MEMDB_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_ROOT = os.path.dirname(MEMDB_DIR)
HOOK_STDIN = json.dumps({"session_id": "hook-test-session",
                         "transcript_path": "/nowhere/t.jsonl",
                         "cwd": "/nowhere",
                         "hook_event_name": "SessionStart"})


def clean_env(home, **extra):
    env = dict(os.environ)
    for key in ("MEMDB_PATH", "MEMDB_JOURNAL", "MEMDB_HOST",
                "MEMDB_HOST_OVERRIDE", "MEMDB_HOOK_SCOPE", "MEMDB_PYTHON",
                "MEMDB_BUDGET", "MEMDB_PART", "MEMDB_PROJECT"):
        env.pop(key, None)
    env.update(MEMDB_HOME=str(home), PYTHONPATH=REPO_ROOT,
               HOME=str(home.parent / "userhome"),
               USERPROFILE=str(home.parent / "userhome"),
               MEMDB_CORE_RULES=os.path.join(str(home), "no-core-rules.md"))
    env.update(extra)
    return env


def run_hook(env, cwd):
    p = subprocess.run([sys.executable, "-m", "memdb", "hook", "session-start"],
                       env=env, cwd=str(cwd), input=HOOK_STDIN,
                       capture_output=True, text=True, timeout=120)
    assert p.returncode == 0, p.stderr
    return p.stdout


def seeded(tmp_path, body="never ship on a friday"):
    home = tmp_path / "memhome"
    home.mkdir()
    (home / "host-id").write_text("pkghost\n", encoding="utf-8")
    env = clean_env(home, MEMDB_PROJECT="pkgproj")
    for argv in (["init"],
                 ["add", "--kind", "constraint", "--project", "pkgproj",
                  "--part", "core-setup", "--subject", "pkg-rule",
                  "--body", body]):
        p = subprocess.run([sys.executable, "-m", "memdb"] + argv, env=env,
                           cwd=str(tmp_path), capture_output=True, text=True,
                           timeout=120)
        assert p.returncode == 0, p.stderr
    return home, env


def test_golden_envelope(tmp_path):
    home, env = seeded(tmp_path)
    out = run_hook(env, tmp_path)
    assert out.strip() == json.dumps({"hookSpecificOutput": {
        "hookEventName": "SessionStart",
        "additionalContext": "# Memory digest: pkgproj/core-setup\n\n"
                             "## Goals and constraints (always in force)\n"
                             "- (c pkghost:1) never ship on a friday"}})
    saved = json.loads((home / "sessions" / "hook-test-session.json")
                       .read_text(encoding="utf-8"))
    assert saved["transcript_path"] == "/nowhere/t.jsonl"


def test_carriage_returns_never_reach_the_context(tmp_path):
    _, env = seeded(tmp_path, body="line one\r\nline two")
    ctx = json.loads(run_hook(env, tmp_path))["hookSpecificOutput"][
        "additionalContext"]
    assert "\r" not in ctx and "line one\nline two" in ctx


def test_empty_scope_marker(tmp_path):
    home = tmp_path / "memhome"
    home.mkdir()
    (home / "host-id").write_text("pkghost\n", encoding="utf-8")
    env = clean_env(home, MEMDB_PROJECT="nosuch")
    subprocess.run([sys.executable, "-m", "memdb", "init"], env=env,
                   cwd=str(tmp_path), check=True, capture_output=True)
    ctx = json.loads(run_hook(env, tmp_path))["hookSpecificOutput"][
        "additionalContext"]
    assert ctx == ("[memdb: no records for project nosuch (part core-setup) - "
                   "it may need backfill or the project slug may differ; "
                   "try: mem search]")


def hook_with_stdin(env, cwd, raw):
    p = subprocess.run([sys.executable, "-m", "memdb", "hook", "session-start"],
                       env=env, cwd=str(cwd), input=raw, capture_output=True, timeout=120)
    assert p.returncode == 0, p.stderr
    return json.loads(p.stdout.decode("utf-8"))["hookSpecificOutput"]["additionalContext"]


def test_a_byte_order_mark_and_bad_json_on_stdin(tmp_path):
    """Verifier iteration 2 (N2): Windows PowerShell pipes a BOM; the hook ignored the payload silently."""
    home, env = seeded(tmp_path)
    env.pop("MEMDB_PROJECT")
    env["GIT_CEILING_DIRECTORIES"] = str(tmp_path).replace("\\", "/")
    proj = tmp_path / "pkgproj"
    proj.mkdir()
    payload = json.dumps({"session_id": "bom", "cwd": str(proj), "hook_event_name": "SessionStart"})
    ctx = hook_with_stdin(env, tmp_path, b"\xef\xbb\xbf" + payload.encode("utf-8"))
    assert ctx.startswith("# Memory digest: pkgproj/core-setup")
    ctx = hook_with_stdin(env, proj, b"{not json")
    assert ctx.startswith("[memdb: hook input on stdin is not a JSON object; the project comes "
                          "from the working directory]\n# Memory digest: pkgproj/core-setup")


def test_unavailable_db_marker(tmp_path):
    home = tmp_path / "memhome"
    home.mkdir()
    (home / "mem.db").write_text("not a database", encoding="utf-8")
    env = clean_env(home, MEMDB_PROJECT="pkgproj")
    ctx = json.loads(run_hook(env, tmp_path))["hookSpecificOutput"][
        "additionalContext"]
    assert ctx == "[memdb UNAVAILABLE - run: mem doctor]"


def test_markers_name_the_installed_command_form(tmp_path):
    home = tmp_path / "memhome"
    home.mkdir()
    (home / "mem.db").write_text("not a database", encoding="utf-8")
    pyz = os.path.join(str(home), "bin", "memdb.pyz")
    config.save(dict(config.DEFAULTS, command_form=config.FORM_PYZ,
                     interpreter="/usr/bin/python3", pyz_path=pyz),
                path=os.path.join(str(home), "config.json"))
    env = clean_env(home, MEMDB_PROJECT="pkgproj")
    ctx = json.loads(run_hook(env, tmp_path))["hookSpecificOutput"][
        "additionalContext"]
    assert ctx == "[memdb UNAVAILABLE - run: /usr/bin/python3 {} doctor]".format(
        config.quote(pyz))


def test_project_scope_stands_down_for_a_user_level_registration(tmp_path):
    home, env = seeded(tmp_path)
    settings = tmp_path / "userhome" / ".claude" / "settings.json"
    settings.parent.mkdir(parents=True)
    settings.write_text(json.dumps({"hooks": {"SessionStart": [
        {"hooks": [{"command": '"/py" -m memdb hook session-start'}]}]}}),
        encoding="utf-8")
    scoped = dict(env, MEMDB_HOOK_SCOPE="project")
    assert run_hook(scoped, tmp_path) == ""
    settings.write_text(json.dumps({"hooks": {"SessionStart": [
        {"hooks": [{"command": '"C:\\Py\\Scripts\\mem.exe" hook session-start'}]}]}}),
        encoding="utf-8")
    assert run_hook(scoped, tmp_path) == ""
    settings.write_text(json.dumps({"hooks": {"SessionStart": [
        {"hooks": [{"command": "bash other.sh"}]}]}}), encoding="utf-8")
    assert json.loads(run_hook(scoped, tmp_path))["hookSpecificOutput"]
    assert json.loads(run_hook(env, tmp_path))["hookSpecificOutput"]


def test_unknown_hook_name_still_exits_zero(tmp_path):
    env = clean_env(tmp_path / "memhome")
    p = subprocess.run([sys.executable, "-m", "memdb", "hook", "nosuch"],
                       env=env, cwd=str(tmp_path), input="{}",
                       capture_output=True, text=True, timeout=120)
    assert p.returncode == 0 and "unknown hook" in p.stderr


def test_hook_runtime_budget(tmp_path, monkeypatch):
    """In-process cost of one session-start on 2,000 records: under 300 ms."""
    home = tmp_path / "memhome"
    home.mkdir()
    (home / "host-id").write_text("pkghost\n", encoding="utf-8")
    monkeypatch.setenv("MEMDB_HOME", str(home))
    monkeypatch.setenv("MEMDB_PROJECT", "pkgproj")
    monkeypatch.setenv("MEMDB_CORE_RULES", str(home / "none.md"))
    for key in ("MEMDB_PATH", "MEMDB_JOURNAL", "MEMDB_HOOK_SCOPE"):
        monkeypatch.delenv(key, raising=False)
    conn = mem.connect()
    mem.init_schema(conn)
    ts = mem.now_iso()
    conn.executemany(
        "INSERT INTO records (uid, kind, project, part, subject, body, status, "
        "confidence, created_at, last_confirmed_at) VALUES "
        "(?, ?, 'pkgproj', ?, ?, ?, 'open', 'confirmed', ?, ?)",
        [("pkghost:{}".format(i), ("constraint", "decision", "blocker")[i % 3],
          "core-setup" if i % 3 == 0 else "work", "s{}".format(i),
          "fact number {} about the bench".format(i), ts, ts)
         for i in range(2000)])
    conn.commit()
    conn.close()
    best = None
    for _ in range(3):
        monkeypatch.setattr(sys, "stdin", io.StringIO(HOOK_STDIN))
        monkeypatch.setattr(sys, "stdout", io.StringIO())
        start = time.perf_counter()
        assert hooks.main(["session-start"]) == 0
        elapsed = time.perf_counter() - start
        best = elapsed if best is None else min(best, elapsed)
    assert best < 0.300, "session-start took {:.0f} ms".format(best * 1000)

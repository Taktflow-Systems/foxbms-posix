"""Memory quality (1.1.0): similarity, write gate, blocker lifecycle, views, parts.

Design: docs/architecture-memory-quality.md.
"""
import json
import sqlite3

import pytest

from memdb import install, journal, lifecycle, mem, similar


def events(host="testhost"):
    return [e for e, _ in journal.read_events(journal.host_file(host))]


def add(run, kind, subject, body, part="core", project="p1", *extra):
    return run(["add", "--kind", kind, "--project", project, "--part", part,
                "--subject", subject, "--body", body] + list(extra))[0]


def record(run, tmp_path, doc, task, part="core", project="p1", date=None):
    p = tmp_path / (task + ".json")
    p.write_text(json.dumps(doc), encoding="utf-8")
    argv = ["record-episode", "--project", project, "--part", part, "--task", task,
            "--json", str(p)]
    return run(argv + (["--date", date] if date else []))[0]


# ------------------------------------------------------------------ similarity

def test_compound_and_family_identifiers():
    a, b = similar.Doc("Gate 15 witness pending"), similar.Doc("gate 16 witness pending")
    assert "gate-15" in a.ids and "gate-16" in b.ids
    assert similar.id_conflict(a, b)
    idf = similar.idf_table([a, b])
    assert similar.dup_score(a, b, idf) == 0.0


def test_sibling_requirement_rows_never_score_as_duplicates():
    a = similar.Doc("VBL-019 derivation is missing from the sw spec")
    b = similar.Doc("VBL-020 derivation is missing from the sw spec")
    assert similar.dup_score(a, b, similar.idf_table([a, b])) == 0.0


def test_reworded_duplicate_scores_above_threshold():
    a = similar.Doc("no dynamic allocation in firmware after init")
    b = similar.Doc("firmware must never use dynamic allocation after init")
    c = similar.Doc("the bench power supply runs at 12 volts")
    idf = similar.idf_table([a, b, c])
    assert similar.dup_score(a, b, idf) >= similar.DUP_THRESHOLD["anchor"]
    assert similar.dup_score(a, c, idf) == 0.0


def test_dates_are_not_tokens_and_numbers_are_not_identifiers():
    d = similar.Doc("full suite green as of 2026-07-20 at 17:57, 741 passed")
    assert "2026-07-20" not in d.tokens and "17:57" not in d.tokens
    assert "741" in d.tokens and d.ids == frozenset()
    assert similar.Doc("PH2-CFU-001 and VBL-019").ids == {"ph2-cfu-001", "vbl-019"}
    assert [similar.specific(t) for t in ("ph2-cfu-001", "vbl-019", "gate-15", "round-2", "a9")] \
        == [True, True, True, False, False]


def test_a_shared_date_never_resolves_a_blocker(db, run, run_text):
    blk = add(run, "blocker", "rules", ".claude/rules/dev-hosts.md states the pre-commit hook is "
              "deliberately NOT installed, but .git/hooks/pre-commit exists (dated 2026-07-20)",
              "dev-host")
    add(run, "constraint", "model", "pre-commit and pre-push hooks are live; vcan0 works; full "
        "SIL suite green as of 2026-07-20; rules are recorded in .claude/rules/dev-hosts.md",
        "core-setup")
    report = json.loads(run_text(["review-blockers", "--project", "p1", "--format", "json"]))
    assert blk["uid"] not in {p["uid"] for p in report["proposals"]}


def test_a_month_or_since_before_a_year_is_never_an_identifier():
    """Review finding 13: 'July 2026' became the specific identifier july-2026 and closed an unrelated blocker."""
    for text in ("pending since July 2026", "the Sept 2026 review", "open since 2026"):
        assert similar.Doc(text).ids == frozenset(), text
    assert "gate-15" in similar.Doc("Gate 15 witness").ids and "gate-2026" in similar.Doc("Gate 2026").ids


def test_a_shared_month_and_year_never_close_a_blocker(db, run, run_text):
    for n in range(12):
        add(run, "state", "filler-%d" % n, "the bench harness %d for rig%d is wired and the spec review is "
            "still open" % (n, n), "misc")
    blk = add(run, "blocker", "sign", "power stage signoff from the OEM pending since July 2026", "hw")
    add(run, "state", "rev", "the July 2026 thermal review is closed", "hw2")
    assert blk["uid"] not in proposals_of(run_text)


def test_negation_and_resolution_cues():
    assert similar.Doc("the rig is not online").negated
    assert not similar.Doc("the rig is online").negated
    assert similar.resolves(None, "the cal table is now created and committed")
    assert not similar.resolves(None, "the cal table is still missing")


def test_hygiene_flags():
    row = {"kind": "decision", "body": "ran the tests and they passed", "part": "x",
           "project": "p1", "subject": "s"}
    assert "narrative-decision" in lifecycle.hygiene_flags(row)
    assert lifecycle.hidden({"kind": "blocker", "body": "none", "part": "x",
                             "project": "p1", "subject": "s"})
    assert lifecycle.hidden({"kind": "state", "body": "x", "part": "memdb-selftest",
                             "project": "p1", "subject": "s"})
    assert lifecycle.display_body({"body": '{"a": "b", "n": 1}'}) == "a: b; n: 1"


# ------------------------------------------------------------------ write gate

def test_write_gate_refuses_a_reworded_duplicate_under_another_subject(db, run, capsys):
    old = add(run, "constraint", "no-heap", "no dynamic allocation in firmware after init")
    before = len(events())
    with pytest.raises(SystemExit) as exc:
        add(run, "constraint", "heap-ban",
            "firmware must never use dynamic allocation after init")
    assert exc.value.code == 2
    err = capsys.readouterr().err
    assert "refused, nothing was journaled" in err and old["uid"] in err
    assert len(events()) == before


def test_write_gate_refuses_a_paraphrased_constraint(db, run):
    """Verifier iteration 5 (N2): two ordinary paraphrases of an open constraint scored 0.461 and 0.483 and were added."""
    add(run, "constraint", "no-heap", "No dynamic memory allocation (no malloc/new) in production firmware; "
        "no exceptions or RTTI.", "core-setup")
    add(run, "constraint", "merge-only", "Direct commits to the main branch are forbidden for every agent on "
        "every host; use merges.", "core-setup")
    for subject, body in (("heap", "Production firmware must never allocate memory dynamically, and must not "
                                   "use exceptions or RTTI."),
                          ("main", "main is merge-only: no agent commits to main directly, on any host")):
        with pytest.raises(SystemExit) as exc:
            add(run, "constraint", subject, body, "core-setup")
        assert exc.value.code == 2


def test_a_letter_label_names_a_different_fact(db, run, run_text):
    """Verifier iteration 6 (N1, N2): 'Gate A' and 'Gate B' lost their letters, so one blocker restated the other."""
    add(run, "constraint", "domain-h", "Hardware requirement Domain H remains open until the bench review", "hw")
    added = add(run, "constraint", "domain-d", "Hardware requirement Domain D remains open until the bench review",
                "hw")
    assert added["action"] == "added"
    old = add(run, "blocker", "gate-a-witness", "Gate A witness evidence is still missing for the bench package",
              "bench")
    add(run, "blocker", "gate-b-witness", "Gate B witness evidence is still missing for the bench package",
        "bench", "p1", "--sibling")
    assert proposals_of(run_text).get(old["uid"], {}).get("action") != "supersede"
    wide = similar.Doc("Hardware Domains D through I remain open and must still be authored")
    narrow = similar.Doc("Hardware Domains H and I remain open and must still be authored")
    assert not similar.id_conflict(wide, narrow)     # the narrowed list restates the range (real 335/4 -> 339/4)
    a, b = similar.Doc("Option A keeps the relay"), similar.Doc("Option B keeps the relay")
    assert similar.id_conflict(a, b) and not similar.id_conflict(similar.Doc("the A-sample board"),
                                                                 similar.Doc("the B-sample board"))


def test_sibling_and_supersedes_are_the_two_ways_past_the_gate(db, run):
    old = add(run, "constraint", "no-heap", "no dynamic allocation in firmware after init")
    sib = add(run, "constraint", "heap-ban",
              "firmware must never use dynamic allocation after init", "core", "p1",
              "--sibling")
    assert sib["action"] == "added" and sib["near_duplicates"][0]["uid"] == old["uid"]
    new = add(run, "constraint", "heap-rule",
              "firmware never uses dynamic allocation after init or in isrs", "core",
              "p1", "--supersedes", old["uid"])
    assert new["superseded"] == old["uid"]
    assert old["uid"] not in [d["uid"] for d in new.get("near_duplicates", [])]
    got = run(["get", old["uid"]])[0]
    assert got["status"] == "superseded" and got["superseded_by"] == new["uid"]
    run(["rebuild", "--full"])
    assert run(["verify", "--full"])[0]["ok"] is True


def test_supersedes_must_name_an_open_row_of_the_same_project_and_kind(db, run):
    dec = add(run, "decision", "store", "use sqlite for the store")
    with pytest.raises(SystemExit, match="is p1/decision, not p1/blocker"):
        add(run, "blocker", "b", "store is slow", "core", "p1", "--supersedes", dec["uid"])
    with pytest.raises(SystemExit, match="not a record"):
        add(run, "decision", "d", "x y", "core", "p1", "--supersedes", "testhost:99")


def test_same_subject_still_supersedes_without_the_gate(db, run):
    add(run, "decision", "storage", "use sqlite for the event store")
    out = add(run, "decision", "storage", "use sqlite with wal for the event store")
    assert out["action"] == "superseded"


def test_created_at_back_dates_an_imported_fact(db, run):
    out = add(run, "state", "s", "imported fact", "core", "p1", "--created-at", "2025-03-04")
    assert run(["get", out["uid"]])[0]["created_at"] == "2025-03-04T00:00:00+00:00"
    with pytest.raises(SystemExit, match="--created-at"):
        add(run, "state", "t", "bad date", "core", "p1", "--created-at", "March")


def test_created_at_is_stored_in_utc_and_rows_are_ordered_by_time(db, run):
    """Review finding 14: '2026-04-10T20:00:00-05:00' sorted before '2026-04-11T00:30:00+00:00' as a string."""
    east = add(run, "state", "offset", "an imported fact with an offset", "core", "p1",
               "--created-at", "2026-04-10T20:00:00-05:00")
    assert run(["get", east["uid"]])[0]["created_at"] == "2026-04-11T01:00:00.000000+00:00"
    offset = {"created_at": "2026-04-10T20:00:00-05:00", "uid": "h:1"}
    utc = {"created_at": "2026-04-11T00:30:00+00:00", "uid": "h:2"}
    assert lifecycle.later(offset, utc) and not lifecycle.later(utc, offset)
    assert lifecycle.later({"created_at": "unparsed-b", "uid": "h:1"}, {"created_at": "unparsed-a", "uid": "h:2"})


# ------------------------------------------------------------------ episodes

def test_resolves_is_required_once_the_part_has_open_blockers(db, run, tmp_path, capsys):
    blk = add(run, "blocker", "rig", "hil rig offline waiting for a usb hub")
    before = len(events())
    with pytest.raises(SystemExit) as exc:
        record(run, tmp_path, {"achievement": ["wired the usb hub"]}, "one")
    assert exc.value.code == 2
    assert blk["uid"] in capsys.readouterr().err and len(events()) == before
    # another part has no open blockers: no requirement there
    record(run, tmp_path, {"achievement": ["docs"]}, "docs", part="docs")
    out = record(run, tmp_path, {"achievement": ["hub fitted"], "resolves": [blk["uid"]]},
                 "two")
    assert len(out["closed_blockers"]) == 1 and out["open_blockers"]["count"] == 0


def test_the_open_blocker_count_is_never_capped_at_the_listed_ten(db, run, tmp_path, capsys):
    """Review finding 12: 15 open blockers were reported as count 10, the length of the ranked list."""
    record(run, tmp_path, {"achievement": ["seeded"], "resolves": [], "blockers": [
        "relay board %d on rig K%03d is broken" % (i, i * 7) for i in range(15)]}, "seed", part="hil")
    with pytest.raises(SystemExit):
        record(run, tmp_path, {"achievement": ["looked at the rigs"]}, "look", part="hil")
    assert "part hil has 15 open blocker(s)" in capsys.readouterr().err
    out = record(run, tmp_path, {"achievement": ["looked at the rigs"], "resolves": []}, "look", part="hil")
    assert out["open_blockers"]["count"] == 15 and len(out["open_blockers"]["top"]) == 5


def test_none_text_separates_empty_slots_from_real_blockers():
    for text in ("none", "None.", "n/a", "None - all clear", "none for the repo-sync task itself",
                 "none in the active source-layer gate set", ""):
        assert lifecycle.none_text(text), text
    for text in ("None of the three rigs boot after flashing", "Nothing works after the update",
                 "no bench power supply on site"):
        assert not lifecycle.none_text(text), text


def test_nothing_before_a_preposition_is_a_real_blocker(db, run, tmp_path):
    """Review finding 4: 'Nothing on the bench boots ...' read as an empty slot, hidden and closed at high."""
    texts = ("Nothing on the bench boots after flashing the new bootloader",
             "Nothing in CI exercises the bootloader update path")
    for text in texts:
        assert not lifecycle.none_text(text), text
        assert not lifecycle.hidden({"kind": "blocker", "body": text, "part": "hil", "project": "p1",
                                     "subject": "s"}), text
    out = record(run, tmp_path, {"blockers": list(texts)}, "bench", part="hil")
    assert out["children"]["blocker"] == 2


def test_episode_blocker_body_none_is_rejected(db, run, tmp_path, capsys):
    for text in ("None.", "n/a", "None - all clear", "none for the merge itself", ""):
        with pytest.raises(SystemExit):
            record(run, tmp_path, {"blockers": [text]}, "t")
        assert "is not a blocker" in capsys.readouterr().err
    out = record(run, tmp_path, {"blockers": ["None of the three rigs boot after flashing"]},
                 "real")
    assert out["children"]["blocker"] == 1


def test_back_dated_episode_keeps_a_full_time(db, run, tmp_path):
    out = record(run, tmp_path, {"achievement": ["x"]}, "old", date="2026-01-02")
    created = run(["get", out["uid"]])[0]["created_at"]
    assert created.startswith("2026-01-02T") and len(created) > 20
    assert mem.episode_ts("2026-01-02")[10:] != "T00:00:00+00:00"


def test_a_dated_episode_is_never_later_than_now(db, run, run_text, tmp_path, monkeypatch):
    """Review finding 11: a local date one day ahead of UTC put the episode in the future, above later handoffs."""
    night_now = "2026-09-13T20:00:00.000000+00:00"
    monkeypatch.setattr(mem, "now_iso", lambda: night_now)
    night = record(run, tmp_path, {"date": "2026-09-14", "achievement": ["night job"],
                                   "next_steps": ["OLD night step"],
                                   "blockers": ["gateway firmware image missing"]}, "night", part="w")
    assert run(["get", night["uid"]])[0]["created_at"] <= night_now
    monkeypatch.setattr(mem, "now_iso", lambda: "2026-09-14T02:00:00.000000+00:00")
    record(run, tmp_path, {"date": "2026-09-14", "achievement": ["gateway firmware image landed"],
                           "next_steps": ["NEW morning step"], "resolves": []}, "morning", part="w")
    text = run_text(["digest", "--project", "p1", "--part", "w"])
    assert "NEW morning step" in text and "OLD night step" not in text


def test_episode_item_supersedes_journals_a_review_event(db, run, tmp_path):
    old = add(run, "decision", "store", "use sqlite for the store")
    out = record(run, tmp_path, {"decisions_with_rationale": [
        {"decision": "use sqlite with wal for the store", "rationale": "readers",
         "supersedes": old["uid"]}]}, "wal")
    assert out["review"]["superseded"] == 1
    assert events()[-1]["type"] == "review"
    assert run(["get", old["uid"]])[0]["status"] == "superseded"
    run(["rebuild", "--full"])
    assert run(["get", old["uid"]])[0]["status"] == "superseded"
    assert run(["verify", "--full"])[0]["ok"] is True


def test_item_supersedes_names_a_uid_of_the_same_project_and_kind_family(db, run, tmp_path, capsys):
    """Review finding 10: "supersedes": "1" was resolved as a local id and superseded another project's row."""
    other = add(run, "decision", "radio", "other project decision about the radio stack", "a", "other")
    blk = add(run, "blocker", "rig", "the gateway rig has no scheduler trace", "a")
    add(run, "decision", "sched", "use zephyr scheduler for the gateway", "a")
    before = len(events())
    for target in ("1", other["uid"], blk["uid"], "testhost:99"):
        with pytest.raises(SystemExit) as exc:
            record(run, tmp_path, {"achievement": ["moved the scheduler"], "decisions_with_rationale": [
                {"decision": "use freertos scheduler for the gateway instead", "supersedes": target}],
                "resolves": []}, "move", part="a")
        assert exc.value.code == 2, target
        assert target in capsys.readouterr().err, target
    assert len(events()) == before
    assert run(["get", other["uid"]])[0]["status"] == "open"


def test_selftest_parts_are_reserved(db, run, tmp_path, capsys):
    with pytest.raises(SystemExit):
        record(run, tmp_path, {"achievement": ["x"]}, "t", part="memdb-selftest")
    assert "reserved for project selftest" in capsys.readouterr().err


# ------------------------------------------------------------------ get and search views

def test_get_returns_the_payload_once_with_uids(db, run, tmp_path):
    ep = record(run, tmp_path, {"achievement": ["calibrated the table"],
                                "decisions_with_rationale": [
                                    {"decision": "keep table v2", "rationale": "drift"}]},
                "cal")
    got = run(["get", ep["uid"]])[0]
    assert isinstance(got["payload"], dict) and "fulltext" not in got
    assert got["id"] == ep["episode_id"]
    child = run(["search", "--query", "keep table v2", "--kind", "decision"])[0]
    assert run(["get", child["uid"]])[0]["source"] == ep["uid"]
    raw = run(["get", ep["uid"], "--raw"])[0]
    assert isinstance(raw["payload"], str) and raw["fulltext"]
    assert len(json.dumps(got)) < len(json.dumps(raw))


def test_search_lines_carry_date_status_and_successor(db, run, run_text):
    a = add(run, "decision", "store", "use sqlite for the store")
    b = add(run, "decision", "store-v2", "use sqlite with wal for the store", "core",
            "p1", "--sibling")
    run(["supersede", a["uid"], "--by", b["uid"]])
    hits = run(["search", "--query", "sqlite store", "--project", "p1"])
    old = [h for h in hits if h["uid"] == a["uid"]][0]
    assert old["status"] == "superseded" and old["by"] == b["uid"]
    assert old["date"] == mem.now_iso()[:10] and "id" not in old
    assert hits[0]["uid"] == b["uid"]
    assert run_text(["search", "--query", "zzzunmatched"]).strip() == "0 results"


def test_a_query_of_stop_words_and_an_unknown_term_finds_nothing(db, run, run_text):
    """Field test iteration 1: 'zzzz no such words' matched every row holding 'such'."""
    add(run, "decision", "placeholders", "keep generic placeholders such as HOME in old notes")
    assert run_text(["search", "--query", "zzzz no such words"]).strip() == "0 results"
    assert run(["search", "--query", "such placeholders"])[0]["subject"] == "placeholders"
    assert run_text(["search", "--query", "the"]).strip() == "0 results"


def test_an_all_caps_stop_word_in_a_query_is_an_acronym(db, run, run_text):
    """Review finding 8: 'CAN' was dropped as the stop word 'can', so the query printed 0 results."""
    add(run, "decision", "can-bitrate", "CAN bus runs at 500 kbit on the body ECU", "net")
    hits = run(["search", "--query", "CAN", "--project", "p1"])
    assert [h["subject"] for h in hits] == ["can-bitrate"]
    assert mem.query_terms("OUT of ALL frames") == ["OUT", "ALL", "frames"]
    assert run_text(["search", "--query", "zzzz no such words"]).strip() == "0 results"


def test_a_blocker_closed_through_resolves_names_the_episode(db, run, tmp_path):
    """Verifier iteration 1 (N9): a resolves close left no trace of which episode closed it."""
    record(run, tmp_path, {"achievement": ["x"], "blockers": ["the rig has no usb hub"]}, "one")
    blk = run(["search", "--query", "usb hub", "--kind", "blocker"])[0]
    second = record(run, tmp_path, {"achievement": ["hub fitted"], "resolves": [blk["uid"]]},
                    "two")
    assert run(["get", blk["uid"]])[0]["closed_by"] == second["uid"]


def test_core_setup_next_steps_name_their_part_and_date(db, run, run_text, tmp_path):
    """Verifier iteration 1 (N8): the session-start view showed another part's steps unlabelled."""
    ep = record(run, tmp_path, {"achievement": ["x"], "next_steps": ["verify the TRACE32 data set"],
                                "resolves": []}, "hil", part="hil-smu")
    out = run_text(["digest", "--project", "p1", "--part", "core-setup"])
    assert "- (n {}, hil-smu, {}) verify the TRACE32 data set".format(
        ep["uid"], mem.now_iso()[:10]) in out


def test_a_handoff_with_no_next_step_shows_none(db, run, run_text, tmp_path):
    """Verifier iteration 2 (N5): 'none; verdict list returned to orchestrator' was listed as a next step."""
    record(run, tmp_path, {"achievement": ["x"], "next_steps": ["flash the rig"], "resolves": []},
           "one", part="rig")
    record(run, tmp_path, {"achievement": ["y"], "next_steps": ["none; verdict list returned"],
                           "resolves": []}, "two", part="rig")
    out = run_text(["digest", "--project", "p1", "--part", "core-setup"])
    assert "verdict list returned" not in out and "flash the rig" not in out


def test_empty_list_and_nothing_left_bodies_are_not_blockers():
    for text in ("[]", "no structural blocker remains", "No remaining blockers."):
        assert lifecycle.none_text(text), text
    assert not lifecycle.none_text("no structural review of the pack harness exists yet")


def test_record_episode_names_closed_blockers_by_uid(db, run, tmp_path):
    first = record(run, tmp_path, {"achievement": ["x"], "blockers": ["the rig has no usb hub"]},
                   "one")
    blk = run(["search", "--query", "usb hub", "--kind", "blocker"])[0]
    out = record(run, tmp_path, {"achievement": ["hub fitted"], "resolves": [blk["uid"]]}, "two")
    assert out["closed_blockers"] == [blk["uid"]] and first["uid"] != blk["uid"]


def test_a_newer_closure_outranks_older_rows_that_call_the_item_pending(db, run):
    stale = add(run, "blocker", "cfu", "PH2-CFU-001 still needs external signoff for the "
                "authority and sequence package", "l0")
    keep = add(run, "decision", "cfu-active", "keep PH2-CFU-001 active until the OEM signs "
               "the authority package", "l0")
    other = add(run, "blocker", "cfu2", "PH2-CFU-002 still needs the witness workflow", "l0")
    closed = add(run, "decision", "cfu-closed", "treat the OEM message as the formal closure "
                 "event for PH2-CFU-001 and promote the authority split", "l0")
    hits = run(["search", "--query", "PH2-CFU-001 authority signoff", "--project", "p1"])
    assert hits[0]["uid"] == closed["uid"]
    shadowed = {h["uid"]: h.get("newer") for h in hits}
    assert shadowed[stale["uid"]] == closed["uid"] and shadowed[keep["uid"]] == closed["uid"]
    hits = run(["search", "--query", "PH2-CFU-002 witness", "--project", "p1"])
    assert hits[0]["uid"] == other["uid"] and "newer" not in hits[0]


def test_a_same_day_closure_shadows_the_pending_row_whatever_the_uid_order(db, run):
    """Imported history: both rows carry 2026-04-11 and the closure has the lower uid."""
    closure = add(run, "decision", "closed", "treat the OEM message as the formal closure event "
                  "for PH2-CFU-001 and promote the accepted authority split", "l0", "p1",
                  "--created-at", "2026-04-11")
    blk = add(run, "blocker", "open", "OEM confirmation for PH2-CFU-001 is still missing, so the "
              "energy boundary remains blocked", "l0", "p1", "--created-at", "2026-04-11")
    hits = run(["search", "--query", "PH2-CFU-001 OEM authority", "--project", "p1"])
    order = [h["uid"] for h in hits]
    assert order.index(closure["uid"]) < order.index(blk["uid"])
    assert hits[order.index(blk["uid"])]["newer"] == closure["uid"]


def test_now_has_reports_the_item_finished(db, run):
    blk = add(run, "blocker", "thr9", "THR-009 still lacks a direct signer-trust witness", "sec")
    done = add(run, "state", "thr9-done", "THR-009 now has a direct CONFIG-side signer-trust "
               "witness and aligned acceptance surfaces", "sec")
    hits = {h["uid"]: h for h in run(["search", "--query", "THR-009 witness", "--project", "p1"])}
    assert hits[blk["uid"]]["newer"] == done["uid"]


def test_the_same_subject_reported_complete_shadows_the_row_calling_it_pending(db, run):
    """Field test iteration 2 (S2): 'OEM round-2 review is still pending' ranked first after 'is complete'."""
    blk = add(run, "blocker", "r2", "OEM round-2 review is still pending, so bilateral contract "
              "closure cannot proceed yet.", "neg", "p1", "--created-at", "2026-04-09")
    done = add(run, "state", "r2-done", "OEM round-2 review is complete for the 46 reopened rows, "
               "and the matrix records 9 rejected rows.", "neg", "p1", "--created-at", "2026-04-10")
    other = add(run, "blocker", "r3", "OEM round-3 review is still pending for the contract "
                "closure.", "neg", "p1", "--created-at", "2026-04-09")
    hits = {h["uid"]: h for h in run(["search", "--query", "OEM contract closure round 2 review",
                                      "--project", "p1"])}
    assert hits[blk["uid"]]["newer"] == done["uid"]
    assert "newer" not in hits[other["uid"]]


def test_a_blocker_is_pending_by_kind_and_a_closure_may_span_a_semicolon(db, run):
    """Field test iteration 2 (L0-2): 'SE_05 and SE_09 need clarification' ranked above 'anomalies resolved; ... SE_05'."""
    blk = add(run, "blocker", "se", "SE_05 prot_arbiter and SE_09 veh_ingress need period-vs-deadline "
              "clarification in sw_architecture task rows", "l0", "p1", "--created-at", "2026-04-17")
    other = add(run, "blocker", "se7", "SE_07 cell_monitor needs period-vs-deadline clarification in "
                "sw_architecture task rows", "l0", "p1", "--created-at", "2026-04-17")
    done = add(run, "state", "se-done", "task_set row anomalies resolved; WdgM supervision promoted "
               "for SE_05 and SE_09", "l0", "p1", "--created-at", "2026-04-17")
    hits = {h["uid"]: h for h in run(["search", "--query", "SE_05 SE_09 deadline clarification",
                                      "--project", "p1"])}
    assert hits[blk["uid"]]["newer"] == done["uid"]
    assert "newer" not in hits[other["uid"]]


def test_a_row_is_never_shadowed_by_its_own_episode(db, run):
    """Verifier iteration 3 (N1): imported blocker 1205/4 carried newer = its own episode 1205 ('review is complete')."""
    ts = "2026-04-10T00:00:00+00:00"
    journal.append_event("testhost", "episode", {
        "project": "p1", "part": "neg", "task": "writeback", "session_id": None, "ts": ts, "doc": {
            "current_state": {"summary": "OEM round-2 review is complete for the 46 reopened rows"},
            "achievement": ["wrote the OEM round-2 dispositions"],
            "blockers": ["The round-2 baseline is not fully closed because 9 reopened rows remain "
                         "rejected after OEM review"]}}, ts)
    run(["rebuild", "--full"])
    hits = run(["search", "--query", "why OEM refused contract closure after round 2", "--project", "p1"])
    blk = [h for h in hits if h["kind"] == "blocker"][0]
    assert "newer" not in blk


def test_a_quoted_file_name_finds_the_row_that_holds_it(db, run, tmp_path):
    """Verifier iteration 5 (N1): 'START-HERE.md' matched only the word 'start', so the row naming the file ranked 203."""
    for n in range(150):
        add(run, "decision", "filler-{}".format(n), "gate {} evidence recorded for package {} owners".format(n, n),
            "dev", "p1", "--sibling")
    for n in range(60):
        add(run, "decision", "start-readiness-{}".format(n), "start readiness review {} opens the start of "
            "boundary work".format(n), "dev", "p1", "--sibling")
    target = record(run, tmp_path, {"current_state": {"summary": "master plan refresh landed on main"},
                                    "achievement": ["refreshed the master plan", "key_shas: new "
                                                    "docs/START-HERE.md, private-IP removed, dead refs dropped"]
                                    + ["plan section {} rewritten with gate {} evidence and owner notes for "
                                       "boundary work package {}".format(n, n + 1, n + 2) for n in range(40)],
                                    "resolves": []}, "plan-refresh", "dev")
    hits = [h["uid"] for h in run(["search", "--query", "START-HERE.md", "--project", "p1"])]
    assert target["uid"] in hits[:3]


def test_a_file_name_with_digits_is_matched_as_a_phrase(db, run, tmp_path):
    """Verifier iteration 6 (N6): 'l0-active-leaf-mcdc-register.yaml' was skipped because the name holds a digit."""
    for n in range(150):
        add(run, "decision", "filler-{}".format(n), "gate {} evidence recorded for package {} owners".format(n, n),
            "dev", "p1", "--sibling")
    for n in range(60):
        add(run, "decision", "l0-leaf-{}".format(n), "L0 active leaf review {} opens the L0 register of the "
            "package".format(n), "dev", "p1", "--sibling")
    holders = [record(run, tmp_path, {"current_state": {"summary": "qualification wave {} landed".format(w)},
                                      "achievement": ["wave {} wired l0-active-leaf-mcdc-register.yaml".format(w)]
                                      + ["package section {} rewritten with gate {} evidence and owner notes "
                                         "for wave {}".format(n, n + 1, w) for n in range(40)],
                                      "resolves": []}, "wave-{}".format(w), "dev")["uid"] for w in range(3)]
    hits = [h["uid"] for h in run(["search", "--query", "l0-active-leaf-mcdc-register.yaml", "--project", "p1"])]
    assert set(holders) <= set(hits[:3])


def test_newer_never_names_a_superseded_neighbour(db, run):
    """Verifier iteration 5 (C6): the topic and closure shadows took a superseded pool row as the newer one."""
    old = add(run, "decision", "mcu", "BMC production target MCU choice is the STM32 family for the board", "hw")
    mid = add(run, "decision", "mcu2", "BMC production target MCU choice is the TMS570 family for the board",
              "hw", "p1", "--sibling")
    end = add(run, "decision", "mcu3", "the AURIX TC375 replaces the TMS570 for the BMC board", "hw", "p1",
              "--supersedes", mid["uid"])
    hits = {h["uid"]: h for h in run(["search", "--query", "BMC production target MCU choice board",
                                      "--project", "p1", "--limit", "20"])}
    assert hits[old["uid"]].get("newer") in (None, end["uid"])


def test_a_newer_closed_row_of_another_kind_never_topic_shadows_an_open_rule(db, run):
    """Review finding 9: a closed blocker about a leak halved the open constraint against it and named itself newer."""
    rule = add(run, "constraint", "no-private", "Never commit private network IPs, email addresses or hardware "
               "serials to tracked files", "core-setup", "p1", "--created-at", "2026-06-01")
    leak = add(run, "blocker", "leak", "handoff file had private network IPs and email addresses committed to "
               "tracked files", "docs", "p1", "--created-at", "2026-09-10")
    run(["close", leak["uid"]])
    hits = run(["search", "--query", "commit private IPs email tracked files", "--project", "p1"])
    assert hits[0]["uid"] == rule["uid"] and "newer" not in hits[0]


def test_newer_names_the_live_end_of_a_supersede_chain(db, run):
    """Verifier iteration 4 (N3): 1581 carried newer=2010, itself superseded by 2291 and then 3295."""
    a = add(run, "decision", "mcu", "BMC MCU is the STM32 for the production target", "hw")
    b = add(run, "decision", "mcu2", "BMC MCU is the TMS570 for the production target", "hw", "p1",
            "--supersedes", a["uid"])
    c = add(run, "decision", "mcu3", "BMC MCU is the AURIX for the production target", "hw", "p1",
            "--supersedes", b["uid"])
    hits = {h["uid"]: h for h in run(["search", "--query", "BMC MCU production target", "--project", "p1"])}
    assert hits[a["uid"]]["newer"] == c["uid"]


def test_an_identifier_range_answers_a_query_for_a_member(db, run):
    """Field test iteration 1 (V4): 'VBL-015..021' never matched a search for VBL-019."""
    other = add(run, "decision", "v4", "VBL-004 timeout supervisor wired into both SIL mains")
    add(run, "decision", "v8", "VBL-008 bus-off detection wired into both SIL mains")
    rng = add(run, "decision", "range", "VBL-015..021 wired into both SIL mains, seven "
              "scenarios unskipped")
    order = [h["uid"] for h in run(["search", "--query", "VBL-019 wired SIL mains",
                                    "--project", "p1"])]
    assert order[0] == rng["uid"] and order.index(other["uid"]) > 0


def test_a_rule_is_not_pending_and_unblocked_is_not_closed(db, run):
    rule = add(run, "decision", "rebase", "require an S-FP-09.3 DBC re-baseline event, not "
               "stacked waivers", "sprint")
    add(run, "state", "next", "S-FP-09.2 closed; next step S-FP-09.3 DBC transport is unblocked",
        "sil")
    hits = run(["search", "--query", "S-FP-09.3 DBC re-baseline waivers", "--project", "p1"])
    assert hits[0]["uid"] == rule["uid"] and "newer" not in hits[0]


def test_search_part_filter_follows_aliases(db, run):
    add(run, "state", "a", "thermistor table calibrated", part="bms-cal")
    add(run, "state", "b", "thermistor wiring checked", part="bms")
    run(["alias", "--project", "p1", "--part", "bms-cal", "--parent", "bms"])
    hits = run(["search", "--query", "thermistor", "--project", "p1", "--part", "bms"])
    assert {h["part"] for h in hits} == {"bms", "bms-cal"}


# ------------------------------------------------------------------ digest

def test_digest_priority_state_and_next_steps_before_blockers_and_episodes(
        db, run, run_text, tmp_path):
    add(run, "constraint", "rule", "never flash on friday")
    for i in range(6):
        add(run, "blocker", "b%d" % i, "thing%d waiting on vendor%d" % (i, i))
    record(run, tmp_path, {"achievement": ["landed the parser"], "resolves": [],
                           "current_state": {"summary": "parser landed", "status": [
                               {"subject": "parser", "state": "parser merged on main"}]},
                           "next_steps": ["wire the parser into the cli"]}, "parser")
    text = run_text(["digest", "--project", "p1", "--part", "core"])
    order = [text.index(h) for h in ("## Goals and constraints", "## Current state",
                                     "## Next steps", "## Open blockers",
                                     "## Recent episodes")]
    assert order == sorted(order)
    assert "wire the parser into the cli" in text
    for budget in (120, 200, 400, 800):
        tight = run_text(["digest", "--project", "p1", "--part", "core",
                          "--budget-tokens", str(budget)])
        assert mem.est_tokens(tight) <= budget, budget
    tight = run_text(["digest", "--project", "p1", "--budget-tokens", "150"])
    assert "never flash on friday" in tight and "rows omitted" in tight


def test_digest_hides_hygiene_rows_and_shadowed_decisions(db, run, run_text):
    add(run, "decision", "narr", "ran the tests and they passed")
    old = add(run, "decision", "store", "keep the store on sqlite")
    new = add(run, "decision", "store-pg", "move the store to postgres instead of sqlite",
              "core", "p1", "--sibling")
    conn = mem.connect()
    try:
        mem.apply_event(conn, {"type": "review", "host": "testhost", "seq": 0,
                               "ts": mem.now_iso(), "payload": {"links": [
                                   {"from": new["uid"], "to": old["uid"],
                                    "relation": "contradicts"}]}})
        conn.commit()
    finally:
        conn.close()
    text = run_text(["digest", "--project", "p1"])
    assert "ran the tests" not in text
    assert "postgres" in text and "keep the store on sqlite" not in text


def test_global_rows_leave_the_digest_once_the_rules_file_exists(
        db, run, run_text, tmp_path, monkeypatch):
    add(run, "constraint", "g", "the chat stays responsive", "cross", "global")
    add(run, "constraint", "p", "project rule here")
    rules = tmp_path / "rules.md"
    monkeypatch.setenv("MEMDB_CORE_RULES", str(rules))
    assert "chat stays responsive" in run_text(["digest", "--project", "p1"])
    rules.write_text("# rules\n", encoding="utf-8")
    assert "chat stays responsive" not in run_text(["digest", "--project", "p1"])
    assert "chat stays responsive" in run_text(["digest", "--project", "p1", "--global"])


# ------------------------------------------------------------------ list, stats, parts, alias

def test_list_pages_without_a_query(db, run, run_text):
    for i in range(5):
        add(run, "state", "s%d" % i, "state number%d" % i)
    text = run_text(["list", "--project", "p1", "--limit", "2"])
    lines = text.strip().splitlines()
    assert len(lines) == 3 and lines[-1] == "2 of 5 shown - next: --offset 2"
    assert json.loads(lines[0])["summary"] == "state number4"
    assert run_text(["list", "--project", "nope"]).strip() == "0 results"


def test_stats_counts_kinds_links_and_hygiene(db, run):
    add(run, "blocker", "b", "rig offline")
    add(run, "decision", "d", "ran the tests and they passed")
    out = run(["stats", "--project", "p1"])[0]
    assert out["records"] == 2 and out["by_kind"]["blocker"] == {"open": 1}
    assert out["open_blocker_age_days"]["<30"] == 1
    assert out["hygiene"]["narrative-decision"] == 1


def test_alias_replays_and_refuses_cycles(db, run, capsys):
    add(run, "state", "a", "alpha", part="bms")
    add(run, "state", "b", "beta", part="bms-cal")
    add(run, "state", "c", "gamma", part="bms-cal-soc")
    parts = {p["part"]: p for p in run(["parts", "--project", "p1", "--suggest"])}
    assert parts["bms-cal-soc"]["suggest_parent"] == "bms-cal"
    run(["alias", "--project", "p1", "--part", "bms-cal", "--parent", "bms"])
    run(["alias", "--project", "p1", "--part", "bms-cal-soc", "--parent", "bms-cal"])
    with pytest.raises(SystemExit, match="cycle"):
        run(["alias", "--project", "p1", "--part", "bms", "--parent", "bms-cal-soc"])
    with pytest.raises(SystemExit, match="no part"):
        run(["alias", "--project", "p1", "--part", "bms", "--parent", "nosuch"])
    conn = mem.connect()
    try:
        assert lifecycle.part_family(conn, "p1", "bms") == {"bms", "bms-cal", "bms-cal-soc"}
    finally:
        conn.close()
    run(["rebuild", "--full"])
    assert run(["verify", "--full"])[0]["ok"] is True
    run(["alias", "--project", "p1", "--part", "bms-cal-soc", "--remove"])
    conn = mem.connect()
    try:
        assert lifecycle.part_family(conn, "p1", "bms") == {"bms", "bms-cal"}
    finally:
        conn.close()


def test_a_part_family_never_holds_the_siblings_of_a_part(db, run, tmp_path):
    """Review finding 7: bms-cal's family took in bms-soc through the shared parent, so its blocker refused the episode."""
    add(run, "state", "a", "alpha", part="bms")
    add(run, "state", "b", "beta", part="bms-cal")
    add(run, "blocker", "soc", "soc estimator diverges on cold cells", part="bms-soc")
    run(["alias", "--project", "p1", "--part", "bms-cal", "--parent", "bms"])
    run(["alias", "--project", "p1", "--part", "bms-soc", "--parent", "bms"])
    conn = mem.connect()
    try:
        assert lifecycle.part_family(conn, "p1", "bms-cal") == {"bms-cal", "bms"}
        assert lifecycle.part_family(conn, "p1", "bms") == {"bms", "bms-cal", "bms-soc"}
    finally:
        conn.close()
    out = record(run, tmp_path, {"achievement": ["calibrated the thermistor table"]}, "cal", part="bms-cal")
    assert out["open_blockers"]["count"] == 0


# ------------------------------------------------------------------ review-blockers

def test_review_blockers_proposes_closes_from_repo_paths_and_later_episodes(
        db, run, run_text, tmp_path):
    repo = tmp_path / "repo"
    (repo / "tools").mkdir(parents=True)
    (repo / "tools" / "check_links.py").write_text("x", encoding="utf-8")
    path_blk = add(run, "blocker", "checker",
                   "tools/check_links.py does not exist so links are unchecked")
    rig = add(run, "blocker", "rig", "hil rig psu4711 dead so no bench runs")
    still = add(run, "blocker", "vendor", "vendor quote for the cellmodule9 harness pending")
    record(run, tmp_path, {"achievement": [
        "replaced psu4711 on the hil rig; bench runs are green again",
        "cellmodule9 harness quote still pending from the vendor"], "resolves": []},
        "psu", part="ops")
    report = json.loads(run_text(["review-blockers", "--project", "p1", "--repo",
                                  str(repo), "--format", "json"]))
    by_uid = {p["uid"]: p for p in report["proposals"]}
    assert by_uid[path_blk["uid"]]["evidence"] == "repo:tools/check_links.py"
    assert by_uid[path_blk["uid"]]["confidence"] == "high"
    assert by_uid[rig["uid"]]["action"] == "close"
    assert still["uid"] not in by_uid
    before = len(events())
    text = run_text(["review-blockers", "--project", "p1", "--repo", str(repo),
                     "--apply", "high"])
    assert len(events()) == before + 1 and events()[-1]["type"] == "review"
    assert "applied:" in text
    closed = [u for u, p in by_uid.items() if p["confidence"] == "high"]
    for uid in closed:
        got = run(["get", uid])[0]
        assert got["status"] == "closed" and got["review"][0]["action"] == "close"
    assert run(["get", still["uid"]])[0]["status"] == "open"
    run(["rebuild", "--full"])
    assert run(["verify", "--full"])[0]["ok"] is True
    for uid in closed:
        assert run(["get", uid])[0]["status"] == "closed"


def test_same_day_date_only_evidence_is_proposed_at_medium_at_most(db, run, run_text):
    closure = add(run, "decision", "closed", "treat the OEM message as the formal closure event "
                  "for PH2-CFU-001 and promote the accepted authority split", "l0", "p1",
                  "--created-at", "2026-04-11")
    blk = add(run, "blocker", "open", "OEM confirmation for PH2-CFU-001 is still missing, so "
              "the authority split stays blocked", "l0", "p1", "--created-at", "2026-04-11")
    report = json.loads(run_text(["review-blockers", "--project", "p1", "--format", "json"]))
    found = {p["uid"]: p for p in report["proposals"]}
    assert found[blk["uid"]]["evidence"] == closure["uid"]
    assert found[blk["uid"]]["confidence"] == "medium"


def test_a_path_that_exists_never_closes_a_blocker_about_its_content(db, run, run_text, tmp_path):
    """Verifier iteration 1 (1296/8): 'script.py has no threat_id awareness' closed because the file exists."""
    repo = tmp_path / "repo"
    (repo / "tools").mkdir(parents=True)
    (repo / "tools" / "trace_tests.py").write_text("x", encoding="utf-8")
    blk = add(run, "blocker", "trace", "tools/trace_tests.py has no threat_id or cs_goal_id "
              "awareness", "sec")
    assert blk["uid"] not in proposals_of(run_text, "--repo", str(repo))


def test_items_not_present_in_an_existing_file_never_close_on_the_path(db, run, run_text, tmp_path):
    """Verifier iteration 2 (872/3): 'frames ... are NOT present in <dbc>' closed at high because the dbc exists."""
    repo = tmp_path / "repo"
    (repo / "test" / "sil").mkdir(parents=True)
    (repo / "test" / "sil" / "taktflow_sil.dbc").write_text("x", encoding="utf-8")
    blk = add(run, "blocker", "dbc", "the 6 supervisor frames (PLANT_A, PLANT_B) are NOT present in "
              "test/sil/taktflow_sil.dbc", "sil")
    gone = add(run, "blocker", "dbc2", "test/sil/taktflow_sil.dbc is missing", "sil", "p1", "--sibling")
    found = proposals_of(run_text, "--repo", str(repo))
    assert blk["uid"] not in found
    assert found[gone["uid"]]["confidence"] == "high"


def test_a_restatement_that_drops_words_is_never_a_high_supersede(db, run, run_text):
    """Verifier iteration 2 (205/6 -> 208/5): 'must be frozen before any layout starts' became 'still missing'."""
    for n, body in enumerate(["the harness connector pinout is unverified before any layout starts",
                              "the thermal pad stack is not chosen before any layout starts",
                              "the bench supply cannot reach 60 volts before any layout starts",
                              "the fuse rating is open before any layout starts"]):
        add(run, "blocker", "filler-%d" % n, body, "hw-pcb", "p1", "--created-at", "2026-04-01")
    old = add(run, "blocker", "freeze", "platform-envelope.yaml must be frozen before any layout "
              "starts", "hw-pcb", "p1", "--created-at", "2026-04-12")
    new = add(run, "blocker", "missing", "platform-envelope.yaml must be frozen and is still missing",
              "hw-pcb", "p1", "--created-at", "2026-04-13", "--sibling")
    assert proposals_of(run_text).get(old["uid"], {}).get("confidence") != "high"
    same = add(run, "blocker", "missing2", "platform-envelope.yaml must be frozen before any layout "
               "starts on the first pcb", "hw-pcb", "p1", "--created-at", "2026-04-14", "--sibling")
    found = proposals_of(run_text)
    assert found[old["uid"]]["by"] == same["uid"] and found[old["uid"]]["confidence"] == "high"


def test_a_restated_row_is_superseded_when_its_successor_closes_in_the_same_review(db, run):
    """Verifier iteration 2 (N1): closes ran first, the supersede onto the closed row was skipped."""
    old = add(run, "blocker", "rig", "the rig has no usb hub", "hw")
    new = add(run, "blocker", "rig2", "the rig has no usb hub for the probe", "hw", "p1", "--sibling")
    out = mem.write_event("review", {"closes": [{"uid": new["uid"], "evidence": "e", "reason": "r"}],
                                     "supersedes": [{"old": old["uid"], "by": new["uid"],
                                                     "reason": "restated"}],
                                     "ts": mem.now_iso()})
    assert out["closed"] == 1 and out["superseded"] == 1
    got = run(["get", old["uid"]])[0]
    assert got["status"] == "superseded" and got["superseded_by"] == new["uid"]


def test_a_cue_sentence_that_shares_two_words_is_never_high(db, run, run_text, tmp_path):
    """Verifier iteration 2 (60/4): 'suite' and 'author' in a re-verification line closed 'suites not authored'."""
    for n in range(4):
        add(run, "state", "filler-%d" % n, "the remaining leaf work %d is still open" % n, "l0")
    blk = add(run, "blocker", "suites", "the remaining non-leaf suites are still not authored yet", "l0")
    record(run, tmp_path, {"achievement": [
        "re-verified the default SIL suite 74/0/0 before push with no co-author trailer, done",
        "the non-leaf planning notes remain in the backlog"], "resolves": []}, "verify", part="sil")
    assert proposals_of(run_text).get(blk["uid"], {}).get("confidence") != "high"


def test_work_kept_open_is_not_a_resolution(db, run, run_text, tmp_path):
    """Verifier iteration 2 (294/6): 'closed while keeping hardware closure work explicitly open' closed it."""
    blk = add(run, "blocker", "hw", "no downstream hardware boundary has been explicitly selected for "
              "opening yet", "method")
    record(run, tmp_path, {"achievement": [
        "recorded the software wave as closed while keeping the downstream hardware boundary "
        "selection explicitly open"], "resolves": []}, "wave", part="sw")
    assert blk["uid"] not in proposals_of(run_text)


def test_a_standing_rule_is_not_ended_by_following_it(db, run, run_text, tmp_path):
    """Verifier iteration 2 (1193/5): taking the snapshot once closed 'any further change requires a snapshot'."""
    blk = add(run, "blocker", "snap", "Any further change to the official matrix or review files will "
              "require a fresh snapshot before editing.", "neg")
    record(run, tmp_path, {"achievement": [
        "Created fresh pre-edit snapshots of the official matrix and review files before editing, done."],
        "resolves": []}, "writeback", part="neg2")
    assert proposals_of(run_text).get(blk["uid"], {}).get("confidence") != "high"


def test_identical_twin_blockers_close_together(db, run, run_text, tmp_path):
    """Verifier iteration 3 (N2): 1480/6 closed, its same-day twin 1482/6 stayed open in the digest."""
    body = "Cluster B (VBL-005/006/007) is blocked by control C-BMC-02"
    add(run, "blocker", "twin-a", body, "bmc", "p1", "--created-at", "2026-07-07")
    add(run, "decision", "cbmc02", "control C-BMC-02 closed and Cluster B VBL-005/006/007 promoted to main",
        "bmc", "p1", "--created-at", "2026-07-07")
    add(run, "blocker", "twin-b", body, "bmc", "p1", "--created-at", "2026-07-07", "--sibling")
    twins = [p for p in proposals_of(run_text).values() if p["kind"] == "blocker"]
    assert len(twins) == 2 and {p["action"] for p in twins} == {"close"}
    assert {p["confidence"] for p in twins} == {"high"}


def test_composed_path_evidence_ignores_templates_readmes_and_build_output(db, run, run_text, tmp_path):
    """Verifier iteration 3 (N3): 'MC/DC measurement reports are still missing' closed on a report template."""
    repo = tmp_path / "repo"
    for rel in ("docs/l0-mcdc-measurement-report-template.yaml", "test/hil/scenarios/closure/README.md",
                "build-probes-on/config_control_lib/cmake_clean_target.cmake"):
        (repo / rel).parent.mkdir(parents=True, exist_ok=True)
        (repo / rel).write_text("x", encoding="utf-8")
    blks = [add(run, "blocker", "mcdc", "packaged per-leaf mcdc measurement reports are still missing", "l0"),
            add(run, "blocker", "haz", "HAZ-009 has no dedicated scripted closure scenario", "hil"),
            add(run, "blocker", "cfg", "config control lib clean target does not exist", "sil")]
    found = proposals_of(run_text, "--repo", str(repo))
    assert not [b["uid"] for b in blks if b["uid"] in found]


def test_a_none_blocker_closes_as_not_a_blocker_never_on_evidence(db, run, run_text):
    """Verifier iteration 4 (35/3): 'none in the active source-layer gate set' closed on a doc-sync episode."""
    blk = add(run, "blocker", "none", "none in the active source-layer gate set", "l0")
    add(run, "decision", "sweep", "closed the active source-layer gate set sweep, done", "l0")
    found = proposals_of(run_text)[blk["uid"]]
    assert found["evidence"] == "hygiene:none-body" and found["confidence"] == "high"


def test_reworded_twin_blockers_close_together(db, run, run_text):
    """Verifier iteration 4 (C3): the real 1480/6 and 1482/6 differ in wording, so the identical-twin rule missed them."""
    add(run, "blocker", "twin-a", "Cluster B (VBL-005/006/007) blocked on C-BMC-02 (DBC input-frame design "
        "decision: SBS-owned vs plant-owned frames)", "bmc", "p1", "--created-at", "2026-07-07")
    add(run, "decision", "cbmc02", "control C-BMC-02 closed: the DBC input-frame design decision took "
        "plant-owned frames, and Cluster B VBL-005/006/007 is promoted to main", "bmc", "p1",
        "--created-at", "2026-07-07")
    add(run, "blocker", "twin-b", "Cluster B (VBL-005, VBL-006, VBL-007) is blocked by control C-BMC-02: a DBC "
        "input-frame design decision (SBS-owned vs plant-owned frames)", "bmc", "p1", "--created-at",
        "2026-07-07", "--sibling")
    twins = [p for p in proposals_of(run_text).values() if p["kind"] == "blocker"]
    assert len(twins) == 2 and {(p["action"], p["confidence"]) for p in twins} == {("close", "high")}


def test_a_missing_path_found_only_deeper_in_the_tree_is_never_high(db, run, run_text, tmp_path):
    """Review finding 5: 'tests/conftest.py does not exist' closed at high on memdb/tests/conftest.py."""
    repo = tmp_path / "repo"
    (repo / "memdb" / "tests").mkdir(parents=True)
    (repo / "memdb" / "tests" / "conftest.py").write_text("x", encoding="utf-8")
    blk = add(run, "blocker", "conftest", "tests/conftest.py does not exist so the root suite has no fixtures",
              "ci")
    assert proposals_of(run_text, "--repo", str(repo))[blk["uid"]]["confidence"] == "medium"
    (repo / "tools" / "tests").mkdir(parents=True)
    (repo / "tools" / "tests" / "conftest.py").write_text("x", encoding="utf-8")
    assert blk["uid"] not in proposals_of(run_text, "--repo", str(repo))
    (repo / "tests").mkdir()
    (repo / "tests" / "conftest.py").write_text("x", encoding="utf-8")
    found = proposals_of(run_text, "--repo", str(repo))[blk["uid"]]
    assert (found["evidence"], found["confidence"]) == ("repo:tests/conftest.py", "high")


def test_a_path_after_a_sentence_end_is_not_the_missing_path(db, run, run_text, tmp_path):
    """Verifier iteration 4 (872/3): 'icd/ does not exist. sprint-scope-decision.md forbids ...' closed on that doc."""
    repo = tmp_path / "repo"
    (repo / "docs").mkdir(parents=True)
    (repo / "docs" / "sprint-scope-decision.md").write_text("x", encoding="utf-8")
    blk = add(run, "blocker", "icd", "the per-frame ICD folder source/icd/ does not exist. "
              "sprint-scope-decision.md sec 5 forbids drive-by frame additions", "sil")
    assert blk["uid"] not in proposals_of(run_text, "--repo", str(repo))


def test_words_of_an_existing_path_never_close_a_blocker(db, run, run_text, tmp_path):
    """Verifier iteration 4 (954/6, 868/5): 'numpy missing in HIL drivers' closed because test/hil/drivers exists."""
    repo = tmp_path / "repo"
    for rel in ("test/hil/drivers/can_fd.py", "test/hil/scenarios/closure/_closure_helpers.py"):
        (repo / rel).parent.mkdir(parents=True, exist_ok=True)
        (repo / rel).write_text("x", encoding="utf-8")
    blks = [add(run, "blocker", "numpy", "numpy missing in HIL drivers causes collection errors", "hil"),
            add(run, "blocker", "haz", "HAZ-009 and HAZ-022 have no dedicated scripted closure scenario", "hil")]
    found = proposals_of(run_text, "--repo", str(repo))
    assert not [b["uid"] for b in blks if b["uid"] in found]


def test_rows_of_one_imported_day_never_restate_each_other(db, run, run_text):
    """Cleanup check iteration 4: same-day imported rows were ordered by uid, and uid order is not event order."""
    old = add(run, "blocker", "open65", "65 of 195 critical rows still have customer disposition OPEN, so "
              "the contract is not closed", "neg", "p1", "--created-at", "2026-04-09")
    add(run, "blocker", "open-all", "all responded critical rows still have customer disposition OPEN, so "
        "the contract is not closed", "neg", "p1", "--created-at", "2026-04-09", "--sibling")
    assert proposals_of(run_text).get(old["uid"], {}).get("action") != "supersede"


def proposals_of(run_text, *extra):
    report = json.loads(run_text(["review-blockers", "--project", "p1", "--format", "json"]
                                 + list(extra)))
    return {p["uid"]: p for p in report["proposals"]}


def test_an_episode_that_still_lists_the_item_never_resolves_it(db, run, run_text, tmp_path):
    """Field test iteration 1 (276/5): the audit episode kept the item as a blocker of its own."""
    blk = add(run, "blocker", "seeds", "WCCA and DFMEA seed records stay unsigned until the Gate 2 "
              "bench executes", "hw")
    record(run, tmp_path, {"achievement": [
        "closed the audit of the unsigned WCCA seed records, DFMEA seed records and the Gate 2 "
        "bench plan"],
        "blockers": ["WCCA and DFMEA seed rows cannot be signed until real bench measurements"],
        "resolves": []}, "audit", part="hw-audit")
    assert blk["uid"] not in proposals_of(run_text)


def test_evidence_naming_one_of_two_identifiers_never_closes_the_blocker(db, run, run_text, tmp_path):
    """Review finding 3: 'VBL-019 and VBL-020 missing' closed on 'VBL-019 added, done'."""
    for n in range(12):
        add(run, "state", "filler-%d" % n, "the bench harness %d for rig%d is wired and the spec review is "
            "still open" % (n, n), "misc")
    blk = add(run, "blocker", "vbl", "VBL-019 and VBL-020 derivations are missing from the sw spec", "reqs")
    record(run, tmp_path, {"achievement": ["VBL-019 derivation added to the sw spec, done"], "resolves": []},
           "vbl19", part="reqs")
    assert blk["uid"] not in proposals_of(run_text)
    record(run, tmp_path, {"achievement": ["VBL-019 and VBL-020 derivations added to the sw spec, done"],
                           "resolves": []}, "vbl20", part="reqs")
    assert proposals_of(run_text)[blk["uid"]]["action"] == "close"


def test_a_conditional_sentence_is_not_a_resolution():
    assert not similar.resolves(None, "audited the packet to determine whether the deliverable "
                                      "could be closed truthfully")
    assert similar.resolves(None, "the deliverable is closed and the packet is committed")


def test_a_shared_identifier_with_little_else_is_never_high(db, run, run_text, tmp_path):
    """Field test iteration 1 (333/5): 'Gate 15' alone tied another boundary's deferral to this one."""
    blk = add(run, "blocker", "g15", "Gate 15 remains deferred due pre-existing software "
              "requirement wording issues outside the hardware packet", "hw")
    record(run, tmp_path, {"achievement": [
        "Removed the closed BND-L1-SVC Gate 15 deferrals for SYSREQ-2741 and SYSREQ-2742",
        "reviewed pre-existing software requirement wording in the hardware packet"],
        "resolves": []}, "svc", part="svc")
    found = proposals_of(run_text)
    assert blk["uid"] not in found or found[blk["uid"]]["confidence"] != "high"


def test_a_temporary_decision_closes_on_its_condition_not_on_its_own_execution(
        db, run, run_text, tmp_path):
    """Field test iteration 1 (290/6): carrying out a 'not yet' decision is not its expiry."""
    dec = add(run, "decision", "carve", "Do NOT carve boot_manager as a BND-L2 boundary yet. "
              "Declare it as platform_trust_elements PTE-001 under the cyber_item envelope with "
              "an explicit boundary_decision that defers the carve-out to the svc_update "
              "start-readiness review.", "cyber")
    record(run, tmp_path, {"achievement": [
        "Two cross-file gaps closed (cyber_item security_gates, platform_trust_elements for "
        "boot_manager).",
        "closed the boot_manager gap: declared as platform_trust_elements PTE-001 under the "
        "cyber_item envelope with an explicit boundary_decision and no BND-L2 carve-out"],
        "resolves": []}, "gaps", part="cyber2")
    found = proposals_of(run_text)
    assert dec["uid"] not in found or found[dec["uid"]]["confidence"] != "high"
    record(run, tmp_path, {"achievement": [
        "the svc_update start-readiness review is closed, so the boot_manager carve-out is done: "
        "platform_trust_elements PTE-001 became a BND-L2 boundary with an explicit "
        "boundary_decision under the cyber_item envelope"], "resolves": []}, "review",
        part="cyber3")
    assert proposals_of(run_text)[dec["uid"]]["confidence"] == "high"


def test_a_closed_status_record_in_the_repo_resolves_a_blocker_naming_its_id(
        db, run, run_text, tmp_path):
    repo = tmp_path / "repo"
    (repo / "working").mkdir(parents=True)
    (repo / "working" / "register.yaml").write_text(
        "items:\n- id: PH2-CFU-004\n  title: witness workflow\n  status: closed_after_promotion\n"
        "- id: PH2-CFU-005\n  status: open\n", encoding="utf-8")
    done = add(run, "blocker", "cfu4", "PH2-CFU-004 artifact-delivery and witness-workflow "
               "package not yet closed for SVC descent", "l0")
    still = add(run, "blocker", "cfu5", "PH2-CFU-005 variant package not yet closed", "l0")
    found = proposals_of(run_text, "--repo", str(repo))
    assert found[done["uid"]]["evidence"] == "repo:working/register.yaml"
    assert found[done["uid"]]["confidence"] == "high"
    assert still["uid"] not in found


def test_only_an_id_key_starts_a_status_record(db, run, run_text, tmp_path):
    """Review finding 6: requirement_id ended the record and parent_id started one, so an open item read closed."""
    repo = tmp_path / "repo"
    (repo / "working").mkdir(parents=True)
    (repo / "working" / "register.yaml").write_text(
        "items:\n- id: PH2-CFU-004\n  requirement_id: SYSREQ-2741\n  status: open\n"
        "- id: PH2-CFU-010\n  parent_id: PH2-CFU-004\n  status: closed\n", encoding="utf-8")
    blk = add(run, "blocker", "cfu4", "PH2-CFU-004 witness workflow package not yet closed", "l0")
    texts = lifecycle.repo_texts(str(repo), lifecycle.repo_index(str(repo)))
    records = lifecycle.status_records(texts)
    assert records["ph2-cfu-004"] == [("working/register.yaml", "open")]
    assert records["ph2-cfu-010"] == [("working/register.yaml", "closed")]
    assert blk["uid"] not in proposals_of(run_text, "--repo", str(repo))


def test_a_placeholder_gone_from_the_repo_resolves_the_blocker_that_quoted_it(
        db, run, run_text, tmp_path):
    repo = tmp_path / "repo"
    (repo / "ci").mkdir(parents=True)
    (repo / "ci" / "tests.yml").write_text("CBMC_SHA: f269f875c84b\n", encoding="utf-8")
    blk = add(run, "blocker", "sha", 'CBMC_DEB_SHA256 placeholder "REPLACE_ME_WITH_REAL_SHA256" '
              "must be replaced before the cbmc CI job can pass", "ci")
    assert proposals_of(run_text, "--repo", str(repo))[blk["uid"]]["action"] == "close"
    (repo / "ci" / "tests.yml").write_text("CBMC_SHA: REPLACE_ME_WITH_REAL_SHA256\n",
                                           encoding="utf-8")
    assert blk["uid"] not in proposals_of(run_text, "--repo", str(repo))


def test_a_placeholder_still_in_a_hidden_directory_or_any_text_file_never_closes(db, run, run_text, tmp_path):
    """Review finding 1: the placeholder scan skipped hidden directories and unlisted extensions, then called it gone."""
    repo = tmp_path / "repo"
    (repo / ".github" / "workflows").mkdir(parents=True)
    (repo / "src").mkdir()
    (repo / ".github" / "workflows" / "ci.yml").write_text("CBMC_SHA: REPLACE_ME_WITH_REAL_SHA256\n",
                                                           encoding="utf-8")
    (repo / "src" / "main.rs").write_text('const KEY: &str = "PLACEHOLDER_SIGNING_KEY";\n', encoding="utf-8")
    (repo / "README.md").write_text("readme\n", encoding="utf-8")
    ci = add(run, "blocker", "sha", 'placeholder "REPLACE_ME_WITH_REAL_SHA256" in .github/workflows/ci.yml '
             "must be replaced before the cbmc job can pass", "ci")
    key = add(run, "blocker", "key", 'src/main.rs still ships the "PLACEHOLDER_SIGNING_KEY" literal', "fw")
    found = proposals_of(run_text, "--repo", str(repo))
    assert ci["uid"] not in found and key["uid"] not in found
    (repo / "src" / "main.rs").write_text("const KEY: &str = env!(\"KEY\");\n", encoding="utf-8")
    (repo / "big.log").write_bytes(b"x" * (lifecycle.TEXT_MAX_BYTES + 1))
    assert proposals_of(run_text, "--repo", str(repo))[key["uid"]]["confidence"] == "medium"


def test_review_event_replays_only_on_rows_still_open(db, run):
    a = add(run, "blocker", "a", "alpha thing blocked")
    run(["close", a["uid"]])
    conn = mem.connect()
    try:
        done = mem.apply_event(conn, {"type": "review", "host": "testhost", "seq": 0,
                                      "ts": mem.now_iso(), "payload": {
                                          "closes": [{"uid": a["uid"], "reason": "r"}]}})
        conn.rollback()
    finally:
        conn.close()
    assert done["closed"] == 0 and done["skipped"] == 1


def test_new_event_types_need_1_1_0():
    assert mem.MIN_VERSION_FOR_EVENT_TYPE["review"] == "1.1.0"
    assert mem.MIN_VERSION_FOR_EVENT_TYPE["alias"] == "1.1.0"


# ------------------------------------------------------------------ consolidate proposals

def test_collision_chains_are_never_superseded(db, run):
    for n in ("019", "020", "021"):
        add(run, "blocker", "vbl-" + n,
            "VBL-{} derivation is missing from the sw spec for the contactor".format(n))
    add(run, "blocker", "rig-a", "hil rig offline waiting for the usb hub delivery")
    add(run, "blocker", "rig-b", "hil rig offline waiting for usb hub delivery", "core",
        "p1", "--sibling")
    out = run(["consolidate", "--dry-run", "--project", "p1"])[0]
    grouped = {u for g in out["near_duplicates"] for u in [g["keep"]] + g["supersede"]
               + g["relate"]}
    assert not any(u for u in grouped if run(["get", u])[0]["subject"].startswith("vbl-"))
    assert len(out["near_duplicates"]) == 1


def test_a_near_duplicate_that_says_more_is_related_never_superseded(db, run):
    """Field test iteration 1: 6 of 9 applied supersedes dropped a cause, a scope or a path."""
    old = add(run, "blocker", "fw-a", "No BMS firmware flashed on the targets because the L1 sw "
              "trees are not opened", "hw")
    new = add(run, "blocker", "fw-b", "No BMS firmware flashed on STM32G4 or TMS570 targets", "hw",
              "p1", "--sibling")
    out = run(["consolidate", "--dry-run", "--project", "p1"])[0]
    group = [g for g in out["near_duplicates"] if new["uid"] in [g["keep"]] + g["relate"]][0]
    assert old["uid"] in group["relate"] and group["supersede"] == []


def test_gate_names_a_change_of_course(db, run, capsys):
    add(run, "decision", "bus", "route the cellmodule telemetry over can bus two")
    with pytest.raises(SystemExit):
        add(run, "decision", "bus-eth",
            "route the cellmodule telemetry over ethernet instead of can bus two")
    assert "change of course ('instead of')" in capsys.readouterr().err


def test_decision_duplicates_are_scored_on_the_decision_not_its_rationale(db, run):
    a = add(run, "decision", "plan-a", "update the canonical master plan in the same job as "
            "the promotion", "l0", "p1", "--rationale",
            "this job changed the active finish path and removed the last L1 blocker")
    b = add(run, "decision", "plan-b", "update the canonical master-plan files in the same job "
            "as the requirement closure", "reqs", "p1", "--rationale",
            "the end-of-job handoff rule requires the live plan to match the state", "--sibling")
    out = run(["consolidate", "--dry-run", "--project", "p1"])[0]
    assert [{g["keep"]} | set(g["relate"]) | set(g["supersede"])
            for g in out["near_duplicates"]] == [{a["uid"], b["uid"]}]


def test_contradiction_needs_the_rejected_clause_to_match_the_older_decision(db, run):
    old = add(run, "decision", "split-rule", "require every child split to carry a local "
              "derivation packet or an explicit citation to a reused promoted derivation artifact")
    unrelated = add(run, "decision", "gate", "add a new gate for the derivation packet "
                    "instead of extending the naming gate")
    new = add(run, "decision", "obs-split", "backfill the OBS child split with a local derivation "
              "packet instead of only citing a reused upstream artifact", "core", "p1",
              "--sibling")
    out = run(["consolidate", "--dry-run", "--project", "p1"])[0]
    assert [c[:2] for c in out["contradicts"]] == [[new["uid"], old["uid"]]]
    assert unrelated["uid"] not in {u for c in out["contradicts"] for u in c[:2]}


def test_negation_alone_is_not_a_contradiction(db, run):
    add(run, "decision", "a", "keep the existing downstream status text while separating the "
        "system close-out")
    add(run, "decision", "b", "preserve the existing status text in the trackers, do not "
        "rewrite parallel team history")
    assert run(["consolidate", "--dry-run", "--project", "p1"])[0]["contradicts"] == []


def test_episodes_recorded_twice_are_related_never_superseded(db, run, tmp_path):
    doc = {"achievement": ["wired the sprint-3 supervisors into the posix sil mains",
                           "unskipped test_cold_boot_enters_standby"], "resolves": []}
    first = record(run, tmp_path, doc, "wire-supervisors")
    second = record(run, tmp_path, dict(doc, current_state={"summary": "same job again"}),
                    "wire-supervisors-again")
    out = run(["consolidate", "--dry-run", "--project", "p1"])[0]
    groups = [g for g in out["near_duplicates"] if g["kind"] == "episode"]
    assert len(groups) == 1 and groups[0]["supersede"] == []
    assert {groups[0]["keep"]} | set(groups[0]["relate"]) == {first["uid"], second["uid"]}


def test_a_state_restated_as_a_constraint_is_superseded_by_it(db, run):
    st = add(run, "state", "stack", "customer mandated a C++ stack for all firmware: no "
             "exceptions, no RTTI, no heap, GoogleTest over Unity", "cross")
    rule = add(run, "constraint", "cpp", "customer-mandated C++ stack for all firmware, embedded "
               "subset: no exceptions, RTTI or heap; GoogleTest over Unity", "core-setup")
    out = run(["consolidate", "--dry-run", "--project", "p1"])[0]
    cross = [g for g in out["near_duplicates"] if g["kind"] == "cross"]
    assert cross == [{"kind": "cross", "keep": rule["uid"], "supersede": [st["uid"]],
                      "relate": []}]


def test_contradiction_is_proposed_for_review_and_never_applied(db, run):
    old = add(run, "decision", "bus", "route the cellmodule telemetry over the redundant "
              "canbus link through the pack harness connector")
    new = add(run, "decision", "bus-eth",
              "cellmodule telemetry moves to ethernet with tsn scheduling instead of the "
              "redundant canbus link, freeing bandwidth headroom for balancing data", "core",
              "p1", "--sibling")
    out = run(["consolidate", "--dry-run", "--project", "p1"])[0]
    assert out["near_duplicates"] == []
    assert [c[:2] + c[3:] for c in out["contradicts"]] == [
        [new["uid"], old["uid"], "instead of"]]
    before = len(events())
    out = run(["consolidate", "--project", "p1", "--apply-proposals"])[0]
    assert "review" not in out and len(events()) == before
    assert "links" not in run(["get", old["uid"]])[0]
    run(["supersede", old["uid"], "--by", new["uid"]])     # the reviewer's call
    assert run(["get", old["uid"]])[0]["status"] == "superseded"


# ------------------------------------------------------------------ install

def test_install_rebuilds_a_projection_from_an_older_schema(db, run):
    add(run, "state", "s", "survives the schema bump")
    conn = sqlite3.connect(db)
    conn.execute("PRAGMA user_version = 4")
    conn.commit()
    conn.close()
    assert install.db_schema_version(db) == 4
    record_ = install.ensure_db(check=True)
    assert record_["changed"] and "schema 4 -> 5" in record_["action"]
    assert install.db_schema_version(db) == 4        # --check wrote nothing
    install.ensure_db(check=False)
    assert install.db_schema_version(db) == mem.SCHEMA_VERSION
    assert run(["search", "--query", "survives schema"])[0]["status"] == "open"

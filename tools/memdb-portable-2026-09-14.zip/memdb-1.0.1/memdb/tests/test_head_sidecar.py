"""Head sidecar (plan-scalability S-MEM-SCALE-02).

append_event derives seq/prev from a per-clone sidecar validated against
the journal's actual bytes - O(1) instead of a full-file parse. The
sidecar is derived state: deleting or corrupting it at ANY point may
cost one slow rescan but must never change an observable outcome.
"""
import json
import os

from memdb import journal


def seed(root, host="testhost", n=25):
    for i in range(n):
        journal.append_event(
            host, "add",
            {"kind": "state", "project": "p", "part": "x",
             "subject": "s%d" % i, "body": "b" * 50,
             "ts": "2026-01-01T00:00:00+00:00"},
            "2026-01-01T00:00:00.%06dZ" % i, root=root)


def sidecar_path(root, host="testhost"):
    return journal.derived_path(host, "head.json", root)


def test_append_maintains_a_valid_sidecar(tmp_path):
    root = str(tmp_path / "jr")
    seed(root)
    sc = json.load(open(sidecar_path(root), encoding="utf-8"))
    events = journal.read_events(journal.host_file("testhost", root))
    assert sc["seq"] == events[-1][0]["seq"] == 25
    assert sc["hash"] == journal.line_hash(events[-1][1])
    assert sc["end"] == os.path.getsize(journal.host_file("testhost", root))


def test_tail_info_agrees_with_full_scan(tmp_path):
    root = str(tmp_path / "jr")
    seed(root)
    path = journal.host_file("testhost", root)
    with journal.lock(root):
        via_sidecar = journal.tail_info("testhost", root)
    assert via_sidecar == journal._scan_tail(path)


def test_sidecar_deletion_changes_nothing_but_speed(tmp_path):
    root = str(tmp_path / "jr")
    seed(root)
    os.remove(sidecar_path(root))
    journal.append_event("testhost", "add",
                         {"kind": "state", "project": "p", "part": "x",
                          "subject": "after-del", "body": "x",
                          "ts": "2026-01-02T00:00:00+00:00"},
                         "2026-01-02T00:00:00Z", root=root)
    path = journal.host_file("testhost", root)
    ok, err = journal.verify_chain(path)
    assert ok, err
    assert journal.read_events(path)[-1][0]["seq"] == 26
    # ...and the sidecar is back (self-healed by the append).
    assert os.path.exists(sidecar_path(root))


def test_stale_sidecar_is_detected_and_healed(tmp_path):
    """Crash between append and sidecar write: the sidecar points at a
    line that is no longer last (its end != file size)."""
    root = str(tmp_path / "jr")
    seed(root)
    path = journal.host_file("testhost", root)
    # simulate the crash: append a valid event line WITHOUT sidecar update
    events = journal.read_events(path)
    prev = journal.line_hash(events[-1][1])
    ev = {"v": 1, "host": "testhost", "seq": 26,
          "ts": "2026-01-02T00:00:00Z", "type": "add", "prev": prev,
          "payload": {"kind": "state", "project": "p", "part": "x",
                      "subject": "torn", "body": "no sidecar update",
                      "ts": "2026-01-02T00:00:00+00:00"}}
    with open(path, "a", encoding="utf-8", newline="\n") as f:
        f.write(journal.canonical_line(ev) + "\n")
    # next append must see seq 26 as the tail, not the stale sidecar's 25
    journal.append_event("testhost", "add",
                         {"kind": "state", "project": "p", "part": "x",
                          "subject": "healed", "body": "x",
                          "ts": "2026-01-03T00:00:00+00:00"},
                         "2026-01-03T00:00:00Z", root=root)
    ok, err = journal.verify_chain(path)
    assert ok, err
    assert [e["seq"] for e, _ in journal.read_events(path)][-3:] == [25, 26, 27]


def test_corrupt_sidecar_json_is_healed(tmp_path):
    root = str(tmp_path / "jr")
    seed(root)
    with open(sidecar_path(root), "w", encoding="utf-8") as f:
        f.write("{not json")
    journal.append_event("testhost", "add",
                         {"kind": "state", "project": "p", "part": "x",
                          "subject": "after-corrupt", "body": "x",
                          "ts": "2026-01-02T00:00:00+00:00"},
                         "2026-01-02T00:00:00Z", root=root)
    ok, err = journal.verify_chain(journal.host_file("testhost", root))
    assert ok, err


def test_sidecar_pointing_at_wrong_bytes_is_rejected(tmp_path):
    root = str(tmp_path / "jr")
    seed(root)
    sc = json.load(open(sidecar_path(root), encoding="utf-8"))
    sc["hash"] = "0" * 64
    with open(sidecar_path(root), "w", encoding="utf-8") as f:
        json.dump(sc, f)
    with journal.lock(root):
        info = journal.tail_info("testhost", root)
    # healed via scan: real tail, not the lying sidecar
    assert info["seq"] == 25
    assert info["hash"] != "0" * 64


def test_sidecar_lives_outside_the_replicated_tree(tmp_path):
    """derived/ must not be under journal/ - the sync script commits
    journal/<host> wholesale and per-clone cache must never replicate."""
    root = str(tmp_path / "jr")
    seed(root)
    assert os.path.commonpath(
        [sidecar_path(root)]) .startswith(os.path.join(root, "derived"))
    assert not sidecar_path(root).startswith(
        os.path.join(root, "journal") + os.sep)

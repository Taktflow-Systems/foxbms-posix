import json

import yaml  # test-only dependency; runtime code stays stdlib

from memdb import mem

EPISODE_1 = {
    "date": "2026-08-01",
    "achievement": ["created negotiation workspace"],
    "decisions_with_rationale": [
        {"decision": "keep live negotiation outside frozen contract baseline",
         "rationale": "preserves authority boundary"},
        {"decision": "use yaml for episode records",
         "rationale": "human auditable"},
    ],
    "current_state": {
        "summary": "negotiation workspace exists and is usable",
        "files_touched": ["notes/negotiation.md"],
        "status": [{"subject": "contract-baseline",
                    "state": "contract baseline unchanged"},
                   "narrative only, no row"],
    },
    "blockers": ["draft schema does not match official matrix"],
    "next_steps": ["expand routing to normative rows"],
}

EPISODE_2 = {
    "date": "2026-08-05",
    "achievement": [
        "fixed: draft schema does not match official matrix"],
    "decisions_with_rationale": [],
    "current_state": {"summary": "schema aligned", "files_touched": [],
                      "status": []},
    "blockers": [],
    "resolves": ["draft-schema-does-not-match-official-matrix"],
    "next_steps": [],
}


def record(run, tmp_path, doc, task):
    p = tmp_path / (task + ".json")
    p.write_text(json.dumps(doc))
    return run(["record-episode", "--project", "p1", "--part", "core",
                "--task", task, "--json", str(p)])[0]


def test_episode_ingest_extracts_children(db, run, tmp_path):
    out = record(run, tmp_path, EPISODE_1, "bootstrap")
    assert out["children"] == {"decision": 2, "blocker": 1, "state": 1}
    assert out["closed_blockers"] == []

    conn = mem.connect(db)
    ep = conn.execute("SELECT * FROM records WHERE id=?",
                      (out["episode_id"],)).fetchone()
    assert ep["kind"] == "episode"
    assert ep["created_at"].startswith("2026-08-01")
    assert json.loads(ep["payload"]) == EPISODE_1

    kids = conn.execute("SELECT kind, count(*) FROM records WHERE "
                        "source_record=? GROUP BY kind",
                        (out["episode_id"],)).fetchall()
    assert dict(kids) == {"decision": 2, "blocker": 1, "state": 1}


def test_blocker_closed_by_later_episode(db, run, tmp_path):
    record(run, tmp_path, EPISODE_1, "bootstrap")
    out2 = record(run, tmp_path, EPISODE_2, "schema-fix")
    assert len(out2["closed_blockers"]) == 1

    conn = mem.connect(db)
    blk = conn.execute("SELECT * FROM records WHERE kind='blocker'").fetchone()
    assert blk["status"] == "closed"


def open_blockers(db):
    conn = mem.connect(db)
    try:
        return sorted(r["subject"] for r in conn.execute(
            "SELECT subject FROM records WHERE kind='blocker' AND status='open'"))
    finally:
        conn.close()


def add_blocker(run, subject, body):
    return run(["add", "--kind", "blocker", "--project", "p1", "--part", "core",
                "--subject", subject, "--body", body])[0]


def test_legacy_episode_event_still_closes_by_substring(db, run):
    from memdb import journal
    add_blocker(run, "rig-offline", "rig offline")
    ts = "2026-08-02T00:00:00+00:00"
    journal.append_event("testhost", "episode", {
        "project": "p1", "part": "core", "task": "legacy", "session_id": None,
        "ts": ts, "doc": {"achievement": ["rig offline fixed"]}}, ts)
    run(["rebuild", "--full"])
    assert open_blockers(db) == []


def test_resolves_closes_only_the_named_blockers(db, run, tmp_path):
    add_blocker(run, "rig-offline", "rig offline")
    add_blocker(run, "ci-flaky", "ci flaky")
    usb = add_blocker(run, "usb-hub", "usb hub missing")
    doc = {"achievement": ["rig offline fixed, ci flaky fixed, usb hub fitted"],
           "resolves": ["rig-offline", usb["uid"], "no-such-blocker"]}
    out = record(run, tmp_path, doc, "fixes")
    assert len(out["closed_blockers"]) == 2
    assert out["resolves_unmatched"] == ["no-such-blocker"]
    assert open_blockers(db) == ["ci-flaky"]
    run(["rebuild", "--full"])
    assert open_blockers(db) == ["ci-flaky"]
    assert run(["verify", "--full"])[0]["ok"] is True


def test_new_episode_naming_none_closes_nothing(db, run, tmp_path):
    add_blocker(run, "none", "none")
    out = record(run, tmp_path, {"achievement": ["blockers: none"], "resolves": []},
                 "quiet")
    assert out["closed_blockers"] == [] and out["resolves_unmatched"] == []
    assert open_blockers(db) == ["none"]


def test_resolves_must_be_a_list_of_strings(db, tmp_path, capsys):
    import pytest
    p = tmp_path / "bad.json"
    p.write_text(json.dumps({"achievement": ["x"], "resolves": "rig-offline"}))
    with pytest.raises(SystemExit) as exc:
        mem.main(["record-episode", "--project", "p1", "--part", "core",
                  "--task", "bad", "--json", str(p)])
    assert exc.value.code == 2
    assert "resolves: expected a list" in capsys.readouterr().err


def test_provenance_defaults_from_session_env(db, run, tmp_path, monkeypatch):
    sessions, projects = tmp_path / "sessions", tmp_path / "projects"
    (projects / "some-project").mkdir(parents=True)
    sessions.mkdir()
    monkeypatch.setattr(mem, "SESSIONS_DIR", str(sessions))
    monkeypatch.setattr(mem, "PROJECTS_DIR", str(projects))
    hooked = tmp_path / "hooked.jsonl"
    hooked.write_text("line\n")
    (sessions / "sid-1.json").write_text(json.dumps(
        {"session_id": "sid-1", "transcript_path": str(hooked)}))
    monkeypatch.setenv("CLAUDE_CODE_SESSION_ID", "sid-1")
    out = record(run, tmp_path, EPISODE_2, "hooked")
    assert out["provenance"] == {"session_id": "env CLAUDE_CODE_SESSION_ID",
                                 "transcript": "sessions/<id>.json"}
    got = run(["get", out["uid"]])[0]
    assert got["session_id"] == "sid-1"
    assert got["payload"]["_transcript"]["path"] == str(hooked)
    assert len(got["payload"]["_transcript"]["sha256"]) == 64

    walked = projects / "some-project" / "sid-2.jsonl"
    walked.write_text("line\n")
    monkeypatch.setenv("CLAUDE_CODE_SESSION_ID", "sid-2")
    out = record(run, tmp_path, EPISODE_2, "walked")
    assert out["provenance"]["transcript"] == "projects/*/<id>.jsonl"
    assert run(["get", out["uid"]])[0]["payload"]["_transcript"]["path"] \
        == str(walked)

    p = tmp_path / "flags.json"
    p.write_text(json.dumps(EPISODE_2))
    out = run(["record-episode", "--project", "p1", "--part", "core", "--task",
               "flags", "--json", str(p), "--session-id", "sid-9"])[0]
    assert out["provenance"] == {"session_id": "flag", "transcript": None}


def test_render_handoff_round_trip(db, run, run_text, tmp_path):
    out = record(run, tmp_path, EPISODE_1, "bootstrap")
    text = run_text(["render-handoff", str(out["episode_id"])])
    doc = yaml.safe_load(text)

    for key in ["date", "project", "part", "task", "achievement",
                "decisions_with_rationale", "current_state", "blockers",
                "next_steps"]:
        assert key in doc, "missing handoff key: " + key
    assert doc["project"] == "p1"
    assert doc["part"] == "core"
    assert doc["task"] == "bootstrap"
    for key in EPISODE_1:
        assert doc[key] == EPISODE_1[key], "round-trip mismatch on " + key


def test_render_handoff_to_file(db, run, tmp_path):
    out = record(run, tmp_path, EPISODE_1, "bootstrap")
    dest = tmp_path / "handoff.yaml"
    run(["render-handoff", str(out["episode_id"]), "--out", str(dest)])
    assert yaml.safe_load(dest.read_text())["task"] == "bootstrap"

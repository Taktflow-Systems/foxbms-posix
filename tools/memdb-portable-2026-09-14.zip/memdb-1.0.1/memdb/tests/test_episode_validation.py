"""Episode validation before append; crash-proof replay (audit F-02, plan
S-AUD-02).

record-episode used to journal the event BEFORE its shape was checked, so
a list-typed current_state was appended permanently and every later
rebuild/verify tracebacked. Now: validate, then preflight the applier in a
rolled-back savepoint, then append. Replay of an already-malformed event
yields an `unresolved` loss report instead of a traceback.
"""
import json
import os
import subprocess
import sys

import pytest

from memdb import journal
from memdb import mem

MEMDB_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

VALID = {
    "date": "2026-09-13",
    "achievement": ["validated the episode"],
    "decisions_with_rationale": [{"decision": "check first",
                                  "rationale": "journal is append-only"}],
    "current_state": {"summary": "shape ok", "files_touched": ["a.py"],
                      "status": ["validation live"]},
    "blockers": [],
    "next_steps": ["keep going"],
}


def write_doc(tmp_path, doc, name="ep.json"):
    p = tmp_path / name
    p.write_text(json.dumps(doc), encoding="utf-8")
    return str(p)


def journal_size():
    p = journal.host_file("testhost")
    return os.path.getsize(p) if os.path.exists(p) else 0


def record_count():
    conn = mem.connect()
    try:
        return conn.execute("SELECT count(*) FROM records").fetchone()[0]
    finally:
        conn.close()


def record(tmp_path, doc):
    mem.main(["record-episode", "--project", "p1", "--part", "core",
              "--task", "t", "--json", write_doc(tmp_path, doc)])


MALFORMED = [
    ("list-current-state", {"current_state": []}, "current_state"),
    ("integer-decisions", {"decisions_with_rationale": 5},
     "decisions_with_rationale"),
    ("non-ascii-body", {"current_state": {"summary": "done — ok"}},
     "U+2014"),
    ("bad-date", {"date": "13/09/2026"}, "date"),
    ("dict-blocker-without-text", {"blockers": [{"owner": "me"}]},
     "blockers[0]"),
]


@pytest.mark.parametrize("over,needle", [m[1:] for m in MALFORMED],
                         ids=[m[0] for m in MALFORMED])
def test_malformed_episode_rejected_before_append(db, run, tmp_path, capsys,
                                                  over, needle):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "g", "--body", "a goal"])
    size, count = journal_size(), record_count()
    doc = dict(VALID)
    doc.update(over)
    with pytest.raises(SystemExit) as e:
        record(tmp_path, doc)
    assert e.value.code == 2
    assert needle in capsys.readouterr().err
    assert journal_size() == size
    assert record_count() == count


def test_all_errors_listed_at_once(db, tmp_path, capsys):
    doc = dict(VALID, date="yesterday", next_steps=7,
               current_state={"status": {"x": 1}, "files_touched": "a.py"})
    with pytest.raises(SystemExit):
        record(tmp_path, doc)
    err = capsys.readouterr().err
    for needle in ("date", "next_steps", "current_state.status",
                   "current_state.files_touched"):
        assert needle in err, needle
    assert journal_size() == 0


def test_non_json_rejected_with_exit_2(db, tmp_path, capsys):
    p = tmp_path / "bad.json"
    p.write_text("{not json", encoding="utf-8")
    with pytest.raises(SystemExit) as e:
        mem.main(["record-episode", "--project", "p1", "--part", "core",
                  "--task", "t", "--json", str(p)])
    assert e.value.code == 2
    assert journal_size() == 0


def test_unknown_top_level_key_only_warns(db, tmp_path, capsys):
    record(tmp_path, dict(VALID, extra_notes="kept"))
    captured = capsys.readouterr()
    assert json.loads(captured.out)["uid"] == "testhost:1"
    assert "extra_notes" in captured.err


def test_valid_episode_advances_head_by_one(db, run, tmp_path):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "g", "--body", "a goal"])
    out = run(["record-episode", "--project", "p1", "--part", "core",
               "--task", "t", "--json", write_doc(tmp_path, VALID)])[0]
    assert out["uid"] == "testhost:2"
    assert run(["doctor"])[0]["checks"]["heads"]["detail"]["testhost"][
        "seq"] == 2


def crashing_episode_payload():
    return {"project": "p1", "part": "core", "task": "bad",
            "session_id": None, "ts": "2026-01-01T00:00:00+00:00",
            "doc": {"achievement": ["x"], "decisions_with_rationale": 5}}


def test_preflight_rejects_applier_crash_without_append(db, run, capsys):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "g", "--body", "a goal"])
    size, count = journal_size(), record_count()
    with pytest.raises(SystemExit) as e:
        mem.write_event("episode", crashing_episode_payload())
    assert e.value.code == 2
    assert "nothing was journaled" in capsys.readouterr().err
    assert journal_size() == size and record_count() == count


def test_preflight_rollback_keeps_count_and_uid_sequence(db, run):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "g", "--body", "a goal"])
    count = record_count()
    conn = mem.connect()
    try:
        ok_ev = {"v": 1, "host": "testhost", "seq": 2, "ts": mem.now_iso(),
                 "type": "add", "prev": None,
                 "payload": {"kind": "state", "project": "p1",
                             "part": "core", "subject": "s", "body": "b",
                             "ts": mem.now_iso()}}
        mem.preflight_apply(conn, ok_ev)
        bad_ev = dict(ok_ev, type="episode",
                      payload=crashing_episode_payload())
        with pytest.raises(TypeError):
            mem.preflight_apply(conn, bad_ev)
        assert conn.execute("SELECT count(*) FROM records").fetchone()[0] \
            == count
    finally:
        conn.close()
    assert record_count() == count
    out = run(["add", "--kind", "state", "--project", "p1", "--part", "core",
               "--subject", "s", "--body", "b"])[0]
    assert out["uid"] == "testhost:2" and out["action"] == "added"


def append_malformed_episode():
    journal.append_event(
        "testhost", "episode",
        {"project": "p1", "part": "core", "task": "legacy-bad",
         "session_id": None, "ts": "2026-01-01T00:00:00+00:00",
         "doc": {"current_state": ["list", "not", "object"]}},
        mem.now_iso())


def test_replay_of_malformed_event_is_a_loss_report(db, run):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "g", "--body", "a goal"])
    append_malformed_episode()
    stats = mem.replay(journal.all_events(), db + ".t")
    os.remove(db + ".t")
    assert stats["applied"] == 1
    assert len(stats["unresolved"]) == 1
    miss = stats["unresolved"][0]
    assert miss["seq"] == 2 and miss["type"] == "episode"
    assert miss["missing"].startswith("apply error: AttributeError")


def test_rebuild_verify_on_malformed_journal_exits_1_with_report(db, run):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "g", "--body", "a goal"])
    append_malformed_episode()
    p = subprocess.run(
        [sys.executable, os.path.join(MEMDB_DIR, "mem.py"), "rebuild",
         "--verify"], capture_output=True, text=True, timeout=120)
    assert p.returncode == 1, p.stderr
    assert "Traceback" not in p.stderr
    report = json.loads(p.stdout.strip().splitlines()[-1])
    assert report["ok"] is False
    assert report["unresolved"][0]["missing"].startswith("apply error")

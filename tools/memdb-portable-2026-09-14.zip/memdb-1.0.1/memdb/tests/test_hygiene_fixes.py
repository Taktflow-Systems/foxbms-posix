"""Fixes for the 2026-08-31 deep-test findings.

1. digest tail reserve: pinned anchors must never starve the handoff
   sections to zero.
2. case-insensitive project matching on read paths (digest, search).
3. consolidate --expire-states: age out stale 'state' records only.
"""
import json

from memdb import journal
from memdb import mem


# ------------------------------------------------- 1. tail reserve

def test_anchor_heavy_digest_still_renders_handoff_sections(db, run,
                                                            run_text):
    # anchors far beyond the budget (part core: core-setup bodies are capped
    # at write time since S-AUD-04)
    for i in range(10):
        run(["add", "--kind", "constraint", "--project", "p1",
             "--part", "core", "--subject", "big%d" % i,
             "--body", "c" * 2000])
    run(["add", "--kind", "state", "--project", "p1", "--part", "core",
         "--subject", "now", "--body", "the current state"])
    cat = run_text(["digest", "--project", "p1", "--budget-tokens", "500"])
    assert "## Goals and constraints" in cat      # anchors intact
    assert "## Current state" in cat              # tail NOT starved
    assert "the current state" in cat


def test_tail_reserve_does_not_inflate_small_digests(db, run, run_text):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    out = run_text(["digest", "--project", "p1"])
    assert "trimmed" not in out


# --------------------------------------- 2. case-insensitive reads

def test_digest_merges_case_split_project_slugs(db, run, run_text):
    run(["add", "--kind", "constraint", "--project", "FO4RE",
         "--part", "core-setup", "--subject", "a", "--body", "upper fact"])
    run(["add", "--kind", "constraint", "--project", "fo4re",
         "--part", "core-setup", "--subject", "b", "--body", "lower fact"])
    cat = run_text(["digest", "--project", "FO4RE"])
    assert "upper fact" in cat and "lower fact" in cat
    cat = run_text(["digest", "--project", "fo4re"])
    assert "upper fact" in cat and "lower fact" in cat


def test_search_project_filter_is_case_insensitive(db, run):
    run(["add", "--kind", "state", "--project", "FO4RE", "--part", "x",
         "--subject", "s", "--body", "casefold retrieval probe"])
    hits = run(["search", "--query", "casefold retrieval probe",
                "--project", "fo4re"])
    assert len(hits) == 1 and hits[0]["project"] == "FO4RE"


def test_write_gating_stays_case_sensitive(db, run):
    """Dedup/supersede must NOT merge across case variants - that would
    change replay semantics for historical events."""
    run(["add", "--kind", "state", "--project", "FO4RE", "--part", "x",
         "--subject", "s", "--body", "one"])
    out = run(["add", "--kind", "state", "--project", "fo4re", "--part", "x",
               "--subject", "s", "--body", "two"])[0]
    assert out["action"] == "added"      # not superseded/confirmed


# ------------------------------------ 3. consolidate --expire-states

def seed_aged(run, kind, subject, days_old):
    import datetime
    ts = (datetime.datetime.now(datetime.timezone.utc)
          - datetime.timedelta(days=days_old)).isoformat()
    journal.append_event(
        "testhost", "add",
        {"kind": kind, "project": "p1", "part": "x", "subject": subject,
         "body": "aged " + subject, "ts": ts}, ts)


def test_expire_states_unverifies_only_stale_states(db, run, run_text):
    """1.1.0: a stale state loses confirmation instead of being closed."""
    seed_aged(run, "state", "old-state", 120)
    seed_aged(run, "state", "fresh-state", 5)
    seed_aged(run, "blocker", "old-blocker", 120)
    seed_aged(run, "decision", "old-decision", 120)
    run(["rebuild", "--full"])
    out = run(["consolidate", "--expire-states", "90"])[0]
    assert out["unverify_n"] == 1 and out["demoted_n"] == 0
    stale = run(["search", "--query", "aged old-state", "--kind", "state"])[0]
    assert stale["status"] == "open" and stale["unverified"] is True
    for q, kind in (("aged old-blocker", "blocker"),
                    ("aged old-decision", "decision"),
                    ("aged fresh-state", "state")):
        hit = run(["search", "--query", q, "--kind", kind])[0]
        assert hit["status"] == "open" and "unverified" not in hit, q
    text = run_text(["digest", "--project", "p1"])
    assert "aged old-state" not in text and "aged fresh-state" in text
    assert "1 older state rows are unverified" in text


def test_expire_states_off_by_default(db, run):
    seed_aged(run, "state", "old-state", 120)
    run(["rebuild", "--full"])
    out = run(["consolidate", "--dry-run"])[0]
    assert out["demoted_n"] == 0 and out["unverify_n"] == 0


def test_expire_states_event_replays(db, run):
    """The unverify must survive a full rebuild (journaled review event)."""
    seed_aged(run, "state", "old-state", 120)
    run(["rebuild", "--full"])
    run(["consolidate", "--expire-states", "90"])
    run(["rebuild", "--full"])
    hit = run(["search", "--query", "aged old-state"])[0]
    assert hit["status"] == "open" and hit["unverified"] is True
    assert run(["verify", "--full"])[0]["ok"] is True


# ---------------------------------------- 4. per-section item caps

def test_bloated_section_cannot_starve_later_sections(db, run, run_text):
    """565 open blockers must not push Recent episodes out of the digest."""
    for i in range(60):
        seed_aged(run, "blocker", "b%d" % i, 1)
    import io, sys, json as _json
    doc = {"achievement": ["landmark job done"],
           "current_state": {"summary": "landmark"}, "blockers": [],
           "decisions_with_rationale": [], "next_steps": []}
    old_stdin = sys.stdin
    sys.stdin = io.StringIO(_json.dumps(doc))
    try:
        run(["record-episode", "--project", "p1", "--part", "x",
             "--task", "landmark", "--json", "-"])
    finally:
        sys.stdin = old_stdin
    run(["rebuild", "--full"])
    text = run_text(["digest", "--project", "p1", "--budget-tokens", "2000"])
    assert "## Recent episodes" in text          # not starved by blockers
    assert "landmark" in text
    assert text.count("- (b ") <= mem.DIGEST_CAPS["blocker"]    # cap applied
    assert "rows omitted - mem digest" in text   # overflow counted

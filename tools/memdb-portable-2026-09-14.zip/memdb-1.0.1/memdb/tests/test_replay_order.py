"""Regression tests for the 2026-08-23 incident: canonical replay order
must equal per-host causal order, supersede must refuse mis-targets, and
CLI output must lead with uids (local ids are not stable across rebuild).
"""
import json
import os

import pytest

from memdb import journal
from memdb import mem


def ep(tmp_path, name, status_items, decisions=()):
    doc = {"achievement": ["did the thing"],
           "decisions_with_rationale": [
               {"decision": d, "rationale": "r"} for d in decisions],
           "current_state": {"summary": "summary", "files_touched": [],
                             "status": list(status_items)},
           "blockers": [], "next_steps": []}
    p = tmp_path / name
    p.write_text(json.dumps(doc))
    return str(p)


def host_events(host="testhost"):
    return [e for e, _ in journal.read_events(journal.host_file(host))]


# ---------------------------------------------------------- event ts

def test_episode_journal_ts_is_wall_clock_not_date(db, run, tmp_path):
    before = mem.now_iso()
    run(["record-episode", "--project", "p1", "--part", "core", "--task",
         "t1", "--json", ep(tmp_path, "a.json", ["x"]), "--date", "2020-01-01"])
    ev = host_events()[-1]
    assert ev["ts"] >= before, "journal ts must be the write time"
    assert ev["payload"]["ts"].startswith("2020-01-01"), \
        "record timestamp keeps the user-supplied date"
    rec = run(["get", "testhost:1"])[0]
    assert rec["created_at"].startswith("2020-01-01")


def test_journal_ts_monotonic_per_host(db, run, tmp_path):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "c",
         "--subject", "g", "--body", "goal"])
    run(["record-episode", "--project", "p1", "--part", "c", "--task", "t",
         "--json", ep(tmp_path, "a.json", ["s"]), "--date", "2020-01-01"])
    run(["add", "--kind", "goal", "--project", "p1", "--part", "c",
         "--subject", "g2", "--body", "goal 2"])
    ts = [e["ts"] for e in host_events()]
    assert ts == sorted(ts)


# ------------------------------------------------- canonical ordering

def test_all_events_never_reorders_within_a_host(db, run, tmp_path):
    """Simulate the legacy journal shape: an episode event whose ts is a
    date-only stamp EARLIER than the add event written just before it."""
    host = "testhost"
    journal.append_event(host, "add", {
        "kind": "state", "project": "p", "part": "c", "subject": "s1",
        "body": "first", "rationale": None, "confidence": "confirmed",
        "session_id": None, "ts": "2026-08-22T22:00:00+00:00"},
        "2026-08-22T22:00:00+00:00")
    journal.append_event(host, "episode", {
        "project": "p", "part": "c", "task": "t", "session_id": None,
        "doc": {"current_state": {"summary": "x", "status": ["child"]}},
        "ts": "2026-08-23T00:00:00+00:00"}, "2026-08-23T00:00:00+00:00")
    journal.append_event(host, "add", {
        "kind": "state", "project": "p", "part": "c", "subject": "s2",
        "body": "later", "rationale": None, "confidence": "confirmed",
        "session_id": None, "ts": "2026-08-22T22:30:00+00:00"},
        "2026-08-22T22:30:00+00:00")
    order = [(e["host"], e["seq"]) for e in journal.all_events()]
    assert order == [(host, 1), (host, 2), (host, 3)]


def test_cross_host_interleave_still_by_time(db):
    journal.append_event("alpha", "add", {"kind": "state", "project": "p",
                         "part": "c", "subject": "a", "body": "a",
                         "rationale": None, "confidence": "confirmed",
                         "session_id": None, "ts": "2026-01-01T10:00:00+00:00"},
                         "2026-01-01T10:00:00+00:00")
    journal.append_event("beta", "add", {"kind": "state", "project": "p",
                         "part": "c", "subject": "b", "body": "b",
                         "rationale": None, "confidence": "confirmed",
                         "session_id": None, "ts": "2026-01-01T09:00:00+00:00"},
                         "2026-01-01T09:00:00+00:00")
    journal.append_event("alpha", "add", {"kind": "state", "project": "p",
                         "part": "c", "subject": "a2", "body": "a2",
                         "rationale": None, "confidence": "confirmed",
                         "session_id": None, "ts": "2026-01-01T11:00:00+00:00"},
                         "2026-01-01T11:00:00+00:00")
    order = [(e["host"], e["seq"]) for e in journal.all_events()]
    assert order == [("beta", 1), ("alpha", 1), ("alpha", 2)]


def test_incident_replay_resolves_child_uids(db, run, tmp_path, monkeypatch):
    """Reproduce 2026-08-23: a same-day episode with a date-only ts, then
    an add with an identical (project, kind, subject, body) to one of its
    children, then a supersede that references the child uid. Rebuild
    and verify must succeed and match the live projection."""
    host = "testhost"
    child_subject = "the-child"
    journal.append_event(host, "episode", {
        "project": "p", "part": "c", "task": "t", "session_id": None,
        "doc": {"current_state": {"summary": "x",
                                  "status": [{"state": "the child",
                                              "subject": child_subject}]}},
        "ts": "2026-08-23T00:00:00+00:00"}, "2026-08-23T00:00:00+00:00")
    conn = mem.connect()
    mem.apply_event(conn, host_events()[-1])
    conn.commit(); conn.close()
    # copy of the child, written "earlier" in UTC on the same day
    journal.append_event(host, "add", {
        "kind": "state", "project": "p", "part": "c",
        "subject": child_subject, "body": "the child", "rationale": None,
        "confidence": "confirmed", "session_id": None,
        "ts": "2026-08-22T22:30:00+00:00"}, "2026-08-22T22:30:00+00:00")
    conn = mem.connect()
    mem.apply_event(conn, host_events()[-1])
    conn.commit(); conn.close()
    live = mem.normalized_dump(db)
    run(["rebuild"])
    assert mem.normalized_dump(db) == live
    out = run(["verify"])[0]
    assert out["ok"] and out["projection_match"] and not out["unresolved"]
    assert run(["get", host + ":1/1"])[0]["kind"] == "state"


def test_rebuild_matches_live_across_hosts_and_dates(db, run, tmp_path, monkeypatch):
    """Two hosts, episodes with backdated --date, adds in between; the
    live projection (arrival order) must equal the canonical replay."""
    for host, date in (("testhost", "2026-03-01"), ("other", "2026-02-01"),
                       ("testhost", "2026-01-15"), ("other", "2026-04-01")):
        monkeypatch.setenv("MEMDB_HOST", host)
        run(["add", "--kind", "state", "--project", "p", "--part", "c",
             "--subject", "s-" + host, "--body", "body " + date])
        run(["record-episode", "--project", "p", "--part", "c", "--task",
             "t-" + date, "--json",
             ep(tmp_path, host + date + ".json", ["shared status line"],
                decisions=["shared decision"]), "--date", date])
    live = mem.normalized_dump(db)
    run(["rebuild"])
    assert mem.normalized_dump(db) == live
    out = run(["verify"])[0]
    assert out["ok"] and not out["unresolved"]


# ------------------------------------------------------- supersede guards

def add(run, subject, body="b", kind="state"):
    return run(["add", "--kind", kind, "--project", "p", "--part", "c",
                "--subject", subject, "--body", body])[0]


def test_supersede_refuses_episode(db, run, tmp_path):
    run(["record-episode", "--project", "p", "--part", "c", "--task", "t",
         "--json", ep(tmp_path, "a.json", ["s"]), "--date", "2026-01-01"])
    new = add(run, "n")
    with pytest.raises(SystemExit, match="episode"):
        run(["supersede", "testhost:1", "--by", new["uid"]])


def test_supersede_refuses_non_open_target_and_self(db, run):
    a = add(run, "a", "aa")
    b = add(run, "b", "bb")
    run(["close", b["uid"]])
    with pytest.raises(SystemExit, match="must be an open"):
        run(["supersede", a["uid"], "--by", b["uid"]])
    with pytest.raises(SystemExit, match="same record"):
        run(["supersede", a["uid"], "--by", a["uid"]])


def test_supersede_refuses_repoint_without_force(db, run):
    a = add(run, "a", "aa")
    b = add(run, "b", "bb")
    c = add(run, "c", "cc")
    run(["supersede", a["uid"], "--by", b["uid"]])
    with pytest.raises(SystemExit, match="--force"):
        run(["supersede", a["uid"], "--by", c["uid"]])
    out = run(["supersede", a["uid"], "--by", c["uid"], "--force"])[0]
    assert out["by_uid"] == c["uid"]
    assert run(["get", a["uid"]])[0]["superseded_by"] == c["uid"]


def test_supersede_and_close_echo_subjects(db, run):
    a = add(run, "old-subject", "aa")
    b = add(run, "new-subject", "bb")
    out = run(["supersede", a["uid"], "--by", b["uid"]])[0]
    assert out["old"]["subject"] == "old-subject"
    assert out["by_record"]["subject"] == "new-subject"
    c = add(run, "to-close", "cc")
    out = run(["close", c["uid"]])[0]
    assert out["record"]["subject"] == "to-close" and out["record"]["was"] == "open"


# --------------------------------------------------------- uid output

def test_digest_lines_carry_uids(db, run, run_text, tmp_path):
    add(run, "rule", "always do x", kind="constraint")
    run(["record-episode", "--project", "p", "--part", "c", "--task", "t",
         "--json", ep(tmp_path, "a.json", ["s"]), "--date", "2026-01-01"])
    text = run_text(["digest", "--project", "p"])
    assert "(c testhost:1)" in text
    assert "(e testhost:2)" in text
    assert "(c1)" not in text


def test_local_ids_change_on_cross_host_rebuild_but_uids_do_not(db, run, monkeypatch):
    mine = add(run, "mine", "m")
    # another host's earlier event arrives later (sync ingest)
    journal.append_event("elder", "add", {"kind": "state", "project": "p",
                         "part": "c", "subject": "e", "body": "e",
                         "rationale": None, "confidence": "confirmed",
                         "session_id": None, "ts": "2000-01-01T00:00:00+00:00"},
                         "2000-01-01T00:00:00+00:00")
    run(["rebuild"])
    after = run(["get", mine["uid"]])[0]
    assert after["uid"] == mine["uid"]
    assert after["id"] != mine["id"], "local ids are NOT stable - use uids"
    assert run(["verify"])[0]["ok"]

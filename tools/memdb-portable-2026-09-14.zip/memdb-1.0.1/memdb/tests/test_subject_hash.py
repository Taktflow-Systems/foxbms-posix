"""Auto-subjects never collide across different facts (field test [3]).

A child row without an explicit subject used to get the first 60 slug
chars of its text, and gated_insert supersedes any open row with the same
subject, so seven per-boundary blockers sharing a 60-char prefix replaced
each other. Events written by record-episode now carry
"subject_rule": "hash"; events without it replay with the old rule.
"""
import json

from memdb import journal
from memdb import mem

PREFIX = ("HIL witness for the boundary cannot run until the flashed target "
          "and the commissioned bench exist for ")
BOUNDARIES = ["config-control", "energy-actuation", "energy-arbiter",
              "obs-diag", "svc-context", "veh-context", "veh-ingress"]


def record(run, tmp_path, doc, task):
    doc = dict({"resolves": []}, **doc)     # 1.1.0: required once the part has open blockers
    p = tmp_path / (task + ".json")
    p.write_text(json.dumps(doc), encoding="utf-8")
    return run(["record-episode", "--project", "p1", "--part", "hil",
                "--task", task, "--json", str(p)])[0]


def open_blocker_bodies():
    conn = mem.connect()
    try:
        return sorted(r["body"] for r in conn.execute(
            "SELECT body FROM records WHERE kind='blocker' AND status='open'"))
    finally:
        conn.close()


def test_long_common_prefix_blockers_all_stay_open(db, run, tmp_path):
    for b in BOUNDARIES:
        record(run, tmp_path, {"blockers": [PREFIX + b]}, "hil-" + b)
    assert open_blocker_bodies() == sorted(PREFIX + b for b in BOUNDARIES)
    run(["rebuild", "--full"])
    assert open_blocker_bodies() == sorted(PREFIX + b for b in BOUNDARIES)
    assert run(["verify", "--full"])[0]["ok"] is True


def test_the_same_fact_recorded_twice_confirms_instead_of_duplicating(
        db, run, tmp_path):
    record(run, tmp_path, {"blockers": [PREFIX + "veh-ingress"]}, "one")
    second = record(run, tmp_path, {"blockers": ["  " + PREFIX.upper()
                                                 + "veh-ingress. "]}, "two")
    assert second["children"]["blocker"] == 1
    assert open_blocker_bodies() == [PREFIX + "veh-ingress"]


def test_auto_subject_shape_is_readable_and_bounded():
    subject = mem.auto_subject(PREFIX + "veh-ingress")
    head, _, digest = subject.rpartition("-")
    assert len(subject) <= 60 and len(digest) == 10
    assert head == mem.slug(PREFIX, 48)
    assert mem.auto_subject("x") != mem.auto_subject("y")


def test_explicit_subject_still_supersedes(db, run, tmp_path):
    record(run, tmp_path, {"blockers": [{"blocker": "rig offline",
                                         "subject": "rig"}]}, "one")
    record(run, tmp_path, {"blockers": [{"blocker": "rig power supply dead",
                                         "subject": "rig"}]}, "two")
    assert open_blocker_bodies() == ["rig power supply dead"]


def test_legacy_events_replay_with_the_sixty_char_rule(db, run):
    """History is unchanged: an old event pair still supersedes on replay."""
    for n, b in enumerate(("config-control", "veh-ingress"), start=1):
        ts = "2026-04-1{}T00:00:00+00:00".format(n)
        journal.append_event("testhost", "episode", {
            "project": "p1", "part": "hil", "task": "legacy-" + b,
            "session_id": None, "ts": ts, "extract": "explicit",
            "resolves": [], "doc": {"blockers": [PREFIX + b]}}, ts)
    run(["rebuild", "--full"])
    assert open_blocker_bodies() == [PREFIX + "veh-ingress"]


def test_resolves_by_readable_prefix_closes_a_unique_hashed_blocker(
        db, run, tmp_path):
    record(run, tmp_path, {"blockers": ["usb hub missing on the rig"]}, "one")
    out = record(run, tmp_path, {"achievement": ["hub fitted"],
                                 "resolves": ["usb-hub-missing-on-the-rig"]},
                 "two")
    assert len(out["closed_blockers"]) == 1 and out["resolves_unmatched"] == []
    assert open_blocker_bodies() == []


def test_resolves_by_an_ambiguous_prefix_closes_nothing(db, run, tmp_path):
    for b in ("veh-ingress", "veh-context"):
        record(run, tmp_path, {"blockers": [PREFIX + b]}, "b-" + b)
    name = mem.slug(PREFIX, 48)
    out = record(run, tmp_path, {"resolves": [name]}, "vague")
    assert out["closed_blockers"] == []
    assert out["resolves_ambiguous"] == [name]
    assert len(open_blocker_bodies()) == 2

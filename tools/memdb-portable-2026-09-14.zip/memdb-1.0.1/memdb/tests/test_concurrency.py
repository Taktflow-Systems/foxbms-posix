"""Concurrency invariants for the journal (incident 2026-08-28).

Two memdb writers on one host used to be unserialised: append_event is a
read-modify-write, so overlapping writers derived the same seq and both
appended, permanently breaking the hash chain of an append-only file that
`mem rebuild` cannot repair. See docs/2026-08-28-concurrency-finding.md.
"""
import os
import subprocess
import sys
import threading

import pytest

from memdb import journal
from memdb import mem

MEMDB_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Enough events that the read-modify-write window is wide enough to lose
# a race if the lock were absent (36 ms measured on a 2466-event journal).
SEED_EVENTS = 400
WRITERS = 6


def seed(root, host="testhost", n=SEED_EVENTS):
    for i in range(n):
        journal.append_event(
            host, "add",
            {"kind": "state", "project": "p", "part": "x",
             "subject": "s%d" % i, "body": "b" * 200,
             "ts": "2026-01-01T00:00:00+00:00"},
            "2026-01-01T00:00:00.%06dZ" % i, root=root)


# ------------------------------------------------------------- threads

def test_concurrent_appends_keep_the_chain_intact(tmp_path):
    root = str(tmp_path / "journal-root")
    seed(root)
    barrier = threading.Barrier(WRITERS)
    errors = []

    def writer(n):
        try:
            barrier.wait()
            journal.append_event(
                "testhost", "add",
                {"kind": "state", "project": "p", "part": "x",
                 "subject": "race%d" % n, "body": "race",
                 "ts": "2026-01-02T00:00:00+00:00"},
                "2026-01-02T00:00:00.00000%dZ" % n, root=root)
        except Exception as e:                          # pragma: no cover
            errors.append(e)

    threads = [threading.Thread(target=writer, args=(i,))
               for i in range(WRITERS)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert not errors

    path = journal.host_file("testhost", root)
    events = journal.read_events(path)
    seqs = [e["seq"] for e, _ in events]
    assert len(events) == SEED_EVENTS + WRITERS
    assert seqs == list(range(1, SEED_EVENTS + WRITERS + 1)), "seq collision"
    ok, err = journal.verify_chain(path)
    assert ok, err
    subjects = {e["payload"]["subject"] for e, _ in events[-WRITERS:]}
    assert subjects == {"race%d" % i for i in range(WRITERS)}


# ----------------------------------------------------------- processes

WRITER_SCRIPT = """
import os, sys, time
sys.path.insert(0, {memdb!r})
os.environ["MEMDB_JOURNAL"] = {root!r}
os.environ["MEMDB_HOST"] = "testhost"
import journal
n, target = sys.argv[1], float(sys.argv[2])
while time.time() < target:      # align processes on a wall-clock barrier
    pass
journal.append_event("testhost", "add",
    {{"kind": "state", "project": "p", "part": "x",
      "subject": "proc" + n, "body": "proc " + n,
      "ts": "2026-01-02T00:00:00+00:00"}},
    "2026-01-02T00:00:00.00000" + n + "Z")
"""


def test_concurrent_appends_across_processes(tmp_path):
    """The threading test alone would pass on a GIL accident; this one
    is the shape that actually corrupted a journal."""
    import time

    root = str(tmp_path / "journal-root")
    seed(root)
    script = tmp_path / "writer.py"
    script.write_text(WRITER_SCRIPT.format(memdb=MEMDB_DIR, root=root))

    nprocs = 4
    target = time.time() + 6.0
    procs = [subprocess.Popen([sys.executable, str(script), str(i),
                               str(target)],
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE)
             for i in range(nprocs)]
    for p in procs:
        out, err = p.communicate(timeout=120)
        assert p.returncode == 0, err.decode("utf-8", "replace")

    path = journal.host_file("testhost", root)
    seqs = [e["seq"] for e, _ in journal.read_events(path)]
    assert seqs == list(range(1, SEED_EVENTS + nprocs + 1)), "seq collision"
    ok, err = journal.verify_chain(path)
    assert ok, err


# --------------------------------------------------------- diagnostics

def corrupt_with_duplicate_seq(root, host="testhost", subject="loser"):
    """Simulate a lost append race, byte for byte.

    Both writers read the same tail, so both derive the same seq and the
    same prev; only their payloads differ. That is what an unlocked
    append_event produced, and it is what makes the two events claim one
    uid (<host>:<seq>) downstream.
    """
    path = journal.host_file(host, root)
    events = journal.read_events(path)
    last, _ = events[-1]
    ev = dict(last)
    ev["payload"] = {"kind": "state", "project": "p1", "part": "core",
                     "subject": subject, "body": "the other writer",
                     "ts": "2026-01-03T00:00:00+00:00"}
    ev["type"] = "add"
    with open(path, "a", encoding="utf-8", newline="\n") as f:
        f.write(journal.canonical_line(ev) + "\n")


def test_verify_chain_names_a_duplicate_seq(db, run, tmp_path):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    root = journal.journal_root()
    corrupt_with_duplicate_seq(root)
    ok, err = journal.verify_chain(journal.host_file("testhost", root))
    assert not ok
    assert "duplicate seq 1" in err, err
    assert "gap" not in err


def test_rebuild_reports_integrity_damage_instead_of_crashing(db, run,
                                                              tmp_path):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    corrupt_with_duplicate_seq(journal.journal_root())
    stats = mem.replay(journal.all_events(), db + ".t")
    os.remove(db + ".t")
    assert len(stats["unresolved"]) == 1
    assert "integrity" in stats["unresolved"][0]["missing"]
    # ...and the CLI surfaces it as a loss report, not a traceback.
    with pytest.raises(SystemExit):
        mem.main(["rebuild"])


def test_verify_reports_duplicate_seq(db, run, tmp_path):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    corrupt_with_duplicate_seq(journal.journal_root())
    with pytest.raises(SystemExit):
        mem.main(["verify"])


# ---------------------------------------------------------------- lock

def test_lock_is_reentrant_within_a_thread(tmp_path):
    root = str(tmp_path / "journal-root")
    with journal.lock(root):
        with journal.lock(root):
            journal.append_event("testhost", "add", {"x": 1},
                                 "2026-01-01T00:00:00Z", root=root)
    assert journal.verify_chain(journal.host_file("testhost", root))[0]
    assert journal._held["depth"] == 0
    assert journal._held["fd"] is None


def test_lock_released_when_the_body_raises(tmp_path):
    root = str(tmp_path / "journal-root")
    with pytest.raises(ValueError):
        with journal.lock(root):
            raise ValueError("boom")
    assert journal._held["depth"] == 0
    with journal.lock(root):            # still acquirable
        pass


def test_lock_times_out_loudly_when_another_process_holds_it(tmp_path):
    root = str(tmp_path / "journal-root")
    os.makedirs(root, exist_ok=True)
    holder = subprocess.Popen(
        [sys.executable, "-c",
         "import sys, time; sys.path.insert(0, {memdb!r});"
         "import journal;"
         "journal.__dict__;"
         "ctx = journal.lock({root!r});"
         "ctx.__enter__(); print('held', flush=True); time.sleep(30)"
         .format(memdb=MEMDB_DIR, root=root)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        assert holder.stdout.readline().strip() == b"held"
        with pytest.raises(SystemExit) as e:
            with journal.lock(root, timeout=0.5):
                pass                                    # pragma: no cover
        assert "timed out" in str(e.value)
    finally:
        holder.kill()
        holder.wait()


# -------------------------------------------------- single-pass rebuild

def test_rebuild_verify_is_a_single_locked_pass(db, run, tmp_path):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    out = run(["rebuild", "--verify"])[0]
    assert out["ok"] is True
    assert out["chains"] == {"testhost": "ok"}
    assert out["unresolved"] == []
    assert out["projection_drift"] is False


def test_rebuild_verify_reports_drift_without_failing(db, run, tmp_path):
    """Drift is routine (a remote journal was just ingested, or a writer
    died between its journal append and its DB apply). The rebuild is the
    repair, so it is reported, not failed on."""
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    journal.append_event(
        "testhost", "add",
        {"kind": "state", "project": "p1", "part": "core",
         "subject": "late", "body": "journal ahead of the projection",
         "ts": "2026-01-02T00:00:00+00:00"},
        "2026-01-02T00:00:00Z")
    out = run(["rebuild", "--verify"])[0]
    assert out["projection_drift"] is True
    assert out["ok"] is True
    assert run(["verify"])[0]["projection_match"] is True


def test_rebuild_verify_fails_on_a_broken_chain(db, run, tmp_path):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    corrupt_with_duplicate_seq(journal.journal_root())
    with pytest.raises(SystemExit):
        mem.main(["rebuild", "--verify"])


def test_plain_rebuild_output_is_unchanged(db, run, tmp_path):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    out = run(["rebuild"])[0]
    # "mode"/"snapshot" joined the contract with the snapshot fast path
    # (plan-scalability S-MEM-SCALE-05); the original keys are unchanged.
    assert {"events", "applied", "unresolved", "records", "db",
            "mode"} <= set(out)


# ----------------------------------------------------- readers vs swap

def test_readers_do_not_block_behind_the_journal_lock(db, run, tmp_path):
    """The SessionStart hook runs `digest` and must never block session
    start, so read-only commands must not wait on a rebuild's lock."""
    import time as _t

    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    mem_py = os.path.join(MEMDB_DIR, "mem.py")
    with journal.lock():                # a rebuild is "in progress"
        t0 = _t.monotonic()
        p = subprocess.run([sys.executable, mem_py, "digest",
                            "--project", "p1"],
                           capture_output=True, timeout=60)
        elapsed = _t.monotonic() - t0
    assert p.returncode == 0, p.stderr.decode("utf-8", "replace")
    assert b"ship it" in p.stdout
    assert elapsed < 20, "digest waited on the lock ({:.1f}s)".format(elapsed)


def test_swap_in_is_atomic_and_keeps_a_prev_backup(db, run, tmp_path):
    """os.replace in one step: mem.db is never absent, so a concurrent
    reader cannot make sqlite create an empty one in the gap."""
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    before = mem.normalized_dump(db)
    fresh = db + ".fresh"
    mem.replay(journal.all_events(), fresh)
    mem.swap_in(fresh, db)
    assert not os.path.exists(fresh)
    assert os.path.exists(db) and os.path.exists(db + ".prev")
    assert mem.normalized_dump(db) == before
    assert mem.normalized_dump(db + ".prev") == before


def test_rebuild_survives_a_reader_holding_the_db_open(db, run, tmp_path):
    """Windows refuses os.replace while another process has the target
    open; swap_in retries until the (short-lived) reader lets go.

    A reader that never lets go still fails the rebuild, loudly, after
    swap_in's timeout - which is the right outcome, not a hang.
    """
    import time as _t

    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    reader = subprocess.Popen(
        [sys.executable, "-c",
         "import sqlite3, sys, time;"
         "c = sqlite3.connect(sys.argv[1]);"
         "c.execute('SELECT count(*) FROM records').fetchone();"
         "print('open', flush=True); time.sleep(1.5); c.close()", db],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        assert reader.stdout.readline().strip() == b"open"
        t0 = _t.monotonic()
        run(["rebuild"])                # must retry through the reader
        if os.name == "nt":             # POSIX replaces an open file at once: no retry
            assert _t.monotonic() - t0 >= 0.5, "swap_in did not have to retry"
    finally:
        reader.wait(timeout=30)
    assert run(["verify"])[0]["projection_match"] is True

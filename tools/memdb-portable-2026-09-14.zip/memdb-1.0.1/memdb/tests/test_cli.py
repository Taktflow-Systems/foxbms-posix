import time

import pytest

from memdb import mem

ADD = ["add", "--kind", "decision", "--project", "p1", "--part", "core",
       "--subject", "storage-engine", "--body", "use sqlite for storage"]


def test_add_get(db, run):
    out = run(ADD + ["--rationale", "stdlib, zero deps"])
    assert out[0]["action"] == "added"
    rid = out[0]["id"]
    got = run(["get", str(rid)])[0]
    assert got["body"] == "use sqlite for storage"
    assert got["rationale"] == "stdlib, zero deps"
    assert got["status"] == "open"


def test_duplicate_add_confirms_not_duplicates(db, run):
    first = run(ADD)[0]
    second = run(["add", "--kind", "decision", "--project", "p1",
                  "--part", "core", "--subject", "storage-engine",
                  "--body", "  USE   sqlite for storage. "])
    assert second[0]["action"] == "confirmed"
    assert second[0]["id"] == first["id"]
    conn = mem.connect(db)
    assert conn.execute("SELECT count(*) FROM records WHERE status='open'"
                        ).fetchone()[0] == 1
    row = conn.execute("SELECT * FROM records WHERE id=?",
                       (first["id"],)).fetchone()
    assert row["last_confirmed_at"] > row["created_at"]


def test_conflicting_add_supersedes(db, run):
    first = run(ADD)[0]
    second = run(["add", "--kind", "decision", "--project", "p1",
                  "--part", "core", "--subject", "storage-engine",
                  "--body", "use postgres for storage"])[0]
    assert second["action"] == "superseded"
    conn = mem.connect(db)
    old = conn.execute("SELECT * FROM records WHERE id=?",
                       (first["id"],)).fetchone()
    assert old["status"] == "superseded"
    assert old["superseded_by"] == second["id"]
    assert conn.execute(
        "SELECT count(*) FROM records WHERE subject='storage-engine' "
        "AND status='open'").fetchone()[0] == 1
    assert conn.execute(
        "SELECT count(*) FROM links WHERE from_id=? AND to_id=? "
        "AND relation='supersedes'",
        (second["id"], first["id"])).fetchone()[0] == 1


def test_search_filters_and_ranking(db, run):
    run(ADD)
    run(["add", "--kind", "blocker", "--project", "p1", "--part", "core",
         "--subject", "flaky-ci", "--body", "ci pipeline flaky on runner 3"])
    run(["add", "--kind", "decision", "--project", "p2", "--part", "core",
         "--subject", "queue", "--body", "use sqlite as a queue"])

    hits = run(["search", "--query", "sqlite storage"])
    assert hits[0]["subject"] == "storage-engine"

    p1_only = run(["search", "--query", "sqlite", "--project", "p1"])
    # the filter names the project, so matching lines do not repeat it
    assert [h["subject"] for h in p1_only] == ["storage-engine"]
    assert "project" not in p1_only[0]

    blockers = run(["search", "--query", "ci flaky", "--kind", "blocker"])
    assert [h["subject"] for h in blockers] == ["flaky-ci"]


def test_supersede_and_close(db, run):
    a = run(ADD)[0]
    b = run(["add", "--kind", "decision", "--project", "p1", "--part", "core",
             "--subject", "storage-engine-v2", "--body", "sqlite plus wal"])[0]
    run(["supersede", a["uid"], "--by", b["uid"]])
    assert run(["get", str(a["id"])])[0]["status"] == "superseded"

    blk = run(["add", "--kind", "blocker", "--project", "p1", "--part",
               "core", "--subject", "disk-full", "--body", "disk full"])[0]
    run(["close", blk["uid"]])
    assert run(["get", str(blk["id"])])[0]["status"] == "closed"


def test_write_commands_refuse_bare_local_ids(db, run):
    """Local ids move on every cross-host rebuild (field test [13])."""
    a = run(ADD)[0]
    b = run(["add", "--kind", "decision", "--project", "p1", "--part", "core",
             "--subject", "storage-engine-v2", "--body", "sqlite plus wal"])[0]
    with pytest.raises(SystemExit, match="--local-id"):
        run(["close", str(b["id"])])
    with pytest.raises(SystemExit, match="--local-id"):
        run(["supersede", str(a["id"]), "--by", b["uid"]])
    with pytest.raises(SystemExit, match="--local-id"):
        run(["supersede", a["uid"], "--by", str(b["id"])])
    assert run(["get", a["uid"]])[0]["status"] == "open"
    run(["supersede", str(a["id"]), "--by", str(b["id"]), "--local-id"])
    assert run(["get", a["uid"]])[0]["status"] == "superseded"
    run(["close", str(b["id"]), "--local-id"])
    assert run(["get", b["uid"]])[0]["status"] == "closed"


def test_supersede_refuses_other_project_or_kind_without_cross(db, run):
    old = run(ADD)[0]
    other_project = run(["add", "--kind", "decision", "--project", "p2",
                         "--part", "core", "--subject", "storage-p2",
                         "--body", "use sqlite in p2"])[0]
    other_kind = run(["add", "--kind", "constraint", "--project", "p1",
                      "--part", "core", "--subject", "storage-rule",
                      "--body", "storage must be sqlite"])[0]
    with pytest.raises(SystemExit, match="p1/decision but --by .* is p2/decision"):
        run(["supersede", old["uid"], "--by", other_project["uid"]])
    with pytest.raises(SystemExit, match="--cross"):
        run(["supersede", old["uid"], "--by", other_kind["uid"]])
    run(["supersede", old["uid"], "--by", other_kind["uid"], "--cross"])
    assert run(["get", old["uid"]])[0]["status"] == "superseded"


def test_close_refuses_a_superseded_record_without_force(db, run):
    a = run(ADD)[0]
    b = run(["add", "--kind", "decision", "--project", "p1", "--part", "core",
             "--subject", "storage-engine-v2", "--body", "sqlite plus wal"])[0]
    run(["supersede", a["uid"], "--by", b["uid"]])
    with pytest.raises(SystemExit, match="superseded by {}".format(b["uid"])):
        run(["close", a["uid"]])
    assert run(["get", a["uid"]])[0]["status"] == "superseded"
    run(["close", a["uid"], "--force"])
    assert run(["get", a["uid"]])[0]["status"] == "closed"


def test_get_missing_record_errors(db, run):
    with pytest.raises(SystemExit):
        run(["get", "9999"])


def test_search_speed_on_1000_rows(db, run):
    conn = mem.connect(db)
    ts = mem.now_iso()
    conn.executemany(
        "INSERT INTO records (kind, project, part, subject, body, status, "
        "confidence, created_at, last_confirmed_at) "
        "VALUES ('state','perf','core',?,?,'open','confirmed',?,?)",
        [("row-{}".format(i),
          "measurement value {} for channel {}".format(i, i % 7), ts, ts)
         for i in range(1000)])
    conn.commit()
    conn.close()

    start = time.perf_counter()
    hits = run(["search", "--query", "measurement channel", "--limit", "5"])
    elapsed = time.perf_counter() - start
    assert len(hits) == 5
    assert elapsed < 0.100, "search took {:.1f} ms".format(elapsed * 1000)


def test_search_summary_mode_then_full(db, run):
    long_body = "the calibration procedure " + "step detail " * 40
    run(["add", "--kind", "state", "--project", "p1", "--part", "core",
         "--subject", "cal-proc", "--body", long_body,
         "--rationale", "measured drift on the reference bench exceeded spec"])
    hits = run(["search", "--query", "calibration procedure"])
    assert hits[0]["subject"] == "cal-proc"
    assert hits[0]["summary"].endswith("...")
    assert len(hits[0]["summary"]) <= mem.SUMMARY_CHARS + 3
    assert hits[0]["date"] == mem.now_iso()[:10] and hits[0]["status"] == "open"
    assert "payload" not in hits[0] and "fulltext" not in hits[0]
    assert hits[0]["why"].startswith("measured drift")
    full = run(["search", "--query", "calibration procedure", "--full"])
    assert full[0]["body"] == long_body
    got = run(["get", hits[0]["uid"]])[0]
    assert got["body"] == long_body

"""Consolidation under log-first semantics.

Write-gating runs at event-apply time (including replay), so two OPEN
rows with the same (project, kind, subject) cannot exist in a canonical
projection - the merge/contradiction paths are a safety net that should
find nothing. Consolidation's live job is demoting stale unverified rows,
and its outcomes are recorded as a `consolidate` event so replicas replay
the same result instead of recomputing against their own wall clock.
"""
import filecmp
from datetime import datetime, timedelta, timezone

from memdb import mem


def add(run, subject, body, confidence="confirmed", kind="state"):
    return run(["add", "--kind", kind, "--project", "p1", "--part", "core",
                "--subject", subject, "--body", body,
                "--confidence", confidence])[0]


def age_row(db, rid, days):
    """Test-only: age a row's clock fields directly in the projection."""
    conn = mem.connect(db)
    ts = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    conn.execute("UPDATE records SET created_at=?, last_confirmed_at=? "
                 "WHERE id=?", (ts, ts, rid))
    conn.commit()
    conn.close()


def test_gating_leaves_nothing_to_merge(db, run):
    add(run, "cal-status", "channel calibrated")
    add(run, "cal-status", "Channel  calibrated.")   # confirm-bump
    add(run, "cal-status", "channel recalibrated")   # supersedes
    report = run(["consolidate"])[0]
    assert report["merged"] == []
    assert report["contradictions"] == []
    conn = mem.connect(db)
    assert conn.execute("SELECT count(*) FROM records WHERE "
                        "subject='cal-status' AND status='open'"
                        ).fetchone()[0] == 1
    conn.close()


def test_stale_unverified_demoted(db, run):
    old = add(run, "old-fact", "maybe true", confidence="unverified",
              kind="decision")
    fresh = add(run, "new-fact", "possibly later", confidence="unverified",
                kind="decision")
    solid = add(run, "solid-fact", "definitely true", kind="decision")
    age_row(db, old["id"], 120)
    age_row(db, solid["id"], 120)
    report = run(["consolidate"])[0]
    assert report["demoted"] == [old["uid"]]

    conn = mem.connect(db)
    assert conn.execute("SELECT status FROM records WHERE id=?",
                        (old["id"],)).fetchone()[0] == "closed"
    assert conn.execute("SELECT status FROM records WHERE id=?",
                        (fresh["id"],)).fetchone()[0] == "open"
    assert conn.execute("SELECT status FROM records WHERE id=?",
                        (solid["id"],)).fetchone()[0] == "open"
    conn.close()


def test_demotion_recorded_as_event(db, run):
    from memdb import journal
    old = add(run, "old-fact", "maybe true", confidence="unverified",
              kind="decision")
    age_row(db, old["id"], 120)
    run(["consolidate"])
    events = journal.read_events(journal.host_file("testhost"))
    assert events[-1][0]["type"] == "consolidate"
    assert events[-1][0]["payload"]["demoted"] == [old["uid"]]


def test_dry_run_makes_zero_writes(db, run, tmp_path):
    from memdb import journal
    old = add(run, "old-fact", "maybe", confidence="unverified", kind="decision")
    age_row(db, old["id"], 120)

    before = str(tmp_path / "before.jsonl")
    after = str(tmp_path / "after.jsonl")
    events_before = len(journal.read_events(journal.host_file("testhost")))
    run(["export", "--jsonl", before])
    report = run(["consolidate", "--dry-run"])[0]
    assert report["dry_run"] is True
    assert report["demoted"]
    run(["export", "--jsonl", after])
    assert filecmp.cmp(before, after, shallow=False)
    assert len(journal.read_events(journal.host_file("testhost"))) \
        == events_before


def test_unverified_state_is_never_closed_by_age(db, run):
    """Age does not make a fact false: stale states stay open, marked unverified."""
    st = add(run, "bench", "the bench runs at 12 volts", confidence="unverified")
    age_row(db, st["id"], 120)
    report = run(["consolidate"])[0]
    assert report["demoted"] == []
    assert run(["get", st["uid"]])[0]["status"] == "open"


def test_dry_run_takes_no_lock(db, run, monkeypatch):
    from memdb import journal

    def refuse():
        raise AssertionError("dry run must not lock")
    monkeypatch.setattr(journal, "lock", refuse)
    assert run(["consolidate", "--dry-run"])[0]["dry_run"] is True


def test_project_proposals_apply_as_one_replayable_review_event(db, run):
    from memdb import journal
    a = add(run, "heap", "no dynamic allocation in the firmware image",
            kind="decision")
    b = run(["add", "--kind", "decision", "--project", "p1", "--part", "core",
             "--subject", "no-heap", "--body",
             "firmware image uses no dynamic allocation", "--sibling"])[0]
    dry = run(["consolidate", "--dry-run", "--project", "p1"])[0]
    groups = dry["near_duplicates"]
    assert len(groups) == 1 and {groups[0]["keep"]} | set(groups[0]["supersede"]) \
        == {a["uid"], b["uid"]}
    run(["consolidate", "--project", "p1", "--apply-proposals"])
    assert journal.read_events(journal.host_file("testhost"))[-1][0]["type"] == "review"
    statuses = sorted(run(["get", u])[0]["status"] for u in (a["uid"], b["uid"]))
    assert statuses == ["open", "superseded"]
    run(["rebuild", "--full"])
    assert sorted(run(["get", u])[0]["status"] for u in (a["uid"], b["uid"])) == statuses
    assert run(["verify", "--full"])[0]["ok"] is True

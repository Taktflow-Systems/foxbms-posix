"""Losslessness invariants: hash chain, replay determinism, cross-host
merge, verify/doctor detection."""
import io
import json
import os
import sys

import pytest

from memdb import journal
from memdb import mem


def ep(tmp_path, name="ep.json", **over):
    doc = {"achievement": ["did the thing"],
           "decisions_with_rationale": [
               {"decision": "use approach A", "rationale": "simplest"}],
           "current_state": {"summary": "thing done",
                             "files_touched": ["src/a.py"],
                             "status": ["A is live"]},
           "blockers": [], "next_steps": ["next"]}
    doc.update(over)
    p = tmp_path / name
    p.write_text(json.dumps(doc))
    return str(p)


def test_writes_append_chained_events(db, run, tmp_path):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship the feature"])
    run(["record-episode", "--project", "p1", "--part", "core",
         "--task", "t1", "--json", ep(tmp_path), "--date", "2026-01-02"])
    path = journal.host_file("testhost")
    events = journal.read_events(path)
    assert [e["seq"] for e, _ in events] == [1, 2]
    ok, err = journal.verify_chain(path)
    assert ok, err


def test_uid_assignment_and_lookup(db, run, tmp_path):
    out = run(["record-episode", "--project", "p1", "--part", "core",
               "--task", "t1", "--json", ep(tmp_path),
               "--date", "2026-01-02"])[0]
    assert out["uid"] == "testhost:1"
    by_uid = run(["get", "testhost:1"])[0]
    assert by_uid["kind"] == "episode"
    child = run(["get", "testhost:1/1"])[0]
    assert child["kind"] == "decision"


def test_rebuild_reproduces_live_db(db, run, tmp_path):
    run(["add", "--kind", "constraint", "--project", "p1", "--part", "core",
         "--subject", "budget", "--body", "stay under 1500 tokens"])
    run(["record-episode", "--project", "p1", "--part", "core",
         "--task", "t1", "--json", ep(tmp_path), "--date", "2026-01-02"])
    run(["close", "testhost:1"])
    live = mem.normalized_dump(db)
    run(["rebuild"])
    assert mem.normalized_dump(db) == live
    out = run(["verify"])[0]
    assert out["ok"] and out["projection_match"]


def test_db_is_disposable(db, run, tmp_path):
    run(["add", "--kind", "decision", "--project", "p1", "--part", "core",
         "--subject", "d1", "--body", "decide alpha"])
    before = mem.normalized_dump(db)
    os.remove(db)
    run(["rebuild"])
    assert mem.normalized_dump(db) == before


def test_cross_host_merge_and_foreign_close(db, run, tmp_path, monkeypatch):
    # host A records a blocker
    monkeypatch.setenv("MEMDB_HOST", "hostA")
    out = run(["add", "--kind", "blocker", "--project", "p1", "--part",
               "core", "--subject", "flaky-ci", "--body", "ci is flaky"])
    a_uid = out[0]["uid"]
    assert a_uid == "hostA:1"
    # host B (same journal root = post-sync state) closes A's blocker
    monkeypatch.setenv("MEMDB_HOST", "hostB")
    run(["close", a_uid])
    events = journal.read_events(journal.host_file("hostB"))
    assert events[0][0]["type"] == "close"
    assert events[0][0]["payload"]["uid"] == a_uid
    # both journals replay to the same converged state
    run(["rebuild"])
    got = run(["get", a_uid])[0]
    assert got["status"] == "closed"
    assert run(["verify"])[0]["ok"]


def test_verify_detects_tampering(db, run, tmp_path):
    run(["add", "--kind", "decision", "--project", "p1", "--part", "core",
         "--subject", "d1", "--body", "decide alpha"])
    path = journal.host_file("testhost")
    lines = open(path, encoding="utf-8").read().splitlines()
    tampered = lines[0].replace("decide alpha", "decide beta")
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(tampered + "\n")
    run(["add", "--kind", "decision", "--project", "p1", "--part", "core",
         "--subject", "d2", "--body", "decide gamma"])
    # chain check on the tampered file must fail (prev hash mismatch)
    with pytest.raises(SystemExit):
        run(["verify"])


def test_verify_detects_projection_drift(db, run, tmp_path):
    run(["add", "--kind", "decision", "--project", "p1", "--part", "core",
         "--subject", "d1", "--body", "decide alpha"])
    conn = mem.connect()
    conn.execute("UPDATE records SET body='hand-edited' WHERE 1=1")
    conn.commit()
    conn.close()
    with pytest.raises(SystemExit):
        run(["verify"])


def test_cross_host_same_subject_converges(db, run, tmp_path, monkeypatch):
    # Two hosts add the same subject; write-gating at replay collapses
    # them to ONE open row deterministically - nothing left to merge, and
    # nothing lost (the superseded/confirmed history is in the journals).
    monkeypatch.setenv("MEMDB_HOST", "hostA")
    run(["add", "--kind", "state", "--project", "p1", "--part", "core",
         "--subject", "s1", "--body", "the value is 42"])
    monkeypatch.setenv("MEMDB_HOST", "hostB")
    run(["add", "--kind", "state", "--project", "p1", "--part", "x",
         "--subject", "s1", "--body", "the value is 43"])
    run(["rebuild"])  # canonicalize
    conn = mem.connect(db)
    open_rows = conn.execute(
        "SELECT count(*) FROM records WHERE subject='s1' AND status='open'"
    ).fetchone()[0]
    total_rows = conn.execute(
        "SELECT count(*) FROM records WHERE subject='s1'").fetchone()[0]
    conn.close()
    assert open_rows == 1
    assert total_rows == 2  # loser superseded, never deleted
    report = run(["consolidate", "--dry-run"])[0]
    assert report["merged"] == [] and report["contradictions"] == []
    assert run(["verify"])[0]["ok"]


def test_doctor_healthy_and_broken(db, run, tmp_path, monkeypatch):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "g", "--body", "a goal"])
    out = run(["doctor"])[0]
    assert out["ok"]
    monkeypatch.setenv("MEMDB_PATH", str(tmp_path / "nope" / "missing.db"))
    with pytest.raises(SystemExit):
        run(["doctor"])


def add_goal(run, subject):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", subject, "--body", "goal " + subject])


def test_torn_tail_is_a_loss_signal_and_blocks_appends(db, run, capsys):
    add_goal(run, "g1")
    path = journal.host_file("testhost")
    size = os.path.getsize(path)
    partial = b'{"v":1,"host":"testhost","seq":2,"ts":"2026-09'
    with open(path, "ab") as f:
        f.write(partial)
    torn = "torn tail at byte {}".format(size)
    assert journal.verify_chain(path) == (False, torn)
    with pytest.raises(SystemExit):
        mem.main(["doctor"])
    report = json.loads(capsys.readouterr().out.strip().splitlines()[-1])
    assert report["checks"]["chain:testhost"] == {"ok": False, "detail": torn}
    for argv in (["verify"], ["verify", "--full"]):
        with pytest.raises(SystemExit) as exc:
            mem.main(argv)
        assert exc.value.code not in (0, None)
        capsys.readouterr()
    with pytest.raises(SystemExit, match=torn):
        add_goal(run, "g2")
    assert os.path.getsize(path) == size + len(partial)


def test_last_line_without_newline_blocks_appends(db, run):
    add_goal(run, "g1")
    path = journal.host_file("testhost")
    with open(path, "rb") as f:
        data = f.read()
    with open(path, "wb") as f:
        f.write(data.rstrip(b"\n"))
    with pytest.raises(SystemExit, match="torn tail at byte 0"):
        add_goal(run, "g2")


def test_unparsable_earlier_line_is_corruption_not_a_torn_tail(db, run):
    add_goal(run, "g1")
    add_goal(run, "g2")
    path = journal.host_file("testhost")
    with open(path, "rb") as f:
        first, rest = f.read().split(b"\n", 1)
    with open(path, "wb") as f:
        f.write(first[:20] + b"\n" + rest)
    with pytest.raises(ValueError):
        list(journal.iter_lines(path))


def test_journal_head_from_file_and_stdin(db, run, monkeypatch):
    add_goal(run, "g1")
    add_goal(run, "g2")
    path = journal.host_file("testhost")
    head = run(["journal-head", "--file", path])[0]
    assert head == {"seq": 2, "hash": journal.tail_info("testhost")["hash"]}
    with open(path, "rb") as f:
        monkeypatch.setattr(sys, "stdin", io.TextIOWrapper(io.BytesIO(f.read())))
    assert run(["journal-head", "--file", "-"])[0] == head
    monkeypatch.setattr(sys, "stdin", io.TextIOWrapper(io.BytesIO(b"")))
    assert run(["journal-head", "--file", "-"])[0] == {"seq": 0, "hash": None}


def test_memdb_host_conflicting_with_host_id_file_is_refused(tmp_path, monkeypatch):
    id_file = tmp_path / "host-id"
    id_file.write_text("workstation\n")
    monkeypatch.setattr(journal, "HOST_ID_FILE", str(id_file))
    monkeypatch.delenv("MEMDB_HOST_OVERRIDE", raising=False)
    monkeypatch.setenv("MEMDB_HOST", "laptop")
    with pytest.raises(SystemExit, match="MEMDB_HOST=laptop conflicts"):
        journal.host_id()
    monkeypatch.setenv("MEMDB_HOST_OVERRIDE", "1")
    assert journal.host_id() == "laptop"
    monkeypatch.delenv("MEMDB_HOST_OVERRIDE")
    monkeypatch.setenv("MEMDB_HOST", "workstation")
    assert journal.host_id() == "workstation"
    monkeypatch.delenv("MEMDB_HOST")
    assert journal.host_id() == "workstation"


def test_doctor_lists_unexpected_memory_files(db, run, tmp_path):
    add_goal(run, "g1")
    report = run(["doctor"])[0]
    assert report["ok"] and report["checks"]["memory_dir"]["detail"]["unexpected"] == []
    (tmp_path / "mem.db.probe").write_bytes(b"x")
    (tmp_path / "sessions").mkdir()
    report = run(["doctor"])[0]
    assert report["ok"]
    assert report["checks"]["memory_dir"]["detail"]["unexpected"] == ["mem.db.probe"]
    assert report["warnings"] == ["unexpected files in the memory directory: mem.db.probe"]


def test_transcript_provenance(db, run, tmp_path):
    t = tmp_path / "transcript.jsonl"
    t.write_text("line1\nline2\n")
    out = run(["record-episode", "--project", "p1", "--part", "core",
               "--task", "t1", "--json", ep(tmp_path),
               "--date", "2026-01-02", "--transcript", str(t)])[0]
    got = run(["get", out["uid"]])[0]
    payload = got["payload"]     # get returns the payload as an object
    assert payload["_transcript"]["path"] == str(t)
    assert len(payload["_transcript"]["sha256"]) == 64

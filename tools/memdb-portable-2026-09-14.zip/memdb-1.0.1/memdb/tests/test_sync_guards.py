"""Sync ingest guards (audit F-03, plan S-AUD-11) against a scratch bare hub.

Each test builds its own hub and host clones under tmp_path and runs the
real `python -m memdb sync` (and the transition wrappers) with every path
(journal, DB, HOME, rules file) redirected into tmp_path, so the user's
store is never touched.
"""
import os
import shutil
import subprocess
import sys

import pytest

from memdb import journal
from memdb import mem

MEMDB_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_ROOT = os.path.dirname(MEMDB_DIR)

pytestmark = pytest.mark.skipif(not shutil.which("git"), reason="needs git")


def git(*args, cwd=None):
    subprocess.run(["git", *args], cwd=cwd, check=True, capture_output=True)


def new_hub(tmp_path):
    hub = tmp_path / "hub.git"
    git("init", "--bare", "-q", "-b", "main", str(hub))
    return hub


def new_host(tmp_path, hub, host):
    root = tmp_path / host
    root.mkdir()
    git("init", "-q", "-b", host + "/journal", cwd=root)
    git("remote", "add", "origin", str(hub), cwd=root)
    return root


def add_event(root, host, n):
    ts = mem.now_iso()
    journal.append_event(host, "add",
                         {"kind": "state", "project": "p", "part": "x",
                          "subject": "s%d" % n, "body": "body %d" % n, "ts": ts},
                         ts, root=str(root))


def sync(tmp_path, root, host, path_prefix=None, override="1",
         break_replace=False):
    env = dict(os.environ)
    for key in ("MEMDB_FULL_VERIFY", "MEMDB_HOST_OVERRIDE"):
        env.pop(key, None)
    env.update(
        MEMDB_JOURNAL=str(root), MEMDB_HOST=host,
        MEMDB_HOME=str(tmp_path / "home" / ".claude" / "memory"),
        MEMDB_PATH=str(tmp_path / (host + ".db")),
        MEMDB_CORE_RULES=str(tmp_path / (host + "-core.md")),
        PYTHONPATH=REPO_ROOT,
        HOME=str(tmp_path / "home"), USERPROFILE=str(tmp_path / "home"),
        GIT_AUTHOR_NAME="memdb-test", GIT_AUTHOR_EMAIL="memdb-test",
        GIT_COMMITTER_NAME="memdb-test", GIT_COMMITTER_EMAIL="memdb-test")
    if override:
        env["MEMDB_HOST_OVERRIDE"] = override
    if path_prefix:
        env["PATH"] = str(path_prefix) + os.pathsep + env["PATH"]
    argv = [sys.executable]
    if break_replace:
        argv += ["-c", BREAK_REPLACE]
    else:
        argv += ["-m", "memdb", "sync"]
    p = subprocess.run(argv, env=env, capture_output=True, text=True,
                       timeout=300)
    return p.returncode, p.stdout + p.stderr


# os.replace is what materialises a fetched journal; a failure there must
# leave the last-seen ref where it was.
BREAK_REPLACE = """
import os, sys
real = os.replace
def broken(src, dst, *a, **k):
    if "journal" in str(dst) and str(dst).endswith("events.jsonl"):
        raise OSError("replace refused by the test")
    return real(src, dst, *a, **k)
os.replace = broken
from memdb import mem
sys.exit(mem.main(["sync"]) or 0)
"""


def two_hosts(tmp_path):
    hub = new_hub(tmp_path)
    b = new_host(tmp_path, hub, "hostb")
    add_event(b, "hostb", 1)
    rc, out = sync(tmp_path, b, "hostb")
    assert rc == 0, out
    a = new_host(tmp_path, hub, "hosta")
    add_event(a, "hosta", 1)
    return hub, a, b


def test_local_ahead_foreign_journal_is_never_overwritten(tmp_path):
    _, a, b = two_hosts(tmp_path)
    rc, out = sync(tmp_path, a, "hosta")
    assert rc == 0, out
    foreign = a / "journal" / "hostb" / "events.jsonl"
    add_event(b, "hostb", 2)                       # written on hostb, not pushed
    shutil.copyfile(b / "journal" / "hostb" / "events.jsonl", foreign)
    before = foreign.read_bytes()
    rc, out = sync(tmp_path, a, "hosta")
    assert rc == 1, out
    assert "INTEGRITY local journal for hostb is ahead of origin" in out
    assert foreign.read_bytes() == before


def test_failed_replace_does_not_advance_last_seen(tmp_path):
    _, a, _ = two_hosts(tmp_path)
    rc, out = sync(tmp_path, a, "hosta", break_replace=True)
    assert rc == 1, out
    assert "could not replace journal/hostb/events.jsonl" in out
    assert not (a / ".git" / "memdb-last-seen" / "hostb").exists()
    assert not (a / "journal" / "hostb" / "events.jsonl").exists()


def test_checkout_failure_stops_the_sync(tmp_path):
    _, a, _ = two_hosts(tmp_path)
    rc, out = sync(tmp_path, a, "hosta")
    assert rc == 0, out
    (a / ".git" / "index.lock").write_text("")
    rc, out = sync(tmp_path, a, "hosta")
    assert rc == 1, out
    assert "cannot check out branch hosta/journal" in out
    assert "rebuild" not in out and "memdb-sync: ok" not in out


def write_config(tmp_path, hub):
    from memdb import config
    home = tmp_path / "home" / ".claude" / "memory"
    home.mkdir(parents=True, exist_ok=True)
    config.save(dict(config.DEFAULTS, hub=hub), path=str(home / "config.json"))


def test_standalone_host_syncs_green_without_a_hub(tmp_path):
    root = tmp_path / "solo"
    root.mkdir()
    git("init", "-q", "-b", "solo/journal", cwd=root)
    add_event(root, "solo", 1)
    write_config(tmp_path, {"mode": "standalone", "url": ""})
    rc, out = sync(tmp_path, root, "solo")
    assert rc == 0, out
    assert "memdb-sync: standalone (no hub): push and fetch skipped" in out
    assert out.strip().splitlines()[-1] == "memdb-sync: ok (host=solo)"


def test_origin_that_differs_from_the_configured_hub_stops_before_push(tmp_path):
    hub = new_hub(tmp_path)
    other = tmp_path / "other.git"
    git("init", "--bare", "-q", "-b", "main", str(other))
    a = new_host(tmp_path, hub, "hosta")
    add_event(a, "hosta", 1)
    write_config(tmp_path, {"mode": "join",
                            "url": str(other).replace("\\", "/")})
    rc, out = sync(tmp_path, a, "hosta")
    assert rc == 1, out
    assert "differs from the configured hub" in out
    heads = subprocess.run(["git", "--git-dir", str(hub), "for-each-ref"],
                           capture_output=True, text=True).stdout
    assert heads.strip() == ""                     # nothing was pushed


def test_scheduled_sync_writes_the_log_without_a_console(tmp_path, monkeypatch):
    """pythonw.exe gives sys.stdout = None; the log must still be written."""
    from memdb import sync as sync_mod
    _, a, _ = two_hosts(tmp_path)
    log = tmp_path / "sync.log"
    for key, value in dict(
            MEMDB_JOURNAL=str(a), MEMDB_HOST="hosta", MEMDB_HOST_OVERRIDE="1",
            MEMDB_HOME=str(tmp_path / "home" / ".claude" / "memory"),
            MEMDB_PATH=str(tmp_path / "hosta.db"),
            MEMDB_CORE_RULES=str(tmp_path / "hosta-core.md"),
            MEMDB_SYNC_LOG=str(log), GIT_AUTHOR_NAME="memdb-test",
            GIT_AUTHOR_EMAIL="memdb-test", GIT_COMMITTER_NAME="memdb-test",
            GIT_COMMITTER_EMAIL="memdb-test").items():
        monkeypatch.setenv(key, value)
    monkeypatch.setattr(sys, "stdout", None)
    assert sync_mod.scheduled() == 0
    lines = log.read_text(encoding="utf-8").splitlines()
    assert "scheduled sync on" in lines[0]
    assert lines[-2:] == ["memdb-sync: ok (host=hosta)", "== exit 0 =="]


def posix_bash():
    """A bash that takes native paths; System32\\bash.exe is the WSL launcher and cannot."""
    found = shutil.which("bash")
    if found and sys.platform == "win32" and os.path.normcase(
            os.path.dirname(found)) == os.path.normcase(os.path.join(
                os.environ.get("SYSTEMROOT", r"C:\Windows"), "system32")):
        return None
    return found


BASH = posix_bash()
SYNC_WRAPPER = os.path.join(MEMDB_DIR, "sync", "memdb_sync.sh")
SCHEDULED_WRAPPER = os.path.join(MEMDB_DIR, "sync", "scheduled_sync.sh")


@pytest.mark.skipif(BASH is None, reason="wrapper-needs-bash")
def test_transition_wrapper_runs_the_python_sync(tmp_path):
    _, a, _ = two_hosts(tmp_path)
    env = dict(os.environ)
    for key in ("MEMDB_PYTHON", "PYTHONPATH", "MEMDB_FULL_VERIFY"):
        env.pop(key, None)
    env.update(MEMDB_JOURNAL=str(a), MEMDB_HOST="hosta", MEMDB_HOST_OVERRIDE="1",
               MEMDB_HOME=str(tmp_path / "home" / ".claude" / "memory"),
               MEMDB_PATH=str(tmp_path / "hosta.db"),
               MEMDB_CORE_RULES=str(tmp_path / "hosta-core.md"),
               HOME=str(tmp_path / "home"), USERPROFILE=str(tmp_path / "home"),
               GIT_AUTHOR_NAME="memdb-test", GIT_AUTHOR_EMAIL="memdb-test",
               GIT_COMMITTER_NAME="memdb-test", GIT_COMMITTER_EMAIL="memdb-test")
    p = subprocess.run([BASH, SYNC_WRAPPER], env=env, cwd=str(tmp_path),
                       capture_output=True, text=True, timeout=300)
    assert p.returncode == 0, p.stdout + p.stderr
    assert p.stdout.strip().splitlines()[-1] == "memdb-sync: ok (host=hosta)"


@pytest.mark.skipif(BASH is None, reason="wrapper-needs-bash")
def test_wrappers_fail_loudly_without_an_interpreter(tmp_path):
    empty = tmp_path / "empty-path"
    empty.mkdir()
    log = tmp_path / "sync.log"
    env = {"PATH": str(empty), "HOME": str(tmp_path),
           "MEMDB_SYNC_LOG": str(log), "SYSTEMROOT": os.environ.get(
               "SYSTEMROOT", "")}
    for wrapper in (SYNC_WRAPPER, SCHEDULED_WRAPPER):
        p = subprocess.run([BASH, wrapper], env=env, cwd=str(tmp_path),
                           capture_output=True, text=True, timeout=60)
        assert p.returncode == 1, (wrapper, p.stdout, p.stderr)
        assert "memdb-sync: FAIL no python interpreter" in p.stdout
    assert "memdb-sync: FAIL no python interpreter" in log.read_text(
        encoding="utf-8")


def test_sync_publishes_its_version_and_warns_about_unreplayable_types(tmp_path):
    """S-PKG-04 version guard: the witness reaches the hub in the same run."""
    import json
    from memdb import __version__
    hub, a, b = two_hosts(tmp_path)
    rc, out = sync(tmp_path, a, "hosta")
    assert rc == 0, out
    shown = subprocess.run(["git", "--git-dir", str(hub), "show",
                            "hosta/journal:journal/hosta/witness-heads.json"],
                           capture_output=True, text=True)
    assert json.loads(shown.stdout)["memdb_version"] == __version__
    witness = b / "journal" / "hostb" / "witness-heads.json"
    body = json.loads(witness.read_text(encoding="utf-8"))
    body.update(memdb_version="9.0.0", event_types=["add", "from-the-future"])
    witness.write_text(json.dumps(body), encoding="utf-8")
    git("add", "journal/hostb", cwd=b)
    git("-c", "user.name=t", "-c", "user.email=t", "commit", "-qm", "w", cwd=b)
    git("push", "-q", "origin", "hostb/journal", cwd=b)
    rc, out = sync(tmp_path, a, "hosta")
    assert rc == 0, out
    assert ("memdb-sync: host hosta runs memdb {} which cannot replay event "
            "type from-the-future written by hostb".format(__version__)) in out


def test_sync_refuses_a_conflicting_host_identity(tmp_path):
    hub = new_hub(tmp_path)
    a = new_host(tmp_path, hub, "hosta")
    id_dir = tmp_path / "home" / ".claude" / "memory"
    id_dir.mkdir(parents=True)
    (id_dir / "host-id").write_text("workstation\n")
    rc, out = sync(tmp_path, a, "laptop", override=None)
    assert rc == 1, out
    assert "MEMDB_HOST=laptop conflicts with the host-id file (workstation)" in out

from memdb import mem


def seed(run, n_state=0):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship-v1", "--body", "ship v1 with passing gate A3"])
    run(["add", "--kind", "constraint", "--project", "p1", "--part", "core",
         "--subject", "no-heap", "--body", "no dynamic allocation in firmware"])
    run(["add", "--kind", "blocker", "--project", "p1", "--part", "core",
         "--subject", "hil-rig", "--body", "hil rig offline"])
    run(["add", "--kind", "decision", "--project", "p1", "--part", "core",
         "--subject", "storage", "--body", "use sqlite",
         "--rationale", "stdlib only"])
    for i in range(n_state):
        run(["add", "--kind", "state", "--project", "p1", "--part", "core",
             "--subject", "channel-{}".format(i),
             "--body", "channel {} calibrated with offset table revision {} "
                       "applied and verified against the reference "
                       "bench".format(i, i)])


def test_digest_contains_all_sections(db, run, run_text):
    seed(run, n_state=3)
    text = run_text(["digest", "--project", "p1"])
    assert "Goals and constraints" in text
    assert "ship v1" in text
    assert "no dynamic allocation" in text
    assert "hil rig offline" in text
    assert "use sqlite -- why: stdlib only" in text
    assert "channel 0 calibrated" in text


def test_budget_respected_and_anchors_survive(db, run, run_text):
    seed(run, n_state=500)
    budget = 400
    text = run_text(["digest", "--project", "p1",
                     "--budget-tokens", str(budget)])
    # 1.1.0 contract: the budget is strict; pinned rows take at most the
    # budget minus the tail reserve (or half of it), so they come first.
    assert mem.est_tokens(text) <= budget
    assert "ship v1" in text
    assert "no dynamic allocation" in text
    assert "## Current state" in text
    # trim notice present, no silent truncation
    assert "rows omitted - mem digest --project p1 --budget-tokens 6000" in text
    assert "or mem search]" in text


def test_untrimmed_digest_has_no_notice(db, run, run_text):
    seed(run, n_state=2)
    text = run_text(["digest", "--project", "p1"])
    assert "rows omitted" not in text


def test_empty_scope_digest_is_valid(db, run_text):
    text = run_text(["digest", "--project", "nothing-here"])
    assert text.startswith("# Memory digest: nothing-here")


def test_superseded_and_closed_rows_excluded(db, run, run_text):
    seed(run)
    run(["add", "--kind", "decision", "--project", "p1", "--part", "core",
         "--subject", "storage", "--body", "use postgres",
         "--rationale", "changed mind"])
    blocker_uid = None
    for line in run(["search", "--query", "hil rig", "--kind", "blocker"]):
        blocker_uid = line["uid"]
    run(["close", blocker_uid])

    text = run_text(["digest", "--project", "p1"])
    assert "use postgres" in text
    assert "use sqlite" not in text  # superseded
    assert "hil rig offline" not in text  # closed


def test_pinned_rows_capped_oldest_confirmation_first(db, run, run_text):
    for i in range(12):
        run(["add", "--kind", "constraint", "--project", "p1", "--part",
             "core-setup", "--subject", "rule-%02d" % i,
             "--body", ("rule %02d " % i) + "y" * 480])
    text = run_text(["digest", "--project", "p1", "--part", "core-setup"])
    pinned = [l for l in text.splitlines() if l.startswith("- (c ")]
    assert sum(mem.est_tokens(l) for l in pinned) <= mem.ANCHOR_BUDGET
    omitted = 12 - len(pinned)
    assert omitted > 0
    assert "rule 11" in text and "rule 00" not in text
    assert ("[{} rows omitted - mem digest --project p1 --part core-setup "
            "--budget-tokens 6000, or mem search]".format(omitted)) in text
    wide = run_text(["digest", "--project", "p1", "--part", "core-setup",
                     "--budget-tokens", "6000"])
    assert "rows omitted" not in wide and "rule 00" in wide


def test_stale_blockers_collapse_to_one_count_line(db, run, run_text, monkeypatch):
    real_now = mem.now_iso
    monkeypatch.setattr(mem, "now_iso", lambda: "2020-01-01T00:00:00+00:00")
    for i in range(20):     # distinct tokens: the write gate refuses rewordings
        run(["add", "--kind", "blocker", "--project", "p1", "--part", "core",
             "--subject", "old-%02d" % i, "--body", "stale item%02d waiting" % i])
    monkeypatch.setattr(mem, "now_iso", real_now)
    for i in range(18):
        run(["add", "--kind", "blocker", "--project", "p1", "--part", "core",
             "--subject", "new-%02d" % i, "--body", "fresh thing%02d pending" % i])
    cap = mem.DIGEST_CAPS["blocker"]
    lines = run_text(["digest", "--project", "p1", "--budget-tokens",
                      "6000"]).splitlines()
    shown = [l for l in lines if l.startswith("- (b ")]
    assert len(shown) == cap and all("fresh thing" in l for l in shown)
    head = lines.index("## Open blockers")
    assert lines[head + cap + 1] == ("- 20 blockers unconfirmed for 90 days not shown: "
                                     "mem review-blockers --project p1")
    assert ("[{} rows omitted - mem digest --project p1 --budget-tokens 6000, or "
            "mem search]".format(18 - cap)) in lines


def test_footers_name_the_installed_command_form(db, run, run_text, tmp_path,
                                                monkeypatch):
    """A footer must be runnable where `mem` is not on PATH (field test [15])."""
    from memdb import config
    home = tmp_path / "cfghome"
    monkeypatch.setenv("MEMDB_HOME", str(home))
    config.save(dict(config.DEFAULTS, interpreter="/opt/py/python3",
                     command_form=config.FORM_INTERPRETER))
    seed(run, n_state=500)
    text = run_text(["digest", "--project", "p1", "--budget-tokens", "400"])
    assert "rows omitted - /opt/py/python3 -m memdb digest --project p1" in text
    assert "or /opt/py/python3 -m memdb search]" in text
    assert "mem search" not in text.replace("memdb search", "")


def test_only_stale_blockers_still_render_the_section(db, run, run_text, monkeypatch):
    monkeypatch.setattr(mem, "now_iso", lambda: "2020-01-01T00:00:00+00:00")
    run(["add", "--kind", "blocker", "--project", "p1", "--part", "core",
         "--subject", "old", "--body", "old blocker"])
    text = run_text(["digest", "--project", "p1"])
    assert "## Open blockers" in text and "old blocker" not in text
    assert ("- 1 blockers unconfirmed for 90 days not shown: mem review-blockers "
            "--project p1") in text
    assert "rows omitted" not in text


def test_user_origin_is_marked_in_digest_and_search(db, run, run_text):
    run(["add", "--kind", "constraint", "--project", "p1", "--part", "core-setup",
         "--subject", "said-by-user", "--body", "never flash on friday",
         "--origin", "user"])
    run(["add", "--kind", "constraint", "--project", "p1", "--part", "core-setup",
         "--subject", "inferred", "--body", "the rig prefers cold boots"])
    text = run_text(["digest", "--project", "p1", "--part", "core-setup"])
    assert "- (c testhost:1 u) never flash on friday" in text
    assert "- (c testhost:2) the rig prefers cold boots" in text
    hits = run(["search", "--query", "flash friday"])
    assert hits[0]["origin"] == "user"
    # the user re-stating an agent row upgrades its origin, never the reverse
    run(["add", "--kind", "constraint", "--project", "p1", "--part", "core-setup",
         "--subject", "inferred", "--body", "the rig prefers cold boots",
         "--origin", "user"])
    run(["add", "--kind", "constraint", "--project", "p1", "--part", "core-setup",
         "--subject", "said-by-user", "--body", "never flash on friday"])
    assert {h["subject"]: h["origin"] for h in run(
        ["search", "--query", "rig cold boots flash friday"])} == {
            "said-by-user": "user", "inferred": "user"}
    run(["rebuild", "--full"])
    assert run(["verify", "--full"])[0]["ok"] is True


def test_core_setup_body_cap_at_write(db, run, monkeypatch):
    import pytest
    base = ["add", "--kind", "constraint", "--project", "p1"]
    with pytest.raises(SystemExit, match="--rationale"):
        run(base + ["--subject", "a", "--part", "core-setup",
                    "--body", "z" * 501])
    assert run(base + ["--subject", "b", "--part", "core-setup",
                       "--body", "z" * 500])[0]["action"] == "added"
    assert run(base + ["--subject", "c", "--part", "work",
                       "--body", "z" * 2000])[0]["action"] == "added"
    with pytest.raises(SystemExit, match="capped at 1000"):
        run(["add", "--kind", "runbook", "--project", "p1", "--part", "ops",
             "--subject", "cmd", "--body", "c" * 1001])
    monkeypatch.setenv("MEMDB_CORE_BODY_MAX", "600")
    assert run(["add", "--kind", "goal", "--project", "p1", "--part",
                "core-setup", "--subject", "g", "--body", "g" * 550])[0][
        "action"] == "added"


def test_global_constraints_pin_in_every_project_digest(db, run, run_text):
    run(["add", "--kind", "constraint", "--project", "global",
         "--part", "cross-cutting", "--subject", "chat-live",
         "--body", "the chat must always stay responsive"])
    seed(run)
    text = run_text(["digest", "--project", "p1"])
    assert "chat must always stay responsive" in text
    assert "no dynamic allocation" in text
    # and a foreign project's constraint must NOT leak in
    run(["add", "--kind", "constraint", "--project", "p2", "--part", "core",
         "--subject", "other", "--body", "unrelated project constraint"])
    text = run_text(["digest", "--project", "p1"])
    assert "unrelated project constraint" not in text

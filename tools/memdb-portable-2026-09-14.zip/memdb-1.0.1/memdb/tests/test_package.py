"""S-PKG-01: the package entry points, and the old command lines still work.

Every subprocess here runs against a throwaway MEMDB_HOME, so none of it
touches the real store.
"""
import json
import os
import shutil
import subprocess
import sys

import pytest

from memdb import mem

MEMDB_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_ROOT = os.path.dirname(MEMDB_DIR)
MEM_PY = os.path.join(MEMDB_DIR, "mem.py")
WRAPPER = os.path.join(MEMDB_DIR, "hooks", "session_start.sh")
HOOK_STDIN = json.dumps({"session_id": "pkg-test-session",
                         "transcript_path": "/nowhere/t.jsonl",
                         "cwd": "/nowhere",
                         "hook_event_name": "SessionStart"})


def clean_env(home, **extra):
    """Environment for a subprocess: a private MEMDB_HOME, no inherited pins."""
    env = dict(os.environ)
    for key in ("MEMDB_PATH", "MEMDB_JOURNAL", "MEMDB_HOST",
                "MEMDB_HOST_OVERRIDE", "MEMDB_HOOK_SCOPE", "MEMDB_PYTHON",
                "MEMDB_BUDGET", "PYTHONPATH"):
        env.pop(key, None)
    env["MEMDB_HOME"] = str(home)
    env["MEMDB_CORE_RULES"] = os.path.join(str(home), "no-core-rules.md")
    env.update(extra)
    return env


def run(argv, env, cwd):
    return subprocess.run(argv, env=env, cwd=str(cwd), capture_output=True,
                          text=True, timeout=120)


def seeded_home(tmp_path, name="home"):
    """A MEMDB_HOME with a host id and one pinned record; returns (home, env)."""
    home = tmp_path / name
    home.mkdir(parents=True, exist_ok=True)
    (home / "host-id").write_text("pkghost\n", encoding="utf-8")
    env = clean_env(home, PYTHONPATH=REPO_ROOT, MEMDB_PROJECT="pkgproj",
                    MEMDB_PART="core-setup")
    assert run([sys.executable, "-m", "memdb", "init"], env,
               tmp_path).returncode == 0
    add = run([sys.executable, "-m", "memdb", "add", "--kind", "constraint",
               "--project", "pkgproj", "--part", "core-setup",
               "--subject", "pkg-rule", "--body", "never ship on a friday"],
              env, tmp_path)
    assert add.returncode == 0, add.stderr
    return home, env


# ------------------------------------------------------------- entry points

def test_module_entry_point_reports_the_version(tmp_path):
    env = clean_env(tmp_path / "home", PYTHONPATH=REPO_ROOT)
    p = run([sys.executable, "-m", "memdb", "--version"], env, tmp_path)
    assert p.returncode == 0, p.stderr
    assert p.stdout.strip() == "memdb " + mem.__version__


def test_schema_loads_through_package_resources():
    text = mem.schema_sql()
    assert "CREATE TABLE IF NOT EXISTS records" in text
    assert "records_fts" in text


def test_flat_script_form_still_initialises(tmp_path):
    """`python <checkout>/memdb/mem.py init` - what every host runs today."""
    home = tmp_path / "flat"
    home.mkdir()
    env = clean_env(home)
    p = run([sys.executable, MEM_PY, "init"], env, tmp_path)
    assert p.returncode == 0, p.stderr
    out = json.loads(p.stdout.strip())
    assert out["schema_version"] == mem.SCHEMA_VERSION
    assert os.path.exists(out["db"])


def test_flat_and_module_forms_agree_on_doctor(tmp_path):
    home, env = seeded_home(tmp_path)
    flat = run([sys.executable, MEM_PY, "doctor"], clean_env(home), tmp_path)
    module = run([sys.executable, "-m", "memdb", "doctor"], env, tmp_path)
    assert flat.returncode == module.returncode == 0, flat.stderr + module.stderr
    a, b = json.loads(flat.stdout), json.loads(module.stdout)
    for report in (a, b):
        report["checks"].pop("verified_anchors", None)
        report["checks"].pop("snapshot", None)
    assert a == b
    assert a["checks"]["version"]["detail"] == mem.__version__


# -------------------------------------------------------------- hook parity

def hook_output(argv, env, cwd):
    p = subprocess.run(argv, env=env, cwd=str(cwd), input=HOOK_STDIN,
                       capture_output=True, text=True, timeout=120)
    assert p.returncode == 0, p.stderr
    return json.loads(p.stdout.strip())


@pytest.mark.skipif(shutil.which("bash") is None, reason="wrapper-needs-bash")
def test_transition_wrapper_matches_the_python_hook(tmp_path):
    """The registered bash command still works: no MEMDB_PYTHON, no
    PYTHONPATH, a foreign cwd."""
    home, env = seeded_home(tmp_path)
    direct = hook_output([sys.executable, "-m", "memdb", "hook",
                          "session-start"], env, tmp_path)
    wrapper_env = clean_env(home, MEMDB_PROJECT="pkgproj",
                            MEMDB_PART="core-setup")
    wrapped = hook_output([shutil.which("bash"), WRAPPER], wrapper_env,
                          tmp_path)
    assert wrapped == direct
    assert "memdb UNAVAILABLE" not in json.dumps(wrapped)

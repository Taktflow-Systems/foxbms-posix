"""`mem project-slug --cwd <dir>` (audit F-11, plan S-AUD-03).

The SessionStart hook used `basename "$CWD"`, which on Windows yields the
whole backslash path as the slug. project-slug resolves the git toplevel,
splits on both separators, and maps the name to the most recently
written spelling of a known project. When the toplevel name is unknown
(a checkout nested in an untracked folder of a larger repo, F-22) it also
tries the folders below the toplevel, then the folders above it.
"""
import os
import subprocess

import pytest

from memdb import mem


def git_init(path):
    os.makedirs(path, exist_ok=True)
    subprocess.run(["git", "init", "-q", str(path)], check=True,
                   capture_output=True, timeout=60)


@pytest.fixture
def ceiling(tmp_path, monkeypatch):
    """Stop git discovery at tmp_path (the pytest temp dir may sit inside a repo)."""
    monkeypatch.setenv("GIT_CEILING_DIRECTORIES",
                       str(tmp_path).replace("\\", "/"))
    return tmp_path


def slug(run_text, cwd):
    return run_text(["project-slug", "--cwd", str(cwd)]).strip()


def add(run, project, n=0):
    run(["add", "--kind", "state", "--project", project, "--part", "x",
         "--subject", "s-%s-%d" % (project, n), "--body", "b " + project])


def test_backslash_path_outside_any_repo(db, run_text, ceiling):
    cwd = "C:\\work\\Some Dir\\MyProj"
    assert slug(run_text, cwd) == "MyProj"
    assert mem.resolve_project_slug(cwd + "\\", None, {}) == "MyProj"


def test_nested_subdirectory_of_a_repo(db, run_text, ceiling):
    git_init(ceiling / "alpha")
    deep = ceiling / "alpha" / "src" / "deep"
    os.makedirs(deep)
    assert slug(run_text, deep) == "alpha"


def test_non_repo_cwd_uses_its_own_name(db, run_text, ceiling):
    plain = ceiling / "plain" / "work"
    os.makedirs(plain)
    assert slug(run_text, plain) == "work"


def test_case_split_project_resolves_to_newest_spelling(db, run, run_text,
                                                        ceiling):
    add(run, "fo4re")
    add(run, "FO4RE")                       # written last -> canonical
    git_init(ceiling / "Fo4Re")
    assert slug(run_text, ceiling / "Fo4Re") == "FO4RE"
    add(run, "fo4re", n=1)                  # a new row, so a newer created_at
    assert slug(run_text, ceiling / "Fo4Re") == "fo4re"


def test_known_toplevel_beats_known_subfolder(db, run, run_text, ceiling):
    add(run, "CUS-BMS")
    add(run, "tools")
    git_init(ceiling / "CUS-BMS")
    sub = ceiling / "CUS-BMS" / "tools"
    os.makedirs(sub)
    assert slug(run_text, sub) == "CUS-BMS"


def test_untracked_folder_inside_a_larger_repo(db, run, run_text, ceiling):
    add(run, "Memory-orchestration")
    git_init(ceiling / "bigrepo")
    folder = ceiling / "bigrepo" / "memory-orchestration"
    os.makedirs(folder)
    assert slug(run_text, folder) == "Memory-orchestration"


def test_unknown_checkout_inside_a_known_parent_folder(db, run, run_text,
                                                       ceiling):
    add(run, "Memory-orchestration")
    checkout = ceiling / "Memory-orchestration" / "claude-remote"
    git_init(checkout)
    assert slug(run_text, checkout) == "Memory-orchestration"


def test_unknown_everywhere_returns_toplevel_name(db, run_text, ceiling):
    git_init(ceiling / "brand-new")
    sub = ceiling / "brand-new" / "lib"
    os.makedirs(sub)
    assert slug(run_text, sub) == "brand-new"


def test_windows_cwd_against_git_style_toplevel():
    known = {"parent-proj": "Parent-Proj"}
    got = mem.resolve_project_slug(
        "x:\\ws\\parent-proj\\checkout", "X:/ws/Parent-Proj/checkout", known)
    assert got == "Parent-Proj"
    assert mem.resolve_project_slug("X:\\", "X:/", known) == "X:"


def test_a_repository_at_a_drive_root_names_the_folder_below_the_drive():
    """Field test iteration 2: a session in X:\\tmp\\x (X:/ is a repo) reported 'no records for project X:'."""
    assert mem.resolve_project_slug("X:\\tmp\\work", "X:/", {}) == "tmp"
    assert mem.resolve_project_slug("X:\\NewProj\\src", "X:/", {"src": "src"}) == "src"


def test_global_is_never_a_slug(db, run, run_text, ceiling):
    run(["add", "--kind", "constraint", "--project", "global",
         "--part", "core-setup", "--subject", "g", "--body", "g"])
    git_init(ceiling / "global")
    assert slug(run_text, ceiling / "global") == "global"
    assert "global" not in mem.known_projects()


def test_missing_db_is_not_created(tmp_path, monkeypatch, run_text, ceiling):
    path = tmp_path / "absent" / "mem.db"
    monkeypatch.setenv("MEMDB_PATH", str(path))
    assert slug(run_text, ceiling / "x" / "proj") == "proj"
    assert not path.exists()

"""Search ranking and a repeatable retrieval eval (audit F-07, plan
S-AUD-05).

Default: a fixture store with ranking traps (superseded and closed
look-alikes, old vs fresh rows, migration tags). MEMDB_EVAL_REAL=1: the
real store (read-only) against tests/eval/queries.jsonl. Both assert
hit@5 >= 0.80 and print hit@1, hit@5, MRR and the search p50 latency.
"""
import json
import os
import time

import pytest

from memdb import journal
from memdb import mem

EVAL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "eval")
HIT5_GATE = 0.80


def percentile(values, pct):
    values = sorted(values)
    return values[min(len(values) - 1, int(round(pct / 100 * (len(values) - 1))))]


def evaluate(conn, queries):
    hit1 = hit5 = 0
    rr, times = 0.0, []
    for q in queries:
        t0 = time.perf_counter()
        rows = mem.search_rows(conn, q["query"], project=q.get("project"),
                               limit=5)
        times.append(time.perf_counter() - t0)
        uids = [r["uid"] for r in rows]
        ranks = [uids.index(u) + 1 for u in q["expect_uids"] if u in uids]
        if ranks:
            hit5 += 1
            hit1 += min(ranks) == 1
            rr += 1.0 / min(ranks)
    n = len(queries)
    report = {"n": n, "hit1": round(hit1 / n, 3), "hit5": round(hit5 / n, 3),
              "mrr": round(rr / n, 3),
              "search_p50_ms": round(percentile(times, 50) * 1000, 2)}
    print(json.dumps(report, sort_keys=True))
    return report


def append_add(host, seq_ts, kind, project, subject, body, ts):
    journal.append_event(host, "add",
                         {"kind": kind, "project": project, "part": "x",
                          "subject": subject, "body": body, "ts": ts}, seq_ts)


def build_fixture(run):
    old = "2024-01-01T00:00:00+00:00"
    new = mem.now_iso()
    rows = [
        ("constraint", "p1", "grep-ban-old", "grep and glob are blocked, use the distiller search", old),
        ("constraint", "p1", "flash-tool", "flash the board with the st-link cli, never the gui", new),
        ("decision", "p1", "storage", "use sqlite for the event store", old),
        ("decision", "p1", "storage", "use sqlite with wal for the event store", new),
        ("state", "p2", "bench", "the bench power supply is at 24 volts", old),
        ("state", "p2", "bench-now", "the bench power supply now runs at 12 volts", new),
        ("constraint", "p2", "migrated", "[migrated 2026-08-22 from auto-memory x/memory/y.md] "
                                         "always tag releases with the build id", new),
        ("preference", "p3", "reports", "lead reports with the outcome in one line", new),
        ("blocker", "p3", "rig", "hil rig offline waiting for a new usb hub", new),
    ]
    for i, (kind, project, subject, body, ts) in enumerate(rows):
        append_add("testhost", ts, kind, project, subject, body, ts)
    run(["rebuild", "--full"])
    conn = mem.connect()
    uid = {r["body"]: r["uid"] for r in conn.execute("SELECT uid, body FROM records")}
    conn.close()
    # the older storage decision is superseded by the newer one (same subject);
    # the reworded grep rule names the row it replaces (the write gate asks)
    run(["add", "--kind", "constraint", "--project", "p1", "--part", "x",
         "--subject", "grep-ban", "--body", "grep and glob are hook-blocked; search with distill.py",
         "--supersedes", uid["grep and glob are blocked, use the distiller search"]])
    run(["close", uid["the bench power supply is at 24 volts"]])
    return uid


def test_fixture_eval_ranks_open_and_recent_first(db, run, capsys):
    uid = build_fixture(run)
    capsys.readouterr()
    queries = [
        {"query": "grep glob blocked distiller", "expect_uids": ["testhost:10"]},
        {"query": "sqlite event store", "expect_uids": [uid["use sqlite with wal for the event store"]]},
        {"query": "bench power supply volts", "expect_uids": [uid["the bench power supply now runs at 12 volts"]]},
        {"query": "flash the board", "expect_uids": [uid["flash the board with the st-link cli, never the gui"]]},
        {"query": "tag releases build id", "expect_uids": [uid[
            "[migrated 2026-08-22 from auto-memory x/memory/y.md] always tag releases with the build id"]]},
        {"query": "outcome in one line", "expect_uids": [uid["lead reports with the outcome in one line"]]},
        {"query": "hil rig usb hub", "expect_uids": [uid["hil rig offline waiting for a new usb hub"]]},
    ]
    conn = mem.connect()
    try:
        report = evaluate(conn, queries)
        assert report["hit5"] >= HIT5_GATE
        # open successor outranks the superseded look-alike; open outranks closed
        top = mem.search_rows(conn, "grep glob blocked distiller", limit=2)
        assert top[0]["uid"] == "testhost:10" and top[1]["status"] == "superseded"
        top = mem.search_rows(conn, "bench power supply volts", limit=2)
        assert [r["status"] for r in top] == ["open", "closed"]
    finally:
        conn.close()


def test_closed_status_never_demotes_an_episode(db, run, tmp_path):
    doc = {"achievement": ["calibrated the thermistor table on the rig"],
           "current_state": {"summary": "thermistor table calibrated"}}
    p = tmp_path / "ep.json"
    p.write_text(json.dumps(doc), encoding="utf-8")
    ep = run(["record-episode", "--project", "p1", "--part", "x", "--task",
              "thermistor-calibration", "--json", str(p)])[0]
    st = run(["add", "--kind", "state", "--project", "p1", "--part", "x",
              "--subject", "thermistor-table", "--body", "thermistor table calibrated"])[0]
    run(["close", st["uid"]])
    conn = mem.connect()
    try:
        rows = mem.search_rows(conn, "thermistor table calibrated", limit=2)
    finally:
        conn.close()
    assert rows[0]["uid"] == ep["uid"] and rows[0]["status"] == "closed"


def test_search_cli_flags_and_snippet(db, run):
    build_fixture(run)
    hits = run(["search", "--query", "grep glob blocked", "--open-only"])
    assert {h["status"] for h in hits} == {"open"}
    hits = run(["search", "--query", "sqlite event store", "--recent", "30"])
    assert len(hits) == 1 and "wal" in hits[0]["summary"]
    hits = run(["search", "--query", "tag releases build id"])
    assert hits[0]["summary"] == "always tag releases with the build id"
    with pytest.raises(SystemExit, match="conflicts"):
        run(["search", "--query", "x", "--open-only", "--status", "closed"])


def test_fts_query_adds_the_exact_phrase():
    assert mem.fts_query("bench volts") == '"bench volts" OR "bench" OR "volts"'
    assert mem.fts_query("single") == '"single"'


@pytest.mark.skipif(os.environ.get("MEMDB_EVAL_REAL") != "1",
                    reason="set MEMDB_EVAL_REAL=1 to evaluate the real store")
def test_real_store_eval():
    queries = [json.loads(l) for l in open(os.path.join(EVAL_DIR, "queries.jsonl"),
                                           encoding="utf-8") if l.strip()]
    assert len(queries) >= 30
    conn = mem.connect(os.environ.get("MEMDB_EVAL_DB") or mem.DEFAULT_DB)
    try:
        report = evaluate(conn, queries)
    finally:
        conn.close()
    assert report["hit5"] >= HIT5_GATE, report

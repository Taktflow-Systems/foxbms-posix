#!/usr/bin/env python3
"""Scale benchmark + budget gates (plan-scalability S-MEM-SCALE-01).

Generates a synthetic multi-host journal (realistic payload mix: ~70%
add / ~25% episode / ~5% close), then times the operations the plan
optimizes. Prints a JSON report; exits non-zero on any budget failure.

Never touches the real store: it builds its own temp MEMDB_JOURNAL /
MEMDB_PATH and refuses to run if they would resolve to ~/.claude.

Usage:
    python tests/bench_scale.py [--events 20000] [--tail 1000] [--keep]
"""
import argparse
import io
import json
import os
import shutil
import sys
import tempfile
import time
from contextlib import redirect_stdout

MEMDB_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, MEMDB_DIR)

HOSTS = (("bench-a", 0.80), ("bench-b", 0.15), ("bench-c", 0.05))

# Budgets independent of N (that is the point: these operations must not
# scale with total history). Full rebuild/replay is O(N) by design and is
# reported, not gated.
BUDGETS = {
    "append_ms": 50.0,              # one add at full journal size
    "snapshot_rebuild_s": 15.0,     # rebuild of a --tail-sized suffix
    "snapshot_verify_s": 20.0,      # verify (snapshot mode)
    "suffix_chain_verify_s": 2.0,   # anchored chain walk, fresh anchor
}


def ts_at(i):
    return "2026-03-%02dT%02d:%02d:%02d+00:00" % (
        1 + i // 86400, (i % 86400) // 3600, (i % 3600) // 60, i % 60)


def gen_events(journal_mod, n):
    """Write n events across HOSTS directly (chain computed inline -
    fixture generation, not the code under test)."""
    import random
    rng = random.Random(42)
    per_host = {}
    for i in range(n):
        r = rng.random()
        acc = 0
        for host, share in HOSTS:
            acc += share
            if r <= acc:
                break
        per_host.setdefault(host, []).append(i)
    uid_pool = []
    for host, idxs in per_host.items():
        path = journal_mod.host_file(host)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        prev = None
        lines = []
        for seq, i in enumerate(idxs, 1):
            roll = rng.random()
            if roll < 0.05 and uid_pool:
                etype = "close"
                payload = {"uid": rng.choice(uid_pool), "ts": ts_at(i)}
            elif roll < 0.30:
                etype = "episode"
                payload = {
                    "project": "bench", "part": "core", "task": "t%d" % i,
                    "session_id": None, "ts": ts_at(i),
                    "doc": {
                        "achievement": ["did %d" % i, "verified %d" % i],
                        "decisions_with_rationale": [
                            {"decision": "chose approach %d" % i,
                             "rationale": "because " + "r" * 120}],
                        "current_state": {
                            "summary": "state after %d " % i + "s" * 200,
                            "status": ["thing %d done" % i]},
                        "blockers": [],
                        "next_steps": ["next %d" % i],
                        "raw_markdown": "# job %d\n" % i + "x" * 1500}}
            else:
                etype = "add"
                payload = {"kind": "state", "project": "bench",
                           "part": "core", "subject": "subj%d" % (i % 500),
                           "body": "body %d " % i + "b" * rng.randint(80, 600),
                           "ts": ts_at(i)}
                uid_pool.append("{}:{}".format(host, seq))
            ev = {"v": 1, "host": host, "seq": seq, "ts": ts_at(i),
                  "type": etype, "prev": prev, "payload": payload}
            line = journal_mod.canonical_line(ev)
            prev = journal_mod.line_hash(line)
            lines.append(line)
        with open(path, "w", encoding="utf-8", newline="\n") as f:
            f.write("\n".join(lines) + "\n")
    return uid_pool


def run_cli(mem_mod, argv):
    """Run a mem command, return its parsed JSON report."""
    buf = io.StringIO()
    with redirect_stdout(buf):
        mem_mod.main(argv)
    lines = buf.getvalue().strip().splitlines()
    return json.loads(lines[-1]) if lines else {}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--events", type=int, default=20000)
    ap.add_argument("--tail", type=int, default=1000,
                    help="events appended after the snapshot")
    ap.add_argument("--keep", action="store_true",
                    help="keep the temp store for inspection")
    args = ap.parse_args()

    tmp = tempfile.mkdtemp(prefix="memdb-bench-")
    os.environ["MEMDB_PATH"] = os.path.join(tmp, "mem.db")
    os.environ["MEMDB_JOURNAL"] = os.path.join(tmp, "journal-root")
    os.environ["MEMDB_HOST"] = "bench-a"
    os.environ["MEMDB_HOST_OVERRIDE"] = "1"
    import journal
    import mem
    assert "claude" not in journal.journal_root().lower() or \
        tmp in journal.journal_root(), "refusing: journal root not temp"

    report = {"events": args.events, "tail": args.tail, "timings": {},
              "budgets": {}, "ok": True}
    t = report["timings"]

    t0 = time.perf_counter()
    gen_events(journal, args.events)
    t["generate_s"] = round(time.perf_counter() - t0, 3)

    # The generator writes raw journals with no sidecar, so the first
    # append pays the one-time full-scan self-heal - report it, but the
    # O(1) claim (S-02) is about steady state: time the SECOND append.
    t0 = time.perf_counter()
    journal.append_event("bench-a", "add",
                         {"kind": "state", "project": "bench",
                          "part": "core", "subject": "probe0",
                          "body": "sidecar heal", "ts": ts_at(args.events)},
                         ts_at(args.events))
    t["append_selfheal_ms"] = round((time.perf_counter() - t0) * 1000, 2)
    t0 = time.perf_counter()
    journal.append_event("bench-a", "add",
                         {"kind": "state", "project": "bench",
                          "part": "core", "subject": "probe",
                          "body": "append probe", "ts": ts_at(args.events)},
                         ts_at(args.events))
    t["append_ms"] = round((time.perf_counter() - t0) * 1000, 2)

    t0 = time.perf_counter()
    out = run_cli(mem, ["rebuild", "--full", "--verify"])
    t["full_rebuild_verify_s"] = round(time.perf_counter() - t0, 3)
    assert out["ok"] and out["mode"] == "full", out

    # tail after the snapshot, then the fast paths (S-04/S-05)
    for i in range(args.tail):
        journal.append_event(
            "bench-a", "add",
            {"kind": "state", "project": "bench", "part": "core",
             "subject": "tail%d" % (i % 50), "body": "tail body %d" % i,
             "ts": ts_at(args.events + 1 + i)},
            ts_at(args.events + 1 + i))

    t0 = time.perf_counter()
    anchor = journal.load_anchor("bench-a")
    ok, err = journal.verify_chain(journal.host_file("bench-a"),
                                   anchor=anchor)
    t["suffix_chain_verify_s"] = round(time.perf_counter() - t0, 3)
    assert ok, err

    t0 = time.perf_counter()
    out = run_cli(mem, ["rebuild"])
    t["snapshot_rebuild_s"] = round(time.perf_counter() - t0, 3)
    assert out["mode"] == "snapshot", out

    t0 = time.perf_counter()
    out = run_cli(mem, ["verify"])
    t["snapshot_verify_s"] = round(time.perf_counter() - t0, 3)
    assert out["ok"] and out["mode"] == "snapshot", out

    t0 = time.perf_counter()
    with redirect_stdout(io.StringIO()):    # digest emits markdown
        mem.main(["digest", "--project", "bench"])
    t["digest_s"] = round(time.perf_counter() - t0, 3)

    for name, budget in BUDGETS.items():
        actual = t[name]
        passed = actual <= budget
        report["budgets"][name] = {"budget": budget, "actual": actual,
                                   "ok": passed}
        if not passed:
            report["ok"] = False

    report["journal_mb"] = round(sum(
        os.path.getsize(journal.host_file(h)) for h, _ in HOSTS
        if os.path.exists(journal.host_file(h))) / 1e6, 1)
    report["db_mb"] = round(os.path.getsize(os.environ["MEMDB_PATH"]) / 1e6,
                            1)
    print(json.dumps(report, indent=1))
    if args.keep:
        print("kept: " + tmp, file=sys.stderr)
    else:
        shutil.rmtree(tmp, ignore_errors=True)
    sys.exit(0 if report["ok"] else 1)


if __name__ == "__main__":
    main()

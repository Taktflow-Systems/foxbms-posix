"""Streaming projection comparison (plan-scalability S-MEM-SCALE-03).

projections_equal must return exactly the verdict the old
normalized_dump string comparison returned, in O(1) memory. The
differential tests run both comparators on every fixture.
"""
import random
import shutil
import sqlite3

from memdb import journal
from memdb import mem


def both_verdicts(a, b):
    streaming = mem.projections_equal(a, b)
    dump = mem.normalized_dump(a) == mem.normalized_dump(b)
    assert streaming == dump, "comparators disagree"
    return streaming


def build_store(run):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    run(["add", "--kind", "constraint", "--project", "p1", "--part", "core",
         "--subject", "safe", "--body", "never break the chain",
         "--rationale", "because"])
    # supersede path: same subject, different body -> links row + pointer
    run(["add", "--kind", "constraint", "--project", "p1", "--part", "core",
         "--subject", "safe", "--body", "never ever break the chain"])


def test_identical_copies_are_equal(db, run, tmp_path):
    build_store(run)
    copy = str(tmp_path / "copy.db")
    shutil.copy2(db, copy)
    assert both_verdicts(db, copy) is True


def test_body_drift_detected(db, run, tmp_path):
    build_store(run)
    copy = str(tmp_path / "copy.db")
    shutil.copy2(db, copy)
    c = sqlite3.connect(copy)
    c.execute("UPDATE records SET body='drifted' WHERE subject='ship'")
    c.commit()
    c.close()
    assert both_verdicts(db, copy) is False


def test_missing_row_detected(db, run, tmp_path):
    build_store(run)
    copy = str(tmp_path / "copy.db")
    shutil.copy2(db, copy)
    c = sqlite3.connect(copy)
    c.execute("DELETE FROM links")
    c.execute("UPDATE records SET superseded_by=NULL")
    c.execute("DELETE FROM records WHERE subject='ship'")
    c.commit()
    c.close()
    assert both_verdicts(db, copy) is False


def test_link_drift_detected(db, run, tmp_path):
    build_store(run)
    copy = str(tmp_path / "copy.db")
    shutil.copy2(db, copy)
    c = sqlite3.connect(copy)
    c.execute("UPDATE links SET relation='relates' "
              "WHERE relation='supersedes'")
    c.commit()
    c.close()
    assert both_verdicts(db, copy) is False


def test_supersede_pointer_drift_detected(db, run, tmp_path):
    build_store(run)
    copy = str(tmp_path / "copy.db")
    shutil.copy2(db, copy)
    c = sqlite3.connect(copy)
    c.execute("UPDATE records SET superseded_by=NULL "
              "WHERE superseded_by IS NOT NULL")
    c.commit()
    c.close()
    assert both_verdicts(db, copy) is False


def test_differential_on_randomized_mutations(db, run, tmp_path):
    """50 random single-cell mutations: streaming and dump comparators
    must agree on every one (plan acceptance criterion)."""
    build_store(run)
    rng = random.Random(20260831)
    # only columns without CHECK constraints: mutation must produce a
    # valid-but-different row, not an integrity error
    mutable = ["body", "subject", "created_at",
               "rationale", "part", "project"]
    base = sqlite3.connect(db)
    ids = [r[0] for r in base.execute("SELECT id FROM records")]
    base.close()
    for i in range(50):
        copy = str(tmp_path / ("m%d.db" % i))
        shutil.copy2(db, copy)
        c = sqlite3.connect(copy)
        if rng.random() < 0.2:      # no-op copy: must compare equal
            expected = True
        else:
            col = rng.choice(mutable)
            rid = rng.choice(ids)
            c.execute("UPDATE records SET {}=? WHERE id=?".format(col),
                      ("mut%d" % i, rid))
            expected = False
        c.commit()
        c.close()
        assert both_verdicts(db, copy) is expected, (i,)

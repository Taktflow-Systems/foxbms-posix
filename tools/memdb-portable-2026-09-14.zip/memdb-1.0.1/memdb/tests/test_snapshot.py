"""Snapshot rebuild (plan-scalability S-MEM-SCALE-05).

The core property: snapshot + tail replay through the UNCHANGED appliers
is provably equal (streaming compare) to a full replay - over randomized
multi-host event mixes. Every fallback is loud, never silent; chain
damage FAILS the fast path rather than falling back.
"""
import json
import os
import random

import pytest

from memdb import journal
from memdb import mem


def append(host, etype, payload, ts):
    journal.append_event(host, etype, payload, ts)


def rand_events(rng, hosts, n, t0=0, uid_pool=None):
    """Append n random events (add/episode/close mix) with increasing ts;
    returns the running uid pool for close targets."""
    uid_pool = uid_pool if uid_pool is not None else []
    seqs = {h: len(journal.read_events(journal.host_file(h))) for h in hosts}
    for i in range(n):
        host = rng.choice(hosts)
        t = t0 + i
        ts = "2026-02-01T%02d:%02d:%02d+00:00" % (t // 3600, (t % 3600) // 60,
                                                  t % 60)
        roll = rng.random()
        if roll < 0.15 and uid_pool:
            append(host, "close", {"uid": rng.choice(uid_pool), "ts": ts},
                   ts)
            seqs[host] += 1
            continue
        if roll < 0.35:
            doc = {"achievement": ["did thing %d" % i],
                   "decisions_with_rationale": [
                       {"decision": "d%d" % i, "rationale": "r"}],
                   "current_state": {"summary": "s%d" % i,
                                     "status": ["state %d" % i]},
                   "blockers": [], "next_steps": ["n"]}
            append(host, "episode",
                   {"project": "p1", "part": "core", "task": "t%d" % i,
                    "doc": doc, "ts": ts, "session_id": None}, ts)
            seqs[host] += 1
            continue
        # adds: subjects repeat (mod 7) so supersede/confirm paths run
        append(host, "add",
               {"kind": rng.choice(["state", "decision", "goal"]),
                "project": "p1", "part": "core",
                "subject": "subj%d" % (i % 7),
                "body": "body %d %s" % (i, "x" * rng.randint(10, 120)),
                "ts": ts}, ts)
        seqs[host] += 1
        uid_pool.append("{}:{}".format(host, seqs[host]))
    return uid_pool


def full_replay_equal(db):
    tmp = db + ".oracle"
    stats = mem.replay(journal.all_events(), tmp)
    assert not stats["unresolved"]
    same = mem.projections_equal(db, tmp)
    os.remove(tmp)
    return same


def test_snapshot_plus_tail_equals_full_replay_randomized(db, run, tmp_path):
    """The plan's core equivalence property, 20 randomized streams.

    Timestamps advance monotonically across trials (real hosts have
    forward-moving clocks); the rewound-clock fallback has its own test.
    """
    clock = 0
    pool = []
    for trial in range(20):
        rng = random.Random(1000 + trial)
        hosts = ["testhost", "hostb"]
        pool = rand_events(rng, hosts, rng.randint(5, 25), t0=clock,
                           uid_pool=pool)
        clock += 100
        out = run(["rebuild", "--full", "--verify"])[0]
        assert out["ok"] is True and out["mode"] == "full"
        pool = rand_events(rng, hosts, rng.randint(1, 15), t0=clock,
                           uid_pool=pool)
        clock += 100
        out = run(["rebuild"])[0]
        assert out["mode"] == "snapshot", out
        assert full_replay_equal(db), "trial %d diverged" % trial


def test_rebuild_uses_snapshot_and_reports_tail(db, run, tmp_path):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    run(["rebuild", "--full"])
    run(["add", "--kind", "state", "--project", "p1", "--part", "core",
         "--subject", "later", "--body", "tail event"])
    out = run(["rebuild"])[0]
    assert out["mode"] == "snapshot"
    assert out["tail"] == 1
    assert out["events"] == 1           # only the tail was replayed


def test_missing_snapshot_falls_back_loudly_to_full(db, run, tmp_path):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    out = run(["rebuild"])[0]
    assert out["mode"] == "full"
    assert "unavailable" in out["snapshot"]


def test_schema_bump_invalidates_snapshot(db, run, tmp_path):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    run(["rebuild", "--full"])
    mpath = mem.snapshot_manifest_path()
    m = json.load(open(mpath, encoding="utf-8"))
    m["schema_version"] = 999
    json.dump(m, open(mpath, "w", encoding="utf-8"))
    out = run(["rebuild"])[0]
    assert out["mode"] == "full"
    assert "schema" in out["snapshot"]


def test_corrupt_snapshot_db_invalidates(db, run, tmp_path):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    run(["rebuild", "--full"])
    with open(mem.snapshot_db_path(), "ab") as f:
        f.write(b"garbage")
    out = run(["rebuild"])[0]
    assert out["mode"] == "full"
    assert "hash mismatch" in out["snapshot"]


def test_rewound_clock_tail_falls_back_to_full(db, run, tmp_path):
    """A tail event whose merge key sorts before the snapshot cutoff
    would reorder history - the fast path must refuse it."""
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    run(["rebuild", "--full"])
    # a NEW host whose events carry an old wall clock: running-max ts
    # starts from scratch, so its key sorts before the snapshot max_key
    append("oldclock", "add",
           {"kind": "state", "project": "p1", "part": "core",
            "subject": "rewound", "body": "old ts",
            "ts": "2001-01-01T00:00:00+00:00"},
           "2001-01-01T00:00:00+00:00")
    out = run(["rebuild"])[0]
    assert out["mode"] == "full"
    assert "sorts at/before" in out["snapshot"]
    assert full_replay_equal(db)


def test_chain_damage_fails_fast_path_never_falls_back(db, run, tmp_path):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    run(["rebuild", "--full"])
    from test_concurrency import corrupt_with_duplicate_seq
    corrupt_with_duplicate_seq(journal.journal_root())
    with pytest.raises(SystemExit):
        mem.main(["rebuild"])


def test_default_verify_uses_snapshot_and_matches(db, run, tmp_path):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    run(["rebuild", "--full"])
    run(["add", "--kind", "state", "--project", "p1", "--part", "core",
         "--subject", "later", "--body", "tail event"])
    out = run(["verify"])[0]
    assert out["mode"] == "snapshot"
    assert out["projection_match"] is True
    out = run(["verify", "--full"])[0]
    assert out["mode"] == "full"
    assert out["projection_match"] is True

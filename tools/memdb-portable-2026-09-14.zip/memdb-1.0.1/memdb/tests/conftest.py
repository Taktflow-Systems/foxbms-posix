import json
import os
import sys

import pytest

MEMDB_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_ROOT = os.path.dirname(MEMDB_DIR)
# The repo root, not memdb/: the package is imported as `memdb.*` so a
# test and the package never hold two copies of one module.
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)
# No test may create, change or delete a real OS schedule; subprocesses inherit it.
os.environ["MEMDB_NO_OS_SCHEDULE"] = "1"

from memdb import mem  # noqa: E402


@pytest.fixture
def db(tmp_path, monkeypatch):
    """Fresh initialized DB + journal root + host identity; returns DB path."""
    path = str(tmp_path / "mem.db")
    monkeypatch.setenv("MEMDB_HOME", str(tmp_path / "memdb-home"))
    monkeypatch.setenv("MEMDB_PATH", path)
    monkeypatch.setenv("MEMDB_JOURNAL", str(tmp_path / "journal-root"))
    monkeypatch.setenv("MEMDB_HOST", "testhost")
    monkeypatch.setenv("MEMDB_HOST_OVERRIDE", "1")
    monkeypatch.delenv("CLAUDE_CODE_SESSION_ID", raising=False)
    monkeypatch.setattr(mem, "SESSIONS_DIR", str(tmp_path / "no-sessions"))
    monkeypatch.setattr(mem, "PROJECTS_DIR", str(tmp_path / "no-projects"))
    mem.main(["init"])
    return path


@pytest.fixture
def run(capsys):
    """Run a mem CLI command, return parsed JSON lines from stdout."""
    def _run(argv):
        mem.main(argv)
        out = capsys.readouterr().out.strip()
        if not out:
            return []
        return [json.loads(line) for line in out.splitlines()]
    return _run


@pytest.fixture
def run_text(capsys):
    """Run a mem CLI command, return raw stdout text."""
    def _run(argv):
        mem.main(argv)
        return capsys.readouterr().out
    return _run

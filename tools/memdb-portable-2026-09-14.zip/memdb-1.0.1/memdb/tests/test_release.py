"""S-PKG-04: release artifacts, `mem selftest`, the cross-host version guard.

The build tests use --worktree so they exercise the code under test; a
real release builds from `git archive HEAD` (docs/release.md). Every run
of an artifact happens in a temp cwd with PYTHONPATH removed, so the
.pyz is the only memdb code the interpreter can find.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import zipfile

import pytest

from memdb import __version__, journal, mem

MEMDB_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_ROOT = os.path.dirname(MEMDB_DIR)
BUILD = os.path.join(REPO_ROOT, "tools", "build_release.py")


def outside_env(tmp_path):
    env = dict(os.environ)
    for key in list(env):
        if key.startswith("MEMDB_") or key == "PYTHONPATH":
            env.pop(key)
    env.update(HOME=str(tmp_path / "home"), USERPROFILE=str(tmp_path / "home"))
    return env


def build(out, *extra):
    p = subprocess.run([sys.executable, BUILD, "--out", str(out), "--no-wheel",
                        "--worktree", *extra], capture_output=True, text=True,
                       timeout=600)
    assert p.returncode == 0, p.stdout + p.stderr
    return json.loads(p.stdout)


@pytest.fixture(scope="module")
def release(tmp_path_factory):
    out = tmp_path_factory.mktemp("dist")
    return out, build(out)


def sha256(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def test_build_produces_both_artifacts_and_the_checksum_file(release):
    out, report = release
    pyz = out / "memdb-{}.pyz".format(__version__)
    portable = out / "memdb-portable-{}.zip".format(__version__)
    assert pyz.is_file() and portable.is_file()
    lines = (out / "SHA256SUMS").read_text(encoding="utf-8").splitlines()
    names = [ln.split("  ", 1)[1] for ln in lines]
    assert names == sorted(names)
    sums = dict(reversed(ln.split("  ", 1)) for ln in lines)
    assert sums == {pyz.name: sha256(pyz), portable.name: sha256(portable)}
    assert report["version"] == __version__
    assert report["wheel"]["built"] is False
    assert {a["name"] for a in report["artifacts"]} == set(sums)


def test_pyz_carries_the_package_without_tests_bench_or_docs(release):
    out, _ = release
    with zipfile.ZipFile(str(out / "memdb-{}.pyz".format(__version__))) as z:
        names = z.namelist()
    assert "__main__.py" in names and "memdb/schema.sql" in names
    assert "memdb/templates/skill.md" in names
    assert not [n for n in names if n.startswith(("memdb/tests/", "memdb/bench/",
                                                  "memdb/docs/"))]
    assert not [n for n in names if "__pycache__" in n]


def test_portable_zip_holds_the_tree_install_guide_and_pyz(release):
    out, _ = release
    top = "memdb-{}/".format(__version__)
    with zipfile.ZipFile(str(out / "memdb-portable-{}.zip".format(
            __version__))) as z:
        names = set(z.namelist())
    for name in ("pyproject.toml", "install/AGENT_INSTALL.md",
                 "memdb/mem.py", "memdb/tests/conftest.py", "CHANGELOG.md",
                 "tools/build_release.py", "memdb-{}.pyz".format(__version__)):
        assert top + name in names, name


def test_build_is_byte_for_byte_reproducible(release, tmp_path):
    out, _ = release
    build(tmp_path)
    assert (tmp_path / "SHA256SUMS").read_bytes() == \
        (out / "SHA256SUMS").read_bytes()


def test_pyz_version_and_selftest_pass_outside_the_checkout(release, tmp_path):
    out, _ = release
    pyz = str(out / "memdb-{}.pyz".format(__version__))
    env = outside_env(tmp_path)
    p = subprocess.run([sys.executable, pyz, "--version"], cwd=str(tmp_path),
                       env=env, capture_output=True, text=True, timeout=120)
    assert p.returncode == 0 and p.stdout.strip() == "memdb " + __version__
    p = subprocess.run([sys.executable, pyz, "selftest"], cwd=str(tmp_path),
                       env=env, capture_output=True, text=True, timeout=300)
    assert p.returncode == 0, p.stdout + p.stderr
    report = json.loads(p.stdout)
    assert report["ok"] is True and report["form"] == "pyz"
    assert [s["step"] for s in report["steps"]] == [
        "init", "add", "record-episode", "close", "supersede",
        "rebuild --full", "verify --full", "digest", "search",
        "hook session-start"]
    assert not (tmp_path / "home").exists()      # never touches HOME


def test_selftest_reports_a_failing_step_and_exits_1(tmp_path, monkeypatch,
                                                     capsys):
    real = mem.selftest_steps

    def broken():
        return [(name, (lambda ctx: "forced failure") if name == "digest"
                 else fn) for name, fn in real()]
    monkeypatch.setattr(mem, "selftest_steps", broken)
    with pytest.raises(SystemExit) as e:
        mem.main(["selftest"])
    assert e.value.code == 1
    report = json.loads(capsys.readouterr().out)
    assert report["ok"] is False
    assert report["steps"][-1]["step"] == "digest"
    assert report["steps"][-1]["ok"] is False


def git(cwd, *args):
    return subprocess.run(["git", *args], cwd=str(cwd), check=True,
                          capture_output=True, text=True)


def test_dirty_means_tracked_changes_under_the_shipped_paths(tmp_path):
    sys.path.insert(0, os.path.dirname(BUILD))
    try:
        import build_release
    finally:
        sys.path.pop(0)
    repo = tmp_path / "repo"
    (repo / "memdb").mkdir(parents=True)
    (repo / "memdb" / "a.py").write_text("x = 1\n", encoding="utf-8")
    (repo / "notes.md").write_text("n\n", encoding="utf-8")
    git(repo, "init", "-q")
    git(repo, "add", ".")
    git(repo, "-c", "user.name=t", "-c", "user.email=t", "commit", "-qm", "c")
    (repo / "memdb" / "new.py").write_text("y = 2\n", encoding="utf-8")
    (repo / "notes.md").write_text("changed\n", encoding="utf-8")
    assert build_release.dirty_paths(str(repo)) == []
    (repo / "memdb" / "a.py").write_text("x = 3\n", encoding="utf-8")
    assert build_release.dirty_paths(str(repo)) == ["memdb/a.py"]


# ------------------------------------------------------------ version guard

def write_witness_file(root, host, heads, **meta):
    path = journal.witness_path(host, str(root))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    body = dict(heads, **meta)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(body, f)


def two_host_root(tmp_path):
    root = tmp_path / "jroot"
    for host in ("hosta", "hostb"):
        journal.append_event(host, "add", {"kind": "state", "project": "p",
                                           "part": "x", "subject": host,
                                           "body": host, "ts": "t"},
                             "2026-01-01T00:00:00+00:00", root=str(root))
    return root


def test_version_guard_warns_about_an_older_host(tmp_path, monkeypatch):
    root = two_host_root(tmp_path)
    write_witness_file(root, "hosta", {}, memdb_version="1.1.0",
                       event_types=["add", "confirm"])
    write_witness_file(root, "hostb", {}, memdb_version="1.0.0",
                       event_types=["add"])
    monkeypatch.setattr(mem, "MIN_VERSION_FOR_EVENT_TYPE", {"confirm": "1.1.0"})
    monkeypatch.setitem(mem.APPLIERS, "confirm", mem.APPLIERS["add"])
    assert mem.version_warnings("hosta", str(root)) == [
        "host hostb runs memdb 1.0.0 which cannot replay event type confirm "
        "written by hosta"]
    assert mem.fleet_versions(str(root)) == {"hosta": "1.1.0", "hostb": "1.0.0"}


def test_version_guard_names_a_type_this_package_cannot_replay(tmp_path):
    root = two_host_root(tmp_path)
    write_witness_file(root, "hostb", {}, memdb_version="9.0.0",
                       event_types=["add", "from-the-future"])
    assert mem.version_warnings("hosta", str(root)) == [
        "host hosta runs memdb {} which cannot replay event type "
        "from-the-future written by hostb".format(__version__)]
    assert mem.fleet_versions(str(root)) == {"hosta": "unknown",
                                             "hostb": "9.0.0"}


def test_witness_records_version_and_event_types(db, run):
    run(["add", "--kind", "state", "--project", "p", "--part", "x",
         "--subject", "s", "--body", "b"])
    run(["verify"])
    w = json.load(open(journal.witness_path("testhost"), encoding="utf-8"))
    assert w["memdb_version"] == __version__
    assert w["event_types"] == ["add"]
    assert w["testhost"]["seq"] == 1
    assert journal.witness_checkpoints("other") == {}


def test_event_types_are_cached_and_follow_appends(db, run):
    run(["add", "--kind", "state", "--project", "p", "--part", "x",
         "--subject", "s", "--body", "b"])
    assert journal.event_types("testhost") == ["add"]
    sidecar = journal.derived_path("testhost", "event-types.json")
    assert os.path.exists(sidecar)
    uid = run(["add", "--kind", "blocker", "--project", "p", "--part", "x",
               "--subject", "b", "--body", "b"])[0]["uid"]
    run(["close", uid])
    assert journal.event_types("testhost") == ["add", "close"]
    with open(sidecar, "w", encoding="utf-8") as f:
        json.dump({"end": 5, "types": ["bogus"]}, f)     # not a line boundary
    assert journal.event_types("testhost") == ["add", "close"]


def test_doctor_prints_the_fleet_version_table(db, run):
    run(["add", "--kind", "state", "--project", "p", "--part", "x",
         "--subject", "s", "--body", "b"])
    run(["verify"])
    report = run(["doctor"])[0]
    assert report["checks"]["fleet"]["detail"] == {"testhost": __version__}


def test_the_release_docs_exist_and_the_changelog_starts_at_1_0_0():
    with open(os.path.join(MEMDB_DIR, "docs", "release.md"),
              encoding="utf-8") as f:
        doc = f.read()
    for needle in ("tools/build_release.py", "SHA256SUMS",
                   "MIN_VERSION_FOR_EVENT_TYPE", "pip install --user --upgrade"):
        assert needle in doc, needle
    with open(os.path.join(REPO_ROOT, "CHANGELOG.md"), encoding="utf-8") as f:
        assert "## 1.0.0" in f.read()


@pytest.mark.skipif(not shutil.which("git"), reason="needs git")
def test_skill_lists_selftest():
    with open(os.path.join(MEMDB_DIR, "templates", "skill.md"),
              encoding="utf-8") as f:
        assert "`selftest`" in f.read()

"""Verified-head anchors and cross-host witnesses (S-MEM-SCALE-04).

Trust model under test: suffix verification trusts the anchor (tampering
below it is out of scope for the routine path), a stale/invalid anchor
falls back to a full walk, anchors advance only after success, and a
peer's witness file catches a rewritten line the anchor would skip.
"""
import json
import os

from memdb import journal
from memdb import mem


def seed(root, host="testhost", n=30):
    for i in range(n):
        journal.append_event(
            host, "add",
            {"kind": "state", "project": "p", "part": "x",
             "subject": "s%d" % i, "body": "b" * 40,
             "ts": "2026-01-01T00:00:00+00:00"},
            "2026-01-01T00:00:00.%06dZ" % i, root=root)


def rewrite_line(path, seq, transform):
    """Rewrite one event line in place (the tamper primitive)."""
    lines = []
    for ev, ln, _, _ in journal.iter_lines(path):
        if ev["seq"] == seq:
            ev = transform(ev)
            ln = journal.canonical_line(ev)
        lines.append(ln)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines) + "\n")


def test_suffix_verify_from_anchor_passes_on_append(tmp_path):
    root = str(tmp_path / "jr")
    seed(root)
    path = journal.host_file("testhost", root)
    anchor = journal.save_anchor("testhost", root)
    assert anchor["seq"] == 30
    seed(root, n=5)     # 5 more (seq 31..35)
    ok, err = journal.verify_chain(path, anchor=anchor)
    assert ok, err


def test_tamper_below_anchor_caught_by_full_walk_only(tmp_path):
    """Documents the trust boundary: the suffix path trusts the anchor;
    --full and witnesses exist to cover what it skips."""
    root = str(tmp_path / "jr")
    seed(root)
    path = journal.host_file("testhost", root)
    anchor = journal.save_anchor("testhost", root)
    # same-length rewrite: byte offsets survive, so the anchor still
    # validates and the suffix path genuinely skips the damage. (A
    # length-changing rewrite shifts every offset, invalidates the
    # anchor bytes, and falls back to a full walk - strictly safer.)
    rewrite_line(path, 3, lambda ev: dict(
        ev, payload=dict(ev["payload"], body="c" * 40)))
    ok_suffix, _ = journal.verify_chain(path, anchor=anchor)
    ok_full, err = journal.verify_chain(path)
    assert ok_suffix is True        # by design: below the anchor
    assert ok_full is False         # the oracle catches it
    assert "chain break" in err


def test_stale_anchor_falls_back_to_full_walk(tmp_path):
    root = str(tmp_path / "jr")
    seed(root)
    path = journal.host_file("testhost", root)
    bogus = {"seq": 10, "hash": "0" * 64, "start": 0, "end": 10}
    ok, err = journal.verify_chain(path, anchor=bogus)
    assert ok, err      # fell back to a full walk of a healthy chain
    rewrite_line(path, 3, lambda ev: dict(
        ev, payload=dict(ev["payload"], body="x")))
    ok, err = journal.verify_chain(path, anchor=bogus)
    assert ok is False  # ...and the fallback walk still catches damage


def test_load_anchor_rejects_tampered_bytes(tmp_path):
    root = str(tmp_path / "jr")
    seed(root)
    journal.save_anchor("testhost", root)
    # rewrite the anchored (last) line -> anchor bytes no longer match
    rewrite_line(journal.host_file("testhost", root), 30,
                 lambda ev: dict(ev, payload=dict(ev["payload"], body="y")))
    assert journal.load_anchor("testhost", root) is None


def test_witness_mismatch_fails_verification(tmp_path):
    """Host B witnessed A's head; A's line at that seq is later rewritten
    (with its chain locally re-linked, which a suffix walk from a fresh
    anchor cannot see). B's checkpoint catches the split view."""
    root = str(tmp_path / "jr")
    seed(root, host="hosta", n=10)
    seed(root, host="hostb", n=1)
    patha = journal.host_file("hosta", root)
    with journal.lock(root):
        heads = journal.heads(root)
    journal.write_witness("hostb", {"hosta": heads["hosta"]}, root)
    # full-chain rewrite of hosta (attacker relinks every prev)
    events = [ev for ev, _ in journal.read_events(patha)]
    events[4]["payload"]["body"] = "rewritten"
    prev = None
    lines = []
    for ev in events:
        ev = dict(ev, prev=prev)
        ln = journal.canonical_line(ev)
        prev = journal.line_hash(ln)
        lines.append(ln)
    with open(patha, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines) + "\n")
    ok, err = journal.verify_chain(patha)   # self-consistent chain...
    assert ok, err
    cps = journal.witness_checkpoints("hosta", root)
    ok, err = journal.verify_chain(patha, checkpoints=cps)
    assert ok is False                      # ...but not what B verified
    assert "witness mismatch" in err


def test_anchor_does_not_advance_past_a_failure(db, run, tmp_path):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    run(["verify", "--full"])
    before = journal.load_anchor("testhost")
    assert before is not None
    from test_concurrency import corrupt_with_duplicate_seq
    corrupt_with_duplicate_seq(journal.journal_root())
    import pytest
    with pytest.raises(SystemExit):
        mem.main(["verify", "--full"])
    after = json.load(open(journal.derived_path(
        "testhost", "verified-head.json"), encoding="utf-8"))
    assert after["seq"] == before["seq"]


def test_verify_writes_witness_and_advances_anchor(db, run, tmp_path):
    run(["add", "--kind", "goal", "--project", "p1", "--part", "core",
         "--subject", "ship", "--body", "ship it"])
    out = run(["verify", "--full"])[0]
    assert out["ok"] is True
    assert journal.load_anchor("testhost")["seq"] == 1
    w = json.load(open(journal.witness_path("testhost"), encoding="utf-8"))
    assert w["testhost"]["seq"] == 1

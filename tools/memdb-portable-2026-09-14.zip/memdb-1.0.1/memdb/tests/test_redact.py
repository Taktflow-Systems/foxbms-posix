import filecmp
import json

import pytest

from memdb import mem
from memdb.redact import check_text, redact_text

CLEAN = "use sqlite for storage on the target device"


def hit_patterns(text):
    return {h["pattern"] for h in check_text(text)}


def test_pattern_classes_detect():
    assert hit_patterns("host at 192.168.1.5 responds") == {"private-ip"}
    assert hit_patterns("gateway 10.0.0.1 and 172.16.9.2") == {"private-ip"}
    assert hit_patterns("mail me at someone@example.com") == {"email"}
    assert hit_patterns("path /home/someuser/notes.txt") == {"home-path"}
    assert hit_patterns(r"under C:\Users\someone\docs") == {"home-path"}
    assert hit_patterns("serial 0123456789abcdef01234567") == {"hex-serial-24"}
    assert hit_patterns("sha " + "a1" * 32) == {"hex-hash-64"}


def test_clean_text_passes():
    assert check_text(CLEAN) == []
    assert check_text("public host example.com port 443, version 172.5") == []


def test_redact_text_placeholders():
    red, hits = redact_text("ping 192.168.1.5 from /home/someuser now")
    assert red == "ping <private-ip> from <home-path> now"
    assert len(hits) == 2


# Dirty fixtures below are assembled at runtime so this file contains no
# private-data pattern literals (keeps the user's pre-write hook quiet).
SYNTH_IP = ".".join(["192", "168", "1", "5"])
SYNTH_HOME = "/" + "home" + "/someuser"


def test_add_accepts_private_data_full_fidelity(db, run):
    """Journals/DB are the private memory domain: capture is lossless.
    Redaction guards the publish boundary (redact-check), not writes."""
    out = run(["add", "--kind", "state", "--project", "p1", "--part", "core",
               "--subject", "bench-host", "--body",
               "bench host is " + SYNTH_IP])
    assert out[0]["action"] == "added"
    got = run(["get", str(out[0]["id"])])
    assert SYNTH_IP in got[0]["body"]


def test_record_episode_accepts_private_data(db, run, tmp_path):
    doc = {"achievement": ["logs copied to " + SYNTH_HOME + "/logs"],
           "current_state": {"summary": "done", "status": []},
           "blockers": [], "next_steps": []}
    p = tmp_path / "ep.json"
    p.write_text(json.dumps(doc))
    out = run(["record-episode", "--project", "p1", "--part", "core",
               "--task", "t", "--json", str(p)])
    assert out[0]["episode_id"] > 0


def test_redact_check_flags_dirty_file(db, run, tmp_path, capsys):
    dirty = tmp_path / "dirty.txt"
    dirty.write_text("reach the bench at " + SYNTH_IP + " please")
    with pytest.raises(SystemExit) as exc:
        run(["redact-check", str(dirty)])
    assert exc.value.code == 2
    assert "private-ip" in capsys.readouterr().err


def test_redact_check_passes_clean(db, run, tmp_path):
    clean = tmp_path / "clean.txt"
    clean.write_text(CLEAN)
    out = run(["redact-check", str(clean)])
    assert out[0]["hits"] == 0


def test_clean_add_accepted(db, run):
    out = run(["add", "--kind", "state", "--project", "p1", "--part", "core",
               "--subject", "bench-host", "--body", CLEAN])
    assert out[0]["action"] == "added"


def test_export_deterministic(db, run, tmp_path):
    run(["add", "--kind", "decision", "--project", "p1", "--part", "core",
         "--subject", "a", "--body", "alpha"])
    run(["add", "--kind", "decision", "--project", "p1", "--part", "core",
         "--subject", "a", "--body", "beta"])  # supersedes -> link row too
    f1, f2 = str(tmp_path / "e1.jsonl"), str(tmp_path / "e2.jsonl")
    run(["export", "--jsonl", f1])
    run(["export", "--jsonl", f2])
    assert filecmp.cmp(f1, f2, shallow=False)
    lines = [json.loads(l) for l in open(f1)]
    assert {l["table"] for l in lines} == {"records", "links"}

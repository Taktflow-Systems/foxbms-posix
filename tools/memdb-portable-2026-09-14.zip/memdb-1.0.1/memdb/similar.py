"""Lexical text similarity for memory rows: duplicates, topics, resolution evidence.

Stdlib only and deterministic. Used by the write gate (add, record-episode),
consolidate, review-blockers and the search re-ranker. Weights are IDF over
the rows being compared, so a word every row shares counts for little and
an identifier two rows share counts for a lot.

Identifiers (tokens holding a digit: PH2-CFU-001, VBL-019, A9, 741) are the
strongest topic keys and the strongest sibling signal: two rows naming
different members of one identifier family (VBL-019 vs VBL-020) are
different facts however similar the rest of the wording is.
"""
import math
import re

WORD = re.compile(r"[A-Za-z0-9][A-Za-z0-9_./\\-]*[A-Za-z0-9]|[A-Za-z0-9]")
COMPOUND = re.compile(r"\b([A-Za-z]{3,})[ _]#?(\d{1,4})\b(?![./-]\d)")
LABEL = re.compile(r"\b([A-Za-z]{3,})\s+([A-Z](?:(?:\s*,\s*|\s+and\s+|\s*(?:through|thru|to|\.\.|-)\s*)[A-Z])*)"
                   r"\b(?![-/.']\w)")      # "Gate A", "Domains D through I", "Domains H and I"; never "A-sample"
LABEL_RANGE = re.compile(r"([A-Z])\s*(?:through|thru|to|\.\.|-)\s*([A-Z])")


def label_letters(group):
    """Letters a label names: 'D through I' is D..I, 'H and I' is H and I; a lone 'I' is the pronoun."""
    letters = set(re.findall(r"[A-Z]", group))
    for lo, hi in LABEL_RANGE.findall(group):
        if ord(lo) < ord(hi):
            letters.update(chr(c) for c in range(ord(lo), ord(hi) + 1))
    return set() if group == "I" else letters


NEGATIONS = frozenset(("not", "no", "never", "without", "cannot", "can't",
                       "cant", "dont", "doesnt", "isnt", "wont", "nothing",
                       "none", "nor"))
STOP = frozenset("""
a about above after again against all also am an and any are as at be because
been before being below between both but by can could did do does doing down
during each either else ever every few for from further had has have having he
her here hers him his how i if in into is it its itself just let like may me
might more most much must my myself now of off on once only onto or other our
ours out over own per same shall she should so some such than that the their
theirs them then there these they this those though through thus to too under
until up upon us very via was we were what when where whether which while who
whom whose why will with within would yet you your yours
etc eg ie vs
""".split())
YEAR_LEADS = frozenset("""
january february march april may june july august september october november december
jan feb mar apr jun jul aug sep sept oct nov dec since in
""".split())
DUP_THRESHOLD = {"blocker": 0.45, "decision": 0.55, "state": 0.55,
                 "anchor": 0.5, "episode": 0.45, "cross": 0.45}
DEFAULT_DUP = 0.55


def stem(word):
    if len(word) > 5 and word.endswith("ing"):
        return word[:-3]
    if len(word) > 4 and word.endswith("ies"):
        return word[:-3] + "y"
    if len(word) > 4 and word.endswith("ed"):
        return word[:-2]
    if len(word) > 4 and word.endswith("es") and word[-3] in "sxzh":
        return word[:-2]
    if len(word) > 3 and word.endswith("s") and not word.endswith("ss"):
        return word[:-1]
    return word


class Doc(object):
    """Token view of one text: content tokens, identifiers, polarity."""
    __slots__ = ("tokens", "ids", "negated", "text")

    def __init__(self, text):
        self.text = text or ""
        tokens, ids, negated = set(), set(), False
        for m in COMPOUND.finditer(self.text):     # "Gate 15" names one gate
            word = m.group(1).lower()
            if len(m.group(2)) == 4 and word in YEAR_LEADS:
                continue            # "July 2026", "since 2026" is a date
            if word not in STOP and word not in NEGATIONS:
                ident = "{}-{}".format(stem(word), m.group(2))
                tokens.add(ident)
                ids.add(ident)
        for m in LABEL.finditer(self.text):        # "Gate A" and "Gate B" are different gates
            word = m.group(1).lower()
            if word not in STOP and word not in NEGATIONS:
                for letter in label_letters(m.group(2)):
                    ident = "{}-{}".format(stem(word), letter.lower())
                    tokens.add(ident)
                    ids.add(ident)
        for raw in WORD.findall(self.text):
            t = raw.lower().replace("\\", "/").strip("./-_")
            if not t:
                continue
            if t in NEGATIONS or t.endswith("n't"):
                negated = True
                continue
            if "/" in t:
                tokens.add(t)
                base = t.rsplit("/", 1)[-1]
                if base:
                    tokens.add(base)
                continue
            if any(c.isdigit() for c in t):
                if DATE_OR_TIME.fullmatch(t) or re.fullmatch(r"\d{1,2}", t):
                    continue        # a shared date or a small count says nothing about topic
                tokens.add(t)
                if re.search(r"[a-z]", t):      # pure numbers are values, not names
                    ids.add(t)
                continue
            for part in re.split(r"[-_.]+", t):
                if len(part) > 1 and part not in STOP:
                    tokens.add(stem(part))
        self.tokens = frozenset(tokens)
        self.ids = frozenset(ids)
        self.negated = negated


DATE_OR_TIME = re.compile(r"\d{4}-\d{2}(?:-\d{2})?(?:t[\d:.]+z?)?|\d{1,2}:\d{2}(?::\d{2})?|"
                          r"\d{4}\d{2}\d{2}")


def specific(identifier):
    """An identifier that names one thing (VBL-019, PH2-CFU-001, Gate-15), not a counter (round-2, A9)."""
    return len(re.findall(r"\d", identifier)) >= 2 or len(re.findall(r"[-_./]", identifier)) >= 2


def family(identifier):
    if re.fullmatch(r"[a-z]+-[a-z]", identifier):
        return identifier[:-1] + "@"        # a letter label: gate-a and gate-b are one family
    return re.sub(r"\d+", "#", identifier)


def id_conflict(a, b):
    """Both name members of one identifier family and each names one the other lacks."""
    fam_a, fam_b = {}, {}
    for t in a.ids:
        fam_a.setdefault(family(t), set()).add(t)
    for t in b.ids:
        fam_b.setdefault(family(t), set()).add(t)
    for fam in set(fam_a) & set(fam_b):
        if not re.search(r"[a-z]", fam):
            continue            # pure numbers are values, not names
        if fam_a[fam] - fam_b[fam] and fam_b[fam] - fam_a[fam]:
            return True
    return False


def idf_table(docs):
    """{token: idf} over a list of Doc."""
    df = {}
    for d in docs:
        for t in d.tokens:
            df[t] = df.get(t, 0) + 1
    n = len(docs)
    return {t: math.log((n + 1.0) / (c + 1.0)) + 1.0 for t, c in df.items()}


def _w(tokens, idf, default):
    return sum(idf.get(t, default) for t in tokens)


def scores(a, b, idf, default=None):
    """(jaccard, overlap, shared tokens) with IDF weights."""
    if default is None:
        default = max(idf.values()) if idf else 1.0
    shared = a.tokens & b.tokens
    if not shared:
        return 0.0, 0.0, shared
    ws = _w(shared, idf, default)
    wa, wb = _w(a.tokens, idf, default), _w(b.tokens, idf, default)
    union = wa + wb - ws
    return ws / union if union else 0.0, ws / min(wa, wb) if min(wa, wb) else 0.0, shared


def dup_score(a, b, idf, default=None):
    """Near-duplicate score in [0, 1]; 0 when the rows are siblings by identifier."""
    if id_conflict(a, b):
        return 0.0
    jac, ovl, shared = scores(a, b, idf, default)
    if len(shared) < 2:
        return 0.0
    return max(jac, 0.85 * ovl)


def is_duplicate(a, b, idf, kind=None, default=None):
    return dup_score(a, b, idf, default) >= DUP_THRESHOLD.get(kind, DEFAULT_DUP)


def rare(tokens, idf, cutoff):
    return {t for t in tokens if idf.get(t, cutoff) >= cutoff}


def groups(docs, idf, threshold, keys=None, max_df=None):
    """Near-duplicate groups (lists of indices, each len >= 2) via rare-token candidates."""
    n = len(docs)
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    index = {}
    limit = max_df or max(8, int(n * 0.05))
    for i, d in enumerate(docs):
        for t in d.tokens:
            index.setdefault(t, []).append(i)
    seen = set()
    for t, members in index.items():
        if len(members) < 2 or len(members) > limit:
            continue
        for x in range(len(members)):
            for y in range(x + 1, len(members)):
                i, j = members[x], members[y]
                if (i, j) in seen:
                    continue
                seen.add((i, j))
                if keys is not None and keys[i] != keys[j]:
                    continue
                if dup_score(docs[i], docs[j], idf) >= threshold:
                    ri, rj = find(i), find(j)
                    if ri != rj:
                        parent[max(ri, rj)] = min(ri, rj)
    out = {}
    for i in range(n):
        out.setdefault(find(i), []).append(i)
    return [sorted(v) for v in out.values() if len(v) > 1]


STRONG_RESOLVED = re.compile(
    r"\b(closed|closure (?:is |was )?(?:achieved|event|complete[d]?)|resolved|done|"
    r"completed?|landed|merged|fixed|no longer|accepted|unblocked|superseded|"
    r"retired|cancell?ed|obsolete|green)\b", re.I)
RESOLVED_CUE = re.compile(
    r"\b(closed|closure|resolved|done|complete[ds]?|landed|merged|wired|"
    r"implemented|exists?|created|installed|accepted|passe[sd]|passing|green|"
    r"fixed|unblocked|no longer|now (?:has|have|is|are|runs?)|delivered|"
    r"promoted|superseded|retired|cancell?ed|obsolete)\b", re.I)
BLOCKING_CUE = re.compile(
    r"\b(still|not yet|yet to|remains?|remaining|missing|pending|blocked|blocks|"
    r"cannot|can't|unable|awaiting|awaits|until|todo|open(?:ed)? (?:gap|item)|"
    r"does not exist|do not exist|absent|lack(?:s|ing)?|needs?|require[sd]?|"
    r"to verify|deferred|not (?:closed|resolved|done|complete|implemented|"
    r"installed|wired|committed|run|executed)|keep(?:s|ing)?\b[^.;]{0,80}\bopen|"
    r"left open|stays? open)\b", re.I)
CHANGE_CUE = re.compile(
    r"\b(instead of|rather than|no longer|replac(?:e|es|ed|ing)|revert(?:s|ed)?|"
    r"cancel(?:s|led|ed)?|retir(?:e|es|ed)|supersed(?:e|es|ed)|drop(?:s|ped)?|"
    r"abandon(?:s|ed)?|reverse[sd]?|overrid(?:e|es|den)|not anymore)\b", re.I)
PENDING_CUE = re.compile(      # the row says something is not finished (not normative verbs)
    r"\b(still|not yet|yet to|remains?|remaining|pending|blocked|blocks|awaiting|awaits|"
    r"until|missing|does not exist|do not exist|deferred|not (?:closed|resolved|done|"
    r"complete|implemented|installed|wired|committed|run|executed))\b", re.I)
CLOSED_CUE = re.compile(
    r"\b(closed|closure (?:is |was )?(?:achieved|event|complete[d]?)|resolved|done|"
    r"completed?|landed|merged|fixed|no longer|accepted|superseded|retired|cancell?ed|"
    r"obsolete|now (?:has|have))\b", re.I)
REJECT_CUE = re.compile(
    r"\b(?:instead of|rather than|no longer|not|never|replac(?:e|es|ed|ing)|"
    r"revert(?:s|ed)?(?: to)?|retir(?:e|es|ed)|supersed(?:e|es|ed)|drop(?:s|ped)?|"
    r"abandon(?:s|ed)?|overrid(?:e|es|den)|cancel(?:s|led|ed)?)\b", re.I)
TEMPORARY_CUE = re.compile(
    r"\b(keep|leave|hold|defer|postpone|park)\b.*\b(until|for now|pending|open|"
    r"blocked|active)\b|\buntil\b|\bfor now\b|\bnot yet\b|\bdo not\b.*\byet\b", re.I)
SENTENCE = re.compile(r"(?<=[.;!?])\s+|\n+")
CONDITIONAL = re.compile(r"\b(whether|if|once|unless|could|would|should|to determine|so that|"
                         r"in order to)\b", re.I)


SUBJECT_END = re.compile(r"\b(?:is|are|was|were|has been|have been|remains?|stays?)\b", re.I)


def sentences(text):
    return [s.strip() for s in SENTENCE.split(text or "") if len(s.strip()) > 12]


def subject(sentence):
    """Content tokens before the first copula: 'OEM round-2 review' in 'OEM round-2 review is still pending'."""
    m = SUBJECT_END.search(sentence or "")
    return Doc(sentence[:m.start()]).tokens if m else frozenset()


def resolves(blocker, sentence):
    """True when the sentence reports resolution, not a condition, and does not restate the block."""
    return bool(RESOLVED_CUE.search(sentence)) and not BLOCKING_CUE.search(sentence) \
        and not CONDITIONAL.search(sentence)

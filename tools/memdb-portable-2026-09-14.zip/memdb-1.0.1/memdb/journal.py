"""Append-only, hash-chained per-host event journal - the system of record.

The SQLite DB is a derived projection: `mem rebuild` reproduces it from
journals alone, so the DB is disposable on every machine. Journal files
live at <journal-root>/journal/<host>/events.jsonl and replicate between
machines via git (one branch per host, per multi-host rules H1-H3).

Events are immutable. Every state change is a new event. Each event
carries (host, seq) - a per-host monotonic counter, no wall-clock
dependency - and `prev`, the SHA-256 of the previous event's canonical
line on the same host. Truncation, reordering, or mutation of a journal
is therefore mechanically detectable (see verify_chain).

Canonical total order across hosts is (ts, host, seq). Replay in that
order is the definition of truth; `mem verify` compares the live DB to a
canonical rebuild.

Appending is a read-modify-write (read the tail to derive seq and prev,
then append), so it MUST run under `lock()`. Without it two concurrent
writers on one host derive the same seq and both append: duplicate uids
(<host>:<seq>) break the chain permanently, and because the journal is
append-only `mem rebuild` - the safe repair - cannot fix it. Reproduced
2026-08-28 (see docs/2026-08-28-concurrency-finding.md).
"""
import contextlib
import errno
import hashlib
import io
import json
import os
import sys
import threading
import time

try:
    from . import paths
except ImportError:                     # loose script: python memdb/mem.py
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import paths  # noqa: E402

# None = derive from paths (honours MEMDB_HOME); tests pin it directly.
HOST_ID_FILE = None
LOCK_NAME = ".memdb.lock"
DEFAULT_LOCK_TIMEOUT = 60.0

try:                                    # POSIX
    import fcntl
    _msvcrt = None
except ImportError:                     # Windows
    fcntl = None
    import msvcrt as _msvcrt


def journal_root():
    return paths.journal_root()


def host_id_file():
    return HOST_ID_FILE or paths.host_id_file()


# ------------------------------------------------------------- locking

_thread_lock = threading.RLock()        # excludes threads within a process
_held = {"depth": 0, "fd": None, "path": None}


def lock_path(root=None):
    return os.path.normcase(os.path.abspath(
        os.path.join(root or journal_root(), LOCK_NAME)))


def lock_timeout():
    raw = os.environ.get("MEMDB_LOCK_TIMEOUT")
    if not raw:
        return DEFAULT_LOCK_TIMEOUT
    try:
        return float(raw)
    except ValueError:
        raise SystemExit(
            "memdb: MEMDB_LOCK_TIMEOUT is not a number: {!r}".format(raw))


def _try_lock(fd):
    """Attempt a non-blocking exclusive lock. True if taken, False if busy.

    Any other OS error propagates: a lock that silently degrades to a
    no-op is worse than no lock, because it manufactures false safety.
    """
    try:
        if fcntl is not None:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        else:
            os.lseek(fd, 0, os.SEEK_SET)
            _msvcrt.locking(fd, _msvcrt.LK_NBLCK, 1)
        return True
    except OSError as e:
        if e.errno in (errno.EACCES, errno.EAGAIN, errno.EDEADLK):
            return False
        raise


def _unlock(fd):
    if fcntl is not None:
        fcntl.flock(fd, fcntl.LOCK_UN)
    else:
        os.lseek(fd, 0, os.SEEK_SET)
        _msvcrt.locking(fd, _msvcrt.LK_UNLCK, 1)


@contextlib.contextmanager
def lock(root=None, timeout=None):
    """Exclusive advisory lock over one journal root, for this machine.

    Reentrant: nested acquisitions in the same thread are counted, and
    the OS-level lock is taken once. It has to be - the file lock is per
    open file description, so a second `open()` in the same process
    would deadlock against itself (verified on Windows: a second fd gets
    EACCES). Blocks up to `timeout` seconds, then fails loudly.
    """
    path = lock_path(root)
    timeout = lock_timeout() if timeout is None else timeout
    deadline = time.monotonic() + timeout
    if not _thread_lock.acquire(timeout=max(timeout, 0.0)):
        raise SystemExit(
            "memdb: timed out after {:g}s waiting for another thread to "
            "release the journal lock ({})".format(timeout, path))
    try:
        if _held["depth"] == 0:
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
            try:
                while not _try_lock(fd):
                    if time.monotonic() >= deadline:
                        raise SystemExit(
                            "memdb: timed out after {:g}s waiting for the "
                            "journal lock held by another process ({}). "
                            "Another memdb write, rebuild, or verify is "
                            "still running.".format(timeout, path))
                    time.sleep(0.02)
            except BaseException:
                os.close(fd)
                raise
            _held.update(depth=1, fd=fd, path=path)
        else:
            if path != _held["path"]:
                raise SystemExit(
                    "memdb: journal lock already held for {} - refusing to "
                    "re-enter for a different root {}".format(
                        _held["path"], path))
            _held["depth"] += 1
        try:
            yield
        finally:
            _held["depth"] -= 1
            if _held["depth"] == 0:
                fd = _held["fd"]
                _held.update(fd=None, path=None)
                try:
                    _unlock(fd)
                finally:
                    os.close(fd)
    finally:
        _thread_lock.release()


def host_id():
    """This machine's host slug: the host-id file, or MEMDB_HOST when it agrees
    with the file (a different MEMDB_HOST needs MEMDB_HOST_OVERRIDE=1)."""
    env = (os.environ.get("MEMDB_HOST") or "").strip()
    path = host_id_file()
    from_file = ""
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            from_file = f.read().strip()
    if env and from_file and env != from_file \
            and os.environ.get("MEMDB_HOST_OVERRIDE") != "1":
        raise SystemExit(
            "memdb: MEMDB_HOST={} conflicts with the host-id file {} ({}); "
            "writing under another host's identity forks its journal. Unset "
            "MEMDB_HOST, or set MEMDB_HOST_OVERRIDE=1 for tests and benches "
            "only".format(env, path, from_file))
    if env or from_file:
        return env or from_file
    raise SystemExit(
        "memdb: host identity unset - set MEMDB_HOST or write a slug to "
        + path)


def host_file(host, root=None):
    return os.path.join(root or journal_root(), "journal", host,
                        "events.jsonl")


def derived_path(host, name, root=None):
    """Per-clone derived state (head sidecar, verified anchors).

    Lives OUTSIDE journal/ so the sync script's `git add journal/<host>`
    can never commit it: it is a cache of this clone's view, not part of
    the replicated record, and it must be safe to delete at any time.
    """
    return os.path.join(paths.derived_dir(root), host, name)


def list_hosts(root=None):
    jdir = os.path.join(root or journal_root(), "journal")
    if not os.path.isdir(jdir):
        return []
    return sorted(h for h in os.listdir(jdir)
                  if os.path.isfile(host_file(h, root)))


def canonical_line(ev):
    return json.dumps(ev, sort_keys=True, separators=(",", ":"))


def line_hash(line):
    return hashlib.sha256(line.encode("utf-8")).hexdigest()


class TornTail(Exception):
    """The LAST line of a journal does not parse: a crash cut an append short."""

    def __init__(self, path, offset):
        super().__init__("torn tail at byte {} of {}".format(offset, path))
        self.path, self.offset = path, offset


def _iter_stream(f, pos, name):
    for raw in f:
        try:
            ln = raw.decode("utf-8").strip("\r\n")
            ev = json.loads(ln) if ln else None
        except ValueError:
            if f.read().strip():
                raise   # an unparsable line with events after it is corruption
            raise TornTail(name, pos)
        if ev is not None:
            yield ev, ln, pos, pos + len(raw)
        pos += len(raw)


def iter_lines(path, offset=0):
    """Yield (event, canonical_line, start, end) with byte offsets.

    `end` is the offset just past the line's newline, i.e. where the next
    line starts. Offsets are what make O(1) tail access (head sidecar)
    and suffix-only verification (anchors) possible.
    """
    if not os.path.exists(path):
        return
    with open(path, "rb") as f:
        f.seek(offset)
        yield from _iter_stream(f, offset, path)


def head_of_bytes(data, name="-"):
    """{seq, hash} of the last event in journal bytes, None when empty."""
    last = None
    for ev, ln, _, _ in _iter_stream(io.BytesIO(data), 0, name):
        last = {"seq": ev["seq"], "hash": line_hash(ln)}
    return last


def read_events(path):
    """Return [(event_dict, raw_line), ...] for one host file."""
    return [(ev, ln) for ev, ln, _, _ in iter_lines(path)]


# --------------------------------------------- tail sidecar and anchors

def _load_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _write_json_atomic(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        json.dump(obj, f, sort_keys=True)
    os.replace(tmp, path)


def _check_line_at(path, ref):
    """Does `ref` = {seq,hash,start,end} describe a real line of `path`?

    Reads only [start, end): O(1) regardless of journal size. Returns the
    validated ref or None. This is the self-healing gate for every
    derived artifact - a sidecar or anchor is TRUSTED only after its
    claimed bytes are re-read and re-hashed against the journal itself,
    so a stale or corrupt artifact can cost one slow rescan, never a
    wrong seq/prev.
    """
    try:
        with open(path, "rb") as f:
            f.seek(ref["start"])
            data = f.read(ref["end"] - ref["start"])
        line = data.decode("utf-8")
        if not line.endswith("\n"):
            return None
        line = line.strip("\r\n")
        if "\n" in line or line_hash(line) != ref["hash"]:
            return None
        return {"seq": ref["seq"], "hash": ref["hash"],
                "start": ref["start"], "end": ref["end"]}
    except (OSError, KeyError, TypeError, UnicodeDecodeError):
        return None


def _scan_tail(path):
    """Full scan for the last event's {seq,hash,start,end} (or None)."""
    last = None
    for ev, ln, s, e in iter_lines(path):
        last = {"seq": ev["seq"], "hash": line_hash(ln), "start": s, "end": e}
    return last


def tail_info(host, root=None):
    """{seq,hash,start,end} of the journal tail, or None if empty.

    Sidecar-first: O(1) when the head sidecar is valid, one full scan to
    self-heal when it is missing/stale/corrupt. Callers must hold lock().
    """
    path = host_file(host, root)
    if not os.path.exists(path):
        return None
    sidecar = _load_json(derived_path(host, "head.json", root))
    if sidecar:
        info = _check_line_at(path, sidecar)
        if info is not None:
            # A stale-but-valid sidecar (crash between append and sidecar
            # write) points at a line that is no longer last: its `end`
            # must be the file's end, or it is not the tail.
            if info["end"] == os.path.getsize(path):
                return info
    return _scan_tail(path)


def load_anchor(host, root=None):
    """Last-verified head {seq,hash,start,end}, validated against the
    journal bytes; None if absent/stale (callers fall back to a full
    walk). Advancing only happens in save_anchor after a SUCCESSFUL
    verify - never on failure."""
    anchor = _load_json(derived_path(host, "verified-head.json", root))
    if not anchor:
        return None
    return _check_line_at(host_file(host, root), anchor)


def _raw_seq(obj):
    seq = obj.get("seq") if isinstance(obj, dict) else None
    return seq if isinstance(seq, int) and not isinstance(seq, bool) else 0


def save_anchor(host, root=None):
    info = tail_info(host, root)
    old = _raw_seq(_load_json(derived_path(host, "verified-head.json", root)))
    new = info["seq"] if info else 0
    if new < old:
        raise SystemExit(
            "memdb: refusing to lower the verified anchor for {} from seq {} "
            "to seq {}: the journal tail was truncated or rewritten".format(
                host, old, new))
    if info:
        _write_json_atomic(derived_path(host, "verified-head.json", root),
                           info)
    return info


def floor_for(host, root=None, manifest_entry=None):
    """Lowest seq the host journal may end at: max of the raw anchor seq, the
    largest witnessed seq and the snapshot manifest seq. Journals only grow."""
    floor = _raw_seq(_load_json(derived_path(host, "verified-head.json", root)))
    witnessed = [s for s in witness_checkpoints(host, root)
                 if isinstance(s, int) and not isinstance(s, bool)]
    if witnessed:
        floor = max(floor, max(witnessed))
    return max(floor, _raw_seq(manifest_entry))


def truncation_message(host, last_seq, floor_seq):
    return ("journal for {} ends at seq {} but a verified head, witness or "
            "snapshot reached seq {}: tail truncated or rewritten".format(
                host, last_seq, floor_seq))


def tail_for_append(host, root=None):
    """tail_info for a writer: SystemExit with the repair steps on a torn tail."""
    path = host_file(host, root)
    try:
        info = tail_info(host, root)
        if info and info["end"] == os.path.getsize(path):
            with open(path, "rb") as f:
                f.seek(info["end"] - 1)
                if f.read(1) != b"\n":
                    raise TornTail(path, info["start"])
    except TornTail as e:
        raise SystemExit(
            "memdb: refusing to append: {} (a crash cut an earlier append "
            "short). Repair: confirm on the hub with git show "
            "origin/{h}/journal:journal/{h}/events.jsonl that the partial "
            "event was never pushed, truncate the file to {n} bytes, then run "
            "mem verify (docs/hub-config.md, Repairs)".format(
                e, h=host, n=e.offset))
    return info


def refuse_below_floor(host, info, root=None):
    """SystemExit when the tail `info` (from tail_info) ends below floor_for(host)."""
    last, floor = (info["seq"] if info else 0), floor_for(host, root)
    if last < floor:
        raise SystemExit("memdb: refusing to append: " + truncation_message(
            host, last, floor))


def witness_path(host, root=None):
    """Witness file: host's verified view of EVERY host's head. Lives
    INSIDE journal/<host>/ deliberately - it replicates over the existing
    per-host branch, so any other host can detect a rewritten prefix
    (transparency-log witness property) on its next verify."""
    return os.path.join(root or journal_root(), "journal", host,
                        "witness-heads.json")


def write_witness(own_host, heads_map, root=None, meta=None):
    """Record own verified view {host: {seq, hash}}; rewrite only on
    change so sync commits do not churn."""
    path = witness_path(own_host, root)
    current = _load_json(path)
    slim = {h: {"seq": v["seq"], "hash": v["hash"]}
            for h, v in heads_map.items()}
    # Non-host keys (memdb_version, event_types): readers treat only dict values as hosts.
    slim.update(meta or {})
    if current != slim:
        _write_json_atomic(path, slim)


def read_witness(host, root=None):
    """One host's witness file as a dict; {} when absent or unreadable."""
    w = _load_json(witness_path(host, root))
    return w if isinstance(w, dict) else {}


def event_types(host, root=None):
    """Sorted event types of one host's journal; a sidecar caches them up to a byte offset."""
    path = host_file(host, root)
    if not os.path.exists(path):
        return []
    sidecar = derived_path(host, "event-types.json", root)
    cache = _load_json(sidecar)
    start, found = 0, set()
    if isinstance(cache, dict) and isinstance(cache.get("types"), list) \
            and isinstance(cache.get("end"), int) \
            and 0 < cache["end"] <= os.path.getsize(path):
        with open(path, "rb") as f:
            f.seek(cache["end"] - 1)
            if f.read(1) == b"\n":      # an offset off a line boundary means rescan
                start, found = cache["end"], set(cache["types"])
    end = start
    try:
        for ev, _, _, stop in iter_lines(path, start):
            found.add(ev.get("type"))
            end = stop
    except (TornTail, ValueError):
        if start == 0:
            raise
        _write_json_atomic(sidecar, {"end": 0, "types": []})
        return event_types(host, root)
    types = sorted(t for t in found if isinstance(t, str))
    if end > 0 and (not isinstance(cache, dict) or cache.get("end") != end
                    or cache.get("types") != types):
        _write_json_atomic(sidecar, {"end": end, "types": types})
    return types


def witness_checkpoints(for_host, root=None):
    """{seq: expected_hash} for one host, unioned from every OTHER
    host's witness file. A traversed seq whose hash differs from a
    witnessed value is a verify failure (split view / rewritten line)."""
    cps = {}
    for h in list_hosts(root):
        if h == for_host:
            continue
        w = _load_json(witness_path(h, root))
        if isinstance(w, dict):
            entry = w.get(for_host)
            if isinstance(entry, dict) and "seq" in entry and "hash" in entry:
                cps[entry["seq"]] = entry["hash"]
    return cps


def verify_chain(path, anchor=None, checkpoints=None, floor_seq=0):
    """Return (ok, error_message_or_None) for one host journal file.

    A duplicate seq is reported as such rather than as a gap: the two
    faults have different causes (concurrent append vs truncation) and
    different repairs, and the old wording pointed at the wrong one.

    `anchor` = {seq,hash,start,end} of a previously verified head: the
    walk covers only the suffix after it (trust-anchor pattern, RFC
    6962 / tlog-checkpoint scaled down to a linear chain). The anchor's
    bytes are re-validated first; a stale/invalid anchor falls back to a
    full walk, never to a wrong verdict. Tampering BELOW a valid anchor
    is out of this call's scope by definition - that is what the
    scheduled full walk and cross-host `checkpoints` exist for.

    `checkpoints` = {seq: expected_line_hash} from other hosts' witness
    files: any traversed seq present must hash-match, else the two hosts
    hold split views and verification fails.
    """
    prev = None
    last_seq = 0
    offset = 0
    if anchor is not None:
        valid = _check_line_at(path, anchor)
        if valid is None:
            return verify_chain(path, None, checkpoints, floor_seq)
        prev, last_seq, offset = valid["hash"], valid["seq"], valid["end"]
    try:
        for ev, line, _, _ in iter_lines(path, offset):
            seq = ev.get("seq")
            if seq == last_seq:
                return False, ("duplicate seq {}: two writers appended "
                               "concurrently".format(seq))
            if isinstance(seq, int) and seq < last_seq:
                return False, "out-of-order seq {} after {}".format(seq, last_seq)
            if seq != last_seq + 1:
                return False, "seq gap: expected {} got {}".format(
                    last_seq + 1, seq)
            if ev.get("prev") != prev:
                return False, "hash chain break at seq {}".format(seq)
            prev = line_hash(line)
            if checkpoints and checkpoints.get(seq, prev) != prev:
                return False, ("witness mismatch at seq {}: another host "
                               "verified a different event here (split view "
                               "or rewritten line)".format(seq))
            last_seq = seq
    except TornTail as e:
        return False, "torn tail at byte {}".format(e.offset)
    if last_seq < floor_seq:
        host = os.path.basename(os.path.dirname(os.path.abspath(path)))
        return False, truncation_message(host, last_seq, floor_seq)
    return True, None


def append_event(host, etype, payload, ts, root=None):
    """Append one event to this host's journal; returns the event dict.

    Read-modify-write: seq and prev come from the current tail, so the
    whole span runs under `lock()` (reentrant, so callers already
    holding it pay nothing). Tail access is O(1) via the head sidecar
    (validated against the journal bytes, full-scan self-heal on any
    mismatch); the sidecar is written AFTER the fsynced append, so a
    crash between the two leaves a stale sidecar that the validation
    detects, never a wrong seq/prev.
    """
    path = host_file(host, root)
    with lock(root):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        info = tail_for_append(host, root)
        refuse_below_floor(host, info, root)
        if info:
            prev, seq, start = info["hash"], info["seq"] + 1, info["end"]
        else:
            prev, seq, start = None, 1, 0
        ev = {"v": 1, "host": host, "seq": seq, "ts": ts, "type": etype,
              "prev": prev, "payload": payload}
        line = canonical_line(ev)
        with open(path, "a", encoding="utf-8", newline="\n") as f:
            f.write(line + "\n")
            f.flush()
            os.fsync(f.fileno())
        _write_json_atomic(
            derived_path(host, "head.json", root),
            {"seq": seq, "hash": line_hash(line), "start": start,
             "end": start + len(line.encode("utf-8")) + 1})
    return ev


def all_events(root=None):
    """All hosts' events in canonical order.

    Merge key is (per-host monotonic ts, host, seq). Within one host the
    journal order (seq) is the causal order and must never be reordered:
    an episode event carries a date-only ts (YYYY-MM-DDT00:00:00) that can
    sort BEFORE events the same host wrote minutes earlier in UTC, which
    on replay let later `add`s pre-empt the episode's child rows and made
    child uids (<host>:<seq>/<n>) unresolvable (workstation seq 2200-2254,
    2026-08-23). The monotonic key = running max of ts per host, so an
    event never sorts ahead of its own predecessors, while cross-host
    interleaving by time is unchanged wherever ts was already monotonic.

    Read under `lock()` so the snapshot cannot contain a torn line from
    a writer mid-append, and so a caller that already holds the lock
    replays exactly the events it locked.
    """
    return [ev for _, ev in merged_events(root)]


def merged_events(root=None):
    """[(key, event)] for all hosts in canonical order, where key is the
    canonical merge key (running-max ts, host, seq). Exposed so snapshot
    rebuilds can prove their tail sorts strictly after the snapshot's
    last included key (see mem.py) instead of assuming clocks behaved.
    """
    evs = []
    with lock(root):
        for host in list_hosts(root):
            running = ""
            for ev, _ in read_events(host_file(host, root)):
                if ev["ts"] > running:
                    running = ev["ts"]
                evs.append(((running, ev["host"], ev["seq"]), ev))
    evs.sort(key=lambda pair: pair[0])
    return evs


def heads(root=None):
    """{host: {seq, ts, hash}} for every host journal present."""
    out = {}
    with lock(root):
        for host in list_hosts(root):
            events = read_events(host_file(host, root))
            if events:
                ev, line = events[-1]
                out[host] = {"seq": ev["seq"], "ts": ev["ts"],
                             "hash": line_hash(line)}
    return out

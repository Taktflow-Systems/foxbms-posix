"""Memory lifecycle proposals: hygiene, blocker review, near-duplicates, contradictions.

Everything here READS the projection and returns proposals; nothing writes.
Callers (mem.py commands) turn accepted proposals into one journaled
`review` event, whose applier lives in mem.py with the other appliers.

Design and thresholds: docs/architecture-memory-quality.md.
"""
import functools
import json
import os
import re
from datetime import datetime, timezone

try:
    from . import similar
except ImportError:                     # loose script
    import similar

ANCHOR_KINDS = ("goal", "constraint", "preference")
BLOCKER_REVIEW_DAYS = 90
NARRATIVE_DECISION = re.compile(
    r"^\s*(did not|didn't|did NOT|used|added|committed|kept|ran|verified|"
    r"searched|confirmed|created|wrote|updated|no (?:src|source|code|"
    r"implementation|repository|repo) change|tests? (?:passed|pass)|verdict)\b",
    re.I)
NONE_BODY = re.compile(r"^\s*(none|n/a|nothing)\b[\s.:;,-]*", re.I)
NARRATIVE_STATE = re.compile(
    r"^\s*(no (?:repository|repo)? ?files? (?:were )?(?:changed|modified)|"
    r"read-only|analysis only|no changes? (?:made|were made))", re.I)
SELFTEST_PART = re.compile(r"^(?:memdb-)?selftest", re.I)
ABSENCE_CUE = re.compile(
    r"(does not exist|do not exist|doesn't exist|don't exist|is missing|are missing|"
    r"missing|not (?:yet )?(?:created|present|written|authored|added|committed)|"
    r"absent|no such|not found|has no|have no|lacks?)", re.I)
PATH_TOKEN = re.compile(
    r"[A-Za-z0-9_.\-]+(?:/[A-Za-z0-9_.\-]+)+\.[A-Za-z0-9]{1,6}"
    r"|[A-Za-z0-9_\-]+\.(?:ya?ml|md|py|cpp|hpp|cc|h|c|sh|json|csv|txt|toml|cmake|dbc|arxml|xml|robot)\b")


# ------------------------------------------------------------------ hygiene

def hygiene_flags(row):
    """Why a row should not be rendered as live memory; [] when clean."""
    keys = row.keys() if hasattr(row, "keys") else row
    kind, body = row["kind"], row["body"] or ""
    part = row["part"] or ""
    flags = []
    if kind == "blocker" and none_text(body):
        flags.append("none-body")
    if json_dict(body) is not None:
        flags.append("json-body")
    if kind == "decision" and NARRATIVE_DECISION.match(body):
        flags.append("narrative-decision")
    if kind == "state" and NARRATIVE_STATE.match(body):
        flags.append("narrative-state")
    project = row["project"] if "project" in keys else ""
    if SELFTEST_PART.match(part) or (project or "").lower() == "selftest" \
            or (row["subject"] or "").startswith("selftest-"):
        flags.append("selftest")
    if kind in ANCHOR_KINDS and (body.rstrip().endswith(";")
                                 or body.lstrip().startswith("Description:")):
        flags.append("cut-body")
    return flags


NONE_LEAD = re.compile(      # 'nothing on the bench boots' is a blocker; 'none for the merge' is an empty slot
    r"^\s*(?:(?:none|n/a|nothing)(?:\s*[.:;,(-]|\s+(?:identified|found|known|remaining|open|"
    r"blocking|currently|yet|here)\b)|none\s+(?:for|in)\b|"
    r"n/a\s+(?:for|in|at|on|to|from|with|within|beyond|besides)\b)",
    re.I)


NOTHING_LEFT = re.compile(r"^\s*(?:\[\s*\]|\{\s*\}|no (?:\w+ )?blockers? (?:remains?|left|found|"
                          r"identified)|no remaining blockers?)\s*\.?\s*$", re.I)


def none_text(text):
    """A blocker slot filled with nothing ('none for the merge itself', '[]'); 'None of the rigs boot' is real."""
    t = (text or "").strip()
    return not t or bool(NONE_BODY.fullmatch(t)) or bool(NOTHING_LEFT.match(t)) \
        or bool(NONE_LEAD.match(t) and len(t) < 80)


HIDDEN_FLAGS = ("none-body", "narrative-decision", "narrative-state", "selftest")


def hidden(row):
    return any(f in HIDDEN_FLAGS for f in hygiene_flags(row))


def json_dict(text):
    t = (text or "").strip()
    if not (t.startswith("{") and t.endswith("}")):
        return None
    try:
        value = json.loads(t)
    except ValueError:
        return None
    return value if isinstance(value, dict) else None


def display_body(row):
    """The body as a reader should see it: a JSON-dict body becomes 'key: value' text."""
    body = row["body"] or ""
    d = json_dict(body)
    if d is None:
        return body
    return "; ".join("{}: {}".format(k, v if isinstance(v, str) else json.dumps(v))
                     for k, v in d.items())


# ------------------------------------------------------------------ text units

def parse_ts(text):
    try:
        ts = datetime.fromisoformat((text or "").replace("Z", "+00:00"))
    except ValueError:
        return None
    return ts if ts.tzinfo else ts.replace(tzinfo=timezone.utc)


def uid_order(uid):
    """(host, seq, child) sort key of a uid; later journal position sorts later."""
    host, _, rest = (uid or "").rpartition(":")
    seq, _, child = rest.partition("/")
    return (host, int(seq) if seq.isdigit() else 0, int(child) if child.isdigit() else 0)


@functools.lru_cache(maxsize=65536)
def _time_of(text):
    return parse_ts(text)


def later(a, b):
    """True when row a was recorded after row b (created_at as a time, the string if unparsable, then journal order)."""
    ta, tb = a["created_at"], b["created_at"]
    if ta != tb:
        pa, pb = _time_of(ta), _time_of(tb)
        if pa is None or pb is None:
            return (ta or "") > (tb or "")
        if pa != pb:
            return pa > pb
    ka, kb = uid_order(a["uid"]), uid_order(b["uid"])
    return ka[0] == kb[0] and ka[1:] > kb[1:]


def date_only_tie(a, b):
    """Both rows carry the same date-only time (imported history): their real order is unknown."""
    ta, tb = a["created_at"] or "", b["created_at"] or ""
    return ta == tb and ta[10:19] == "T00:00:00"


def episode_units(row):
    """Evidence sentences of an episode: summary, achievements, status items."""
    try:
        doc = json.loads(row["payload"] or "{}")
    except ValueError:
        doc = {}
    if not isinstance(doc, dict):
        doc = {}
    texts = [row["body"] or ""]
    for item in _items(doc.get("achievement")):
        texts.append(_item_text(item))
    state = doc.get("current_state")
    if isinstance(state, dict):
        for item in _items(state.get("status")):
            texts.append(_item_text(item))
    return texts


def _items(value):
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _item_text(item):
    if isinstance(item, dict):
        for key in ("state", "text", "decision", "blocker", "achievement"):
            if isinstance(item.get(key), str):
                return item[key]
        return json.dumps(item, sort_keys=True)
    return str(item)


def topic_text(row):
    return " ".join(x for x in (display_body(row), row["rationale"] or "") if x)


# ------------------------------------------------------------------ blocker review

class Unit(object):
    __slots__ = ("row", "text", "doc")

    def __init__(self, row, text):
        self.row, self.text, self.doc = row, text, similar.Doc(text)


def project_rows(conn, project):
    return conn.execute(
        "SELECT * FROM records WHERE project=? COLLATE NOCASE ORDER BY id",
        (project,)).fetchall()


def evidence_units(rows):
    units = []
    for r in rows:
        if r["kind"] == "episode":
            for text in episode_units(r):
                for s in similar.sentences(text) or ([text] if text else []):
                    units.append(Unit(r, s))
        elif r["kind"] in ("decision", "state") + ANCHOR_KINDS:
            for s in similar.sentences(display_body(r)) or [display_body(r)]:
                units.append(Unit(r, s))
    return units


def rare_cutoff(n):
    """IDF of a token held by about 2% of n documents (never fewer than 3)."""
    import math
    df = max(3, int(n * 0.02))
    return math.log((n + 1.0) / (df + 1.0)) + 1.0


ANCHOR_SENTENCE_COVER = 0.25   # an identifier alone in a sentence says little about the rest
CUE_SENTENCE_COVER = 0.5       # without an identifier the cue sentence itself must name most of the blocker
CUE_FULL_COVER = 0.4           # ... counting common words too: two rare words were most of "suites not authored"
STANDING = re.compile(r"\b(?:any (?:further|future|later|new)|every time|each time|whenever|always)\b",
                      re.I)
CONDITION = re.compile(r"\b(?:until|pending|unless|defers?(?: [\w-]+){0,3} (?:to|until)|"
                       r"before|after)\b(.*)", re.I)


def counter_texts(row):
    """What an evidence episode still lists as work: its blockers and next steps."""
    if row["kind"] != "episode":
        return []
    try:
        doc = json.loads(row["payload"] or "{}")
    except ValueError:
        return []
    if not isinstance(doc, dict):
        return []
    return [_item_text(item) for key in ("blockers", "next_steps")
            for item in _items(doc.get(key))]


def _share(part, whole, idf):
    total = sum(idf.get(t, 1.0) for t in whole)
    return sum(idf.get(t, 1.0) for t in part) / total if total else 0.0


def still_listed(blocker_doc, row, idf):
    """True when the evidence row keeps the item among its own blockers or next steps."""
    for text in counter_texts(row):
        doc = similar.Doc(text)
        if similar.id_conflict(blocker_doc, doc):
            continue
        jac, ovl, shared = similar.scores(blocker_doc, doc, idf)
        if len(shared) >= 3 or (len(shared) >= 2 and ovl >= 0.35) or any(
                similar.specific(t) for t in shared & blocker_doc.ids):
            return True
    return False


def condition_doc(row):
    """The condition a temporary decision waits on ('until X', 'defers it to X'), or None."""
    m = CONDITION.search(display_body(row))
    return similar.Doc(m.group(1)) if m and m.group(1).strip() else None


def resolution_evidence(blocker_doc, blocker_row, units_by_row, index, idf, cut):
    """(unit, confidence, covered): a later row whose cue sentence names the blocker; cover of the whole row."""
    rare_b = {t for t in blocker_doc.tokens if idf.get(t, 0) >= cut}
    if not rare_b:
        return None
    weight_b = sum(idf[t] for t in rare_b)
    candidates = set()
    for t in rare_b:
        candidates.update(index.get(t, ()))
    condition = condition_doc(blocker_row) if blocker_row["kind"] == "decision" else None
    named = {t for t in blocker_doc.ids if similar.specific(t)}
    best = None
    for rid in candidates:
        row_units = units_by_row[rid]
        row = row_units[0].row
        if rid == blocker_row["id"]:
            continue
        if len(named) >= 2 and not named <= set().union(*(u.doc.tokens for u in row_units)):
            continue        # evidence for one of several named items leaves the others open
        same_day = not later(row, blocker_row) and date_only_tie(row, blocker_row)
        if not later(row, blocker_row) and not same_day:
            continue
        if blocker_row["source_record"] is not None and (
                rid == blocker_row["source_record"]
                or row["source_record"] == blocker_row["source_record"]):
            continue        # the episode that recorded the blocker never resolves it
        if still_listed(blocker_doc, row, idf):
            continue
        cue_hit, strong, anchor, sentence_cover = None, False, False, 0.0
        covered = set()
        for u in row_units:
            if similar.id_conflict(blocker_doc, u.doc):
                continue
            shared = rare_b & u.doc.tokens
            covered |= shared
            ids = {t for t in shared & blocker_doc.ids if similar.specific(t)}
            if not (ids or len(shared) >= 2) or not similar.resolves(blocker_doc, u.text):
                continue
            is_strong = bool(similar.STRONG_RESOLVED.search(u.text))
            here = sum(idf[t] for t in shared) / weight_b
            if cue_hit is None or (bool(ids), is_strong, here) > (anchor, strong, sentence_cover):
                cue_hit, strong, anchor, sentence_cover = u, is_strong, bool(ids), here
        if cue_hit is None:
            continue
        cover = sum(idf[t] for t in covered) / weight_b
        if anchor:
            confidence = "high" if strong and cover >= 0.4 else \
                "medium" if cover >= 0.3 else None
            if confidence == "high" and sentence_cover < ANCHOR_SENTENCE_COVER:
                confidence = "medium"
        else:
            confidence = "high" if strong and cover >= 0.6 else \
                "medium" if cover >= (0.5 if strong else 0.6) else None
            if confidence == "high" and (sentence_cover < CUE_SENTENCE_COVER or _share(
                    blocker_doc.tokens & cue_hit.doc.tokens, blocker_doc.tokens, idf) < CUE_FULL_COVER):
                confidence = "medium"
        if confidence is None:
            continue
        if confidence == "high" and STANDING.search(display_body(blocker_row)):
            confidence = "medium"       # following a standing rule once does not end it
        if same_day:
            confidence = "medium"
        if confidence == "high" and blocker_row["kind"] == "decision" and (
                condition is None or len(condition.tokens & cue_hit.doc.tokens) < 2):
            confidence = "medium"       # carrying out a temporary decision is not its end
        score = (confidence == "high", cover, row["created_at"])
        if best is None or score > best[0]:
            best = (score, cue_hit, confidence, sorted(covered))
    return (best[1], best[2], best[3]) if best else None


def repo_index(repo):
    """(lower-case relative paths, {basename: [paths]}, {path word: [paths]}) of a repository tree."""
    paths, names, words = set(), {}, {}
    skip = {".git", "node_modules", "build", "__pycache__", ".venv", "venv", "legacy"}
    for base, dirs, files in os.walk(repo):
        dirs[:] = [d for d in dirs if d not in skip and not d.startswith(".")
                   and not BUILD_DIR.match(d)]
        rel_base = os.path.relpath(base, repo).replace("\\", "/")
        for f in files:
            rel = f if rel_base == "." else rel_base + "/" + f
            paths.add(rel.lower())
            names.setdefault(f.lower(), []).append(rel)
            for w in path_words(rel):
                words.setdefault(w, []).append(rel)
    return paths, names, words


def path_words(text):
    """Stemmed alphabetic words of a path or clause, split on every separator."""
    return {similar.stem(w) for w in re.split(r"[^a-z]+", (text or "").lower())
            if len(w) > 2 and w not in similar.STOP}


BUILD_DIR = re.compile(r"^(?:build|cmake-build|out)(?:[-_.].*)?$", re.I)


PATH_ABSENT = re.compile(r"(does not exist|do not exist|doesn't exist|don't exist|is missing|"
                         r"are missing|missing|not (?:yet )?(?:created|present|written|authored|"
                         r"added|committed)|absent|no such|not found)", re.I)
PATH_SUBJECT = re.compile(r"[\s`'\"),]*(?:(?:file|script|directory|folder|still|yet|currently|"
                          r"also|is|are|was|were)\s+)*", re.I)
PATH_ABSENT_END = re.compile(r"\s*(?:$|[.,;:)]|(?:so|and|but|from|in|on|yet|which|because|for|"
                             r"entirely|anywhere)\b)", re.I)


LOCATION = re.compile(r"\b(?:in|from|inside|within|under|of|at|to|into)\b", re.I)


def path_is_absent(body, m, cues):
    """True when a cue says the path itself is absent, not something inside it ('x.py has no ...')."""
    for c0, c1 in cues:
        gap = body[c1:m.start()]
        if 0 <= m.start() - c1 <= 12 and not LOCATION.search(gap) and not re.search(r"[.;]\s", gap):
            return True
        if 0 <= c0 - m.end() <= 40 and PATH_SUBJECT.fullmatch(body[m.end():c0]) \
                and PATH_ABSENT_END.match(body[c1:c1 + 24]):
            return True
    return False


def path_evidence(body, index):
    """(path, confidence) when the body calls a path missing and the repository has it."""
    if index is None or not PATH_ABSENT.search(body or ""):
        return None
    paths, names = index[0], index[1]
    cues = [c.span() for c in PATH_ABSENT.finditer(body)]
    for m in PATH_TOKEN.finditer(body):
        if not path_is_absent(body, m, cues):
            continue
        token = re.sub(r"^(?:\./)+", "", m.group(0).replace("\\", "/"))
        low = token.lower()
        if "/" in low:
            if low in paths:
                return token, "high"
            deeper = [p for p in names.get(low.rsplit("/", 1)[-1], [])
                      if p.lower().endswith("/" + low)]
            if len(deeper) == 1:        # the same relative path under another directory
                return deeper[0], "medium"
        else:
            hits = names.get(low, [])
            if len(hits) == 1:
                return hits[0], "medium"
    return None


TEXT_EXTENSIONS = (".md", ".yaml", ".yml", ".py", ".csv", ".cpp", ".hpp", ".h", ".c", ".cc",
                   ".json", ".txt", ".toml", ".dbc", ".cmake", ".sh", ".puml", ".xml", ".arxml")
TEXT_MAX_BYTES = 2000000
ID_KEY = re.compile(r"^(\s*)(-\s+)?id\s*:\s*['\"]?([A-Za-z0-9][\w.-]*)['\"]?\s*(?:#.*)?$",
                    re.I)       # exactly `id`: requirement_id or parent_id names another record
STATUS_KEY = re.compile(r"^\s*(?:-\s+)?(?:status|state|disposition|resolution)\s*:\s*['\"]?([\w-]+)",
                        re.I)
CLOSED_STATUS = re.compile(r"^(?:closed|done|resolved|completed?|delivered|retired|cancell?ed|"
                           r"superseded|obsolete)(?:$|[_-])", re.I)
PLACEHOLDER = re.compile(r"replace_?me|placeholder|todo|tbd|fixme|changeme", re.I)
LITERAL = re.compile(r"[`\"']([^`\"'\s]{6,80})[`\"']|\b([A-Z][A-Z0-9]*(?:_[A-Z0-9]+){2,})\b")


def repo_texts(repo, index):
    """{relative path: text} of the repository's text files (index from repo_index)."""
    texts = {}
    for rel in sorted({p for found in index[1].values() for p in found}):
        if not rel.lower().endswith(TEXT_EXTENSIONS):
            continue
        try:
            with open(os.path.join(repo, rel), "rb") as f:
                data = f.read(TEXT_MAX_BYTES + 1)
        except OSError:
            continue
        if len(data) <= TEXT_MAX_BYTES:
            texts[rel] = data.decode("utf-8", "replace")
    return texts


def status_records(texts):
    """{identifier: [(path, status)]} from YAML records that carry an id key and a status key."""
    out = {}
    for rel, text in texts.items():
        if not rel.lower().endswith((".yaml", ".yml")):
            continue
        lines = text.splitlines()
        for i, line in enumerate(lines):
            m = ID_KEY.match(line)
            if not m:
                continue
            fields = len(m.group(1)) + (len(m.group(2)) if m.group(2) else 0)
            status = None
            for nxt in lines[i + 1:i + 40]:
                if not nxt.strip():
                    continue
                indent = len(nxt) - len(nxt.lstrip())
                if indent < fields or (indent == fields and ID_KEY.match(nxt)) or (
                        m.group(2) and indent <= len(m.group(1))):
                    break
                s = STATUS_KEY.match(nxt)
                if s and indent == fields:
                    status = s.group(1)
                    break
            if status:
                out.setdefault(m.group(3).lower(), []).append((rel, status))
    return out


def id_status_evidence(body, records):
    """(path, 'high') when the first identifier a pending blocker names has only closed records."""
    if records is None or not (similar.PENDING_CUE.search(body) or ABSENCE_CUE.search(body)):
        return None
    doc = similar.Doc(body)
    for raw in similar.WORD.findall(body):
        t = raw.lower().strip("./-_")
        if t in doc.ids and similar.specific(t) and re.search(r"[a-z].*[-_]|[-_].*[a-z]", t):
            found = records.get(t, [])
            closed = sorted(p for p, s in found if CLOSED_STATUS.match(s))
            if closed and len(closed) == len(found):
                return closed[0], "high"
            return None
    return None


def placeholder_literals(body):
    """Quoted or ALL_CAPS literals of a body that look like placeholders."""
    return [lit for lit in (m.group(1) or m.group(2) for m in LITERAL.finditer(body or ""))
            if PLACEHOLDER.search(lit)]


BINARY_PROBE = 8192


def placeholder_scan(repo, literals):
    """{'found', 'read', 'skipped'}: literals held by a non-binary file; hidden directories count, only .git is left out."""
    wanted = {lit: lit.encode("utf-8") for lit in literals}
    scan = {"found": set(), "read": 0, "skipped": False}

    def unreadable(_error):
        scan["skipped"] = True

    for base, dirs, files in os.walk(repo, onerror=unreadable):
        dirs[:] = [d for d in dirs if d != ".git"]
        for name in files:
            try:
                with open(os.path.join(base, name), "rb") as f:
                    data = f.read(TEXT_MAX_BYTES + 1)
            except OSError:
                scan["skipped"] = True
                continue
            if b"\0" in data[:BINARY_PROBE]:
                continue
            if len(data) > TEXT_MAX_BYTES:
                scan["skipped"] = True
                continue
            scan["read"] += 1
            scan["found"].update(lit for lit, raw in wanted.items() if raw in data)
    return scan


def literal_gone_evidence(body, scan):
    """(note, confidence) when a placeholder the blocker quotes is in no file read; 'medium' when a file went unread."""
    if not scan or not scan["read"]:
        return None
    for literal in placeholder_literals(body):
        if literal not in scan["found"]:
            return "no longer contains " + literal, "medium" if scan["skipped"] else "high"
    return None


def part_family(conn, project, part):
    """The part, its aliases/children (transitively) and its ancestor chain, never an ancestor's other children."""
    if not part:
        return None
    try:
        edges = conn.execute("SELECT part, parent FROM parts WHERE project=? "
                             "COLLATE NOCASE", (project,)).fetchall()
    except Exception:
        return {part}
    parent = {e["part"]: e["parent"] for e in edges}
    family = {part}
    changed = True
    while changed:
        changed = False
        for child, par in parent.items():
            if par in family and child not in family:
                family.add(child)
                changed = True
    node = part
    while node in parent and parent[node] not in family:
        node = parent[node]
        family.add(node)
    return family


def review_blockers(conn, project, part=None, repo=None, now=None):
    """Proposals for every open blocker (and temporary decision) in scope."""
    now = now or datetime.now(timezone.utc)
    rows = project_rows(conn, project)
    family = part_family(conn, project, part)
    in_scope = (lambda r: family is None or r["part"] in family)
    blockers = [r for r in rows if r["kind"] == "blocker" and r["status"] == "open"
                and in_scope(r)]
    temporary = [r for r in rows if r["kind"] == "decision" and r["status"] == "open"
                 and in_scope(r) and similar.TEMPORARY_CUE.search(r["body"] or "")]
    units = evidence_units(rows)
    docs = [u.doc for u in units] + [similar.Doc(display_body(r)) for r in blockers]
    idf = similar.idf_table(docs)
    cut = rare_cutoff(len(docs))
    index, units_by_row = {}, {}
    for u in units:
        units_by_row.setdefault(u.row["id"], []).append(u)
        for t in u.doc.tokens:
            if idf.get(t, 0) >= cut:
                index.setdefault(t, set()).add(u.row["id"])
    index_repo = repo_index(repo) if repo else None
    texts = repo_texts(repo, index_repo) if repo else None
    records = status_records(texts) if repo else None
    literals = {lit for r in blockers for lit in placeholder_literals(display_body(r))}
    scan = placeholder_scan(repo, literals) if repo and literals else None
    proposals, review = [], []
    open_blocker_docs = [(r, similar.Doc(display_body(r))) for r in blockers]
    for r, doc in open_blocker_docs + [(d, similar.Doc(display_body(d))) for d in temporary]:
        found = None
        if r["kind"] == "blocker" and none_text(display_body(r)):
            found = {"action": "close", "uid": r["uid"], "evidence": "hygiene:none-body",
                     "confidence": "high", "reason": "not a blocker: the body is an empty slot"}
        if found is None and r["kind"] == "blocker":
            hit = path_evidence(display_body(r), index_repo)
            if hit:
                found = {"action": "close", "uid": r["uid"], "evidence": "repo:" + hit[0],
                         "confidence": hit[1], "reason": "path exists: " + hit[0]}
        if found is None and r["kind"] == "blocker":
            hit = id_status_evidence(display_body(r), records)
            if hit:
                found = {"action": "close", "uid": r["uid"], "evidence": "repo:" + hit[0],
                         "confidence": hit[1], "reason": "closed status record in " + hit[0]}
        if found is None and r["kind"] == "blocker":
            hit = literal_gone_evidence(display_body(r), scan)
            if hit:
                found = {"action": "close", "uid": r["uid"], "evidence": "repo:" + hit[0],
                         "confidence": hit[1], "reason": "the repository " + hit[0]}
        if found is None:
            ev = resolution_evidence(doc, r, units_by_row, index, idf, cut)
            if ev:
                unit, confidence, shared = ev
                found = {"action": "close", "uid": r["uid"], "evidence": unit.row["uid"],
                         "confidence": confidence,
                         "reason": "resolved: " + _snip(unit.text, 160),
                         "shared": shared[:8]}
        if found is None and r["kind"] == "blocker":
            newer, full = restated_by(r, doc, open_blocker_docs, idf)
            if newer:
                found = {"action": "supersede", "uid": r["uid"], "by": newer["uid"],
                         "confidence": "high" if full else "medium",
                         "reason": "restated later: " + _snip(display_body(newer), 120)}
        if found:
            found.update(kind=r["kind"], part=r["part"], date=r["created_at"][:10],
                         summary=_snip(display_body(r), 140))
            proposals.append(found)
            continue
        if r["kind"] != "blocker":
            continue
        created = parse_ts(r["last_confirmed_at"] or r["created_at"])
        age = (now - created).days if created else None
        if age is not None and age > BLOCKER_REVIEW_DAYS:
            review.append({"uid": r["uid"], "part": r["part"], "age_days": age,
                           "summary": _snip(display_body(r), 140)})
    twins(proposals, open_blocker_docs, idf)
    return {"project": project, "part": part, "open_blockers": len(blockers),
            "temporary_decisions": len(temporary), "proposals": proposals,
            "review": review}


TWIN_SCORE = 0.6     # the same blocker worded twice, anchored by a shared specific identifier


def is_twin(a, b, idf):
    if a.tokens == b.tokens:
        return True
    shared_ids = {t for t in a.ids & b.ids if similar.specific(t)}
    return bool(shared_ids) and similar.dup_score(a, b, idf) >= TWIN_SCORE


def twins(proposals, blocker_docs, idf):
    """Give a blocker the close of its twin (same part, same blocker worded again) when its own proposal is weaker."""
    by_uid = {p["uid"]: p for p in proposals}
    rank = {"high": 2, "medium": 1}
    closes = [(r, d, by_uid[r["uid"]]) for r, d in blocker_docs
              if by_uid.get(r["uid"], {}).get("action") == "close"
              and not by_uid[r["uid"]]["evidence"].startswith("hygiene:")]
    for r, doc in blocker_docs:
        own = by_uid.get(r["uid"])
        mine = rank.get(own["confidence"], 0) if own and own["action"] == "close" else 0
        best = None
        for other, odoc, prop in closes:
            if other["id"] == r["id"] or other["part"] != r["part"] or rank.get(prop["confidence"], 0) <= mine:
                continue
            if is_twin(doc, odoc, idf) and (best is None or rank[prop["confidence"]] > rank[best["confidence"]]):
                best = prop
        if best is None:
            continue
        item = dict(best, uid=r["uid"], date=r["created_at"][:10], summary=_snip(display_body(r), 140),
                    reason="same blocker as {}; {}".format(best["uid"], best["reason"]))
        if own is None:
            proposals.append(item)
        else:
            proposals[proposals.index(own)] = item


RESTATED_THRESHOLD = 0.5    # review-blockers applies these; stricter than the report-only groups


def restated_by(row, doc, candidates, idf):
    """(newest open blocker of the part repeating this one, whether it holds every content word); covering wins."""
    best, full = None, False
    for other, odoc in candidates:
        if other["id"] == row["id"] or not later(other, row):
            continue
        if other["part"] != row["part"] or (
                row["source_record"] is not None
                and other["source_record"] == row["source_record"]):
            continue
        if similar.dup_score(doc, odoc, idf) < RESTATED_THRESHOLD:
            continue
        if lossy(doc, odoc, idf):
            continue
        whole = covers(odoc, doc)
        if date_only_tie(other, row) and not whole:
            continue        # an imported day has no known order: only a row holding every word may replace
        if best is None or whole > full or (whole == full and later(other, best)):
            best, full = other, whole
    return best, full


def lossy(old, new, idf, cut=None):
    """True when superseding old by new would drop at least two above-median tokens."""
    cut = _median(idf) if cut is None else cut
    missing = [t for t in old.tokens - new.tokens if idf.get(t, 0) > cut]
    return len(missing) >= 2


def covers(new, old):
    """True when the newer row says every content word of the older one: nothing is lost."""
    return old.tokens <= new.tokens


def _median(idf):
    values = sorted(idf.values())
    return values[len(values) // 2] if values else 0


def _snip(text, n):
    s = re.sub(r"\s+", " ", (text or "").strip())
    if len(s) <= n:
        return s
    cut = s.rfind(" ", 0, n - 3)
    return s[:cut if cut > n // 2 else n - 3] + "..."


# ------------------------------------------------------------------ near-duplicates, contradictions

EPISODE_DUP = 0.7      # whole episodes recorded twice; a series of similar jobs stays apart


def quality_proposals(conn, project,
                      kinds=("blocker", "decision", "state", "anchor", "episode", "cross")):
    """Near-duplicate groups and contradiction links; rows are compared on the body, never the rationale."""
    rows = project_rows(conn, project)
    out = {"project": project, "near_duplicates": [], "contradicts": []}
    pools = {}
    for r in rows:
        family = "anchor" if r["kind"] in ANCHOR_KINDS else r["kind"]
        if family == "episode" or r["status"] == "open":
            pools.setdefault(family, []).append(r)
    for family, pool in sorted(pools.items()):
        if family not in kinds:
            continue
        if family == "episode":
            docs = [similar.Doc(" ".join(episode_units(r))) for r in pool]
        else:
            docs = [similar.Doc(display_body(r)) for r in pool]
        idf = similar.idf_table(docs)
        threshold = EPISODE_DUP if family == "episode" else \
            similar.DUP_THRESHOLD.get(family, similar.DEFAULT_DUP)
        for group in similar.groups(docs, idf, threshold):
            out["near_duplicates"].append(_group_item(family, [pool[i] for i in group],
                                                      {pool[i]["id"]: docs[i] for i in group},
                                                      idf))
        if family == "decision":
            out["contradicts"] = contradictions(pool, docs, idf)
    if "cross" in kinds:
        out["near_duplicates"] += cross_kind(pools.get("state", []), pools.get("anchor", []))
    return out


def _group_item(family, members, docs_by_id, idf):
    """Keep the newest member; supersede an older one of its part it fully covers, relate the rest."""
    members = sorted(members, key=lambda r: (r["created_at"], uid_order(r["uid"])))
    keep = members[-1]
    kdoc = docs_by_id[keep["id"]]
    item = {"kind": family, "keep": keep["uid"], "supersede": [], "relate": []}
    for m in members[:-1]:
        if family != "episode" and m["part"] == keep["part"] \
                and covers(kdoc, docs_by_id[m["id"]]):
            item["supersede"].append(m["uid"])
        else:
            item["relate"].append(m["uid"])
    return item


def cross_kind(states, anchors):
    """A state row that repeats a newer goal, constraint or preference: superseded by it."""
    if not states or not anchors:
        return []
    sdocs = [similar.Doc(display_body(r)) for r in states]
    adocs = [similar.Doc(topic_text(r)) for r in anchors]
    idf = similar.idf_table(sdocs + adocs)
    out = []
    for s, sd in zip(states, sdocs):
        best = None
        for a, ad in zip(anchors, adocs):
            if not later(a, s):
                continue
            score = similar.dup_score(sd, ad, idf)
            if score >= similar.DUP_THRESHOLD["cross"] and (best is None or score > best[0]):
                best = (score, a, ad)
        if best:
            covered = covers(best[2], sd)
            out.append({"kind": "cross", "keep": best[1]["uid"],
                        "supersede": [s["uid"]] if covered else [],
                        "relate": [] if covered else [s["uid"]]})
    return out


CLAUSE_END = re.compile(r"[.;:,()]|\s--\s|$")


def rejected_clauses(text):
    """(cue, clause) pairs: what a decision turns away from, after 'instead of', 'rather than', 'not'."""
    return split_decision(text)[1]


def split_decision(text):
    """(what the decision chose, [(cue, rejected clause)]): the text with its rejected clauses cut out."""
    text = text or ""
    kept, clauses, pos = [], [], 0
    for m in similar.REJECT_CUE.finditer(text):
        if m.start() < pos:
            continue
        tail = text[m.end():m.end() + 120]
        end = CLAUSE_END.search(tail)
        clause = tail[:end.start()] if end else tail
        if len(clause.strip()) < 6:
            continue
        kept.append(text[pos:m.start()])
        clauses.append((m.group(0).strip(), clause.strip()))
        pos = m.end() + len(clause)
    kept.append(text[pos:])
    return " ".join(kept), clauses


def contradictions(pool, docs, idf):
    """[newer, older, score, cue]: the clause the newer rejects shares 2 tokens (1 rare or an id) with the older."""
    cut = rare_cutoff(len(docs))
    topical = (cut + 1.0) / 2
    split = [split_decision(display_body(r)) for r in pool]
    chosen = [similar.Doc(s[0]) for s in split]
    index = {}
    for i, d in enumerate(chosen):
        for t in d.tokens:
            if idf.get(t, 0) >= cut or t in d.ids:
                index.setdefault(t, []).append(i)
    limit = max(8, int(len(docs) * 0.02))
    best = {}
    for i, new in enumerate(pool):
        for cue, clause in split[i][1]:
            cdoc = similar.Doc(clause)
            keys = [t for t in cdoc.tokens if t in index and len(index[t]) <= limit]
            for j in {j for t in keys for j in index[t]}:
                old = pool[j]
                if j == i or not later(new, old) or (
                        old["source_record"] is not None
                        and old["source_record"] == new["source_record"]):
                    continue
                od, nd = docs[j], docs[i]
                if similar.id_conflict(nd, od):
                    continue
                hit = cdoc.tokens & chosen[j].tokens
                strong = {t for t in hit if idf.get(t, 0) >= cut or t in od.ids}
                if len(hit) < 2 or not strong:
                    continue
                # same subject: the rest of the newer decision is about what the older one chose
                topic = (chosen[i].tokens & chosen[j].tokens) - hit
                if len(topic) < 2 or not any(idf.get(t, 0) >= topical for t in topic):
                    continue
                jac, ovl, shared = similar.scores(nd, od, idf)
                score = max(jac, 0.85 * ovl)
                if score >= similar.DUP_THRESHOLD["decision"]:
                    continue
                pair = [new["uid"], old["uid"], round(score, 3), cue.lower()]
                if old["uid"] not in best or pair[2] > best[old["uid"]][2]:
                    best[old["uid"]] = pair
    return sorted(best.values(), key=lambda p: (uid_order(p[1]), uid_order(p[0])))


# ------------------------------------------------------------------ write gate

PARAPHRASE_SCORE = 0.42     # iteration 5: rules reworded in other words scored 0.461 and 0.483
PARAPHRASE_SHARED = 4       # ... sharing 5 content words; no real anchor pair scores 0.36-0.439


def write_gate(conn, project, kind, body, subject=None, rationale=None, limit=3):
    """(near_duplicates, related) open rows for a new fact, best first."""
    family = ANCHOR_KINDS if kind in ANCHOR_KINDS else (kind,)
    marks = ",".join("?" * len(family))
    rows = conn.execute(
        "SELECT * FROM records WHERE project=? COLLATE NOCASE AND status='open' "
        "AND kind IN ({})".format(marks), (project,) + tuple(family)).fetchall()
    if not rows:
        return [], []
    new = similar.Doc(body)
    docs = [similar.Doc(display_body(r)) for r in rows]
    idf = similar.idf_table(docs + [new])
    threshold = similar.DUP_THRESHOLD.get("anchor" if kind in ANCHOR_KINDS else kind,
                                          similar.DEFAULT_DUP)
    dups, related = [], []
    for r, d in zip(rows, docs):
        if subject and r["subject"] == subject:
            continue
        score = similar.dup_score(new, d, idf)
        entry = {"uid": r["uid"], "part": r["part"], "score": round(score, 3),
                 "summary": _snip(display_body(r), 120)}
        paraphrase = kind in ANCHOR_KINDS and score >= PARAPHRASE_SCORE \
            and len(new.tokens & d.tokens) >= PARAPHRASE_SHARED
        if score >= threshold or paraphrase:
            dups.append(entry)
        elif score >= 0.3:
            related.append(entry)
    key = (lambda e: -e["score"])
    return sorted(dups, key=key)[:limit], sorted(related, key=key)[:limit]


def open_blocker_count(conn, project, part):
    """Number of open blockers in the part family (open_blockers_for lists only the top ones)."""
    family = part_family(conn, project, part) or {part}
    return conn.execute(
        "SELECT count(*) FROM records WHERE project=? COLLATE NOCASE AND kind='blocker' "
        "AND status='open' AND part IN ({})".format(",".join("?" * len(family))),
        (project,) + tuple(sorted(family))).fetchone()[0]


def open_blockers_for(conn, project, part, text, limit=10):
    """Open blockers of the part family, most similar to the episode text first."""
    family = part_family(conn, project, part) or {part}
    marks = ",".join("?" * len(family))
    rows = conn.execute(
        "SELECT * FROM records WHERE project=? COLLATE NOCASE AND kind='blocker' "
        "AND status='open' AND part IN ({})".format(marks),
        (project,) + tuple(sorted(family))).fetchall()
    if not rows:
        return []
    doc = similar.Doc(text)
    docs = [similar.Doc(display_body(r)) for r in rows]
    idf = similar.idf_table(docs + [doc])
    ranked = sorted(zip(rows, docs), key=lambda p: (-similar.scores(doc, p[1], idf)[1],
                                                    p[0]["created_at"]), )
    return [{"uid": r["uid"], "date": r["created_at"][:10],
             "summary": _snip(display_body(r), 100)} for r, _ in ranked[:limit]]


def part_suggestions(conn, project, part, limit=3):
    """Existing parts whose slug shares tokens with a part the project never used."""
    names = [r[0] for r in conn.execute(
        "SELECT DISTINCT part FROM records WHERE project=? COLLATE NOCASE", (project,))]
    if part in names or not names:
        return []
    mine = set(t for t in re.split(r"[-_]+", part.lower()) if len(t) > 1 and not t.isdigit())
    scored = []
    for name in names:
        theirs = set(t for t in re.split(r"[-_]+", name.lower()) if len(t) > 1 and not t.isdigit())
        if mine and theirs:
            score = len(mine & theirs) / float(len(mine | theirs))
            if score >= 0.34:
                scored.append((-score, name))
    return [n for _, n in sorted(scored)[:limit]]

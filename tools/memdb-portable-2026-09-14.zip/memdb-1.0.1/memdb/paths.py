"""Every filesystem location memdb uses, resolved in one place.

MEMDB_HOME moves the whole data directory; MEMDB_PATH and MEMDB_JOURNAL
still override their single entry, so existing hosts keep working.
Nothing here touches the disk except reading config.json for the one
location install records there; callers create what they need.

Setting MEMDB_HOME at all marks a non-default data home: machine-global
things (the OS schedule, the harness rules file) are then isolated from
the real host's, because a redirected HOME alone cannot be told apart
from the real profile.

Locations under the user's harness directory (~/.claude) are NOT part of
the data home: they belong to the harness, and a harness adapter owns
them (memdb.harness). They are resolved here so no other module builds
a path by hand.
"""
import json
import os

ENV_HOME = "MEMDB_HOME"
ENV_DB = "MEMDB_PATH"
ENV_JOURNAL = "MEMDB_JOURNAL"
CORE_RULES_NAME = "memdb-core-global.md"


def _user(path):
    return os.path.expanduser(path)


def claude_dir():
    return os.path.join(_user("~"), ".claude")


def default_home():
    return os.path.join(claude_dir(), "memory")


def home_is_default():
    """True unless MEMDB_HOME is set (to any value)."""
    return not os.environ.get(ENV_HOME)


def home():
    """The data directory: MEMDB_HOME, else ~/.claude/memory."""
    value = os.environ.get(ENV_HOME)
    return os.path.normpath(_user(value)) if value else default_home()


def db_path():
    return os.environ.get(ENV_DB) or os.path.join(home(), "mem.db")


def default_db_path():
    """The DB path MEMDB_PATH overrides; used for reports, not for access."""
    return os.path.join(home(), "mem.db")


def journal_root():
    return os.environ.get(ENV_JOURNAL) or os.path.join(home(), "journal")


def host_id_file():
    return os.path.join(home(), "host-id")


def sessions_dir():
    return os.path.join(home(), "sessions")


def config_path():
    return os.path.join(home(), "config.json")


def embcache_path():
    return os.path.join(home(), "embcache.sqlite")


def install_backups_dir():
    return os.path.join(home(), "install-backups")


def local_dir():
    """Host-specific additions spliced into rendered templates."""
    return os.path.join(home(), "local")


def sync_log():
    return os.path.join(home(), "sync.log")


def bin_dir():
    """Where the .pyz install form keeps the artifact it runs from."""
    return os.path.join(home(), "bin")


def derived_dir(root=None):
    """Per-clone derived state; outside journal/ so sync never commits it."""
    return os.path.join(root or journal_root(), "derived")


def claude_projects_dir():
    return os.path.join(claude_dir(), "projects")


def claude_settings_file():
    return os.path.join(claude_dir(), "settings.json")


def claude_rules_dir():
    return os.path.join(claude_dir(), "rules")


def _recorded_core_rules():
    try:
        with open(config_path(), encoding="utf-8") as f:
            value = json.load(f).get("core_rules")
    except (OSError, ValueError, AttributeError):
        return None
    return value if isinstance(value, str) and value else None


def core_rules_file():
    """render-core output: MEMDB_CORE_RULES, else the path install recorded, else by data home."""
    env = os.environ.get("MEMDB_CORE_RULES")
    if env:
        return env
    recorded = _recorded_core_rules()
    if recorded:
        return recorded
    if not home_is_default():
        return os.path.join(home(), "rules", CORE_RULES_NAME)
    return os.path.join(claude_rules_dir(), CORE_RULES_NAME)


def claude_skill_file():
    return os.path.join(claude_dir(), "skills", "memdb", "SKILL.md")

"""The one machine-specific file: <memdb-home>/config.json.

Every installed artifact (hook registration, schedule, rendered skill and
rule block) is generated from these values, so no rendered file ever
carries a path of the source checkout. Environment variables still win
over config values wherever both exist.

command() is the ONLY producer of memdb command lines. If a second
producer appears, the three command forms drift apart between the hook,
the schedule and the documentation - which is the failure this file
exists to prevent.
"""
import json
import os
import re
import shutil
import subprocess
import sys

try:
    from . import paths
except ImportError:                     # loose script: python memdb/mem.py
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import paths  # noqa: E402

FORM_MEM = "mem"
FORM_INTERPRETER = "interpreter"
FORM_PYZ = "pyz"
FORMS = (FORM_MEM, FORM_INTERPRETER, FORM_PYZ)

HUB_MODES = ("join", "new", "standalone")
SCHEDULE_KINDS = ("windows-task", "cron", "launchd", "none")
# Written only by `mem install` / `mem schedule`: a hand edit would drift
# from the git origin or the OS schedule they describe.
INSTALL_OWNED_KEYS = ("host_id", "hub", "schedule", "command_form",
                      "interpreter", "pyz_path", "mem_path", "harnesses",
                      "version", "core_rules", "safe_path")

DEFAULTS = {
    "host_id": "",
    "hub": {"mode": "standalone", "url": ""},
    "harnesses": [],
    "interpreter": "",
    "command_form": FORM_INTERPRETER,
    "safe_path": False,
    "pyz_path": "",
    "mem_path": "",
    "embed": {"url": "http://localhost:11434", "model": "nomic-embed-text",
              "dim": 256, "enabled": False},
    "schedule": {"kind": "none", "time": "12:00"},
    "core_rules": "",
    "version": "",
}


def exists(path=None):
    return os.path.isfile(path or paths.config_path())


def load(path=None):
    """The config with defaults filled in; a missing file means all defaults."""
    try:
        with open(path or paths.config_path(), encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        data = {}
    if not isinstance(data, dict):
        data = {}
    out = {}
    for key, default in DEFAULTS.items():
        value = data.get(key, default)
        if isinstance(default, dict):
            merged = dict(default)
            if isinstance(value, dict):
                merged.update(value)
            value = merged
        out[key] = value
    for key, value in data.items():     # keep keys a newer memdb wrote
        out.setdefault(key, value)
    return out


def text_of(cfg):
    """The exact text save() writes, so install can diff before writing."""
    return json.dumps(cfg, indent=2, sort_keys=True) + "\n"


def save(cfg, path=None):
    path = path or paths.config_path()
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write(text_of(cfg))
    os.replace(tmp, path)
    return path


def get(key, default=None, path=None):
    return load(path).get(key, default)


def set_value(key, value, path=None):
    cfg = load(path)
    cfg[key] = value
    save(cfg, path)
    return cfg


# ------------------------------------------------------------------ hub

_DRIVE = re.compile(r"^[A-Za-z]:[\\/]")


def is_local_hub(url):
    """True for a hub git reaches without ssh: file://, POSIX or drive paths."""
    url = url or ""
    return (url.startswith("file://") or url.startswith("/")
            or url.startswith("\\\\") or bool(_DRIVE.match(url)))


def hub_journal_url(url):
    """The journal repo URL of a hub spec; a bare ssh host gets the default path."""
    if not url:
        return ""
    if is_local_hub(url) or "://" in url or ":" in url:
        return url
    return url + ":git/memory-journal.git"


def ssh_repo_path(url):
    """The repository path on the ssh host of a non-local hub spec."""
    url = hub_journal_url(url)
    if url.startswith("ssh://"):
        rest = url[len("ssh://"):]
        path = "/" + rest.split("/", 1)[1] if "/" in rest else ""
        return path[len("/~/"):] if path.startswith("/~/") else path
    path = url.split(":", 1)[1] if ":" in url else ""
    return path[len("~/"):] if path.startswith("~/") else path


def ssh_host(url):
    """The ssh destination of a non-local hub spec, with any path stripped."""
    url = url or ""
    if url.startswith("ssh://"):
        return url[len("ssh://"):].split("/", 1)[0]
    return url.split(":", 1)[0]


def _remote_key(url):
    url = (url or "").strip().rstrip("/")
    if url.startswith("file://"):
        url = url[len("file://"):]
    if is_local_hub(url):
        return os.path.normcase(os.path.normpath(url))
    return url


def same_remote(a, b):
    """Two git remote URLs name the same repository (local paths normalised)."""
    return _remote_key(a) == _remote_key(b)


# ------------------------------------------------------- command forms

def interpreter(cfg=None):
    """Absolute interpreter recorded at install time; this one otherwise."""
    cfg = load() if cfg is None else cfg
    return cfg.get("interpreter") or sys.executable


def pyz_path(cfg=None):
    cfg = load() if cfg is None else cfg
    return cfg.get("pyz_path") or os.path.join(paths.bin_dir(), "memdb.pyz")


def base(cfg=None):
    """argv prefix with no subcommand: the `{{MEM}}` of rendered files."""
    cfg = load() if cfg is None else cfg
    form = cfg.get("command_form") or FORM_INTERPRETER
    if form == FORM_MEM:
        # Absolute: cron and Task Scheduler run with a minimal PATH.
        return [cfg.get("mem_path") or "mem"]
    if form == FORM_PYZ:
        # Never `-m memdb` here: inside a .pyz the package is runnable,
        # not importable.
        return [interpreter(cfg), pyz_path(cfg)]
    # -m puts the working directory first on sys.path: a memdb checkout there would run instead
    return [interpreter(cfg)] + (["-P"] if cfg.get("safe_path") else []) + ["-m", "memdb"]


def command(cmd, *args, **kwargs):
    """argv for `mem <cmd> ...` in this host's installed command form."""
    return base(kwargs.get("cfg")) + [str(cmd)] + [str(a) for a in args]


WINDOWS = os.name == "nt"


def quote(part):
    """Quote one argv element for a command STRING that sh, Git Bash and cmd.exe parse alike."""
    if WINDOWS and ("\\" in part or _DRIVE.match(part)):
        # Git Bash (Claude Code's hook shell) eats backslashes; cmd.exe needs C:/ quoted.
        return '"{}"'.format(part.replace("\\", "/"))
    return '"{}"'.format(part) if (" " in part or "\t" in part) else part


def command_text(cmd, *args, **kwargs):
    """command() as one string, for files that hold a command line."""
    return " ".join(quote(p) for p in command(cmd, *args, **kwargs))


def base_text(cfg=None):
    """The command prefix as one string: what `{{MEM}}` renders to."""
    return " ".join(quote(p) for p in base(cfg))


def display_prefix():
    """Command prefix for printed hints: the installed form, else `mem`; never raises."""
    try:
        return base_text(load()) if exists() else "mem"
    except Exception:
        return "mem"


def hook_command_text(name, **kwargs):
    return command_text("hook", name, **kwargs)


MARKER = "memdb"


def _first_token(text):
    text = text.strip()
    if text.startswith('"'):
        end = text.find('"', 1)
        return text[1:end] if end > 0 else text[1:]
    return text.split()[0] if text else ""


def is_memdb_command(text):
    """True for a registered command string of memdb, older forms included."""
    text = (text or "").replace("\\", "/")
    if not text.strip():
        return False
    if MARKER in text and ("-m memdb" in text or "memdb.pyz" in text
                           or "/memdb/mem.py" in text or "memdb-hook" in text
                           or "session_start.sh" in text):
        return True
    name = _first_token(text).rsplit("/", 1)[-1].lower()
    return name in ("mem", "mem.exe") and " hook " in text


def running_pyz():
    """The .pyz archive this package is executing from, or None."""
    here = os.path.abspath(__file__)
    idx = here.lower().find(".pyz" + os.sep)
    return here[:idx + 4] if idx >= 0 else None


def detect_command_form(pyz=None):
    """(form, detail): pyz when asked or running from one, `mem` when it runs, else interpreter."""
    pyz = pyz or running_pyz()
    if pyz:
        return FORM_PYZ, pyz
    found = shutil.which("mem")
    if found:
        try:
            p = subprocess.run([found, "--version"], capture_output=True,
                               text=True, timeout=30)
            if p.returncode == 0 and p.stdout.startswith("memdb "):
                return FORM_MEM, found
        except (OSError, subprocess.SubprocessError):
            pass
    return FORM_INTERPRETER, sys.executable


def host_id_file_value():
    try:
        with open(paths.host_id_file(), encoding="utf-8") as f:
            return f.read().strip() or None
    except OSError:
        return None


def cmd_config(args):
    """mem config show|get|set"""
    if args.action == "show":
        shown = load()
        shown["source"] = "file" if exists() else "defaults"
        shown["path"] = paths.config_path()
        shown["host_id_file"] = host_id_file_value()
        if not exists():
            print("config: no config.json at {}; the values shown are built-in "
                  "defaults, not this host's settings (this host was not "
                  "installed by mem install; see install --check)".format(
                      paths.config_path()), file=sys.stderr)
        print(json.dumps(shown, indent=2, sort_keys=True))
        return
    if args.action == "get":
        print(json.dumps(load().get(args.key), sort_keys=True))
        return
    if args.key in INSTALL_OWNED_KEYS:
        raise SystemExit("config: {} is written by mem install (or mem schedule)"
                         " so it cannot drift from what it describes; re-run "
                         "mem install --check with the new value".format(args.key))
    try:
        value = json.loads(args.value)
    except (TypeError, ValueError):
        value = args.value
    save(set_value(args.key, value))
    print(json.dumps({"set": args.key, "value": value,
                      "path": paths.config_path()}, sort_keys=True))

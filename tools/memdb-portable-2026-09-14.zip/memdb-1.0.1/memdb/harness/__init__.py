"""Harness adapters: everything that knows where a specific agent tool keeps
its skills, rules and hook registrations.

The rest of memdb never touches a harness path. An adapter implements
paths(), render(), register_hooks(), check() and unregister(); every write
of a user-owned file copies the original into
<memdb-home>/install-backups/ first and returns a unified diff, so
`mem install --check` can show exactly what would change.
"""
import datetime
import difflib
import os
import sys

try:
    from .. import config, paths
except ImportError:                     # loose script: python memdb/mem.py
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import config  # noqa: E402
    import paths  # noqa: E402

RULE_START = "<!-- memory-persistence-rule"
RULE_END = "<!-- /memory-persistence-rule -->"
LEGACY_RULE_HEADING = "# Memory Persistence Rule (memdb)"


def template_text(name):
    """Text of a packaged template, from a wheel, a .pyz or the source tree."""
    pkg = __package__.rsplit(".", 1)[0] if __package__ else ""
    if pkg:
        from importlib.resources import files
        return files(pkg).joinpath("templates", name).read_text(
            encoding="utf-8")
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    with open(os.path.join(here, "templates", name), encoding="utf-8") as f:
        return f.read()


LOCAL_PLACEHOLDER = "{{LOCAL_ADDITIONS}}\n"


def local_additions(name):
    """Host-specific text for one template from <memdb-home>/local/<name>; '' when absent."""
    try:
        with open(os.path.join(paths.local_dir(), name), encoding="utf-8") as f:
            text = f.read().replace("\r\n", "\n").strip("\n")
    except OSError:
        return ""
    return "\n" + text + "\n" if text else ""


def render(name, mapping):
    text = template_text(name)
    if LOCAL_PLACEHOLDER in text:
        text = text.replace(LOCAL_PLACEHOLDER, local_additions(name))
    for key, value in mapping.items():
        text = text.replace("{{" + key + "}}", value)
    return text


def read_text(path):
    """File content, or None when it does not exist.

    Note:
        A present-but-unreadable file stops the install; returning None
        would make write_text treat it as absent and overwrite it.
    """
    try:
        with open(path, encoding="utf-8", newline="") as f:
            return f.read()
    except FileNotFoundError:
        return None
    except UnicodeDecodeError as e:
        raise SystemExit(
            "memdb: {} is not valid UTF-8 ({}); refusing to rewrite a file "
            "memdb cannot read exactly".format(path, e))
    except OSError as e:
        raise SystemExit("memdb: cannot read {}: {}".format(path, e))


def dominant_newline(text):
    """The line ending a document already uses, so an insert matches it."""
    return "\r\n" if text and text.count("\r\n") > text.count("\n") / 2 else "\n"


def diff(path, old, new):
    """Unified diff between the file's current and intended content."""
    if old == new:
        return ""
    return "".join(difflib.unified_diff(
        (old or "").splitlines(True), (new or "").splitlines(True),
        fromfile=path + " (current)", tofile=path + " (memdb)", n=2))


def backup(path):
    """Copy a user file into install-backups before memdb rewrites it."""
    if not os.path.exists(path):
        return None
    stamp = datetime.date.today().isoformat()
    name = "{}-{}.bak".format(stamp, os.path.basename(path).lstrip("."))
    target = os.path.join(paths.install_backups_dir(), name)
    os.makedirs(os.path.dirname(target), exist_ok=True)
    n = 1
    while os.path.exists(target):
        target = target[:-4] + ".{}.bak".format(n)
        n += 1
    with open(path, "rb") as src, open(target, "wb") as dst:
        dst.write(src.read())
    return target


def write_text(path, text, check=False):
    """Write text, backing the old file up. Returns a change record."""
    old = read_text(path)
    if old == text:
        return {"path": path, "kind": "file", "changed": False}
    record = {"path": path, "kind": "file", "changed": True,
              "diff": diff(path, old, text), "created": old is None}
    if check:
        record["applied"] = False
        return record
    record["backup"] = backup(path)
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    tmp = path + ".memdb.tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    os.replace(tmp, path)
    record["applied"] = True
    return record


def find_rule_block(text):
    """(start, end) of an existing memdb rule block, or None."""
    if text is None:
        return None
    start = text.find(RULE_START)
    if start >= 0:
        end = text.find(RULE_END, start)
        if end >= 0:
            return start, end + len(RULE_END)
    start = text.find(LEGACY_RULE_HEADING)
    if start < 0:
        return None
    # A pre-package block with no markers: it runs to the next top-level
    # heading, which is where the surrounding document resumes.
    nxt = text.find("\n# ", start + len(LEGACY_RULE_HEADING))
    return start, (len(text) if nxt < 0 else nxt + 1)


def splice_rule_block(text, block):
    """The document with memdb's rule block replaced, or appended if absent."""
    eol = dominant_newline(text)
    block = block.replace("\r\n", "\n").rstrip("\n").replace("\n", eol)
    if text is None or not text.strip():
        return (block + eol) if block else ""
    span = find_rule_block(text)
    if span:
        head, tail = text[:span[0]], text[span[1]:]
        tail = tail.lstrip("\r\n")
        if not block:
            return head.rstrip("\r\n") + (eol + eol + tail if tail else eol)
        return head + block + eol + eol + tail if tail else head + block + eol
    body = text.rstrip("\r\n")
    return body + eol + eol + block + eol


def tildify(path):
    """A path under the home directory written with ~, else unchanged."""
    home = os.path.expanduser("~")
    norm, base = os.path.normcase(path), os.path.normcase(home)
    if norm.startswith(base + os.sep):
        return "~/" + path[len(home) + 1:].replace("\\", "/")
    return path


def template_mapping(cfg):
    return {"MEM": config.base_text(cfg),
            "HOST_SLUG": cfg.get("host_id") or "<host>",
            "SKILL_PATH": tildify(paths.claude_skill_file())}


def get(name):
    from . import claude_code, codex, generic
    adapters = {"claude-code": claude_code, "codex": codex,
                "generic": generic}
    if name not in adapters:
        raise SystemExit("memdb: unknown harness {!r} (known: {})".format(
            name, ", ".join(sorted(adapters))))
    return adapters[name]


def names():
    return ("claude-code", "codex", "generic")

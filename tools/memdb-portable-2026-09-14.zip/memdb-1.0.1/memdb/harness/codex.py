"""Codex adapter: skill file, a rules file, and the AGENTS.md include line.

Codex has no SessionStart hook, so its rule block carries the digest call
explicitly instead of relying on injection.
"""
import os
import sys

try:
    from .. import paths
    from . import (read_text, render, splice_rule_block, template_mapping,
                   tildify, write_text)
except ImportError:                     # loose script: python memdb/mem.py
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import paths  # noqa: E402
    from harness import (read_text, render, splice_rule_block,  # noqa: E402
                         template_mapping, tildify, write_text)

NAME = "codex"
INCLUDE_LINE = "See ~/.codex/rules/end_of_job_handoff.md (memdb memory rule)."


def home():
    return os.path.join(os.path.expanduser("~"), ".codex")


def paths_for():
    return {"skill": os.path.join(home(), "skills", "memdb", "SKILL.md"),
            "rule": os.path.join(home(), "rules", "end_of_job_handoff.md"),
            "agents": os.path.join(home(), "AGENTS.md")}


def available():
    return os.path.isdir(home())


def rule_text(cfg):
    """The rule block with the hook sentence replaced by an explicit digest."""
    mapping = template_mapping(cfg)
    mapping["SKILL_PATH"] = tildify(paths_for()["skill"])
    text = render("rule.md", mapping)
    return text.replace(
        "the SessionStart hook injects the core-setup digest; if it is "
        "absent or reports a failure, run",
        "Codex has no SessionStart hook, so run")


def apply(cfg, check=False):
    where = paths_for()
    mapping = template_mapping(cfg)
    mapping["SKILL_PATH"] = tildify(where["skill"])
    out = [write_text(where["skill"], render("skill.md", mapping), check),
           write_text(where["rule"], rule_text(cfg), check)]
    agents = read_text(where["agents"])
    if agents is None or INCLUDE_LINE not in agents:
        sep = "" if not agents else ("\n" if agents.endswith("\n") else "\n\n")
        out.append(write_text(where["agents"],
                              (agents or "") + sep + INCLUDE_LINE + "\n",
                              check))
    return out


def register_hooks(cfg, check=False, events=None):
    return []       # Codex has no hook mechanism to register into


def unregister(cfg, check=False):
    where = paths_for()
    out = []
    text = read_text(where["rule"])
    if text is not None:
        out.append(write_text(where["rule"], splice_rule_block(text, ""),
                              check))
    agents = read_text(where["agents"])
    if agents and INCLUDE_LINE in agents:
        out.append(write_text(where["agents"],
                              agents.replace(INCLUDE_LINE + "\n", "")
                              .replace(INCLUDE_LINE, ""), check))
    return out


def check(cfg):
    return [r for r in apply(cfg, check=True) if r.get("changed")]

"""Generic adapter: prints what to add by hand, writes nothing.

For a harness memdb does not know: it renders the skill and rule block to
stdout, so a human or an agent can paste them wherever that harness keeps
them. There is no MCP server in this release (plan step S-MQ-11), so no
MCP registration is printed: a snippet naming a missing subcommand would
fail the moment it was pasted.
"""
import os
import sys

try:
    from . import render, template_mapping
except ImportError:                     # loose script: python memdb/mem.py
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from harness import render, template_mapping  # noqa: E402

NAME = "generic"


def paths_for():
    return {}


def available():
    return True


def apply(cfg, check=False):
    mapping = template_mapping(cfg)
    print("# memdb: add these by hand for this harness")
    print("\n## skill (save as SKILL.md where your harness keeps skills)\n")
    print(render("skill.md", mapping))
    print("\n## rule block (add to the global agent instructions)\n")
    print(render("rule.md", mapping))
    return [{"path": "(stdout)", "kind": "file", "changed": False,
             "applied": not check}]


def register_hooks(cfg, check=False, events=None):
    return []


def unregister(cfg, check=False):
    return []


def check(cfg):
    return []

"""Claude Code adapter: skill file, CLAUDE.md rule block, settings.json hooks.

settings.json is re-serialised with json.dump(indent=2), so byte identity
with the user's formatting is not promised; --check prints the unified
diff, which makes a formatting-only change visible before it is applied.
"""
import json
import os
import shutil
import sys

try:
    from .. import config, paths
    from . import (RULE_END, read_text, render, splice_rule_block,
                   template_mapping, write_text)
except ImportError:                     # loose script: python memdb/mem.py
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import config  # noqa: E402
    import paths  # noqa: E402
    from harness import (RULE_END, read_text, render,  # noqa: E402
                         splice_rule_block, template_mapping, write_text)

NAME = "claude-code"
MATCHER = "startup|clear|compact"
HOOK_EVENTS = {"SessionStart": ("session-start", MATCHER, 20)}
# ~/.claude entries memdb itself creates on a host without Claude Code.
MEMDB_OWNED = ("memory", "rules")


def paths_for():
    return {"skill": paths.claude_skill_file(),
            "rule": os.path.join(paths.claude_dir(), "CLAUDE.md"),
            "settings": paths.claude_settings_file()}


def cli_on_path():
    return shutil.which("claude")


def available():
    """The claude CLI is on PATH, or ~/.claude holds more than the memory and rules memdb writes."""
    if cli_on_path():
        return True
    try:
        entries = os.listdir(paths.claude_dir())
    except OSError:
        return False
    return any(e not in MEMDB_OWNED for e in entries)


# --------------------------------------------------------------- render

def render_files(cfg, check=False):
    """Write the skill and splice the rule block into CLAUDE.md."""
    mapping = template_mapping(cfg)
    where = paths_for()
    out = [write_text(where["skill"], render("skill.md", mapping), check)]
    block = render("rule.md", mapping)
    current = read_text(where["rule"])
    out.append(write_text(where["rule"], splice_rule_block(current, block),
                          check))
    return out


# ---------------------------------------------------------------- hooks

def load_settings(path):
    text = read_text(path)
    if not text or not text.strip():
        return {}
    try:
        data = json.loads(text)
    except ValueError:
        raise SystemExit(
            "memdb: {} is not valid JSON; fix or move it aside before "
            "installing".format(path))
    return data if isinstance(data, dict) else {}


def hook_entry(name, timeout, cfg):
    return {"type": "command",
            "command": config.hook_command_text(name, cfg=cfg),
            "timeout": timeout}


def strip_memdb_hooks(hooks):
    """Remove every memdb entry from a hooks map; returns the cleaned map."""
    out = {}
    for event, groups in (hooks or {}).items():
        kept_groups = []
        for group in groups or []:
            entries = [h for h in (group.get("hooks") or [])
                       if not config.is_memdb_command(h.get("command"))]
            if entries:
                kept = dict(group)
                kept["hooks"] = entries
                kept_groups.append(kept)
            elif not (group.get("hooks") or []):
                kept_groups.append(group)
        if kept_groups:
            out[event] = kept_groups
    return out


def reorder_like(new, original):
    """new, with the keys of `original` first and in their original order."""
    out = {k: new[k] for k in original if k in new}
    out.update({k: v for k, v in new.items() if k not in out})
    return out


def settings_with_hooks(current, cfg, events=None):
    """The settings document memdb intends: its hooks merged, nothing else touched."""
    data = json.loads(json.dumps(current))       # deep copy, order preserved
    data["autoMemoryEnabled"] = False
    before = data.get("hooks") or {}
    hooks = strip_memdb_hooks(before)
    for event, (name, matcher, timeout) in sorted(
            (events or HOOK_EVENTS).items()):
        groups = hooks.setdefault(event, [])
        entry = hook_entry(name, timeout, cfg)
        for group in groups:
            if group.get("matcher") == matcher:
                group.setdefault("hooks", []).append(entry)
                break
        else:
            groups.append({"matcher": matcher, "hooks": [entry]})
    data["hooks"] = reorder_like(hooks, before)
    return reorder_like(data, current)


def settings_text(data):
    return json.dumps(data, indent=2, ensure_ascii=False) + "\n"


def register_hooks(cfg, check=False, events=None):
    path = paths_for()["settings"]
    current = load_settings(path)
    return [write_text(path, settings_text(
        settings_with_hooks(current, cfg, events)), check)]


def unregister(cfg, check=False):
    """Remove memdb's hooks and rule block; leaves the skill file in place."""
    where = paths_for()
    out = []
    current = load_settings(where["settings"])
    if current:
        data = json.loads(json.dumps(current))
        data["hooks"] = strip_memdb_hooks(data.get("hooks") or {})
        if not data["hooks"]:
            data.pop("hooks")
        out.append(write_text(where["settings"], settings_text(data), check))
    text = read_text(where["rule"])
    if text:
        block_free = splice_rule_block(text, "")
        block_free = block_free.replace(RULE_END + "\n", "").replace(
            RULE_END, "")
        out.append(write_text(where["rule"], block_free, check))
    return out


# ---------------------------------------------------------------- check

def apply(cfg, check=False):
    """Files only; the caller runs register_hooks so both stay one write each."""
    return render_files(cfg, check)


def check(cfg):
    """What `mem install` would change here, without writing anything."""
    records = apply(cfg, check=True) + register_hooks(cfg, check=True)
    return [r for r in records if r.get("changed")]

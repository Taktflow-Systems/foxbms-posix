"""`mem install`: the whole of the old ten-step manual install, idempotently.

Order matters and is the point: prove the tool works, then write identity,
then the journal repo and hub, then the projection, then replication, and
only last the harness wiring - so a failure never leaves a harness
pointing at a memory layer that does not work.

Nothing is written without --yes: a run with neither flag is a check.
Every side effect (files, git configuration, the OS schedule, runs such as
the first sync and the install episode) is a change record, so --check
shows all of it. Every user-owned file is backed up under
<memdb-home>/install-backups/ before it is rewritten.
"""
import io
import json
import os
import platform
import shlex
import shutil
import subprocess
import sys
import tempfile

try:
    from . import __version__, config, harness, journal, mem, paths, schedule
except ImportError:                     # loose script: python memdb/mem.py
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import config  # noqa: E402
    import harness  # noqa: E402
    import journal  # noqa: E402
    import mem  # noqa: E402
    import paths  # noqa: E402
    import schedule  # noqa: E402
    __version__ = mem.__version__

MIN_PYTHON = (3, 9)
DEFAULT_TIME = "12:00"


def run(argv, cwd=None, timeout=300, check=False, env=None):
    """Run a program, returning the completed process; never raises on exit code."""
    try:
        p = subprocess.run(argv, cwd=cwd, capture_output=True, text=True,
                           timeout=timeout, env=env, errors="replace")
    except (OSError, subprocess.SubprocessError) as e:
        raise SystemExit("install: cannot run {}: {}".format(argv[0], e))
    if check and p.returncode != 0:
        raise SystemExit("install: {} failed: {}".format(
            " ".join(argv), (p.stderr or p.stdout).strip()))
    return p


def git(*args, **kwargs):
    return run(["git", *args], **kwargs)


def batch_git_env():
    """git never prompts during install: no terminal prompt, ssh in batch mode."""
    env = dict(os.environ)
    env["GIT_TERMINAL_PROMPT"] = "0"
    env.setdefault("GIT_SSH_COMMAND",
                   "ssh -o BatchMode=yes -o ConnectTimeout=15")
    return env


# ------------------------------------------------------------ preflight

def preflight(hub_mode, hub_url, pyz_source=None, cfg=None):
    """Every precondition, checked before a single file is written."""
    checks = []

    def add(name, ok, detail):
        checks.append({"check": name, "ok": bool(ok), "detail": detail})
        return ok

    add("python", sys.version_info >= MIN_PYTHON, platform.python_version())
    try:
        import sqlite3
        conn = sqlite3.connect(":memory:")
        conn.execute("CREATE VIRTUAL TABLE t USING fts5(x)")
        conn.close()
        add("sqlite_fts5", True, sqlite3.sqlite_version)
    except Exception as e:
        add("sqlite_fts5", False, str(e))
    git_path = shutil.which("git")
    add("git", git_path is not None, git_path or "not on PATH")
    add("interpreter", os.path.isabs(sys.executable), sys.executable)
    if pyz_source:
        version = pyz_version(pyz_source)
        add("pyz", version is not None,
            "{} ({})".format(pyz_source, version or "does not run"))
    if cfg and cfg.get("command_form") != config.FORM_PYZ:
        add("command-form", *command_form_runs(cfg))
    if git_path and hub_mode == "join":
        url = config.hub_journal_url(hub_url)
        p = run(["git", "ls-remote", url], timeout=90, env=batch_git_env())
        add("hub:" + url, p.returncode == 0,
            "reachable" if p.returncode == 0
            else (p.stderr or p.stdout).strip() or "exit {}".format(p.returncode))
    elif hub_mode == "new" and config.is_local_hub(hub_url):
        target = local_path(hub_url)
        ok = not os.path.exists(target) or os.path.isfile(
            os.path.join(target, "HEAD"))
        add("hub:" + target, ok, "creatable" if ok else
            "exists and is not a bare git repository")
    elif hub_mode == "new":
        host = config.ssh_host(hub_url)
        p = run(["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=15",
                 host, "true"], timeout=60)
        add("ssh:" + host, p.returncode == 0,
            "reachable" if p.returncode == 0
            else (p.stderr or p.stdout).strip() or "exit {}".format(p.returncode))
    root = journal.journal_root()
    if git_path and hub_mode in ("join", "new"):
        # every sync commits the journal; without an identity each one fails
        where = root if os.path.isdir(os.path.join(root, ".git")) else tempfile.gettempdir()
        p = run(["git", "var", "GIT_COMMITTER_IDENT"], cwd=where, timeout=60)
        add("git-identity", p.returncode == 0,
            "set" if p.returncode == 0 else
            "git has no user.name/user.email for the journal repo: {}".format(
                ([ln.strip() for ln in (p.stderr or "").splitlines() if ln.strip()] or [""])[-1]))
    if hub_mode == "standalone" and os.path.isdir(os.path.join(root, ".git")):
        current = current_origin(root)
        add("standalone-without-origin", current is None,
            "no origin" if current is None else
            "the journal repo already has origin {}; use --hub \"join {}\"".format(
                current, current))
    failed = [c for c in checks if not c["ok"]]
    if failed:
        raise SystemExit("install: preflight failed: " + json.dumps(failed))
    return checks


def command_form_runs(cfg):
    """(ok, detail): the recorded command runs this version with no checkout help.

    Note:
        Hooks and schedules start in a foreign directory without the
        installing shell's PYTHONPATH, so the probe does too.
    """
    env = dict(os.environ)
    env.pop("PYTHONPATH", None)
    argv = config.command("--version", cfg=cfg)
    p = run(argv, cwd=tempfile.gettempdir(), timeout=120, env=env)
    out = p.stdout.strip()
    want = "memdb " + __version__
    if p.returncode == 0 and out == want:
        return True, "{} -> {}".format(" ".join(argv), out)
    return False, (
        "{} gave {!r} (exit {}), expected {!r}: the hook and the schedule "
        "could not run memdb; install the wheel for this interpreter or "
        "install with --pyz".format(" ".join(argv), out or (p.stderr or "")
                                    .strip()[-300:], p.returncode, want))


def pyz_version(path):
    """The version a .pyz reports, or None when it does not run."""
    if not os.path.isfile(path):
        return None
    p = run([sys.executable, path, "--version"], timeout=120)
    out = p.stdout.strip()
    return out.split(" ", 1)[1] if p.returncode == 0 and out.startswith(
        "memdb ") else None


def selftest_result():
    """mem selftest when this build has it; a note when it does not."""
    if not hasattr(mem, "cmd_selftest"):
        return {"ran": False, "detail": "no selftest in this build"}
    p = run([sys.executable] + self_argv("selftest"), timeout=300)
    return {"ran": True, "ok": p.returncode == 0,
            "detail": (p.stdout or p.stderr).strip()[:2000]}


def self_argv(*args):
    """argv (after the interpreter) that runs THIS memdb, pyz or package."""
    pyz = config.running_pyz()
    return ([pyz] if pyz else ["-m", "memdb"]) + list(args)


# ----------------------------------------------------------- hub helpers

def local_path(url):
    if url.startswith("file://"):
        url = url[len("file://"):]
    return os.path.abspath(url)


def normalise_hub_url(url):
    """Local hub paths become absolute with forward slashes; anything else is kept."""
    if config.is_local_hub(url) and not url.startswith("file://"):
        return os.path.abspath(url).replace("\\", "/")
    return url


def current_origin(root):
    p = git("remote", "get-url", "origin", cwd=root)
    return p.stdout.strip() if p.returncode == 0 and p.stdout.strip() else None


# ------------------------------------------------------- identity, repo

def write_host_id(slug, check=False):
    path = paths.host_id_file()
    current = None
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            current = f.read().strip()
    if current and current != slug:
        raise SystemExit(
            "install: host-id file says {!r} but --host says {!r}; a host "
            "never changes its slug (it owns a journal branch). Fix the "
            "argument, or move {} aside deliberately.".format(
                current, slug, path))
    record = {"path": path, "kind": "file", "changed": current != slug}
    if not record["changed"]:
        return record
    record["applied"] = not check
    if not check:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="\n") as f:
            f.write(slug + "\n")
    return record


def write_config(cfg, check=False):
    path = paths.config_path()
    old = harness.read_text(path)
    new = config.text_of(cfg)
    record = {"path": path, "kind": "file", "changed": old != new}
    if record["changed"]:
        record.update(diff=harness.diff(path, old, new), applied=not check)
        if not check:
            config.save(cfg)
    return record


def ensure_journal_repo(slug, hub_mode, hub_url, check=False):
    """git init the journal root on this host's branch and point origin at the hub."""
    root = journal.journal_root()
    exists = os.path.isdir(os.path.join(root, ".git"))
    records = [{"path": "journal-repo", "kind": "git", "root": root,
                "branch": slug + "/journal", "changed": not exists}]
    if not exists and not check:
        os.makedirs(root, exist_ok=True)
        git("init", "-q", "-b", slug + "/journal", root, check=True)
    records[0]["applied"] = not check if not exists else None
    current_id = None
    if exists:
        p = git("config", "--local", "--get", "agent.host-id", cwd=root)
        current_id = p.stdout.strip() or None
    records.append({"path": "agent.host-id", "kind": "git", "from": current_id,
                    "to": slug, "changed": current_id != slug})
    if current_id != slug and not check:
        git("config", "--local", "agent.host-id", slug, cwd=root, check=True)
    if hub_mode == "new":
        records.append(create_hub(hub_url, check))
    if hub_mode in ("join", "new"):
        url = config.hub_journal_url(hub_url)
        current = current_origin(root) if exists else None
        changed = current is None or not config.same_remote(current, url)
        records.append({"path": "origin", "kind": "git", "from": current,
                        "to": url, "changed": changed})
        if changed and not check:
            verb = "add" if current is None else "set-url"
            git("remote", verb, "origin", url, cwd=root, check=True)
    return records


def create_hub(hub_url, check):
    """Bare hub repositories for `--hub new`: a local path or over ssh."""
    if config.is_local_hub(hub_url):
        target = local_path(hub_url)
        exists = os.path.isfile(os.path.join(target, "HEAD"))
        record = {"path": "hub", "kind": "git", "target": target,
                  "changed": not exists}
        if not exists and not check:
            git("init", "--bare", "-q", "-b", "main", target, check=True)
        return record
    host, repo = config.ssh_host(hub_url), shlex.quote(
        config.ssh_repo_path(hub_url))
    probe = run(["ssh", "-o", "BatchMode=yes", host,
                 "test -f {}/HEAD".format(repo)], timeout=120)
    # The same path origin will point at, so the created repo is the one synced.
    remote_cmd = 'mkdir -p "$(dirname {0})" && git init --bare -q -b main {0}'.format(
        repo)
    record = {"path": "hub", "kind": "git", "target": host,
              "changed": probe.returncode != 0, "command": remote_cmd}
    if record["changed"] and not check:
        run(["ssh", "-o", "BatchMode=yes", host, remote_cmd], timeout=300,
            check=True)
    return record


def ensure_db(check):
    path = mem.db_path()
    record = {"path": path, "kind": "file", "changed": not os.path.exists(path),
              "action": "init schema"}
    version = db_schema_version(path)
    if version and version != mem.SCHEMA_VERSION:
        # The DB is a projection: an upgrade replays the journals, never migrates.
        record.update(changed=True, action="rebuild --full (schema {} -> {})".format(
            version, mem.SCHEMA_VERSION))
        if not check:
            buf, keep = io.StringIO(), sys.stdout
            sys.stdout = buf
            try:
                mem.main(["rebuild", "--full"])
            finally:
                sys.stdout = keep
            record["rebuild"] = buf.getvalue().strip()[-500:]
        return record
    if not check:
        conn = mem.connect()
        try:
            mem.init_schema(conn)
        finally:
            conn.close()
    return record


def db_schema_version(path):
    """PRAGMA user_version of an existing DB, or None."""
    if not os.path.exists(path):
        return None
    import sqlite3
    try:
        conn = sqlite3.connect("file:{}?mode=ro".format(path.replace("\\", "/")),
                               uri=True)
        try:
            return conn.execute("PRAGMA user_version").fetchone()[0]
        finally:
            conn.close()
    except sqlite3.Error:
        return None


def copy_pyz(source, check):
    """Copy the .pyz to <memdb-home>/bin/memdb.pyz plus a versioned copy (D-7)."""
    version = pyz_version(source) or __version__
    stable = os.path.join(paths.bin_dir(), "memdb.pyz")
    records = []
    for target in (stable, os.path.join(paths.bin_dir(),
                                        "memdb-{}.pyz".format(version))):
        same = os.path.exists(target) and _same_bytes(source, target)
        record = {"path": target, "kind": "file", "changed": not same,
                  "source": source}
        if not same and not check:
            os.makedirs(paths.bin_dir(), exist_ok=True)
            tmp = target + ".tmp"
            shutil.copyfile(source, tmp)
            os.replace(tmp, target)
        records.append(record)
    return records


def _same_bytes(a, b):
    if os.path.abspath(a) == os.path.abspath(b):
        return True
    with open(a, "rb") as fa, open(b, "rb") as fb:
        return fa.read() == fb.read()


def run_sync(cfg):
    """First replication through the installed command form."""
    p = run(config.command("sync", cfg=cfg), timeout=1800)
    return {"ran": True, "ok": p.returncode == 0,
            "detail": (p.stdout or p.stderr).strip()[-4000:]}


def run_json(cfg, *argv):
    """(ok, parsed JSON or text) of one mem command in the installed form."""
    p = run(config.command(*argv, cfg=cfg), timeout=600)
    text = p.stdout.strip()
    try:
        parsed = json.loads(text.splitlines()[-1]) if text else {}
    except ValueError:
        parsed = {"output": text[-2000:]}
    if p.returncode != 0 and p.stderr.strip():
        parsed = dict(parsed, stderr=p.stderr.strip()[-2000:])
    return p.returncode == 0, parsed


# ------------------------------------------------------------- episode

def record_install_episode(cfg, report):
    """Journal what this install did, so the fleet can see it in search."""
    touched = sorted({harness.tildify(c["path"]) for c in report["changes"]
                      if c.get("kind") == "file" and c.get("changed")
                      and os.path.isabs(c["path"])})
    doc = {
        "achievement": ["memdb {} installed on host {}".format(
            __version__, cfg["host_id"])],
        "current_state": {
            "summary": "memdb {} installed: command form {}, hub {}, "
                       "harnesses {}, schedule {}".format(
                           __version__, cfg["command_form"],
                           cfg["hub"]["mode"],
                           ",".join(cfg["harnesses"]) or "none",
                           cfg["schedule"]["kind"]),
            "status": [{"subject": "memdb-install-" + cfg["host_id"],
                        "state": "memdb {} on {}, command form {}".format(
                            __version__, cfg["host_id"], cfg["command_form"])}],
            "files_touched": touched,
        },
        "blockers": [],
        "resolves": [],
        "next_steps": [],
    }
    fd, path = tempfile.mkstemp(suffix=".json", prefix="memdb-install-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            json.dump(doc, f)
        argv = ["record-episode", "--project", "memdb", "--part", "install",
                "--task", "install-" + cfg["host_id"], "--json", path,
                "--session-id", "install-" + cfg["host_id"]]
        p = run(config.command(*argv, cfg=cfg), timeout=300)
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    if p.returncode != 0:
        return {"recorded": False, "ok": False,
                "detail": (p.stderr or p.stdout).strip()[:2000]}
    try:
        return {"recorded": True, "ok": True,
                "uid": json.loads(p.stdout.strip())["uid"]}
    except (ValueError, KeyError):
        return {"recorded": True, "ok": True, "detail": p.stdout.strip()[:500]}


# --------------------------------------------------------------- install

def build_config(args, existing):
    cfg = dict(existing)
    cfg["host_id"] = args.host or cfg.get("host_id") or ""
    if not cfg["host_id"]:
        raise SystemExit("install: --host <slug> is required (the human "
                         "chooses it; never invent one)")
    mode, url = parse_hub(args.hub) if args.hub else (
        cfg["hub"]["mode"], cfg["hub"]["url"])
    cfg["hub"] = {"mode": mode, "url": url}
    form, detail = config.detect_command_form(args.pyz)
    cfg["command_form"] = form
    cfg["interpreter"] = sys.executable
    cfg["safe_path"] = form == config.FORM_INTERPRETER and sys.version_info >= (3, 11)
    cfg["pyz_path"] = (os.path.join(paths.bin_dir(), "memdb.pyz")
                       if form == config.FORM_PYZ else "")
    cfg["mem_path"] = detail if form == config.FORM_MEM else ""
    cfg["harnesses"], source = resolve_harnesses(args.harness)
    cfg["version"] = __version__
    cfg["embed"] = dict(cfg.get("embed") or {})
    if args.embed == "off":
        cfg["embed"]["enabled"] = False
    cfg["core_rules"] = (os.path.join(paths.claude_rules_dir(),
                                      paths.CORE_RULES_NAME)
                         if "claude-code" in cfg["harnesses"] else
                         os.path.join(paths.home(), "rules",
                                      paths.CORE_RULES_NAME))
    cfg["schedule"], note = schedule_for(args.schedule, mode,
                                         existing.get("schedule") or {})
    return cfg, {"command_form": detail, "harness_source": source,
                 "schedule_note": note,
                 "pyz_source": (args.pyz or config.running_pyz())
                 if form == config.FORM_PYZ else None}


def schedule_for(arg, hub_mode, previous):
    """(schedule config, note): no OS schedule unless the host really wants one."""
    name = schedule.name_for_home()
    time = previous.get("time") or DEFAULT_TIME
    if arg == "none":
        return {"kind": "none", "name": name, "time": time}, "--schedule none"
    if arg:
        schedule.parse_time(arg)
        return ({"kind": schedule.kind_for_platform(), "name": name,
                 "time": arg}, "explicit --schedule")
    if hub_mode == "standalone":
        return ({"kind": "none", "name": name, "time": time},
                "standalone: nothing to replicate")
    if not schedule.is_default_home():
        return ({"kind": "none", "name": name, "time": time},
                "MEMDB_HOME is set: an OS schedule needs an explicit "
                "--schedule HH:MM")
    return ({"kind": schedule.kind_for_platform(), "name": name,
             "time": time}, "default for a hub member")


def parse_hub(text):
    """('join'|'new'|'standalone', url) from the --hub argument."""
    parts = (text or "").split(None, 1)
    mode = parts[0] if parts else "standalone"
    if mode not in config.HUB_MODES:
        raise SystemExit("install: --hub must be 'join <url>', 'new <url>' "
                         "or 'standalone', got {!r}".format(text))
    url = parts[1].strip() if len(parts) > 1 else ""
    if mode in ("join", "new") and not url:
        raise SystemExit("install: --hub {} needs a hub URL: an ssh target "
                         "or a local path".format(mode))
    return mode, normalise_hub_url(url) if url else url


def resolve_harnesses(arg):
    """(names, source): the harnesses to wire and how they were chosen."""
    if arg:
        names = [n.strip() for n in arg.split(",") if n.strip()]
        for name in names:
            harness.get(name)
        return names, "--harness argument"
    found = [n for n in ("claude-code", "codex")
             if harness.get(n).available()]
    if not found:
        return ["generic"], "auto-detected: no known harness directory"
    return found, "auto-detected: " + ", ".join(
        "{} ({})".format(n, harness.tildify(_harness_dir(n))) for n in found)


def _harness_dir(name):
    return paths.claude_dir() if name == "claude-code" else \
        harness.get("codex").home()


def cmd_install(args):
    check = bool(args.check) or not args.yes
    existing = config.load()
    cfg, detail = build_config(args, existing)
    report = {"version": __version__, "host": cfg["host_id"],
              "command_form": cfg["command_form"],
              "command_form_detail": detail["command_form"],
              "hub": cfg["hub"], "harnesses": cfg["harnesses"],
              "harness_source": detail["harness_source"],
              "memdb_home": paths.home(), "check": check, "changes": []}
    if check and not args.check:
        report["note"] = "no --yes given: check mode, nothing was written"

    report["preflight"] = preflight(cfg["hub"]["mode"], cfg["hub"]["url"],
                                    detail["pyz_source"], cfg)
    report["selftest"] = selftest_result()
    if report["selftest"].get("ran") and not report["selftest"].get("ok"):
        raise SystemExit("install: selftest failed, nothing was wired: "
                         + json.dumps(report["selftest"]))

    changes = report["changes"]
    changes.append(write_host_id(cfg["host_id"], check))
    if detail["pyz_source"]:
        changes.extend(copy_pyz(detail["pyz_source"], check))
    changes.append(write_config(cfg, check))
    changes.extend(ensure_journal_repo(cfg["host_id"], cfg["hub"]["mode"],
                                       cfg["hub"]["url"], check))
    changes.append(ensure_db(check))
    replicate = cfg["hub"]["mode"] != "standalone"
    changes.append({"path": "sync", "kind": "run", "changed": False,
                    "would_run": replicate})
    if replicate and not check:
        report["sync"] = run_sync(cfg)

    for name in cfg["harnesses"]:
        adapter = harness.get(name)
        changes.extend(adapter.apply(cfg, check))
        changes.extend(adapter.register_hooks(cfg, check))

    sched = schedule.plan_change(cfg, existing)
    changes.append(sched)
    if sched["changed"] and not check:
        if sched["action"] == "install":
            schedule.install(cfg, cfg["schedule"]["time"],
                             cfg["schedule"]["kind"], cfg["schedule"]["name"])
        else:
            old = existing.get("schedule") or {}
            schedule.remove(old.get("kind"),
                            old.get("name") or schedule.name_for_home())
    sched["applied"] = (not check) if sched["changed"] else None
    report["schedule"] = dict(cfg["schedule"], note=detail["schedule_note"])

    changed = [c for c in changes if c.get("changed")]
    something = bool(changed)
    for name in ("install-episode", "verify", "doctor"):
        changes.append({"path": name, "kind": "run", "changed": False,
                        "would_run": something if name == "install-episode"
                        else True})
    report["changed_files"] = [c["path"] for c in changed]
    if check:
        report["applied"] = False
        print_report(report, changed)
        return

    report["episode"] = (record_install_episode(cfg, report) if something
                         else {"recorded": False, "detail": "nothing changed"})
    ok_v, report["verify"] = run_json(cfg, "verify")
    ok_d, doctor = run_json(cfg, "doctor")
    report["doctor"] = {"ok": ok_d and bool(doctor.get("ok")),
                        "warnings": doctor.get("warnings", []),
                        "failed": sorted(k for k, v in (doctor.get("checks")
                                                        or {}).items()
                                         if not v.get("ok"))}
    report["verify"]["ok"] = ok_v and bool(report["verify"].get("ok"))
    report["applied"] = True
    print_report(report, changed)
    sync_ok = report.get("sync", {}).get("ok", True)
    if not (report["verify"]["ok"] and report["doctor"]["ok"] and sync_ok):
        raise SystemExit(1)


def write_err(text):
    """UTF-8 to stderr whatever the console code page, so the diff shows the real bytes."""
    buf = getattr(sys.stderr, "buffer", None)
    if buf is None:
        sys.stderr.write(text)
        return
    sys.stderr.flush()
    buf.write(text.encode("utf-8"))
    buf.flush()


def print_report(report, changed):
    for change in changed:
        if change.get("diff"):
            write_err(change["diff"] + "\n")
    printable = dict(report)
    printable["changes"] = [{k: v for k, v in c.items() if k != "diff"}
                            for c in report["changes"]]
    print(json.dumps(printable, indent=2, sort_keys=True))


# ------------------------------------------------------------- uninstall

def cmd_uninstall(args):
    """Reverse the harness wiring and the schedule; never touch the journal."""
    check = bool(args.check) or not args.yes
    cfg = config.load()
    report = {"host": cfg.get("host_id"), "changes": [], "check": check}
    if check and not args.check:
        report["note"] = "no --yes given: check mode, nothing was written"
    for name in cfg.get("harnesses") or harness.names():
        adapter = harness.get(name)
        report["changes"].extend(adapter.unregister(cfg, check))
    sched = cfg.get("schedule") or {}
    if sched.get("kind", "none") != "none":
        name = sched.get("name") or schedule.name_for_home()
        record = {"path": "schedule:{}:{}".format(sched["kind"], name),
                  "kind": "schedule", "changed": True, "action": "remove",
                  "applied": not check}
        report["changes"].append(record)
        if not check:
            record["result"] = schedule.remove(sched["kind"], name)
            cfg["schedule"] = dict(sched, kind="none")
            config.save(cfg)
    if args.purge_data:
        if not args.yes:
            raise SystemExit("uninstall: --purge-data deletes the journal and "
                             "the DB; it needs --yes as well")
        report["purged"] = purge_data(check)
    else:
        report["data"] = "kept: {} (journal and DB untouched)".format(
            paths.home())
    changed = [c for c in report["changes"] if c.get("changed")]
    report["changed_files"] = [c["path"] for c in changed]
    print_report(report, changed)


def purge_data(check):
    targets = [mem.db_path(), journal.journal_root()]
    if check:
        return {"would_remove": targets}
    removed = []
    for path in targets:
        if os.path.isdir(path):
            shutil.rmtree(path)
            removed.append(path)
        elif os.path.exists(path):
            os.remove(path)
            removed.append(path)
    return {"removed": removed}

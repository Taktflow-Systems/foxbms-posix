<!-- memory-persistence-rule v3 (memdb): the procedure lives in the memdb skill -->
# Memory Persistence Rule (memdb)

memdb is the only memory store: a per-host append-only journal with a disposable SQLite projection, tool `{{MEM}}`. The harness auto-memory (`MEMORY.md`) is retired; never write it.
Two moments are mandatory in every project unless the user says otherwise:

1. Task start: the SessionStart hook injects the core-setup digest; if it is absent or reports a failure, run `{{MEM}} digest --project <slug> --part core-setup` first. Use `search` for specific priors.
2. End of every completed job, read-only analysis included: record an episode with `{{MEM}} record-episode --project <slug> --part <slug> --task <slug> --json <file>`, run `{{MEM}} sync`, and mention the episode uid in the final response.

Load the memdb skill (`{{SKILL_PATH}}`) for the procedure: episode JSON shape, validation and `resolves`, slug rules, core-setup vs handoff, uids, privacy, failure behaviour.
Record durable goals, constraints and preferences the user states mid-job at once with `--origin user`; never delete records, supersede them.
A `verify` or `doctor` failure is a loss signal: surface it to the user immediately.
{{LOCAL_ADDITIONS}}
<!-- /memory-persistence-rule -->

---
name: memdb
description: Procedure for the memdb memory layer. Use at TASK START to read memory back (digest, search) and at the END OF EVERY JOB to record an episode (JSON shape, validation, slugs, sync); also when adding, superseding or closing a durable goal, constraint, preference or runbook.
---

# memdb - memory procedure

Tool: `{{MEM}} <cmd>` (Python 3 stdlib only). Replication: `{{MEM}} sync`.
Subcommands: `init`, `add`, `get`, `search`, `list`, `stats`, `parts`,
`alias`, `supersede`, `close`, `review-blockers`,
`record-episode`, `render-handoff`, `digest`, `render-core`, `core-lint`,
`project-slug`, `export`, `consolidate`, `rebuild`, `verify`, `snapshot`,
`sync`, `doctor`, `selftest`, `redact-check`, `journal-head`, `config`,
`install`, `uninstall`, `schedule`, `hook`.

## 1. The layer

- System of record: the per-host append-only, hash-chained journal
  `<memdb-home>/journal/journal/<host>/events.jsonl`, replicated via git
  (one branch per host, hub on the user's own server). The SQLite DB
  (`<memdb-home>/mem.db`, `MEMDB_PATH` overrides) is a disposable
  projection: `rebuild` reproduces it from journals alone, `verify` proves
  chain integrity and projection match. Never edit journal files or the DB
  by hand. The data directory is `~/.claude/memory` unless `MEMDB_HOME`
  says otherwise; `{{MEM}} config show` prints this host's settings and
  says `"source": "defaults"` when this host was never installed. This
  file is rendered by `mem install`: host-specific additions belong in
  `<memdb-home>/local/skill.md`, which every render keeps.
- Host identity: `<memdb-home>/host-id` (this machine: `{{HOST_SLUG}}`);
  writes refuse to run without it.
- Address records by uid ONLY: `<host>:<seq>`, children `<host>:<seq>/<n>`.
  Local integer ids are reassigned by every cross-host rebuild or sync (a
  stale id mis-targeted supersede events on 2026-08-23), so `close` and
  `supersede` refuse a bare integer unless `--local-id` is given. `digest`
  and `search` print uids. `supersede` refuses episodes, non-open targets and
  a `--by` in another project or of another kind (`--cross`), and needs
  `--force` to re-point a superseded record; `close` of a superseded
  record needs `--force`.
- Files (handoff YAML, digest markdown, the rendered
  `~/.claude/rules/memdb-core-global.md`) are views: never hand-edited,
  never read back as a source of truth.
- memdb is the ONLY memory store. The harness auto-memory
  (`~/.claude/projects/<dir>/memory/*.md` with a `MEMORY.md` index) is
  retired (`autoMemoryEnabled: false`): never write or create it, and treat
  any file found there as stale.

## 2. Task start: readback

In Claude Code the SessionStart hook (`{{MEM}} hook session-start`)
injects the core-setup digest of the current project, and the sync renders
the global core-setup rows into `~/.claude/rules/memdb-core-global.md`.
Without that hook (Codex, or a `[memdb: ...]` failure marker) run first:
`{{MEM}} digest --project <slug> --part core-setup`.

1. Work-area context: `digest --project <slug> --part <work-part>`
   (default budget 1500 tokens, never exceeded). Order: pinned goals,
   constraints, preferences and runbooks; current state; next steps of the
   latest handoff; live decisions; open blockers; recent episodes. Rerun
   with `--budget-tokens 6000` when a "[N rows omitted ...]" marker
   appears. Blockers unconfirmed for 90 days and unverified states are
   counted, not shown. Rows of project `global` are left out once the
   rules file exists (`--global` adds them).
2. Specific priors: `search --query "..." [--project <slug>] [--part <slug>]
   [--kind <kind>] [--open-only] [--recent DAYS]`. Results are summary
   lines: uid, kind, part, status, date, ~240-char summary, `why`, and
   when they apply `by` (the successor of a superseded row), `newer` (a
   newer row on the same topic), `unverified`, `origin`. Open and recent
   rows rank first; a superseded or contradicted row ranks below its
   successor. Read the status and date before trusting a hit. An empty
   result prints `0 results`. Expand only promising hits with `get <uid>`
   (payload as an object, links and review history; `--raw` for the stored
   row) or rerun with `--full`. Never default to `--full`.
   `--part` also covers the part's aliases (see `parts`, `alias`).
   Without a query: `list --project <slug> [--part] [--kind] [--status]`
   pages newest first; `stats --project <slug>` counts kinds, links, open
   blocker ages and hygiene flags.
3. Legacy YAML handoffs written before 2026-08-15 are read-only history
   for explicit archaeology, never default context.

## 3. Two layers: core-setup vs handoff

- **`core-setup` part**: durable facts that must be true at session start
  (live install or instance, tool paths, invariants, hazards, user
  preferences, standing goals, proven commands). Kinds `constraint`,
  `goal`, `preference`, `runbook` only; never `decision`, `state`,
  `blocker` or episodes. One record per fact with a stable `--subject`.
  Bodies are capped at 500 chars (runbooks 1000): put detail in
  `--rationale`. Update by `supersede`, never by a near-duplicate.
  Cross-project user preferences: `--project global --part core-setup`.
  `mem core-lint` reports rows that break these rules.
- **Every other part**: the handoff layer, episodes and their
  decision/state/blocker children scoped to the work area they happened
  in ("what happened, what is pending"), read via `digest --part` and
  `search`.
- **Promotion rule**: when an episode reveals a fact that will still matter
  next month regardless of task (a path, a fragile component, a wrong
  assumption that cost a session), ALSO write it as a core-setup
  constraint in the same job. No episode narrative in core-setup; no setup
  invariant left only inside an episode.

## 4. Durable records mid-job

When the user states a durable goal, constraint or preference, record it at
once with `--origin user`: `{{MEM}} add --kind goal|constraint|preference
--origin user --project <slug> --part core-setup --subject <stable-key> --body
"..." [--rationale "..."]` (agent-inferred facts keep the default `agent`; the
digest marks user rows `u`). A command proven to work first time: `add --kind
runbook --subject <task> --body "<exact command>"`. Close finished goals and
blockers with `close <uid>`. Never delete records; supersede them with
`supersede <old-uid> --by <new-uid>`.

Write gate: `add` refuses (exit 2, nothing journaled) a body that repeats
an open row of the same project and kind under another subject, and lists
the rows it repeats. Then either `add ... --supersedes <uid>` (the new row
replaces that one; use it for a changed course too) or `add ... --sibling`
when it really is a different fact. `--created-at YYYY-MM-DD` keeps the
original date of an imported fact.

Blocker lifecycle: `review-blockers --project <slug> [--part <slug>]
[--repo <repo root>]` lists open blockers that later rows or the
repository already resolve (a path the blocker calls missing exists, the
item's YAML status records are all closed, a quoted placeholder is gone, a
later episode reports it done, a newer blocker restates it), each with
its evidence and a confidence. Check the evidence, then close or
supersede by uid; `--apply high` journals the high-confidence proposals as
one `review` event. Never apply `medium` unread: about one in four is
wrong. The review cannot see work the repository finished without a
memdb record, so close a blocker in `resolves` when your job ends it. `consolidate --project <slug> --dry-run` proposes
near-duplicate supersedes and links (`--apply-proposals` journals them)
and lists contradiction candidates: decisions whose rejected alternative
is what an older decision chose. Those are never applied; read both and
`supersede` the older one when the newer one replaces it. Parts: `parts --project <slug>
--suggest` lists parts by activity and proposes parents; `alias --project
<slug> --part <child> --parent <part>` makes `--part <part>` cover the
child in digest, search and list.

## 5. End of job: record an episode

Record after every completed job: a meaningful task, read-only analysis,
code or document changes, a durable deliverable, even when no repository
file changed. Skip only when the user says not to, when the turn was pure
question-and-answer with no work done, or when the memory layer is
unusable (section 7).

1. If the job changed a project plan, execution order, active stop,
   milestone status or finish-path assumption, update the canonical master
   plan or status tracker first, and name that file in the episode.
2. Write the episode JSON to a temp or scratchpad file (never the project
   tree), ASCII only:

```json
{
  "date": "YYYY-MM-DD",
  "achievement": ["what actually got done"],
  "decisions_with_rationale": [{"decision": "...", "rationale": "..."}],
  "current_state": {
    "summary": "...",
    "files_touched": ["repo-relative/path"],
    "status": [
      {"subject": "stable-key", "state": "a fact that must stay an open row"},
      "narrative: what is true now vs still pending"
    ]
  },
  "blockers": [],
  "resolves": ["<uid or subject of a blocker this job fixed>"],
  "next_steps": ["concrete and short"]
}
```

3. `record-episode` validates the shape before anything is journaled
   (exit 2, nothing appended):

   | field | accepted |
   |---|---|
   | `date` | absent, null, or `YYYY-MM-DD` |
   | `achievement`, `next_steps` | absent, null, string, or list |
   | `decisions_with_rationale` | absent, null, string, or list; items are strings or objects with `decision` |
   | `blockers` | absent, null, string, or list; items are strings or objects with `blocker` or `text` |
   | `resolves` | list of strings (blocker uids or subjects); REQUIRED, `[]` allowed, when the part has open blockers |
   | `blockers` items | never `none`, `n/a` or empty text: use an empty list |
   | `supersedes` in a decision or blocker object | a uid string: the new row replaces that open row |
   | `current_state` | absent, null, string, or object |
   | `current_state.summary` | absent, null, or string |
   | `current_state.status` | absent, null, string, or list; an object with `subject` needs a string `state` |
   | `current_state.files_touched` | absent, null, or list of strings |
   | every string and key | ASCII only |
   | any other top-level key | kept, warning on stderr |

4. What becomes a row: every decision and every blocker. A status item
   becomes an open `state` row ONLY as `{"subject": "<stable-key>",
   "state": "..."}`; plain strings are narrative, kept in the episode and
   found by `search`. A decision or blocker without an explicit `subject`
   gets `<readable slug>-<hash of its text>`, so it confirms an identical
   fact but never replaces a different one; give a stable `subject` when a
   reworded fact must supersede its predecessor. A blocker closes ONLY
   when `resolves` names it: its uid, its subject, or the readable slug
   part of its subject when exactly one open blocker matches (several
   matches close nothing and come back as `resolves_ambiguous`); names
   that match nothing come back as `resolves_unmatched`. When the part
   already has open blockers and the document has no `resolves` key,
   `record-episode` refuses (exit 2) and lists them, most related first:
   name the ones this job fixed, or give `"resolves": []`. Open `state`
   rows not re-confirmed for a while become `unverified`: they stay open
   and searchable but leave the digest until a job confirms them again.
   A decision that reads as narrative ("ran", "verified", "no source
   change") belongs in `achievement`; `record-episode` warns about it.
5. Run `{{MEM}} record-episode --project <project-slug> --part
   <part-slug> --task <task-slug> --json <episode.json>`. Session id and
   transcript default to `CLAUDE_CODE_SESSION_ID` and its transcript file;
   pass `--session-id`/`--transcript` elsewhere. It prints the uid, child
   counts, provenance sources, `open_blockers` (count and top uids still
   open in the part), `near_duplicates` (items that repeat an open row
   elsewhere: supersede or close one) and `part_suggestions` (existing
   parts with a similar slug when this part is new).
6. Replicate: `{{MEM}} sync` (commits this host's journal branch,
   pushes to the hub, ingests other hosts' journals, rebuilds and
   verifies; a standalone host skips push and fetch). If sync fails,
   report it: the local journal still holds the event. Never skip
   recording because sync might fail.
7. Final response: the episode is recorded (or its failure reported), and
   its uid is mentioned when relevant.

Content rules: `achievement` lists what actually got done;
`decisions_with_rationale` holds material decisions only; `current_state`
separates what is true now from what is pending and says so explicitly
when no repository file changed; `blockers` holds real blockers (empty list
if none); `next_steps` are concrete and short.

Slug rules (all short, stable, filesystem-safe):

- project: the real workspace or repo name (`mem project-slug --cwd <dir>`
  resolves it); if the work happened in an external sibling workspace, use
  that workspace's name, not the shell-driving repo's.
- part: the narrowest meaningful work area; prefer a subsystem, folder,
  module, feature or contract slice named in the request, else the dominant
  touched path group; `cross-cutting` only when the work truly spans
  unrelated parts.

## 6. Privacy: full fidelity inside, redaction at the boundary

Journals and DB are the PRIVATE memory domain (user-owned machines and the
user's own hub). Capture is lossless: real paths, hostnames and identifiers
stay; do NOT pre-redact memory content. Anything leaving the domain (files
for repos with third-party remotes, published docs, pasted output) must
pass `{{MEM}} redact-check <file>` (exit 2 with a span report on hits) and
be redacted per the never-commit-private-data rule first. `render-handoff`
warns on stderr when a rendered file contains private data. Never weaken
redact.py patterns.

## 7. Handoff files and failure behaviour

- A handoff file only on explicit request: `render-handoff <episode-uid>
  --out <path the user names>`. Never hand-write handoff YAML.
- Broken DB: `rebuild` (always safe, the DB is a projection).
- Journal or tool unusable: stop and report it, and say the journal event
  is missing and needs backfill.
- `verify` or `doctor` failure: surface it to the user immediately;
  verification failures are loss signals, never noise. A broken memory
  layer must never silently drop a job record.
{{LOCAL_ADDITIONS}}

"""Daily sync schedule: Windows Task Scheduler, cron, or launchd.

One entry per data home, always running config.command("sync",
"--scheduled"), so the scheduled run uses exactly the command form
everything else uses. The hand-written equivalents stay documented in
docs/hub-config.md as the reference of what this command creates.

Isolation: the default data home (MEMDB_HOME unset) owns the entry named
`memdb-sync-daily`; a MEMDB_HOME gets `memdb-sync-daily-<8 hex of its
path>`, so a scratch or test home can never overwrite or delete the real
host's entry. Removal uses the kind and name recorded in config.json,
never a platform guess.
"""
import difflib
import hashlib
import json
import os
import platform
import re
import subprocess
import sys
from xml.sax.saxutils import escape, unescape

try:
    from . import config, paths
    from .harness import render
except ImportError:                     # loose script: python memdb/mem.py
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import config  # noqa: E402
    import paths  # noqa: E402
    from harness import render  # noqa: E402

DEFAULT_NAME = "memdb-sync-daily"
LEGACY_CRON = ("memdb_sync.sh", "scheduled_sync.sh")
NO_OS_ENV = "MEMDB_NO_OS_SCHEDULE"
_QUERIES = (("schtasks", "/Query"), ("crontab", "-l"))


def _run(argv, input=None):
    """The only door to the OS scheduler; mutating calls honour MEMDB_NO_OS_SCHEDULE."""
    read_only = any(argv[0] == prog and flag in argv for prog, flag in _QUERIES)
    if not read_only and os.environ.get(NO_OS_ENV) == "1":
        raise SystemExit("schedule: refusing to change the OS scheduler: {}=1 "
                         "(set by the test suite)".format(NO_OS_ENV))
    try:
        return subprocess.run(argv, input=input, capture_output=True,
                              text=True, timeout=120, errors="replace")
    except (OSError, subprocess.SubprocessError) as e:
        raise SystemExit("schedule: {} unavailable: {}".format(argv[0], e))


def kind_for_platform():
    if os.name == "nt":
        return "windows-task"
    if platform.system() == "Darwin":
        return "launchd"
    return "cron"


def is_default_home():
    return paths.home_is_default()


def name_for_home():
    """The schedule entry name this data home owns."""
    if is_default_home():
        return DEFAULT_NAME
    digest = hashlib.sha256(os.path.normcase(os.path.abspath(
        paths.home())).encode("utf-8")).hexdigest()[:8]
    return "{}-{}".format(DEFAULT_NAME, digest)


def parse_time(text):
    """('HH', 'MM') from HH:MM; SystemExit on anything else."""
    parts = (text or "").split(":")
    if len(parts) != 2 or not all(p.isdigit() for p in parts):
        raise SystemExit("schedule: --time must be HH:MM, got {!r}".format(text))
    hour, minute = int(parts[0]), int(parts[1])
    if not (0 <= hour < 24 and 0 <= minute < 60):
        raise SystemExit("schedule: --time out of range: {!r}".format(text))
    return "{:02d}".format(hour), "{:02d}".format(minute)


def sync_argv(cfg):
    return config.command("sync", "--scheduled", cfg=cfg)


# ------------------------------------------------------------- windows

def task_action(cfg):
    """(command, arguments): windowless through a headless console host."""
    args = " ".join(config.quote(a) for a in sync_argv(cfg))
    return "conhost.exe", "--headless " + args


def task_xml(cfg, when, name):
    hour, minute = parse_time(when)
    command, arguments = task_action(cfg)
    return render("task.xml", {
        "TASK_NAME": escape(name),
        "HOST_SLUG": escape(cfg.get("host_id") or "<host>"),
        "START_BOUNDARY": "2026-01-01T{}:{}:00".format(hour, minute),
        "COMMAND": escape(command),
        "ARGUMENTS": escape(arguments, {'"': "&quot;"})})


def _tag(xml, tag):
    m = re.search(r"<{0}>(.*?)</{0}>".format(tag), xml or "", re.S)
    return unescape(m.group(1), {"&quot;": '"'}) if m else ""


def windows_entry_text(command, arguments, start):
    m = re.search(r"T(\d\d:\d\d)", start or "")
    return "command: {} {}\nstarts: {}\n".format(command, arguments,
                                                 m.group(1) if m else "")


def windows_current(name):
    p = _run(["schtasks", "/Query", "/TN", name, "/XML"])
    if p.returncode != 0:
        return None
    return windows_entry_text(_tag(p.stdout, "Command"),
                              _tag(p.stdout, "Arguments"),
                              _tag(p.stdout, "StartBoundary"))


def windows_install(cfg, when, name):
    xml = task_xml(cfg, when, name)
    tmp = os.path.join(paths.home(), name + ".xml")
    os.makedirs(os.path.dirname(tmp), exist_ok=True)
    # schtasks /XML insists on UTF-16; anything else is "invalid XML".
    with open(tmp, "w", encoding="utf-16", newline="\r\n") as f:
        f.write(xml)
    try:
        p = _run(["schtasks", "/Create", "/TN", name, "/XML", tmp, "/F"])
        if p.returncode != 0:
            raise SystemExit("schedule: schtasks /Create failed: {}".format(
                (p.stderr or p.stdout).strip()))
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
    return {"kind": "windows-task", "name": name, "time": when}


def windows_remove(name):
    p = _run(["schtasks", "/Delete", "/TN", name, "/F"])
    return {"removed": p.returncode == 0, "name": name,
            "detail": (p.stderr or p.stdout).strip()}


def windows_status(name):
    p = _run(["schtasks", "/Query", "/TN", name, "/FO", "LIST"])
    return {"exists": p.returncode == 0,
            "detail": (p.stdout or p.stderr).strip()}


# ---------------------------------------------------------------- cron

def crontab_read():
    p = _run(["crontab", "-l"])
    return p.stdout if p.returncode == 0 else ""


def crontab_write(text):
    p = _run(["crontab", "-"], input=text)
    if p.returncode != 0:
        raise SystemExit("schedule: crontab failed: {}".format(
            (p.stderr or p.stdout).strip()))


def _is_own_cron_line(line, name, default_home):
    if line.rstrip().endswith("# " + name):
        return True
    if not default_home or "# " + DEFAULT_NAME in line:
        return False
    # Pre-package entries (no marker) belong to the default home only.
    return any(s in line for s in LEGACY_CRON) or (
        "-m memdb" in line and " sync" in line)


def cron_lines_without_memdb(text, name, default_home):
    """Every crontab line except this home's memdb entry (and, for the default home, legacy ones)."""
    return [ln for ln in text.splitlines()
            if not _is_own_cron_line(ln, name, default_home)]


def cron_line(cfg, when, name):
    hour, minute = parse_time(when)
    cmd = " ".join(config.quote(a) for a in sync_argv(cfg))
    return "{} {} * * * {} # {}".format(int(minute), int(hour), cmd, name)


def cron_current(name, default_home):
    own = [ln for ln in crontab_read().splitlines()
           if _is_own_cron_line(ln, name, default_home)]
    return ("\n".join(own) + "\n") if own else None


def cron_install(cfg, when, name, default_home):
    lines = cron_lines_without_memdb(crontab_read(), name, default_home)
    lines.append(cron_line(cfg, when, name))
    crontab_write("\n".join(lines).strip("\n") + "\n")
    return {"kind": "cron", "name": name, "time": when, "line": lines[-1]}


def cron_remove(name, default_home):
    lines = cron_lines_without_memdb(crontab_read(), name, default_home)
    crontab_write("\n".join(lines).strip("\n") + ("\n" if lines else ""))
    return {"removed": True, "name": name}


def cron_status(name, default_home):
    current = cron_current(name, default_home)
    return {"exists": current is not None,
            "detail": (current or "no memdb line in crontab").strip()}


# ------------------------------------------------------------- launchd

def launchd_label(name):
    return "com.memdb.sync" + name[len(DEFAULT_NAME):].replace("-", ".")


def launchd_plist_path(name):
    return os.path.join(os.path.expanduser("~"), "Library", "LaunchAgents",
                        launchd_label(name) + ".plist")


def launchd_plist(cfg, when, name):
    hour, minute = parse_time(when)
    args = "".join("    <string>{}</string>\n".format(escape(a))
                   for a in sync_argv(cfg))
    return ('<?xml version="1.0" encoding="UTF-8"?>\n'
            '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '
            '"http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
            '<plist version="1.0"><dict>\n'
            '  <key>Label</key><string>{}</string>\n'
            '  <key>ProgramArguments</key><array>\n{}  </array>\n'
            '  <key>StartCalendarInterval</key><dict>\n'
            '    <key>Hour</key><integer>{}</integer>\n'
            '    <key>Minute</key><integer>{}</integer>\n'
            '  </dict>\n</dict></plist>\n').format(
                launchd_label(name), args, int(hour), int(minute))


def launchd_install(cfg, when, name):
    path = launchd_plist_path(name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(launchd_plist(cfg, when, name))
    _run(["launchctl", "unload", path])
    p = _run(["launchctl", "load", path])
    if p.returncode != 0:
        raise SystemExit("schedule: launchctl load failed: {}".format(
            (p.stderr or p.stdout).strip()))
    return {"kind": "launchd", "name": name, "time": when, "plist": path}


def launchd_remove(name):
    path = launchd_plist_path(name)
    if os.path.exists(path):
        _run(["launchctl", "unload", path])
        os.remove(path)
        return {"removed": True, "name": name}
    return {"removed": False, "name": name, "detail": "no plist"}


def launchd_current(name):
    try:
        with open(launchd_plist_path(name), encoding="utf-8") as f:
            return f.read()
    except OSError:
        return None


# ------------------------------------------------------------------ api

def intended_text(cfg, when, kind, name):
    """The entry as install() would create it, in the form current_text() reads."""
    if kind == "windows-task":
        command, arguments = task_action(cfg)
        hour, minute = parse_time(when)
        return windows_entry_text(command, arguments,
                                  "2026-01-01T{}:{}:00".format(hour, minute))
    if kind == "cron":
        return cron_line(cfg, when, name) + "\n"
    if kind == "launchd":
        return launchd_plist(cfg, when, name)
    return None


def current_text(kind, name):
    if kind == "windows-task":
        return windows_current(name)
    if kind == "cron":
        return cron_current(name, name == DEFAULT_NAME and is_default_home())
    if kind == "launchd":
        return launchd_current(name)
    return None


def plan_change(new_cfg, old_cfg):
    """Change record for the schedule: current OS entry vs the intended one."""
    new = new_cfg.get("schedule") or {}
    old = old_cfg.get("schedule") or {}
    kind, name = new.get("kind", "none"), new.get("name") or name_for_home()
    record = {"kind": "schedule", "changed": False,
              "path": "schedule:{}:{}".format(kind, name)}
    if kind == "none":
        old_kind = old.get("kind", "none")
        if old_kind != "none":
            old_name = old.get("name") or name_for_home()
            current = current_text(old_kind, old_name)
            record.update(path="schedule:{}:{}".format(old_kind, old_name),
                          changed=current is not None, action="remove",
                          diff=_diff(record["path"], current, None))
        return record
    current = current_text(kind, name)
    intended = intended_text(new_cfg, new.get("time") or "12:00", kind, name)
    record.update(changed=current != intended, action="install",
                  diff=_diff(record["path"], current, intended))
    return record


def _diff(label, old, new):
    if old == new:
        return ""
    return "".join(difflib.unified_diff(
        (old or "").splitlines(True), (new or "").splitlines(True),
        fromfile=label + " (current)", tofile=label + " (memdb)", n=2))


def install(cfg, when, kind=None, name=None):
    kind = kind or kind_for_platform()
    name = name or name_for_home()
    if kind == "none":
        return {"kind": "none"}
    if kind == "windows-task":
        return windows_install(cfg, when, name)
    if kind == "cron":
        return cron_install(cfg, when, name,
                            name == DEFAULT_NAME and is_default_home())
    if kind == "launchd":
        return launchd_install(cfg, when, name)
    raise SystemExit("schedule: unknown kind {!r}".format(kind))


def remove(kind, name):
    """Remove one named entry of one kind; no kind means nothing to remove."""
    if kind == "windows-task":
        return windows_remove(name)
    if kind == "cron":
        return cron_remove(name, name == DEFAULT_NAME and is_default_home())
    if kind == "launchd":
        return launchd_remove(name)
    return {"removed": False, "name": name,
            "detail": "no schedule kind configured; nothing removed"}


def last_sync_line():
    """The last line of sync.log, or a note that there is none."""
    try:
        with open(paths.sync_log(), encoding="utf-8", errors="replace") as f:
            lines = [ln.rstrip("\n") for ln in f if ln.strip()]
    except OSError:
        return "no sync.log at {}".format(paths.sync_log())
    return lines[-1] if lines else "sync.log is empty"


def status(kind=None, name=None):
    name = name or name_for_home()
    kind = kind or kind_for_platform()
    if kind == "windows-task":
        out = windows_status(name)
    elif kind == "cron":
        out = cron_status(name, name == DEFAULT_NAME and is_default_home())
    elif kind == "launchd":
        path = launchd_plist_path(name)
        out = {"exists": os.path.exists(path), "detail": path}
    else:
        out = {"exists": False, "detail": "kind none"}
    out["kind"], out["name"] = kind, name
    out["last_sync_log_line"] = last_sync_line()
    return out


def cmd_schedule(args):
    """mem schedule install|remove|status"""
    cfg = config.load()
    current = cfg.get("schedule") or {}
    name = current.get("name") or name_for_home()
    configured = current.get("kind") if current.get("kind") != "none" else None
    if args.action == "status":
        print(json.dumps(status(args.kind or configured, name), sort_keys=True))
        return
    if args.action == "remove":
        kind = args.kind or configured
        result = remove(kind, name)
        cfg["schedule"] = {"kind": "none", "name": name,
                           "time": current.get("time", "12:00")}
        config.save(cfg)
        print(json.dumps(result, sort_keys=True))
        return
    if not is_default_home() and not args.time:
        raise SystemExit("schedule: MEMDB_HOME is not the default data home; "
                         "an OS schedule for it needs an explicit --time HH:MM")
    when = args.time or current.get("time") or "12:00"
    result = install(cfg, when, args.kind, name)
    cfg["schedule"] = {"kind": result.get("kind", "none"), "name": name,
                       "time": when}
    config.save(cfg)
    print(json.dumps(result, sort_keys=True))

"""`python -m memdb <cmd>` - the interpreter form of the `mem` console script."""
from .mem import main

if __name__ == "__main__":
    main()

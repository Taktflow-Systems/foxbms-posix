#!/usr/bin/env bash
# TRANSITION WRAPPER (one release). The hook itself is Python:
#   mem hook session-start   ==   python -m memdb hook session-start
#
# It exists because the user-level hook registrations on the existing
# hosts still name this path, set no environment, and run from a foreign
# working directory. `mem install` re-registers the Python form and this
# file goes away. Contract unchanged: always exit 0.
set -u

MARKER='{"hookSpecificOutput": {"hookEventName": "SessionStart", "additionalContext": "%s"}}'

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." 2>/dev/null && { pwd -W 2>/dev/null || pwd; })"
if [ -z "${ROOT:-}" ]; then
    printf "$MARKER\n" '[memdb UNAVAILABLE - cannot locate the memdb checkout]'
    exit 0
fi

pick_python() {
    if [ -n "${MEMDB_PYTHON:-}" ]; then
        printf '%s' "$MEMDB_PYTHON"
        return 0
    fi
    for cand in python3 python; do
        if command -v "$cand" >/dev/null 2>&1 \
                && "$cand" -c 'import sqlite3' >/dev/null 2>&1; then
            printf '%s' "$cand"
            return 0
        fi
    done
    if command -v py >/dev/null 2>&1 \
            && py -3 -c 'import sqlite3' >/dev/null 2>&1; then
        printf '%s' 'py -3'
        return 0
    fi
    return 1
}

if ! PY="$(pick_python)"; then
    printf "$MARKER\n" '[memdb UNAVAILABLE - no python interpreter with sqlite3]'
    exit 0
fi

# Windows interpreters need ';' and a drive-letter path; pwd -W gave us one.
SEP=":"
case "$ROOT" in [A-Za-z]:*) SEP=";" ;; esac
export PYTHONPATH="$ROOT${PYTHONPATH:+$SEP$PYTHONPATH}"

exec $PY -m memdb hook session-start

# memdb harness hooks

Hooks are Python subcommands of the package, not shell scripts:
`mem hook <name>`, `memdb-hook <name>` and
`python -m memdb hook <name>` are the same entry point. No bash is
required on any platform.

`memdb/hooks/session_start.sh` is a TRANSITION WRAPPER for one release:
it resolves an interpreter (`MEMDB_PYTHON`, else the first of `python3`,
`python`, `py -3` that can `import sqlite3`), puts the checkout on
`PYTHONPATH` and execs `python -m memdb hook session-start`. It exists
only because the hook registrations on the existing hosts still name that
path; `mem install` replaces them and the wrapper goes away.

## SessionStart digest injection

Register the hook ONCE, at user level, in `~/.claude/settings.json`, so
every session on the host gets it (`<interpreter>` = the absolute Python
path recorded at install time):

```json
{
  "autoMemoryEnabled": false,
  "hooks": {
    "SessionStart": [
      {
        "matcher": "startup|clear|compact",
        "hooks": [
          {
            "type": "command",
            "command": "\"<interpreter>\" -m memdb hook session-start",
            "timeout": 20
          }
        ]
      }
    ]
  }
}
```

- `matcher`: a fresh start, `/clear` and a compaction lose the context,
  so they re-inject; `resume` keeps it, so it does not.
- `autoMemoryEnabled: false` turns off Claude Code's built-in auto memory
  (the `~/.claude/projects/<dir>/memory/MEMORY.md` files and the standing
  instructions about them). Two memory systems must not compete: memdb is
  the only store, and a second one splits facts between two places that
  disagree.
- This repository's own `.claude/settings.json` registers the same script
  by relative path with `MEMDB_HOOK_SCOPE=project`; that copy stands down
  when the user-level registration exists, so nothing is injected twice.

What the hook does:

- resolves the project slug with `mem project-slug --cwd <session cwd>`:
  the git toplevel name, else a folder below or above it, mapped to the
  most recently written spelling of a known project (Windows paths
  included);
- injects `mem digest --project <slug> --part core-setup` (the session
  start layer);
- writes `{session_id, transcript_path}` to
  `~/.claude/memory/sessions/<session_id>.json` for episode provenance.

Environment knobs (all optional):

- `MEMDB_HOME` - the whole data directory (default `~/.claude/memory`)
- `MEMDB_PATH` - DB location (default `<MEMDB_HOME>/mem.db`)
- `MEMDB_JOURNAL` - journal root (default `<MEMDB_HOME>/journal`)
- `MEMDB_PROJECT` - project slug (default: `mem project-slug --cwd <cwd>`)
- `MEMDB_PART` - part slug filter (default `core-setup`; `all` = whole
  project)
- `MEMDB_BUDGET` - digest token budget (default 1500)
- `MEMDB_CORE_RULES` - the static global rules file the digest defers to
- `MEMDB_PYTHON` - interpreter, read by the transition wrapper only

Failure behavior: the hook always exits 0. A broken memory layer never
blocks session start.

## Session context = two files

Every session starts with exactly two memory blocks, both bounded:

1. **Static global rules file** - `~/.claude/rules/memdb-core-global.md`
   (override with `MEMDB_CORE_RULES`). Written by
   `mem render-core --out <path>` after every green sync rebuild: open
   `global` goal/constraint/preference rows and global runbooks, one
   bullet per row with its uid, sorted by kind and subject, no
   timestamps. It is byte-identical while the DB is unchanged, so the
   prompt cache stays warm, and the command refuses to write more than
   25,000 bytes or 200 lines (it lists the 10 longest rows instead).
   Claude Code loads it like any other user rule file.
2. **Per-project digest** - injected by the hook with `--no-global` (the
   global rows are already in file 1) whenever the rules file exists.
   Pinned rows are capped at `ANCHOR_BUDGET` (1,200 tokens by default);
   the least recently confirmed rows are left out first and the digest
   says how many, with the command that shows them all.

Write-time caps keep the pinned layer small at the source: `mem add`
refuses a core-setup goal/constraint/preference body over
`MEMDB_CORE_BODY_MAX` (500 chars) and any runbook body over 1,000
chars. Put the rule in `--body` and the narrative and evidence in
`--rationale` (searchable, never pinned). `mem core-lint` reports rows
that break the layer's rules (disallowed kinds, over-cap bodies, case-
split project slugs) as a read-only proposal.

## Failure visibility

The hook never blocks session start (exit 0 always), but failure and
emptiness are visible marker lines in the injected context instead of
silence: `[memdb UNAVAILABLE - run: <mem> doctor]` when the digest cannot
render, `[memdb: no records for project X ...; try: <mem> search]` when
the scope is empty. `<mem>` is the installed command form from
`config.json` (plain `mem` on a store that was never installed), and the
digest footers name commands the same way.

## End-of-job flow

At the end of a job the agent runs, as its final-response step (`mem` =
this host's command form, as rendered into the skill by `mem install`):

```sh
mem record-episode \
    --project <project-slug> --part <part-slug> --task <task-slug> \
    --json episode.json [--session-id <id>] [--transcript <path>]
mem sync
```

`episode.json` carries the handoff shape as JSON: `date`, `achievement`,
`decisions_with_rationale` (list of `{decision, rationale}`),
`current_state` (`{summary, files_touched, status}`), `blockers`,
`next_steps`. The journal event is the record; the DB is a rebuildable
projection; handoff YAML is rendered only on explicit request
(`render-handoff <episode-id-or-uid> --out <path>`).

`record-episode` validates the document BEFORE anything is journaled
(exit 2, every error listed, nothing appended), then preflights the
applier inside a rolled-back savepoint. Accepted field types:

| field | accepted |
|---|---|
| `date` | absent, null, or `YYYY-MM-DD` |
| `achievement`, `next_steps` | absent, null, string, or list |
| `decisions_with_rationale` | absent, null, string, or list; items are strings or objects with `decision` |
| `blockers` | absent, null, string, or list; items are strings or objects with `blocker` or `text` |
| `current_state` | absent, null, string, or object |
| `current_state.summary` | absent, null, or string |
| `current_state.status` | absent, null, string, or list |
| `current_state.files_touched` | absent, null, or list of strings |
| every string and key | ASCII only (the first offending path and code point is reported) |
| any other top-level key | kept in the payload, warning on stderr |

Capture is full-fidelity: journals and DB are the PRIVATE memory domain
(user-owned machines + self-hosted hub), so real paths and hostnames are
allowed and preserved. Redaction guards the publish boundary instead:
anything leaving the private domain must pass
`mem redact-check <file>` (exit 2 on hits).

"""Harness hooks as Python subcommands: `memdb-hook <name>`, `mem hook <name>`.

Contract for every hook: read the harness payload on stdin, write at most
one JSON object on stdout, exit 0 on EVERY path, bounded runtime. Failure
and emptiness are visible marker lines in the injected context, never
silence - a broken memory layer must not look like an empty one.

No shell is involved: these run with the interpreter alone, on Windows
without Git Bash.
"""
import json
import os
import re
import sys

try:
    from .. import mem, paths
except ImportError:                     # loose tree: python memdb/mem.py hook
    import mem
    import paths

SESSION_ID_RE = re.compile(r"[A-Za-z0-9._-]+")
# {mem} is this host's command form (config.display_prefix), never a bare
# `mem` that may not be on PATH.
UNAVAILABLE_FMT = "[memdb UNAVAILABLE - run: {mem} doctor]"
EMPTY_FMT = ("[memdb: no records for project {p} (part {part}) - it may need "
             "backfill or the project slug may differ; try: {mem} search]")


def mem_prefix():
    try:
        return mem.command_prefix()
    except Exception:
        return "mem"


BAD_INPUT = ("[memdb: hook input on stdin is not a JSON object; the project comes from the "
             "working directory]")


def read_payload():
    """(payload, ok): the harness hook JSON on stdin, UTF-8 with or without a BOM; ok False when unparsable."""
    try:
        buf = getattr(sys.stdin, "buffer", None)
        raw = buf.read().decode("utf-8", "replace") if buf is not None else sys.stdin.read()
    except (OSError, ValueError, AttributeError):
        return {}, True
    raw = raw.lstrip("\ufeff")
    if not raw.strip():
        return {}, True
    try:
        data = json.loads(raw)
    except ValueError:
        return {}, False
    return (data, True) if isinstance(data, dict) else ({}, False)


def emit(event_name, context):
    """Print the harness envelope; carriage returns never reach the context."""
    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": event_name,
        "additionalContext": (context or "").replace("\r", "")}}))


def session_file(session_id):
    return os.path.join(paths.sessions_dir(), session_id + ".json")


def record_session(data):
    """Persist {session_id, transcript_path} for record-episode provenance."""
    sid = str(data.get("session_id") or "")
    if not sid or not SESSION_ID_RE.fullmatch(sid):
        return None
    path = session_file(sid)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        current = {}
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                current = json.load(f)
        if not isinstance(current, dict):
            current = {}
        current.update({"session_id": sid,
                        "transcript_path": data.get("transcript_path")})
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8", newline="\n") as f:
            json.dump(current, f, sort_keys=True)
        os.replace(tmp, path)
    except (OSError, ValueError):
        return None
    return sid


def _memdb_command(cmd):
    """A memdb SessionStart registration in any command form, the `mem` form included."""
    try:
        from .. import config
    except ImportError:
        import config
    return config.is_memdb_command(cmd) and ("session_start.sh" in cmd
                                             or "session-start" in cmd)


def user_level_registered():
    """Is a memdb SessionStart hook registered at user level?"""
    try:
        with open(paths.claude_settings_file(), encoding="utf-8") as f:
            groups = json.load(f).get("hooks", {}).get("SessionStart", [])
        cmds = [h.get("command", "") for g in groups for h in g.get("hooks", [])]
    except (OSError, ValueError, AttributeError, TypeError):
        return False
    return any(_memdb_command(c or "") for c in cmds)


def project_for(cwd):
    """The canonical project slug for a working directory."""
    if os.environ.get("MEMDB_PROJECT"):
        return os.environ["MEMDB_PROJECT"]
    try:
        slug = mem.project_slug_for(cwd)
    except Exception:
        slug = ""
    return slug or os.path.basename(os.path.abspath(cwd or os.getcwd()))


def digest_context(project, part, no_global):
    """(text, ok) of the digest for one scope; never raises."""
    try:
        conn = mem.connect()
        try:
            lines = mem.digest_lines(conn, project, part,
                                     digest_budget(), include_global=not no_global)
        finally:
            conn.close()
    except Exception:
        return UNAVAILABLE_FMT.format(mem=mem_prefix()), False
    if len([ln for ln in lines[1:] if ln.strip()]) == 0:
        return EMPTY_FMT.format(p=project, part=part or "all",
                                mem=mem_prefix()), True
    return "\n".join(lines), True


def digest_budget():
    raw = os.environ.get("MEMDB_BUDGET")
    try:
        return int(raw) if raw else 1500
    except ValueError:
        return 1500


def hook_session_start(argv):
    """SessionStart: inject the per-project digest as additional context."""
    data, readable = read_payload()
    record_session(data)
    if os.environ.get("MEMDB_HOOK_SCOPE") == "project" and user_level_registered():
        return 0
    cwd = data.get("cwd") or os.getcwd()
    part = os.environ.get("MEMDB_PART", "core-setup")
    part = None if part == "all" else part
    no_global = os.path.exists(paths.core_rules_file())
    text, _ = digest_context(project_for(cwd), part, no_global)
    emit("SessionStart", text if readable else BAD_INPUT + "\n" + text)
    return 0


HOOKS = {"session-start": hook_session_start}


def main(argv=None):
    """Dispatch one hook by name. Always returns 0; hooks never block."""
    argv = list(sys.argv[1:] if argv is None else argv)
    name = argv[0] if argv else ""
    handler = HOOKS.get(name)
    if handler is None:
        print("memdb-hook: unknown hook {!r} (known: {})".format(
            name, ", ".join(sorted(HOOKS))), file=sys.stderr)
        return 0
    try:
        return handler(argv[1:]) or 0
    except SystemExit:
        return 0
    except BaseException as e:
        print("memdb-hook: {} failed: {}: {}".format(name, type(e).__name__, e),
              file=sys.stderr)
        return 0


if __name__ == "__main__":
    sys.exit(main())

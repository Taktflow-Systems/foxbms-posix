"""memdb - log-first memory for agent harnesses.

The per-host append-only journal is the system of record; the SQLite DB
is a rebuildable projection. `mem` is the CLI (memdb.mem:main),
`memdb-hook` the harness hook entry point (memdb.hooks:main).

Nothing is imported here: the hook and the CLI must start in a few tens
of milliseconds, and importing the package must never open a DB.
"""

__version__ = "1.0.1"

__all__ = ["__version__"]

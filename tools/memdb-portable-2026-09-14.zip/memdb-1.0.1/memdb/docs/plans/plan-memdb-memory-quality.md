# memdb memory-quality plan: a packaged memory, not a checkout

## How to read this

Audience: an AI worker landing cold, with no prior conversation context.
Every step carries: Step ID, Goal, Inputs, Deliverables (concrete file
paths), Acceptance criteria (independently checkable), Gate / review
reference, Definition of done. Two tracks: **S-PKG-01..05** make memdb an
installable package that works unchanged on any machine; **S-MQ-01..12**
close the memory-quality weaknesses. Execute S-PKG first, then S-MQ in
numeric order; every S-MQ deliverable is written against the package
layout S-PKG-01 defines (Python entry points, no shell scripts, no
absolute paths in rendered files). Gates: the memdb test suite
(`python -m pytest memdb/tests -q` from the repository root after
S-PKG-01; `python -m pytest tests -q` from `memdb/` before), the full
oracle (`mem verify --full` and `mem rebuild --verify --full` on the real
store), the scale budgets (`memdb/tests/bench_scale.py`, table in
`memdb/docs/perf-budgets.md`), the retrieval evals
(`memdb/tests/test_search_eval.py`), the fresh-machine install test
(S-PKG-05), the hook fixture suite (`~/.claude/hooks/tests/test_hooks.py`),
and user review for every change to user-level settings, rule files or
stored data. Rules in force: the user-level CLAUDE.md (STRICT MODE,
memory-persistence rule), `rules/multi-host-agent-workflow.md` H1-H8,
`rules/never_commit_private_data.md`. Commit discipline as in the audit
plan: one commit per step on this host's branch, pushed in the same turn.

Path placeholders (never write personal absolute paths into this repo):
`<memdb-checkout>` = the clone that contains `memdb/` (the repository
root, where `pyproject.toml` lands); `~` = the user profile directory;
`<memdb-home>` = the data directory, default `~/.claude/memory`;
`<hub-ssh-spec>` = the SSH target of the self-hosted hub;
`$DISTILL_HOME` = the text distiller directory; `<yyyy-mm-dd>` = the date
the step is executed.

Predecessor plans, both complete except the two-day acceptance items:
`memdb/docs/plans/plan-scalability.md` (S-MEM-SCALE-01..06) and
`memdb/docs/plans/plan-memdb-audit-followup.md` (S-AUD-01..14). This plan
does not reopen them. The existing portable package description
(`install/README.md`, `install/AGENT_INSTALL.md`, `install/PROMPT.txt`,
the two templates) is the input of the S-PKG track and is superseded by
it.

## Requirement added 2026-09-13: packagable, usable as is on another machine

The user's words: "i want this design to be packagable and usable as is
in another machine, design it like that". Read as: a person on a new
machine obtains one artifact, runs one install command, and has the
complete memory layer (tool, hooks, skill, rule block, sync, schedule,
hub membership) working with no manual path editing, no bash
requirement, no copying of files by hand, and no step that depends on
this workspace's layout. What today prevents that (measured 2026-09-13):

| gap | evidence |
|---|---|
| rendered files carry absolute paths of this workspace | `~/.claude/skills/memdb/SKILL.md` and the CLAUDE.md rule block name `<memdb-checkout>/memdb/mem.py` and `memdb_sync.sh` in full; `~/.claude/settings.json` hook command names the checkout path |
| hooks and sync are bash scripts | `hooks/session_start.sh`, `sync/memdb_sync.sh`, `sync/scheduled_sync.sh`; Windows needs Git Bash and the scheduled task names its `bash.exe` path |
| interpreter name differs per OS | scripts call `python3`; the workstation has `python` 3.14 and `python3` 3.13, the rule block says `python` |
| install is a ten-step manual procedure for an agent | `install/AGENT_INSTALL.md`: place tree, pytest, host-id, git init, remote, init, first sync, render two templates with five placeholders, edit CLAUDE.md, edit settings.json, schedule |
| the tool is a flat script directory | `memdb/mem.py` inserts its own directory into `sys.path`; no `pyproject.toml`, no `__main__`, `schema.sql` opened by file path (breaks inside a zip) |
| no versioned artifact | "memdb-portable.zip" is produced by hand; no version string, no checksum, no compatibility rule between hosts running different code |
| tests need pytest and bash | `tests/conftest.py` imports `mem` by path; `test_sync_guards.py` skips without bash |
| harness coupling | Claude Code paths (`~/.claude/...`) are constants in `mem.py` and the hook; Codex support is prose in the install guide |

## Baseline (measured 2026-09-13, workstation, after S-AUD-14)

| measure | value |
|---|---|
| records / events | 19,314 / 3,520 (workstation 3,520; laptop 4; pi 2) |
| open records on 2026-09-13 morning (before state expiry) | 12,065 of 18,896 |
| open blockers / TaktflowBMS blockers older than 90 days | 1,180 / 487 |
| open `state` rows before / after the two expiry runs | 4,308 / 3,514 then minus 1,282 |
| search, keyword query "bash cwd resets H: wrong repo" | `workstation:3324` at rank 1 |
| search, paraphrase "commit accidentally landed in the wrong repository" | `workstation:3324` at rank 5, four unrelated rows above it |
| eval `tests/eval/queries.jsonl` (35 queries, stored wording) | hit@1 0.657, hit@5 0.943, MRR 0.795, p50 26-29 ms |
| episodes with transcript hash before S-AUD-13 | 13 of 2,080 |
| digest `--project Memory-orchestration --part core-setup --no-global` | 1,850 chars, 10 lines |
| standing text at session start (CLAUDE.md + user rules + rendered core file) | ~7,200 tokens |
| `links` rows with relation `relates` | 0 (no code path writes one) |
| rows with `confidence = unverified` demoted by the 90-day rule | 0 |
| memdb tests | 187 pass |
| embedding backend | ollama on the default port; `nomic-embed-text:latest` installed (137M, F16, 768 dims, context 2,048) |
| interpreters | workstation `python` 3.14.6, `python3` 3.13.14; laptop and pi Linux `python3` |

## Invariants this plan must not break

- The journal is append-only and hash-chained; events are never rewritten.
- Full replay of all journals is the definition of truth. Every applier
  change is keyed on a payload field that old events do not carry, so the
  projection of existing events is unchanged, with one permitted
  exception: a step may add a NEW column whose value is derived
  deterministically from fields old events already carry (S-MQ-09
  `valid_to` from `ev["ts"]`); an existing column of an existing row never
  changes. Appliers stay deterministic: no network call, no embedding, no
  wall clock inside an applier.
- Every schema change bumps `SCHEMA_VERSION` in the step that lands it
  (5 in S-MQ-02, 6 in S-MQ-04, 7 in S-MQ-09, 8 in S-MQ-10), each bump
  costs one `rebuild --full` per host, and `init_schema` refuses an older
  DB with the existing rebuild text. `witness-heads.json` carries the
  writer's `schema_version`; a head mismatch between hosts on different
  schema versions is reported by `mem sync` as `version-skew`, never as
  drift.
- Network calls in the write path (embedding, S-MQ-04) run after the
  journal lock is released and never delay or fail the journal write.
- No long-lived memdb process holds a connection to `mem.db` between
  requests: hooks exit, the MCP server (S-MQ-11) opens and closes per
  request. Sync and rebuild replace the DB file with `os.replace`, which
  fails on Windows while another process holds it open.
- Every fast path (snapshot, anchors) stays provably equal to full replay.
  Anything non-deterministic (vectors, read counters) lives in
  projection-only tables or `derived/` and is excluded from
  `projections_equal`.
- Capture is full-fidelity; no redaction inside the memory domain.
- Records are never deleted; supersede or close only.
- The package, its hooks and its sync are Python 3.9+ stdlib only at
  runtime. `git` is the only external program (sync and project-slug);
  `bash` is never required. An optional accelerator may be imported
  inside a `try`, never required.
- Portability: no rendered or installed file (skill, rule block, hook
  registration, schedule) contains a path of the source checkout; the
  only machine-specific values are the interpreter path recorded at
  install time, the data directory, the host id, the hub URL and, for
  the `.pyz` install form, the artifact path `<memdb-home>/bin/memdb.pyz`,
  all in one config file. Every rendered command line comes from one
  helper, `config.command(cmd)` (S-PKG-02), so the three command forms of
  D-9 cannot diverge between hook, schedule, MCP snippet, skill and rule
  block.
- The SessionStart hook never blocks session start. Every hook has the
  same contract: exit 0 on every path, bounded runtime, failure visible as
  a marker line, never silence.
- Existing hosts keep working through the transition: `python
  <memdb-checkout>/memdb/mem.py <cmd>` and `bash
  <memdb-checkout>/memdb/sync/memdb_sync.sh` stay valid for one release
  as thin wrappers; the data directory default stays `~/.claude/memory`.
- No `--force`, no `git reset --hard`, no journal or DB edits by hand.
- Nothing in this repo may contain personal absolute paths, IPs or emails.
- A new event type is deployed to every host (package upgrade +
  `rebuild --full`) before the first event of that type is written
  anywhere; a host running older code fails `rebuild` on an unknown type
  by design, and the sync warns about it before that happens (S-PKG-04).

## Weakness register (from episode `workstation:3518`)

| id | sev | where | weakness | closed by |
|---|---|---|---|---|
| W-01 | high | `mem.py` search_rows, fts_query | Retrieval is lexical only; a paraphrase without the stored vocabulary misses; the eval is harvested from stored wording and overstates recall | S-MQ-01, S-MQ-04 |
| W-02 | high | harness hooks | Capture is voluntary: no Stop / SessionEnd hook, a forgotten `record-episode` or a crash loses the session | S-MQ-03 |
| W-03 | high | `mem.py` apply_episode item_fields, gated_insert | Subject = slug of the first 60 chars; a reworded fact never supersedes its predecessor; consolidate merges exact bodies only | S-MQ-06 |
| W-04 | high | `mem.py` apply_episode, digest_lines | `achievement` and `next_steps` never become rows; the digest shows episode subject and date only | S-MQ-02 |
| W-05 | med | `mem.py` compute_consolidate, digest_lines | Forgetting is by age, not relevance; blockers never expire; no read or usefulness signal; `unverified` is never set automatically | S-MQ-07 |
| W-06 | high | `mem.py` digest_lines, session-start hook | Context is a fixed recency-ordered budget unrelated to the task; pinned eviction drops least-recently-confirmed first; the handoff layer is not injected | S-MQ-05, S-MQ-07 |
| W-07 | med | `record-episode --part` | Part slugs are free text chosen per job; the handoff layer fragments | S-MQ-08 |
| W-08 | med | `schema.sql`, appliers | No validity interval, no `relates` links, no entity or path index, "as of date" impossible | S-MQ-09 |
| W-09 | med | `schema.sql` origin, confidence | No agent identity; confidence is binary and never set by the system; no user confirmation path | S-MQ-10 |
| W-10 | med | test suite, eval | Effort concentrated on integrity; retrieval failure is silent | S-MQ-01 |
| W-11 | low | CLI | Subprocess-per-call, 160-char snippets; no MCP server for other harnesses | S-MQ-11 |
| W-12 | med | blocker lifecycle | No triage path for 1,180 open blockers | S-MQ-07 |
| W-13 | low | session start | ~7,200 tokens of standing text per session regardless of task | S-MQ-05 (recall replaces part of the digest) |
| W-14 | low | `redact.py`, render-handoff | Regex-only patterns miss usernames, hostnames, project names; render only warns | S-MQ-12 |
| W-15 | high | packaging (table above) | Not installable as is on another machine: absolute paths, bash, manual ten-step install, unversioned artifact | S-PKG-01..05 |
| W-16 | high | `mem.py` search_rows, cmd_search | Ranking has no supersession or recency-of-content signal: an older open row outranks the newer row that corrects it, and search lines carry no date (field test 2026-09-13: 7 of 20 top answers misleading while the right row was held for 17 of 20) | unassigned (added 2026-09-13) |
| W-17 | med | `mem.py` digest_lines, test hygiene | Test and selftest records land in a real project and render in its digest (`memdb-selftest` episodes under TaktflowBMS) | unassigned (added 2026-09-13) |
| W-18 | med | `validate_episode_doc`, `item_fields`, core rows | Kind and body pollution: narrative decisions, JSON-dict and "none" blocker bodies, durable facts stored as state, core rows cut mid-list, local integer ids cited in durable text | unassigned (added 2026-09-13) |
| W-19 | med | `cmd_record_episode` ts, import | Time order lost: date-only `T00:00:00` episode timestamps, import date kept as `created_at`, uid order not chronological | unassigned (added 2026-09-13); as-of queries stay S-MQ-09 |
| W-20 | med | CLI output | Output cost and friction: `get` prints episode JSON twice, empty search prints nothing, no list or stats command, `consolidate --dry-run` takes the journal lock, no `--project` on consolidate and core-lint, a confirm event's uid resolves to nothing | unassigned (added 2026-09-13); snippet length stays W-11 |
| W-21 | med | stored data | Content gaps: no current-status row per active part, no superseding chain for replaced models, standing rules stored as repeated decisions | unassigned (added 2026-09-13); handled as the Part B real-store cleanup proposal |

## Field test 2026-09-13 (TaktflowBMS): evidence and triage

A field test ran memdb 1.0.0 (checkout `7b41e35` plus the uncommitted
S-PKG-02/03 work) against the TaktflowBMS project store on the
workstation, read-only on the real store, with a throwaway store for the
write path. The report and its raw evidence stay outside this repository
because they quote project content. Numbers measured on 2026-09-13:

| measure | value |
|---|---|
| engineer questions answered from memdb (20) | correct 9, stale 1, misleading 7, missing 3; right row held for 17, ranked first for 6 |
| TaktflowBMS open blockers / open decisions / episodes | 565 / 2,036 / 691 |
| episodes using `resolves` | 0 of 691 |
| blockers ever closed / ever recorded | 4 / 579 |
| sampled open blockers already resolved in the repo | 14 of 25 (56 %) |
| sampled open decisions contradicted by a later open decision | 2 of 15; `contradicts` links in the store: 0 of 721 |
| hand-found duplicate clusters / proposed by `consolidate --dry-run` | 49 (35 blocker, 13 decision, 1 cross-kind) / 0 |
| distinct facts lost to 60-char auto-subject collisions | 6 per-boundary blockers in one chain, plus 3 more pairs |
| narrative decisions / JSON-dict blockers / "none" blockers (open) | 123 / 37 / 7 |
| session-start digest usefulness | `--part core-setup` about 7 % (13 of 14 rows are global rows already in the rules file, 17 project pinned rows omitted); project digest under 10 %, 0 of 2,036 decisions rendered |
| read command latency | search and get 0.09-0.15 s, digest 0.14-0.19 s, `verify --full` 4.3 s (19,330 records) |

Triage (user decision 2026-09-13: integrity, data-loss and install
defects are packaging blockers fixed in the S-PKG sweep before release
1.0.0; memory-quality findings are fixed in release 1.1.0):

| finding | class | owner |
|---|---|---|
| bare `install` / `uninstall` apply their changes | packaging blocker | S-PKG-02 sweep |
| OS schedule machine-global, not isolated by the data home | packaging blocker | S-PKG-02 sweep |
| 60-char auto-subject collision supersedes different facts | packaging blocker (data loss) | S-PKG-02 sweep |
| hub ssh-only, config vs origin drift, standalone sync always fails | packaging blocker | S-PKG-02/03 sweep |
| `config show` prints defaults as host settings | packaging blocker | S-PKG-02 sweep |
| `install --check` under-reports, silent harness auto-add, cp1252 diff, templates drop host-specific skill text | packaging blocker | S-PKG-02 sweep |
| write commands accept bare integer local ids | packaging blocker | S-PKG-02 sweep |
| no-op reinstall journals an episode; nonexistent `mcp` snippet; data home does not isolate render-core; install episode inherits the session id | packaging blocker | S-PKG-02/03 sweep |
| doctor flags memdb's own config.json and bin/; footers name `mem` where it is not on PATH | packaging blocker | S-PKG-02 sweep |
| blockers never close | memory quality | S-MQ-07 (W-12) |
| stale open rows outrank correcting rows; no date in search lines | memory quality | W-16 (unassigned) |
| contradictions never linked; near-duplicates missed | memory quality | S-MQ-06 (W-03) |
| digest budget priority and section content | memory quality | S-MQ-05 (W-06) |
| next steps never reach the digest | memory quality | S-MQ-02 (W-04) |
| selftest records inside a real project | memory quality | W-17 (unassigned) |
| time ordering lost | memory quality | W-19 (unassigned) |
| part fragmentation | memory quality | S-MQ-08 (W-07) |
| kind and body pollution, integer ids in durable text | memory quality | W-18 (unassigned) |
| state sweep closes still-true facts | memory quality | S-MQ-07 (W-05) |
| output cost and CLI friction | memory quality | W-20 (unassigned) |
| private data in routine output | memory quality | S-MQ-12 (W-14) |
| content gaps (status rows, superseding chains) | memory quality | W-21 (unassigned) |

## Decisions

Delegated by the user on 2026-09-13 ("you decide"); taken by the worker
with the basis stated. D-7 to D-9 were added with the packaging
requirement under the same delegation.

- **D-1** embedding backend: ollama, model `nomic-embed-text:latest`
  (present on the workstation: 137M parameters, F16, native 768 dims,
  context 2,048 tokens, default port), vectors truncated to 256 dims and
  L2-normalised; embedding text capped at 1,500 chars. Laptop and pi run
  without embeddings.
- **D-2** search budget: `search_p50_ms` 300 for project-scoped hybrid
  search, stdlib only, no numpy (two behaviours across hosts, no wheel on
  the pi); `--lexical` keeps the 100 ms path.
- **D-3** auto-episodes: one journaled `[auto]` episode per ended session
  that had tool activity and no explicit episode, no child rows (a draft
  that is never journaled does not replicate and dies with the clone).
- **D-4** the worker applies the user-level settings changes (hook
  registration) through `mem install`, which backs the file up under
  `<memdb-home>/install-backups/` and prints the diff; the diff is quoted
  in the step episode (same delegation as S-AUD-03 D-5).
- **D-5** fuzzy consolidation applied by the worker after self-review,
  text-similarity groups (`similar >= 0.85`) only; the vector-only
  `review` list is never applied automatically.
- **D-6** schema version 5 and the `confirm` event type deploy in the
  order: upgrade the package on laptop and pi, `mem rebuild --full` and
  `verify --full` there, only then the first `confirm` event anywhere;
  the step episode names the version each host runs.
- **D-7** package form: one Python package `memdb` with console scripts
  `mem` and `memdb-hook`, distributed as (a) a wheel built from
  `pyproject.toml` and (b) a stdlib `zipapp` file `memdb-<version>.pyz`
  that runs with any Python 3.9+ and no pip. Basis: pip and setuptools
  are not guaranteed on a locked-down machine; a `.pyz` is one file and
  needs nothing; the wheel gives `mem` on PATH where pip exists. The
  `.pyz` install form copies the artifact to `<memdb-home>/bin/memdb.pyz`
  (plus a versioned copy `memdb-<version>.pyz` beside it) so the path
  written into hooks and schedules is stable across upgrades.
- **D-8** data directory stays `~/.claude/memory` by default
  (`MEMDB_HOME` overrides everything under it). Basis: three hosts
  already hold journals there; a move gains nothing and risks a split.
- **D-9** hook and schedule commands are written with the absolute
  interpreter path recorded at install time (`sys.executable`) in the
  form `"<interpreter>" -m memdb hook <name>`; the rule block and the
  skill say `mem <cmd>` when `mem` resolves on PATH after install, else
  the interpreter form, chosen and reported by `mem install`. Basis:
  `python3` does not exist on Windows, `python` may be a Store alias, and
  PATH differs between a hook shell and a login shell; a pinned
  interpreter is the only form that works in all three. Three command
  forms exist in `config.command_form`: `mem` (console script on PATH),
  `interpreter` (`"<interpreter>" -m memdb <cmd>`, wheel installed
  without PATH) and `pyz` (`"<interpreter>" "<memdb-home>/bin/memdb.pyz"
  <cmd>`, no pip); `-m memdb` alone is never written for a `.pyz`
  install because the package is not importable there.

## Execution order and cut line

Two tranches; the second starts only when the first is complete and its
acceptance numbers are in `perf-budgets.md`.

| tranche | steps | what the user gets | stop condition |
|---|---|---|---|
| 1 | S-PKG-01, S-PKG-02, S-PKG-03, S-MQ-01, S-MQ-02, S-MQ-03, S-MQ-04, S-MQ-05 | installable package with Python hooks and sync; next steps in the digest; no session lost; paraphrase retrieval; prompt-time recall | all tranche-1 DoDs met and one week of green scheduled syncs |
| 2 | S-PKG-04, S-PKG-05, S-MQ-06, S-MQ-07, S-MQ-08, S-MQ-09, S-MQ-10, S-MQ-11, S-MQ-12 | versioned release and fleet migration; write gate, retention, parts, validity, identity, MCP, redaction | each step independently |

Overridden by the user on 2026-09-13 (see Status): release 1.0.0 is cut
after the S-PKG-02..05 sweep, ahead of S-MQ-01..05; the memory-quality
work ships as release 1.1.0.

Basis: the tranche-1 steps close the four high-severity weaknesses W-01,
W-02, W-04, W-06 and the install half of W-15; every tranche-2 step is
medium or low severity or a fleet operation that benefits from tranche-1
having run for a week. S-PKG-04 and S-PKG-05 move to tranche 2 because
the three real hosts keep working on the checkout plus transition
wrappers (invariant above) until the release is cut; a schema bump in
tranche 1 (S-MQ-02, S-MQ-04) is deployed to laptop and pi by pulling the
checkout and running `rebuild --full` there, as today.

## Steps: packaging track

### S-PKG-01: one installable package, one entry point

- **Goal**: `memdb` is a Python package with a `pyproject.toml`, a
  `python -m memdb` entry, console scripts, package-data schema, and
  hooks as entry points, while every existing command line keeps working.
- **Inputs**: `memdb/mem.py`, `memdb/journal.py`, `memdb/redact.py`,
  `memdb/schema.sql`, `memdb/hooks/session_start.sh`,
  `memdb/tests/conftest.py`, `memdb/tests/*.py`, `.gitignore`, W-15.
  Independent of every S-MQ step; first step of the plan.
- **Deliverables**:
  - `pyproject.toml` at the repository root: `[project] name = "memdb"`,
    `version` read from `memdb/__init__.py` (`__version__ = "1.0.0"`),
    `requires-python = ">=3.9"`, no dependencies,
    `[project.scripts] mem = "memdb.mem:main"`, `memdb-hook =
    "memdb.hooks:main"`, setuptools backend, package data
    `schema.sql` and `templates/*.md`, `tests`, `bench` and `docs`
    excluded from the wheel.
  - `memdb/__init__.py` (`__version__`), `memdb/__main__.py` (calls
    `mem.main`), `memdb/mem.py` and `memdb/journal.py` importing siblings
    as `from . import journal` with an `except ImportError` fallback to
    the flat import, so `python memdb/mem.py` still runs; `init_schema`
    reads `schema.sql` through `importlib.resources` (works inside a
    wheel and a `.pyz`); `mem --version` prints the package version;
    `doctor` reports it.
  - `memdb/paths.py`: single source of every location: `home()` =
    `MEMDB_HOME` or `~/.claude/memory`; `db_path()`, `journal_root()`,
    `sessions_dir()`, `host_id_file()`, `config_path()`, `embcache_path()`,
    `derived_dir()`, `install_backups_dir()`, `sync_log()`; `mem.py` and
    `journal.py` call these instead of their own constants
    (`MEMDB_PATH` and `MEMDB_JOURNAL` remain honoured overrides).
  - `memdb/hooks/__init__.py` with `main(argv)`: subcommand
    `session-start` reimplementing `session_start.sh` in Python (same
    stdin JSON, same `hookSpecificOutput`, same markers, same
    `MEMDB_HOOK_SCOPE` stand-down, same exit-0 contract, no shell);
    `memdb/hooks/session_start.sh` becomes a transition wrapper for one
    release: it resolves the interpreter as `$MEMDB_PYTHON` if set, else
    the first of `python3`, `python`, `py -3` that runs `import sqlite3`;
    sets `PYTHONPATH` to its own directory's `../..` (the checkout root)
    so `-m memdb` imports without an install; execs `-m memdb hook
    session-start`; on any failure prints the existing `[memdb: ...
    UNAVAILABLE]` marker and exits 0. Rationale: the hook registration on
    all three hosts and the laptop and pi cron lines set no environment
    variable and run from a foreign cwd, and they keep calling the shell
    entry points until S-PKG-05 re-registers them.
  - `mem hook <name>` as a CLI alias of `memdb-hook <name>`, so the
    `.pyz` form `python memdb.pyz hook session-start` works.
  - `memdb/tests/conftest.py`: imports `from memdb import mem, journal`
    with the repository root on `sys.path`; every test file switches its
    `import mem` / `import journal` accordingly; a new
    `memdb/tests/test_package.py`: `python -m memdb --version` works from
    a temp cwd, `schema.sql` loads via resources, `python memdb/mem.py
    init` (flat form) still works, `hook session-start` produces the
    same JSON as the bash script for the same stdin (golden fixture),
    the transition wrapper produces that JSON from a foreign cwd with
    `MEMDB_PYTHON` unset and `PYTHONPATH` empty (skipped where no
    `bash` is on PATH, marker `wrapper-needs-bash`).
  - `.gitignore`: `dist/`, `build/`, `*.egg-info/`.
  - `memdb/docs/perf-budgets.md`: startup budget row `cli_start_ms`
    (`python -m memdb --version`) < 150 ms, measured.
- **Acceptance criteria**:
  - `pip install --user <memdb-checkout>` (or `pipx install`) puts `mem`
    on PATH and `mem doctor` on the real store prints `ok` with the
    version.
  - Without installing: `python -m memdb doctor` from the repository root
    and `python <memdb-checkout>/memdb/mem.py doctor` print identical
    reports.
  - The 187 existing tests pass under the new import layout, plus
    `test_package.py`.
  - `mem hook session-start` under 300 ms on the real store (the current
    bash hook budget is the 20 s timeout; the measurement is recorded).
- **Gate / review reference**: memdb test suite; full oracle unchanged
  (no data change).
- **Definition of done**: `pip install` of the checkout gives a working
  `mem` on the workstation and every old command line still works.

### S-PKG-02: config, install command, harness adapters

- **Goal**: `mem install` performs the whole of `install/AGENT_INSTALL.md`
  idempotently from one config, for Claude Code and Codex, with backups
  and a printed report, and `mem install --check` shows the diff without
  touching anything.
- **Inputs**: S-PKG-01, `install/AGENT_INSTALL.md` (steps 2-10 are the
  specification), `install/memdb-skill.template.md`,
  `install/memory-persistence-rule.template.md`, `memdb/hooks/README.md`
  (registration snippet), `memdb/docs/hub-config.md` (Cadence), the
  user-level `~/.claude/settings.json` shape (hooks, `autoMemoryEnabled`,
  `env`), D-4, D-8, D-9.
- **Deliverables**:
  - `memdb/config.py`: `<memdb-home>/config.json` with keys `host_id`
    (mirrors the `host-id` file, which stays the identity source of
    truth for `journal.host_id()`), `hub` (`{"mode": "join" | "new" |
    "standalone", "url": ...}`), `harnesses` (list of `claude-code`,
    `codex`, `generic`), `interpreter` (absolute `sys.executable` at
    install), `command_form` (`"mem"`, `"interpreter"` or `"pyz"`, D-9),
    `pyz_path` (set only for the `pyz` form), `embed`
    (`{"url", "model", "dim", "enabled"}`), `schedule`
    (`{"kind": "windows-task" | "cron" | "launchd" | "none", "time":
    "HH:MM"}`), `version`; `mem config get|set|show`; every module reads
    through `config.get()`, environment variables still win;
    `config.command(cmd, *args) -> list[str]` returns the argv for the
    configured form and is the ONLY producer of command lines written
    into hooks, schedules, the MCP snippet, the skill and the rule block.
  - `memdb/templates/skill.md` and `memdb/templates/rule.md` moved from
    `install/` into the package (package data), placeholders reduced to
    `{{MEM}}` (the command form of D-9), `{{HOST_SLUG}}`, `{{SKILL_PATH}}`;
    `{{SYNC_SH}}` replaced by `{{MEM}} sync`; no other placeholder. The
    rendered skill of one host is byte-identical to another host's when
    both resolve `mem` on PATH.
  - `memdb/harness/__init__.py`, `claude_code.py`, `codex.py`,
    `generic.py`: each adapter implements `paths()`, `render()` (skill
    and rule block into the harness's locations), `register_hooks(spec)`
    (Claude Code: merge the memdb entries into `~/.claude/settings.json`
    `hooks` by a stable `memdb` marker in the command string, set
    `autoMemoryEnabled: false`, leave every other key JSON-equal (the
    file is re-serialised with `json.dump(indent=2, ensure_ascii=False)`
    plus a trailing newline, so byte identity is not promised; `--check`
    prints the unified diff so formatting-only changes are visible);
    Codex: write `~/.codex/rules/end_of_job_handoff.md` and ensure the
    `AGENTS.md` include line; generic: print what to add), `check()`
    (what is missing or stale), `unregister()`. Every write of a user
    file copies the original to `<memdb-home>/install-backups/<yyyy-mm-dd>-<name>.bak`
    first.
  - `memdb/install.py`: `mem install --host <slug> --hub <join <url> |
    new <hub-ssh-spec> | standalone> [--harness claude-code,codex]
    [--schedule HH:MM|none] [--check] [--yes]`: preflight (Python >= 3.9,
    `sqlite3` with FTS5, git present, interpreter path, and for hub modes
    `join` and `new` an `ssh -o BatchMode=yes <hub host> true` probe
    whose failure names the missing key or host and stops before any
    file is written), `mem selftest` (S-PKG-04) before
    wiring anything, host-id file, journal repo init on
    `<slug>/journal`, hub remote (`new` creates the bare repos over ssh:
    `git init --bare -b main` for `memdb.git` and
    `memory-journal.git`), `mem init`, first `mem sync` (the unborn-branch
    quirk of AGENT_INSTALL step 7 is handled inside `mem sync`: an empty
    own branch skips the push leg with a notice instead of failing),
    adapters render and register, schedule install, install episode
    (`--project memdb --part install --task install-<slug>`), final
    `verify` and `doctor`; prints the AGENT_INSTALL final-report
    checklist as JSON; re-running changes nothing and says so.
    `mem uninstall [--keep-data]` reverses the adapters and the schedule,
    never touches journals or the DB unless `--purge-data` is given and
    confirmed.
  - `mem schedule install|remove|status`: Windows `schtasks /Create /XML`
    with a task XML generated from `memdb/templates/task.xml` (daily at
    `HH:MM`, `StartWhenAvailable`; the `schtasks` flags alone cannot set
    `StartWhenAvailable`), Linux `crontab` line, macOS launchd plist, all
    running `config.command("sync", "--scheduled")`; `status` prints
    whether the entry exists and the last `sync.log` line.
  - `install/AGENT_INSTALL.md` rewritten to: preflight, obtain the
    artifact, `pip install` or `python memdb.pyz install ...`, answer the
    three parameters, read the report; `install/PROMPT.txt` updated;
    `install/README.md` describes the two artifacts. The ten manual steps
    are gone from the guide and live in `install.py`.
  - `memdb/docs/hub-config.md`: Cadence section points at
    `mem schedule`; the hand-written `Register-ScheduledTask` and cron
    lines stay as the reference of what the command creates.
  - `memdb/tests/test_install.py`: with `HOME`, `USERPROFILE` and
    `MEMDB_HOME` redirected to `tmp_path`: standalone install creates
    every file, second run is a no-op, `--check` on a modified settings
    file reports the diff and writes nothing, backups exist, Codex
    adapter output, `uninstall --keep-data` leaves the journal, the
    settings merge preserves unrelated hooks JSON-equal and in their
    original key order (fixture = the shape of the workstation's settings
    with the personal paths replaced), the `pyz` command form renders
    `"<interpreter>" "<pyz_path>" <cmd>` everywhere and never `-m memdb`.
- **Acceptance criteria**:
  - On the workstation, `mem install --check` reports only the expected
    differences (hook command form, rule block `{{MEM}}` form); `mem
    install --yes` applies them; a fresh session's transcript shows the
    SessionStart attachment from the Python hook and no bash process.
  - The rendered `~/.claude/skills/memdb/SKILL.md` and the CLAUDE.md rule
    block contain no path of the checkout (checked by `mem redact-check`
    plus a test asserting the absence of `<memdb-checkout>`'s real
    value).
  - `mem install` on a temp HOME completes standalone in under 60 s and
    `mem doctor` there is green with zero records.
  - Tests pass.
- **Gate / review reference**: memdb test suite; D-4 (the settings diff
  quoted in the episode).
- **Definition of done**: one command installs memdb on a machine with a
  temp HOME and re-running it is a no-op.

### S-PKG-03: sync and every hook in Python, bash retired

- **Goal**: Replication, the scheduled entry point and every harness hook
  run with the interpreter alone, on Windows without Git Bash, with the
  same guarantees the shell scripts give today.
- **Inputs**: `memdb/sync/memdb_sync.sh` (222 lines: the specification,
  steps 0-5 and 4b), `memdb/sync/scheduled_sync.sh`,
  `memdb/tests/test_sync_guards.py`, `memdb/hooks/__init__.py`
  (S-PKG-01), `memdb/docs/hub-config.md`, the 2026-08-28 concurrency
  finding (lock semantics). Depends on S-PKG-01, S-PKG-02.
- **Deliverables**:
  - `memdb/sync.py`: `mem sync [--full-verify] [--scheduled]`
    reimplementing every check of the shell script with `subprocess`
    calls to `git` and direct calls into `mem`: host identity guard,
    journal root and `.git` presence, shallow-clone refusal, own-branch
    checkout, commit own journal, push (never `--force`; unborn branch
    handled), fetch with prune, per-host fast-forward assertion against
    `.git/memdb-last-seen/<host>`, head comparison via
    `journal.head_of_bytes` (no `mem journal-head` subprocess), atomic
    materialisation with `os.replace`, `rebuild --verify` under one lock
    (full oracle on the cadence stamp `.git/memdb-last-full-verify` or
    `--full-verify`), `consolidate --expire-states` after a green full
    oracle, `render-core`, exit 0 only when every step succeeded; every
    message text unchanged so `sync.log` readers and tests keep matching;
    `--scheduled` appends the timestamp header and exit line to
    `sync.log` (replaces `scheduled_sync.sh`).
  - `memdb/sync/memdb_sync.sh` and `scheduled_sync.sh`: transition
    wrappers for one release with the same interpreter resolution and
    `PYTHONPATH` rule as the hook wrapper of S-PKG-01, execing `-m memdb
    sync [--scheduled]`; a failure to find an interpreter prints
    `memdb-sync: FAIL no python interpreter` and exits 1 (a sync may
    fail loudly; a hook may not). `hub-config.md` and the skill say
    `mem sync`.
  - `memdb/tests/test_sync_guards.py`: runs `python -m memdb sync` via
    `subprocess` with the same redirected environment; the four existing
    guard tests keep their assertions; the `mv` shim test becomes a
    monkeypatched `os.replace` failure; the `bash` skip marker is gone.
  - `memdb/tests/test_hooks_py.py`: `hook session-start` golden output,
    stand-down with `MEMDB_HOOK_SCOPE=project`, unavailable DB marker,
    empty-scope marker, carriage returns stripped; runtime under 300 ms.
- **Acceptance criteria**:
  - One real `mem sync` on the workstation prints `memdb-sync: ok
    (host=workstation)`; `sync.log` gains a `--scheduled` entry from the
    re-registered daily task that names no `bash.exe`.
  - Before S-PKG-05: one cron-triggered run on the laptop and one on the
    pi through the unchanged cron line and the transition wrapper prints
    `memdb-sync: ok` in their `sync.log` (no environment change on
    either host).
  - Laptop and pi cron lines replaced by `mem schedule install` (via
    S-PKG-05 deployment) and their `sync.log` show `memdb-sync: ok`.
  - `test_sync_guards.py` runs on Windows without bash on PATH (verified
    with a PATH lacking Git's `usr/bin`).
  - Tests pass.
- **Gate / review reference**: memdb test suite; one real sync per host.
- **Definition of done**: no memdb function on any host requires bash.

### S-PKG-04: versioned artifacts, selftest, cross-host version guard

- **Goal**: A release is a versioned, checksummed pair of artifacts built
  by a stdlib script, any machine can prove the tool works before wiring
  it, and hosts on incompatible versions are told before they break.
- **Inputs**: S-PKG-01..03, `memdb/journal.py` (`write_witness`,
  `witness_checkpoints`), `memdb/mem.py` (`APPLIERS`, `cmd_doctor`),
  `memdb/bench/run_bench.py` as a stdlib-runner pattern, D-7.
- **Deliverables**:
  - `tools/build_release.py` (stdlib): reads `__version__`, builds
    `dist/memdb-<version>.pyz` with `zipapp` (`__main__` = `memdb.mem:main`,
    package data included, tests/bench/docs excluded), builds
    `dist/memdb-portable-<version>.zip` (the package tree plus `install/`,
    `pyproject.toml`, the `.pyz`, `LICENSE` if present), writes
    `dist/SHA256SUMS`; builds the wheel with `pip wheel . --no-deps -w
    dist` when pip and setuptools are available and reports if not
    (the wheel is optional, the `.pyz` is not); refuses to build with a
    dirty working tree unless `--allow-dirty`.
  - `mem selftest`: stdlib-only smoke run in a temp `MEMDB_HOME`: init,
    add, record-episode, close, supersede, rebuild --full, verify --full,
    digest, search, hook session-start; prints one JSON line; exit 1 on
    any failure; used by `mem install` preflight (pytest remains the
    full gate, never required on a target machine).
  - Version guard: `write_witness` adds `"memdb_version"` and
    `"event_types": [...]` (the types this host's journal contains) to
    `witness-heads.json`; `mem sync` warns `memdb-sync: host <h> runs
    memdb <v> which cannot replay event type <t> written by <host2>`
    when another host's witness shows a version below the package's
    `MIN_VERSION_FOR_EVENT_TYPE` table (module constant in `mem.py`,
    one entry per event type introduced after 1.0.0); `doctor` prints
    the fleet version table.
  - `memdb/docs/release.md`: how to build, what each artifact is, the
    compatibility rule (a newer package always replays older journals;
    an older package refuses unknown event types; upgrade every host
    before writing a new type), the upgrade procedure per install form
    (`pip install --upgrade`, replace the `.pyz`), and the changelog
    entry format; `CHANGELOG.md` at the repository root starting at
    1.0.0.
  - `memdb/tests/test_release.py`: the build script produces both
    artifacts and the checksum file in a temp dir; `python
    memdb-<v>.pyz --version` and `python memdb-<v>.pyz selftest` pass
    from a cwd outside the checkout; the version guard warns on a fixture
    witness with an older version.
- **Acceptance criteria**:
  - `python tools/build_release.py` on the workstation produces
    `dist/memdb-1.0.0.pyz`, `dist/memdb-portable-1.0.0.zip`,
    `dist/SHA256SUMS`, and the wheel (pip present); sizes recorded in
    the episode.
  - `python dist/memdb-1.0.0.pyz selftest` passes from `C:\` and from
    `/tmp` on the laptop.
  - `mem doctor` on the workstation shows all three hosts' versions after
    S-PKG-05.
- **Gate / review reference**: memdb test suite; the artifacts are the
  input of S-PKG-05.
- **Definition of done**: a `.pyz` built by the script passes `selftest`
  on a machine that has never seen the checkout.

### S-PKG-05: fresh-machine acceptance and fleet migration

- **Goal**: The artifact installs and operates on a machine with no prior
  memdb state, joins the hub, records, syncs and fires hooks, and the
  three real hosts run the package instead of the checkout.
- **Inputs**: S-PKG-01..04 artifacts, a scratch bare hub (pattern from
  `test_sync_guards.py`), the laptop and the pi (SSH reachable), the
  workstation, `install/AGENT_INSTALL.md` (rewritten), D-4, D-6.
- **Deliverables**:
  - `memdb/tests/test_fresh_machine.py` (marked `slow`, run explicitly):
    with `HOME`/`USERPROFILE`/`MEMDB_HOME` redirected to a temp dir and
    the `.pyz` as the only memdb code on `sys.path`: `install --host
    fresh --hub new <local bare path>`, then `add`, `record-episode`,
    `sync`, `verify --full`, `hook session-start` with a Claude-shaped
    stdin, `install` again (no-op), `uninstall --keep-data`; a second
    temp host joins the same hub and sees the first host's episode in
    `search`.
  - `memdb/docs/audits/<yyyy-mm-dd>-fresh-machine.md`: the transcript
    of one manual run on Windows (workstation, temp HOME) and one on
    Linux (laptop, temp HOME) from the `.pyz` alone, with timings and
    the report JSON.
  - Fleet migration, in this order and recorded in the episode: the
    artifacts travel by `scp` from the workstation `dist/` to
    `<host>:~/memdb-release/<version>/` and `sha256sum -c SHA256SUMS`
    must pass there before anything is installed (commands and the
    checksum lines quoted in the episode); laptop
    and pi `pip install --user` (or the `.pyz`) the release, `mem install
    --host <their slug> --hub join <hub-ssh-spec> --yes` (host-id files
    already exist and must match), `mem rebuild --full`, `mem verify
    --full`, `mem schedule install` replacing the cron line; then the
    workstation the same way, replacing the `memdb-sync-daily` task;
    every host's `sync.log` shows `memdb-sync: ok`; the old absolute-path
    hook registration and rule block are gone from all three
    `settings.json` and CLAUDE.md files (backups kept).
  - `install/README.md`: the origin line updated with the release
    version and the fresh-machine result.
- **Acceptance criteria**:
  - `test_fresh_machine.py` green on Windows and Linux.
  - The manual runs complete with no step outside `mem install`'s
    report; no file was edited by hand.
  - `mem doctor` on the workstation lists three hosts on the same
    version; `mem search --project memdb --part install` lists the three
    install episodes of the migration.
  - Two consecutive scheduled syncs green on every host (`sync.log`).
- **Gate / review reference**: fresh-machine test; user review of the
  three settings diffs (D-4); full oracle on every host.
- **Definition of done**: a machine that never saw this checkout runs
  memdb from the artifact alone, and the three real hosts run the same
  release.

## Steps: memory-quality track

Every deliverable below is written against the S-PKG layout: hooks are
subcommands of `memdb/hooks/__init__.py` registered by the harness
adapter, the sync is `memdb/sync.py`, templates live in
`memdb/templates/`, paths come from `memdb/paths.py`, and the MCP server
is a package entry point.

### S-MQ-01: paraphrase eval and retrieval telemetry

- **Goal**: Retrieval quality is measured on queries that do NOT reuse the
  stored wording, and every later retrieval change is gated by that
  number.
- **Inputs**: `memdb/tests/test_search_eval.py`,
  `memdb/tests/eval/queries.jsonl`, `memdb/docs/perf-budgets.md`,
  `~/.claude/projects/*/<session>.jsonl` transcripts of the last 60 days
  (read for their first user prompt only), W-01, W-10. Independent of
  every other S-MQ step.
- **Deliverables**:
  - `memdb/mem.py` `cmd_transcript_prompts` (`mem transcript-prompts
    --days 60 [--project <slug>]`): stdlib JSONL reader over
    `~/.claude/projects/*/*.jsonl` printing one JSON line per session
    (`session_id`, project via `project-slug` of the transcript cwd,
    first user prompt <= 300 chars, date). This is the only sanctioned
    way to harvest prompts on the workstation: `head`, `sed` and
    windowed reads are blocked by the read-policy hook. The reader
    module is shared with S-MQ-03's `draft-episode`.
  - `memdb/tests/eval/paraphrase.jsonl`: at least 40 lines of
    `{"query": ..., "expect_uids": [...], "project": optional, "source":
    "transcript-prompt" | "authored"}`. Rule for authoring: the query is
    written from the task as the user phrased it (transcript first prompt)
    or by the worker WITHOUT opening the expected record's body; the
    expected uids are resolved afterwards by `mem search` and `mem get`.
    At least 10 queries must share no token with the expected record's
    subject or body (checked by a test helper).
  - `memdb/tests/test_search_eval.py`: a second eval over
    `paraphrase.jsonl` printing hit@1, hit@5, MRR and the zero-overlap
    subset separately; the real-store run under `MEMDB_EVAL_REAL=1`;
    budget assertion `paraphrase_hit5 >= 0.80` marked expected-fail until
    S-MQ-04 lands (a skip marker with the step id, not a silently lowered
    number).
  - `memdb/mem.py` `cmd_eval` (`mem eval [--set stored|paraphrase|all]`):
    runs the eval sets against the live DB and prints one JSON line per
    set; `memdb/sync.py` runs `eval --set all` after a green rebuild and
    appends the line to the sync output so `sync.log` carries a weekly
    recall number.
  - `memdb/docs/perf-budgets.md`: rows `paraphrase_hit5` (budget 0.80),
    `paraphrase_zero_overlap_hit5` (reported, gated at 0.60 after S-MQ-04)
    with the baseline measured by this step.
- **Acceptance criteria**:
  - `paraphrase.jsonl` has >= 40 queries, >= 10 zero-overlap; the helper
    test proves the overlap property.
  - `mem redact-check memdb/tests/eval/paraphrase.jsonl` exits 0 before
    the file is committed (prompts come from private transcripts; the
    repo has a third-party remote).
  - The baseline numbers for both sets are written into
    `perf-budgets.md` with the date.
  - The stored-wording eval is unchanged (hit@5 0.943 on the real store).
  - One sync run prints the eval line and `sync.log` contains it.
- **Gate / review reference**: memdb test suite; perf budgets.
- **Definition of done**: `mem eval --set paraphrase` prints a baseline on
  the real store and the sync log carries the number.

### S-MQ-02: next steps and achievements reach the digest

- **Goal**: A resuming agent sees the latest handoff's next steps and
  summary in the session-start digest without opening an episode payload.
- **Inputs**: `memdb/mem.py` (`apply_episode`, `digest_lines`, `KINDS`,
  `validate_episode_doc`), `memdb/schema.sql` (kind CHECK),
  `memdb/tests/test_episode.py`, `memdb/tests/test_digest.py`,
  `memdb/templates/skill.md`, W-04. Lands schema version 5. Every later
  schema change bumps again (S-MQ-04 to 6, S-MQ-09 to 7, S-MQ-10 to 8)
  and each bump costs one `rebuild --full` per host (3.5k events,
  seconds). A shared version number across steps was rejected: a v5 DB
  built before S-MQ-09 would fail with SQL errors on the new columns
  instead of the clean `init_schema` refusal.
- **Deliverables**:
  - `memdb/schema.sql`: kind CHECK gains `'next'`; `SCHEMA_VERSION = 5`
    in `memdb/mem.py`; `init_schema` refusal text unchanged (rebuild, not
    migrate); package version bumped to 1.1.0 with
    `MIN_VERSION_FOR_EVENT_TYPE` untouched (no new event type).
  - `memdb/mem.py` `cmd_record_episode`: payload `"extract": "explicit-v2"`.
    `apply_episode`: when `extract == "explicit-v2"`, each `next_steps`
    item (string, or dict with `step` and optional `subject`) becomes a
    row of kind `next`, status `open`, `source_record` = the episode,
    uid `<episode-uid>/<n>`; before inserting, every open `next` row of
    the same (project, part) whose `source_record` is an OLDER episode is
    set `superseded` with `superseded_by` = the new episode id (a handoff
    replaces the previous handoff's to-do list). Events with
    `extract == "explicit"` or absent replay exactly as today.
  - `memdb/mem.py` `digest_lines`: `- (e <uid>) <subject> (<date>):
    <snip(body, 120)>` for episode lines; new trimmable section `## Next
    steps (latest handoff)` rendered directly after `## Recent episodes`,
    open `next` rows of the scope ordered by `created_at DESC, id`,
    capped at `SECTION_CAP`; `--part` scoping applies. `cmd_search`,
    `search_rows` and `compute_consolidate` accept the new kind without
    change (verified by test). `close <uid>` works on `next` rows.
  - `memdb/mem.py` `validate_episode_doc`: `next_steps` items are strings
    or dicts with a string `step`.
  - `memdb/templates/skill.md` and the rendered skills (re-rendered by
    `mem install`): section 5 says next steps become open `next` rows
    superseded by the next handoff of the same part, and that a finished
    next step is closed with `close <uid>`.
  - `memdb/tests/test_episode.py`: v1 event replays with no `next` rows;
    v2 event creates them; a second v2 episode in the same part supersedes
    the first's open `next` rows and leaves another part's rows open.
    `memdb/tests/test_digest.py`: the section renders after Recent
    episodes, the episode line carries the summary snippet, the section
    is trimmed before pinned rows. `memdb/tests/test_init.py`: version 5
    refuses a v4 DB.
- **Acceptance criteria**:
  - `mem rebuild --full` then `mem verify --full` green on the real store;
    the record count is unchanged (old events create no `next` rows).
  - One real `record-episode` with three next steps shows a `## Next steps
    (latest handoff)` section with three lines in `mem digest --project
    <p> --part <part>`.
  - The digest for that project stays within its budget (`est_tokens` of
    the output <= 1,500 with default settings).
  - Tests pass.
- **Gate / review reference**: memdb test suite; full oracle; D-6 for the
  fleet rebuild.
- **Definition of done**: a fresh session's digest shows the previous
  session's next steps as lines with uids.

### S-MQ-03: harness-side capture (no session ends unrecorded)

- **Goal**: A session that did work but never ran `record-episode` still
  leaves a journaled, searchable episode, and unrecorded sessions are
  visible at the next session start.
- **Inputs**: `memdb/hooks/__init__.py`, `memdb/harness/claude_code.py`,
  `memdb/mem.py` (`cmd_record_episode`, `resolve_provenance`,
  `validate_episode_doc`, `apply_episode`), `<memdb-home>/sessions/<id>.json`,
  Claude Code hook events `Stop` (stdin: `session_id`, `transcript_path`,
  `stop_hook_active`) and `SessionEnd` (stdin adds `reason`), transcript
  JSONL format (`type` user/assistant, `message.content` blocks with
  `tool_use` name and input), W-02, D-3, D-4. Depends on S-MQ-02 (payload
  version field).
- **Deliverables**:
  - `memdb/mem.py` `cmd_draft_episode` (`mem draft-episode --session-id
    <id> [--transcript <path>]`): parses the transcript with stdlib only
    (the shared reader of S-MQ-01), incrementally: the byte offset
    reached is stored as `transcript_offset` in `sessions/<id>.json` and
    only the appended tail is parsed on the next call (a file shorter
    than the offset resets it to 0), so `hook stop` cost is proportional
    to the turn, not to the transcript;
    finds the explicit record = the last Bash `tool_use` whose command
    contains `record-episode` OR the last MCP tool use named
    `memdb_record_episode` (S-MQ-11), and counts tool uses after it,
    EXCLUDING memdb's own calls: Bash commands that invoke `mem `,
    `mem.py`, `memdb_sync.sh`, `memdb.pyz` or `-m memdb`, and MCP tools
    whose name starts with `memdb_` (the mandatory sync call after every
    `record-episode` must not turn a compliant session into a draft);
    writes `<memdb-home>/sessions/<id>.draft.json` when the count is
    >= 1 for Write/Edit/NotebookEdit/Bash or >= 10 in total; the draft
    holds `{project (via project-slug of the transcript cwd), task (slug
    of the first user prompt, 60 chars), files (paths from Write/Edit
    inputs, deduplicated, repo-relative when under the cwd), last_text
    (the final assistant text block, ASCII-transliterated, <= 2,000
    chars), tool_count, last_tool_ts, first_prompt (<= 300 chars)}`.
    Never journals. Exits 0 on every path and prints one JSON line.
  - `memdb/mem.py` `cmd_flush_drafts` (`mem flush-drafts [--idle-minutes
    30] [--dry-run] [--session-id <id>]`): for every draft whose
    transcript has not changed for `--idle-minutes` (or whose
    `sessions/<id>.json` carries `ended_at`), and for which no episode
    with that `session_id` exists with `created_at` after `last_tool_ts`,
    journals an episode with payload `"extract": "auto"`, project from
    the draft, part `auto`, task `[auto] <task-slug>`, doc `{achievement:
    files, current_state: {summary: last_text[:500]}, raw_markdown:
    first_prompt + last_text, next_steps: []}`; `apply_episode` with
    `extract == "auto"` creates the episode row only (no children); the
    draft is renamed to `<id>.draft.done.json`. Prints the uids
    journaled.
  - `memdb/hooks/__init__.py` subcommands `stop` (runs `draft-episode`
    only when `stop_hook_active` is false; 5 s cap) and `session-end`
    (writes `ended_at` and `reason` into `sessions/<id>.json`, runs
    `draft-episode`, then `flush-drafts --idle-minutes 0 --session-id
    <id>`); both exit 0 always. `memdb/harness/claude_code.py` registers
    them (`Stop`, `SessionEnd`) through `mem install`; the hook README
    documents both contracts.
  - `memdb/sync.py` step 0b: `flush-drafts` (default idle 30 minutes)
    before committing the own journal, so crashed or killed sessions are
    flushed by the daily sync at the latest.
  - `memdb/hooks/__init__.py` `session-start`: appends the marker
    `[memdb: N sessions since <date> ended without an episode - mem
    flush-drafts --dry-run lists them]` when `sessions/*.draft.json`
    exist; `cmd_doctor` check `unrecorded_sessions`.
  - `memdb/mem.py` `digest_lines`: `[auto]` episodes render in Recent
    episodes like others; `search` results carry `"auto": true` for them.
  - `memdb/tests/test_auto_episode.py`: a fixture transcript with an
    explicit `record-episode` followed by two edits yields a draft; one
    with the record as the last tool use yields none; flush with an idle
    transcript journals one `[auto]` episode with zero children; flush
    twice journals nothing new; a v1 replay of the fixture journal is
    unchanged; non-ASCII in the transcript is transliterated and the
    validator accepts the doc; the `stop` and `session-end` hook
    subcommands produce the expected files from Claude-shaped stdin.
- **Acceptance criteria**:
  - A print-mode session that edits one file and exits without
    `record-episode` produces, after `flush-drafts --idle-minutes 0`, one
    episode `[auto] ...` findable by `mem search --query "<a word from the
    first prompt>"`.
  - A session that ran `record-episode` followed only by the sync
    command (the memdb-rule sequence) produces no draft and no auto
    episode; the fixture for this case is in `test_auto_episode.py`.
  - `mem verify --full` green after one week of auto episodes.
  - `hook stop` completes under 1 s on a first pass over a 5 MB
    transcript and under 100 ms on a subsequent pass with a 1 KB tail
    (both measured, recorded in the step episode).
  - Tests pass; the settings diff produced by `mem install` is quoted in
    the episode (D-4).
- **Gate / review reference**: memdb test suite; full oracle; D-3, D-4.
- **Definition of done**: `mem doctor` reports zero unrecorded sessions
  older than 30 minutes on the workstation two days running.

### S-MQ-04: hybrid retrieval (bm25 + local embeddings, projection-only)

- **Goal**: A paraphrase finds the record; vectors are a disposable
  projection cache that never touches the journal or the appliers, and a
  host without the backend degrades to lexical search.
- **Inputs**: `memdb/mem.py` (`search_rows`, `cmd_search`, `fts_query`,
  `cmd_rebuild`, `projections_equal`, `_norm_record_cursor`),
  `memdb/schema.sql`, `memdb/sync.py`, `memdb/config.py` (`embed` keys),
  ollama HTTP API (`POST /api/embed`, body `{"model", "input": [..]}`,
  response `{"embeddings": [[..]]}`), S-MQ-01 eval sets, W-01, D-1, D-2.
  Depends on S-MQ-01 (gate) and S-MQ-02 (schema bump).
- **Deliverables**:
  - Pre-condition, first action of the step: `ollama show
    nomic-embed-text` output quoted in the step episode. The 256-dim
    truncation of D-1 stands only if the served model is v1.5
    (Matryoshka-trained); if it is v1, `dim` is 768 and D-1 is amended
    in this file before any vector is written. Texts are prefixed with
    nomic's task prefixes, `search_document: ` when stored and
    `search_query: ` for the query; the prefix is part of `text_sha`.
  - `memdb/schema.sql`: `SCHEMA_VERSION = 6` (new table below).
  - `memdb/embed.py` (stdlib): `embed_texts(texts, model=None, url=None,
    dim=256, timeout=20)` batching 64 texts per request to
    `config.embed.url` (default `http://localhost:11434`) `/api/embed`
    with `config.embed.model` (default `nomic-embed-text`), truncating
    each vector to `dim` and L2-normalising, returning `None` when the
    server is unreachable or the model is missing (one-line stderr
    notice); `pack(vec) -> bytes` / `unpack(bytes)` via `array('f')`;
    `dot(a, b)` via `sum(map(operator.mul, a, b))`.
  - `memdb/schema.sql`: `records_vec (id INTEGER PRIMARY KEY REFERENCES
    records(id) ON DELETE CASCADE, model TEXT NOT NULL, dim INTEGER NOT
    NULL, text_sha TEXT NOT NULL, vec BLOB NOT NULL)`; excluded from
    `_norm_record_cursor` / `projections_equal` and from `cmd_export`
    unless `--with-vectors`.
  - `<memdb-home>/embcache.sqlite` (created by `embed.py`, path from
    `paths.embcache_path()`): `(model, text_sha) -> vec`, so a rebuild
    re-embeds nothing already seen; it lives outside the journal git tree
    (`<memdb-home>/journal`), `doctor` lists it as expected and asserts
    it is not tracked by the journal repo.
  - `memdb/mem.py` `cmd_embed` (`mem embed [--pending|--all] [--limit N]`):
    text = `subject + "\n" + body + "\n" + (rationale or "")` capped at
    1,500 chars; embeds rows without a vector for the current model (or
    whose `text_sha` changed), cache first; prints counts; exits 0 with
    `"backend": "unavailable"` when ollama is down. `write_event` calls
    `embed --pending` best-effort for the rows it just wrote AFTER the
    journal lock is released (never fails the write, 5 s cap, skipped
    when `config.embed.enabled` is false; `append_ms` is measured up to
    lock release and excludes it);
    `memdb/sync.py` runs `embed --pending` after a green rebuild;
    `cmd_rebuild` copies vectors forward from the live DB by `(uid,
    text_sha)` before swap, so a rebuild does not drop coverage.
  - `memdb/mem.py` `search_rows`: when `records_vec` has coverage >= 50 %
    of the candidate scope and the query embeds, stage A = bm25 top 100
    with the existing status/age scaling, stage B = cosine top 100 over
    the scope (project/part/kind/status filters applied in SQL first),
    fused by reciprocal rank (k = 60) then divided by the same status and
    age factors, tie-break `id`; `--lexical` forces stage A only;
    results carry `"via": "bm25" | "vec" | "both"`. `fts_query` also adds
    prefix terms (`token*`) for tokens >= 5 chars so inflections match.
  - `mem install` writes `embed.enabled` true only when the backend
    answers at install time (`--embed off` forces false); `doctor`
    reports backend reachability, model and coverage.
  - `memdb/docs/perf-budgets.md`: `search_p50_ms` 300 for project-scoped
    hybrid, 100 unchanged for `--lexical`, with the D-2 rationale; rows
    `embed_coverage` (>= 0.95 of open rows after sync) and
    `paraphrase_hit5` gated at 0.80, `paraphrase_zero_overlap_hit5` at
    0.60; `memdb/tests/bench_scale.py` gains `vec_scan_ms` (stage B over
    100k synthetic vectors, reported, budget set from the measurement)
    because stage B is a full scan of the scope in pure Python.
  - `memdb/tests/test_hybrid_search.py`: a fake embed server (stdlib
    `http.server` in a thread) returning deterministic vectors; fusion
    order; `--lexical`; unavailable backend degrades to bm25 with the
    notice; rebuild carries vectors forward; `projections_equal` ignores
    `records_vec`; cache hit avoids a second request; `embed.enabled`
    false skips every request.
- **Acceptance criteria**:
  - Real store: `mem eval --set paraphrase` hit@5 >= 0.80 and the
    zero-overlap subset >= 0.60; `--set stored` hit@5 >= 0.90.
  - The 2026-09-13 paraphrase probe returns `workstation:3324` at rank 1.
  - `search --project <p>` p50 <= 300 ms over the eval queries on the real
    store; `--lexical` p50 <= 100 ms.
  - `mem verify --full` green with vectors present (they are outside the
    comparison); `rebuild --full` keeps coverage >= 0.95.
  - Laptop and pi (no ollama): `mem search` works, prints the backend
    notice once, and `doctor` reports `embed: unavailable`.
- **Gate / review reference**: memdb test suite; perf budgets; retrieval
  eval; D-1, D-2.
- **Definition of done**: the paraphrase gate is green on the real store
  and both evals are in the sync log.

### S-MQ-05: task-aware recall at prompt time

- **Goal**: Memory relevant to what the user just asked is injected when
  the prompt arrives, bounded, deduplicated per session, without waiting
  for the agent to search.
- **Inputs**: `memdb/mem.py` (`search_rows`, `digest_lines`, `snip`),
  `memdb/hooks/__init__.py`, `memdb/harness/claude_code.py`,
  `<memdb-home>/sessions/<id>.json`, Claude Code `UserPromptSubmit` hook
  (stdin: `session_id`, `cwd`, `prompt`; output
  `hookSpecificOutput.additionalContext`), S-MQ-04, W-06, W-13, D-4.
  Depends on S-MQ-04 (quality) but functions on bm25 alone.
- **Deliverables**:
  - `memdb/mem.py` `cmd_recall` (`mem recall --project <slug> --query -
    [--part <p>] [--budget-tokens 800] [--exclude-file <path>]`): query
    read from stdin (prompt text is untrusted; never on the command line);
    skips prompts under 4 indexable tokens or starting with `/`; runs
    `search_rows` with `status` open plus episodes, limit 20; drops uids
    listed in the exclude file; keeps hits whose fused rank is within the
    top 8 and whose score is within 2x of the best; renders
    `# Memory recall for this prompt` with one line per hit `- (<kind
    initial> <uid>) <snip(body, 200)>` plus `-- why:` for decisions;
    stops at the budget; appends `[recall: N more - mem search --query
    "..."]` when trimmed; prints nothing when no hit passes.
  - `memdb/hooks/__init__.py` subcommand `user-prompt`: reads the hook
    JSON, resolves the project with `project-slug --cwd`, runs `recall`
    in-process with `--exclude-file sessions/<id>.recall.json`, appends
    the injected uids to that file, caps the per-session total at 4,000
    tokens (then injects nothing more), 2 s cap, exit 0 always; failure
    shows as `[memdb recall UNAVAILABLE]` only on the first prompt.
    `memdb/harness/claude_code.py` registers it (`UserPromptSubmit`).
    `hook session-start` seeds `sessions/<id>.recall.json` with every
    uid it injected in the digest, so recall never repeats a pinned row
    (`workstation:3324` is a pinned global constraint and would otherwise
    be injected twice in every session).
  - `memdb/mem.py` `digest_lines`: `Current state` and `Live decisions`
    sections are reduced to `SECTION_CAP = 8` by default when the
    `user-prompt` hook is registered (`config.harnesses` records it),
    since recall now serves the long tail; the `--budget-tokens` default
    stays 1,500.
  - Hook README: the fourth hook, its budget, the per-session cap and the
    exclusion file.
  - `memdb/docs/perf-budgets.md`: `recall_hook_ms` p50 < 300 on the real
    store (measured over the eval queries through `hook user-prompt`).
  - `memdb/tests/test_recall.py`: budget respected; exclusion works across
    two calls; slash-command and short prompts produce no output; the
    per-session cap; a prompt containing shell metacharacters is inert
    (query passed via stdin); the hook subcommand's JSON envelope.
- **Acceptance criteria**:
  - A fresh session whose first prompt is a paraphrase of a NON-pinned
    record (chosen by the worker with `mem search`, named in the step
    episode) shows a `# Memory recall for this prompt` block containing
    that uid in its transcript JSONL (hook attachment); the block contains
    no uid present in that session's SessionStart attachment; the second
    prompt in the same session does not repeat it. `workstation:3324` is
    not a valid probe target here because the digest already injects it.
  - `recall_hook_ms` p50 < 300 on the real store.
  - Session start context (rules file + digest) does not grow: `est_tokens`
    of the SessionStart attachment <= its S-AUD-04 value for FO4RE (1,202
    tokens with `--no-global`).
  - Tests pass; the settings diff quoted in the episode (D-4).
- **Gate / review reference**: memdb test suite; perf budgets; D-4.
- **Definition of done**: the first prompt of a session pulls the
  relevant constraint into context without any agent action.

### S-MQ-06: near-duplicate write gate and fuzzy consolidation

- **Goal**: A reworded fact confirms or supersedes its predecessor instead
  of becoming a sibling, deterministically under replay, and the existing
  near-duplicates are merged once.
- **Inputs**: `memdb/mem.py` (`gated_insert`, `apply_add`, `apply_episode`
  `item_fields`, `compute_consolidate`, `cmd_consolidate`, `norm_body`),
  `memdb/tests/test_consolidate.py`, `memdb/tests/test_replay_order.py`,
  W-03, D-5. Depends on S-MQ-02 (payload versioning pattern); the CLI
  proposal part uses S-MQ-04 vectors when present.
- **Deliverables**:
  - `memdb/mem.py` `similar(a, b) -> float`: deterministic text
    similarity on `norm_body` = max(`difflib.SequenceMatcher(None, a,
    b).ratio()`, token-set Jaccard); no randomness, no network.
  - `memdb/mem.py` `gated_insert(..., gate=1)`: with `gate == 2`, when no
    exact (project, kind, subject) open match exists, candidates = open
    rows of the same (project, kind, part) ordered by
    `last_confirmed_at DESC` limit 300, pre-filtered by token-set
    Jaccard >= 0.5 and `SequenceMatcher.quick_ratio()` before `ratio()`
    runs (full `ratio()` over 300 bodies does not fit the 20 ms budget);
    the best candidate with `similar >= 0.90` is CONFIRMED
    (last_confirmed_at bumped, same return as today) ONLY IF the two
    normalised bodies also have the same multiset of digit tokens and
    the same set of negation tokens (`not`, `never`, `no`, `without`,
    `off`, `disable`, `disabled`); a pair that fails that check falls
    through to SUPERSEDE, because "timeout 60s" vs "timeout 30s" or
    "always" vs "never" are different facts at similarity 0.97; with
    `0.75 <= similar < 0.90` it is SUPERSEDED by
    the new row (link `supersedes`); below 0.75 a plain insert. Thresholds
    and the token lists are module constants; the gate version is read
    from the event payload
    (`"gate": 2` written by `cmd_add` and `cmd_record_episode` from this
    step on); events without the field replay with the exact rule.
  - `memdb/mem.py` `cmd_add`: prints `"gate": "confirmed-similar" |
    "superseded-similar"` with the matched uid and similarity; `--no-gate`
    writes `"gate": 1` for a deliberate sibling.
  - `memdb/mem.py` `compute_consolidate(..., fuzzy=False)`: with
    `--fuzzy`, groups open rows of the same (project, kind) by
    `similar >= 0.85` (union-find, oldest row kept), and when vectors
    exist proposes an extra `review` list of pairs with cosine >= 0.92
    that the text rule did not catch (never auto-applied); `--dry-run
    --fuzzy --out <path>` writes the report as
    `memdb/docs/audits/<yyyy-mm-dd>-fuzzy-consolidate.md`; applying writes
    ONE `consolidate` event whose payload lists the merges (the applier
    is unchanged).
  - `memdb/tests/test_similarity_gate.py`: reworded constraint confirms
    (>= 0.90); the same wording with one number changed supersedes
    instead of confirming; a negation flip supersedes; partial rewrite
    supersedes; unrelated inserts; replay of a
    mixed v1/v2 journal is byte-identical to the live projection;
    determinism across two replays; performance: 300-candidate gate under
    20 ms.
  - `memdb/tests/bench_scale.py`: `append_ms` budget unchanged (50 ms)
    measured with gate 2 payloads.
- **Acceptance criteria**:
  - `mem verify --full` green after deployment (old events unchanged).
  - `mem add` of a paraphrased open constraint reports
    `confirmed-similar` with the original uid; record count unchanged.
  - The fuzzy report on the real store is applied (D-5); open non-episode
    rows drop by the merged count and nothing is deleted (total record
    count unchanged).
  - `append_ms` stays under 50 ms at 100k events.
- **Gate / review reference**: memdb test suite; full oracle; scale
  budgets; D-5.
- **Definition of done**: a reworded fact cannot create a sibling row
  without `--no-gate`, and the one-time merge is journaled.

### S-MQ-07: relevance-based retention and blocker triage

- **Goal**: What stays pinned and what is offered for closing is driven by
  use and confirmation, not by age alone, and open blockers have a triage
  path.
- **Inputs**: `memdb/mem.py` (`cmd_get`, `cmd_recall`, `digest_lines`
  pinned cap, `compute_consolidate`, `cmd_doctor`), `memdb/journal.py`
  `derived_path`, `memdb/sync.py`, W-05, W-06, W-12. Depends on S-MQ-05
  (recall counts as a read).
- **Deliverables**:
  - `memdb/mem.py` `reads` sidecar at `derived/<host>/reads.json`
    `{uid: {"n": int, "last": ts}}`, updated by `get` and by every uid
    `recall` injected; written atomically; never journaled, never
    replayed, safe to delete (documented in `hub-config.md` Journal root
    layout); `derived/` is listed in the journal repo's `.gitignore`,
    asserted by a test and by `doctor`, so read counters never replicate.
  - `memdb/mem.py` `digest_lines`: pinned eviction order becomes (origin
    `user` never evicted) then ascending `(reads.n, last_confirmed_at)`;
    the omission marker is unchanged.
  - `memdb/mem.py` `cmd_triage` (`mem triage --project <p> [--kind
    blocker|decision|next|state] [--older-than 90] [--limit 50]`): lists
    open rows with uid, age in days, reads, parent episode subject and
    date, and a proposal `close` when the parent episode's project has >=
    3 newer episodes in the same part and the row has zero reads, else
    `keep`; `--out <path>` writes the table as Markdown; `--apply <path>`
    reads a reviewed table whose `decision` column says `close` or `keep`
    and journals one `close` event per `close` line, printing the uids.
  - `memdb/sync.py`: after the weekly full oracle prints one line
    `memdb-sync: triage <N> open blockers older than 90 days in <M>
    projects (mem triage --project <largest>)`.
  - `memdb/templates/skill.md` section 4: monthly runbook "`mem triage
    --project <p> --out <scratch>`, review, `--apply`".
  - Rows added by `add --kind state` default to `confidence unverified`
    unless `--confidence confirmed` (so the 90-day demotion rule finally
    has input); `cmd_add` writes the resolved value into the event
    payload so `apply_add` is unchanged and old events replay as before;
    `record-episode` children stay `confirmed`; auto
    episodes (S-MQ-03) have no children.
  - `memdb/tests/test_retention.py`: read counting, eviction order with
    a user row, triage proposal rule, `--apply` writes only the `close`
    lines, sidecar deletion is harmless.
- **Acceptance criteria**:
  - `mem triage --project TaktflowBMS --kind blocker --older-than 90
    --out <scratch>` lists the 487 rows with proposals; after review and
    `--apply`, the digest count line drops accordingly and no record is
    deleted.
  - A user-origin constraint is never dropped from the pinned block at
    any budget (test).
  - `mem verify --full` green (sidecar excluded).
- **Gate / review reference**: memdb test suite; full oracle; user review
  of the triage table before `--apply`.
- **Definition of done**: pinned eviction uses reads, and one triage round
  has been applied through journaled close events.

### S-MQ-08: part canonicalisation

- **Goal**: Two jobs on the same work area land in the same part, and a
  new part is a deliberate choice, not a typo.
- **Inputs**: `memdb/mem.py` (`known_projects`, `resolve_project_slug`,
  `cmd_record_episode`, `cmd_add`, `core_lint`), W-07. Independent of
  S-MQ-03..07.
- **Deliverables**:
  - `memdb/mem.py` `known_parts(project)`: `{lower: most recently written
    spelling}` from `records`; `cmd_part_slug` (`mem part-slug --project
    <p> --part <text> [--paths a,b,c]`): exact or case-insensitive known
    match wins; else the closest known part by `difflib.get_close_matches`
    (cutoff 0.8) is printed with `"suggested": true`; else the input
    slugified with `"new": true`.
  - `cmd_record_episode` and `cmd_add`: a `--part` that is new for the
    project prints a stderr warning naming up to 5 closest existing parts;
    `--part-new` silences it; `MEMDB_STRICT_PART=1` turns the warning
    into exit 2 (for hooks and scripts).
  - `core_lint`: new section `part_split` listing case-split and
    near-duplicate parts per project (pairs with `get_close_matches`
    ratio >= 0.85) with the canonical spelling and the row counts, as a
    read-only proposal; re-homing is done by `add`/`supersede` events on
    user approval, as in S-AUD-04.
  - `memdb/tests/test_part_slug.py`: exact, case-split, close match, new
    part, strict mode.
- **Acceptance criteria**:
  - `mem core-lint` on the real store lists the part splits with counts
    (the number recorded in the step episode).
  - `record-episode --part Memdb` on project `Memory-orchestration`
    warns and names `memdb`.
  - Tests pass.
- **Gate / review reference**: memdb test suite.
- **Definition of done**: a near-duplicate part cannot be written silently.

### S-MQ-09: validity intervals and path references

- **Goal**: Every fact carries when it stopped being true, "as of" queries
  work, and records can be found by the file or component they concern.
- **Inputs**: `memdb/schema.sql`, `memdb/mem.py` (`apply_close`,
  `apply_supersede`, `apply_consolidate`, `gated_insert`, `apply_episode`,
  `search_rows`, `cmd_get`, `_norm_record_cursor`), W-08, D-6. Depends on
  S-MQ-02 (schema 5).
- **Deliverables**:
  - `memdb/schema.sql`: `SCHEMA_VERSION = 7`; `valid_to TEXT` (NULL while
    open) and `refs TEXT` (JSON list of path or component strings) on
    `records`; `records_fts` gains column `refs`; triggers updated.
    `write_witness` records `schema_version`, and `mem sync` reports a
    head mismatch against a host on another schema version as
    `version-skew` (informational) rather than drift, so the rollout
    window between hosts is quiet.
  - `memdb/mem.py` appliers: `apply_close`, `apply_supersede`,
    `apply_consolidate` and the supersede branch of `gated_insert` set
    `valid_to = ev["ts"]` (the journal event timestamp, deterministic on
    replay); `apply_episode` sets `refs` on the episode row and its
    children from `current_state.files_touched`; `apply_add` from
    payload `refs` (`add --refs a.c,b.h`); old events fill `valid_to`
    from their own timestamps on replay, so the column is populated
    historically without a migration.
  - `memdb/mem.py` `search_rows(..., as_of=None)` and `cmd_get --as-of
    <date>`: filter `created_at <= as_of AND (valid_to IS NULL OR valid_to
    > as_of)`; `cmd_search --as-of`.
  - `memdb/mem.py` `cmd_about` (`mem about <term> [--project <p>]`): rows
    whose `refs` or `subject` contain the term (FTS on `refs` weighted
    3.0, subject 5.0), open first, one line each; also used by `recall`
    when the prompt names a path that exists under the cwd.
  - `memdb/mem.py` `links`: `record-episode` payload `relates`
    (list of uids) becomes `relates` links from the episode; `add
    --relates <uid,...>` likewise; `get` prints the record's links both
    ways.
  - `_norm_record_cursor` and `projections_equal` include the new
    columns (they are deterministic).
  - `memdb/tests/test_validity.py`: `valid_to` set by close, supersede,
    consolidate; `--as-of` before and after; `refs` from files_touched;
    `about` by path; `relates` links round-trip through replay.
- **Acceptance criteria**:
  - `mem rebuild --full` then `verify --full` green on every host (D-6);
    every superseded or closed row has a non-null `valid_to` (one SQL
    count = 0 nulls, recorded in the episode).
  - `mem get workstation:2666 --as-of 2026-08-30` returns the row as open;
    `--as-of 2026-09-13` returns it as superseded.
  - `mem about journal.py --project Memory-orchestration` lists the
    episodes that touched it.
- **Gate / review reference**: memdb test suite; full oracle; D-6.
- **Definition of done**: an "as of" query and a by-path query both work
  on the real store.

### S-MQ-10: agent identity and user confirmation

- **Goal**: Every record says which agent asserted it, and the user can
  confirm or reject a fact with one journaled command.
- **Inputs**: `memdb/schema.sql`, `memdb/mem.py` (`cmd_add`,
  `cmd_record_episode`, `apply_add`, `apply_episode`, `APPLIERS`,
  `MIN_VERSION_FOR_EVENT_TYPE`, `digest_lines`, `cmd_search`),
  `memdb/harness/*.py` (exported environment), W-09, D-6. Depends on
  S-MQ-02 (schema 5) and S-PKG-04 (version guard). Requires every host on
  the new package before the first `confirm` event.
- **Deliverables**:
  - `memdb/schema.sql`: `SCHEMA_VERSION = 8`; `agent TEXT NOT NULL
    DEFAULT 'unknown'` on `records`; payloads carry `agent` resolved in
    this order: `--agent <id>`, else `MEMDB_AGENT`, else detection from
    environment the harness already exports (Claude Code's Bash tool
    sets `CLAUDECODE=1` and `CLAUDE_CODE_ENTRYPOINT`, mapped to
    `claude-code`; Codex's exported variables mapped to `codex`; the
    exact variable names are confirmed with `env` in each harness at
    step start and quoted in the episode, detection_basis = that
    output), else `unknown`; the hook subcommands pass `--agent
    claude-code` explicitly. No environment injection through
    `settings.json` or the rule block: neither survives a Windows hook
    shell or a hand-typed CLI call. Old events project `unknown`.
  - New event type `confirm` `{uid, verdict: "confirmed" | "rejected",
    ts, origin}` with `apply_confirm`: `confirmed` sets `confidence
    confirmed`, `origin user`, bumps `last_confirmed_at`; `rejected` sets
    `status closed` and `valid_to`. CLI `mem confirm <uid>` and `mem
    reject <uid> [--reason]` (reason stored in payload and appended to
    `rationale`). `MIN_VERSION_FOR_EVENT_TYPE["confirm"]` = this
    release's version; `mem confirm` refuses to write while `doctor`'s
    fleet table shows a host below it (override `--i-know-all-hosts-upgraded`).
  - `digest_lines` and `cmd_search`: rows show `agent` in `--full` output;
    the digest tag stays ` u` for user origin.
  - `memdb/docs/release.md`: the deployment order (upgrade every host,
    `mem rebuild --full`, then first `confirm`).
  - `memdb/tests/test_confirm.py`: confirm and reject replay; unknown
    event type on old code fails loudly (regression guard that the
    APPLIERS map is consulted); agent default and override; the refusal
    when a fixture witness shows an older host.
- **Acceptance criteria**:
  - Laptop and pi upgraded and rebuilt before the first `confirm` event is
    journaled (checked by `mem doctor`'s fleet version table).
  - `mem confirm workstation:3324` changes its origin to `user` in the
    digest tag; `verify --full` green.
- **Gate / review reference**: memdb test suite; full oracle; D-6.
- **Definition of done**: one confirmed and one rejected record exist and
  replay identically on all three hosts.

### S-MQ-11: MCP server for other harnesses

- **Goal**: Any MCP-capable harness reaches memdb without shell access,
  with the same read-only and write commands and the same output shapes,
  through a package entry point.
- **Inputs**: `memdb/mem.py` (`search_rows`, `cmd_recall`, `cmd_get`,
  `cmd_about`, `cmd_add`, `cmd_record_episode`, `cmd_confirm`), the stdio
  JSON-RPC pattern of `$DISTILL_HOME/distill_mcp.py`,
  `memdb/harness/generic.py`, W-11. Independent; after S-MQ-05 and
  S-MQ-09 for tool coverage.
- **Deliverables**:
  - `memdb/mcp.py` (stdlib) with `mem mcp` as its entry: stdio JSON-RPC
    2.0 server exposing `memdb_search`, `memdb_recall`, `memdb_get`,
    `memdb_about`, `memdb_add`, `memdb_record_episode` (document passed
    as JSON, same validation), `memdb_confirm`; each tool returns the
    same JSON the CLI prints; writes go through `write_event` under the
    journal lock; every request opens and closes its own SQLite
    connection and no file handle on `mem.db` survives between requests
    (invariant above: sync and rebuild `os.replace` the DB, which fails
    on Windows while a handle is open; a test runs a rebuild while the
    server idles between two requests and both requests succeed).
  - `memdb/harness/generic.py`: `mem install --harness generic` prints
    the MCP registration snippet from `config.command("mcp")` (so the
    `pyz` form renders correctly) for
    `~/.claude.json` or any harness's MCP config; `memdb/docs/mcp.md`
    documents the tool list and that the CLI stays the reference.
  - `memdb/tests/test_mcp.py`: initialize handshake, tools/list, a search
    call, a rejected record-episode (validation error surfaces in-band).
- **Acceptance criteria**:
  - A session with the server registered lists the seven tools and a
    `memdb_search` call returns the same uids as the CLI for the same
    query.
  - Tests pass.
- **Gate / review reference**: memdb test suite; user approval for the
  MCP registration (user-level config).
- **Definition of done**: one real `memdb_record_episode` through MCP is
  visible in `mem digest`.

### S-MQ-12: redaction coverage at the publish boundary

- **Goal**: Rendered or exported memory can be redacted mechanically,
  including site-specific names, before it leaves the private domain.
- **Inputs**: `memdb/redact.py`, `memdb/mem.py` (`cmd_render_handoff`,
  `cmd_export`, `cmd_redact_check`), `memdb/paths.py`,
  `rules/never_commit_private_data.md`, W-14. Independent.
- **Deliverables**:
  - `memdb/redact.py`: loads `<memdb-home>/redact-extra.txt` (path from
    `paths.py`, `MEMDB_REDACT_EXTRA` overrides) with lines
    `<placeholder>=<literal>` or `<placeholder>=re:<regex>` (comments and
    blanks ignored); built-in patterns extended with Windows UNC user
    paths and `<user>@<host>` shell prompts; `check_text` reports the
    pattern name; patterns are never weakened (test pins the existing
    fixtures).
  - `memdb/mem.py`: `render-handoff --redact` and `export --redact` write
    the redacted text and print the hit count; without the flag the
    warning stays.
  - `memdb/tests/test_redact.py`: extra-file literals and regexes, the
    new built-ins, `--redact` outputs contain no hit.
- **Acceptance criteria**:
  - `mem redact-check` on a `--redact` rendered handoff of the last
    workstation episode exits 0.
  - Existing redact fixtures unchanged and passing.
- **Gate / review reference**: memdb test suite.
- **Definition of done**: a rendered handoff can be made hit-free by one
  flag.

## Explicitly deferred (watch items with triggers)

- **LLM-assisted extraction of episodes** (summaries, decision mining from
  transcripts): trigger = auto episodes (S-MQ-03) exceed 30 % of all
  episodes over a month, meaning the explicit path is losing. Design when
  triggered: a local model via ollama produces the structured doc, the
  result goes through the same validator and `record-episode`, marked
  `extract: "llm"`, never inside an applier.
- **Hybrid logical clock for cross-host order** (F-21 of the audit plan):
  unchanged trigger, a second host writing >= 50 events per month.
- **Entity table** (components, tools, people as first-class rows):
  trigger = `mem about` misses because the same component is named three
  ways in `refs` in more than 10 % of a project's rows. Design when
  triggered: `entities (id, name, aliases)` in the projection, derived
  from `refs` by a deterministic alias file in the journal.
- **Journal segment rotation**: S-MEM-SCALE-07, unchanged trigger.
- **Reducing the standing text below 3.5k tokens** (W-13): revisit after
  S-MQ-05 has run for a month; measure whether the digest can shrink to
  pinned rows plus next steps when recall is active.
- **Signed releases and a package index**: trigger = a fourth machine or
  a second person installs memdb. Design when triggered: `SHA256SUMS`
  signed with the user's key, artifacts published on the self-hosted hub
  as a git tag, `mem install --from <url>` verifying the checksum.
- **Encrypted transport for a third-party hub**: option (b) of
  `plans/2026-08-15-lossless-memory-architecture.md`; trigger = the user
  wants a hub that is not self-hosted.

## Status

- 2026-09-13: plan written from the weakness review recorded as episode
  `workstation:3518`. No step started. Decisions D-1 to D-6 pending.
  Baseline table above is the reference for every "unchanged" acceptance
  criterion.
- 2026-09-13: decisions D-1 to D-6 delegated by the user ("you decide")
  and taken by the worker; see the Decisions section (episode
  `workstation:3520`).
- 2026-09-13: requirement added by the user: "packagable and usable as is
  in another machine". The plan gained the S-PKG-01..05 track (executed
  first), weakness W-15, decisions D-7 to D-9 (taken under the same
  delegation), the portability invariant, and every S-MQ deliverable was
  re-targeted at the package layout (Python hook subcommands registered by
  a harness adapter, `memdb/sync.py`, `memdb/templates/`,
  `memdb/paths.py`, `mem mcp`). Facts, thresholds and acceptance numbers
  of the S-MQ steps are unchanged. No step started.
- 2026-09-13: review pass (episode `workstation:3522`) folded in. Changes:
  per-step schema bumps 5/6/7/8 with `version-skew` reporting; three
  command forms including `pyz` and the `config.command()` single
  producer; transition wrappers with interpreter fallback and
  `PYTHONPATH`; S-MQ-03 excludes memdb's own tool calls and MCP records
  from the draft rule and parses incrementally; S-MQ-06 CONFIRM requires
  equal digit and negation tokens plus a prefilter; S-MQ-05 session-start
  seeds the recall exclusion file and the probe target is a non-pinned
  row; S-MQ-04 nomic v1.5 check, task prefixes, embed after lock release,
  `vec_scan_ms`; S-MQ-11 per-request DB connections; S-PKG-02 JSON-equal
  settings merge, task XML, ssh preflight; S-MQ-01 `transcript-prompts`
  helper and redact-check; S-MQ-10 agent detection from harness
  environment; S-PKG-05 scp plus checksum transfer; two execution
  tranches with S-PKG-04/05 in tranche 2. No step started.
- 2026-09-13: S-PKG-01 committed (`7b41e35`). The TaktflowBMS field test
  finished; its numbers and triage are in the section "Field test
  2026-09-13". User decision, 2026-09-13: release 1.0.0 is cut after the
  packaging sweep (S-PKG-02..05, including every packaging blocker of the
  field test), ahead of S-MQ-01..05, overriding the tranche gate of
  "Execution order and cut line"; memory-quality findings are mapped to
  their owning steps here and fixed in release 1.1.0 on branch
  `workstation/memdb-quality`. Weaknesses W-16..W-21 added, unassigned.
- 2026-09-13: S-PKG-02 and S-PKG-03 landed as ONE commit, noted here as
  the job rules require: `memdb/mem.py` carries the parsers of both steps
  (install, uninstall, schedule, config for S-PKG-02; sync for S-PKG-03)
  and the hashed-subject and bare-local-id fixes in the same hunks, so it
  cannot be split without an interactive add. The commit also closes the
  field-test packaging blockers P-01..P-16 (triage file outside the repo).
  Deviations from the step text, each covered by a test: the templates
  gained one extra placeholder `{{LOCAL_ADDITIONS}}` (host additions from
  `<memdb-home>/local/<file>` survive every render); the default schedule
  name `memdb-sync-daily` is used only when `MEMDB_HOME` is unset, any
  other home gets `memdb-sync-daily-<hash8>` and no OS schedule unless
  `--schedule` is explicit; the rule template names `verify` and `doctor`
  in the installed command form; the wrapper tests skip when the only
  bash on PATH is the WSL launcher. Laptop and pi keep their 03:17
  cadence by passing `--schedule 03:17` at migration (S-PKG-05).
  Pre-commit self-review fixed four more defects in the same commit,
  each test-first: the `mem` command form records the absolute path of
  `mem` (`mem_path`; cron and Task Scheduler have a minimal PATH); a
  `mem`-form hook is recognised on re-install and by the project-scope
  stand-down (it was duplicated); `--hub "new <ssh-spec>"` creates the
  repository origin points at, after a probe; install preflight runs the
  recorded command from a temporary directory without `PYTHONPATH` and
  stops when it cannot start this memdb version.
- 2026-09-13: S-PKG-04 committed (`83ef593`): `tools/build_release.py`,
  `mem selftest`, the version guard, `docs/release.md`, `CHANGELOG.md`.
  S-PKG-05 fresh-machine half committed (`508ee8c`), which is the 1.0.0
  release commit: `test_fresh_machine.py` green on Windows and on the
  laptop (284 passed there in a throwaway venv), audit
  `docs/audits/2026-09-13-fresh-machine.md`. The first laptop run found
  four defects, all fixed before the release commit and listed in the
  audit (F-1..F-5). Artifacts built from `508ee8c`: the `.pyz`
  (89,805 bytes, byte-identical to the tested candidate), the wheel
  (87,148 bytes) and the portable zip (1,024,491 bytes), with
  `SHA256SUMS`. Fleet migration done in order laptop, pi, workstation
  (install episodes `laptop:5`, `pi:3`, `workstation:3531`; step episode
  `workstation:3532`): laptop and pi on the `.pyz` form (pip refuses
  `--user` there) with cron at 03:17; workstation on the wheel, its
  editable install removed, Windows task at 12:00; `rebuild --full` and
  `verify --full` green on every host; `mem doctor` lists all three
  hosts on 1.0.0. Host-specific skill text moved to
  `<memdb-home>/local/skill.md`. Deviation: the Stage 5 stop before
  applying the three diffs was not taken, because the user's instruction
  for this job forbade asking for permission; the diffs are kept with the
  job's evaluation data outside the repository. Pending acceptance of
  S-PKG-05: two consecutive green scheduled syncs on every host (first
  observable 2026-09-14). Defects ranked for 1.1.0: the Codex adapter
  appends its AGENTS.md reference even when an include of the same rule
  file exists; install backups collide by basename (the Claude and Codex
  `SKILL.md`); the pi keeps a stale `~/.claude/rules/memdb-core-global.md`
  now that its core rules render under `<memdb-home>/rules/`.
- 2026-09-13: release 1.0.1 (`e625e53`). A fresh Claude Code session on
  the workstation after the 1.0.0 migration logged the SessionStart hook
  as `C:Python314python.exe: command not found`: Claude Code runs hook
  commands through Git Bash, which drops the backslashes of an unquoted
  Windows path. The S-PKG-02 acceptance item "a fresh session's
  transcript shows the SessionStart attachment from the Python hook" had
  not been checked against a real session before 1.0.0. Fix, test-first:
  `config.quote()` writes forward slashes and quotes drive paths on
  Windows; a test runs the installed `settings.json` command through Git
  Bash and cmd.exe. Artifacts from `e625e53`: `.pyz` 89,907 bytes and
  portable zip 1,026,502 bytes, both byte-identical to the tested
  candidate; wheel 87,249 bytes. Fleet upgraded in order laptop, pi,
  workstation (install episodes `laptop:6`, `pi:4`, `workstation:3533`).
  Linux hosts changed only the `.pyz` copies and `config.json`; the
  workstation rewrote the hook, both skills, both rule blocks and the
  task command. `rebuild --full` and `verify --full` green on every host,
  and `mem doctor` lists all three hosts on 1.0.1. A new `claude -p`
  session's transcript shows `hook_success` for `SessionStart:startup`
  (exit 0) and the digest as additional context. Part B branches from
  `e625e53`, not from `508ee8c`. Pending acceptance of S-PKG-05 is
  unchanged; the exact check is on each host, after 2026-09-15 03:17
  (laptop, pi) or 12:00 (workstation): `mem schedule status` shows
  `exists: true`, and the host's `<memdb-home>/sync.log`, read in full,
  has two consecutive `--scheduled` entries dated on different days, each
  ending `memdb-sync: ok (host=<host>)` followed by `== exit 0 ==`.

# memdb + distill audit follow-up plan

## How to read this

Audience: an AI worker landing cold, with no prior conversation context.
Every step below is self-contained and carries: Step ID, Goal, Inputs,
Deliverables (concrete file paths), Acceptance criteria (independently
checkable), Gate / review reference, Definition of done. Execute the steps
in numeric order unless a step says it is independent; the order is the
priority order derived from the audit severities. Gates used by this plan:
the memdb test suite (`memdb/tests/`, run `python -m pytest tests -q` from
`memdb/`), the full oracle (`mem verify --full` and `mem rebuild --verify
--full` on the real store), the scale budgets (`memdb/tests/bench_scale.py`,
table in `memdb/docs/perf-budgets.md`), the distiller suite
(`$DISTILL_HOME/tests/test_distiller.py`), the hook fixture suite
(`~/.claude/hooks/tests/test_hooks.py`), and user review for every change
to user-level configuration, rule files, or stored data. Rules in force:
the user-level CLAUDE.md (STRICT MODE and the memory-persistence rule),
`rules/multi-host-agent-workflow.md` H1-H8, and
`rules/never_commit_private_data.md`.

Path placeholders used throughout (never write personal absolute paths
into files of this repo):

- `<memdb-checkout>`: the clone of this repository, the directory that
  contains `memdb/`.
- `$DISTILL_HOME`: the text distiller directory (`tools/text_distiller`
  inside the CUS-BMS repository; the env var is set in the user-level
  settings). `<cus-bms-repo>` is that repository's root.
- `<drive-root>`: the workspace root that holds a `.claude/rules/` folder
  loaded by sessions started there (the parent of this checkout).
- `~`: the user profile directory.
- `<yyyy-mm-dd>` in a deliverable name: the date the step is executed.

Source of the findings: the 2026-09-13 audit, recorded as episode
`workstation:3177` (`mem get workstation:3177` prints the full record; its
13 state children carry the measurements) and constraint
`workstation:3176`. The register below repeats every finding so this file
is self-contained.

## Baseline (measured 2026-09-13, workstation)

| measure | value |
|---|---|
| records / open | 18,896 / 12,065 |
| events by host | workstation 3,174; laptop 3; pi 1 |
| open blockers / goals+blockers older than 30 days | 1,180 / 1,095 |
| open `state` rows older than 60 days | 793 |
| episodes with transcript hash / with session id | 13 / 225 of 2,080 |
| core-setup digest tokens, global / TaktflowBMS / FO4RE | ~4,400 / ~6,500 / ~32,000 (budget setting 1,500) |
| global lines repeated into every project digest | 30 lines, ~17.7 KB |
| core-setup rows with disallowed kinds | 17 |
| user-level CLAUDE.md / user rules tokens | ~4,700 / ~2,200 |
| memdb tests / distiller tests | 108 pass / 62 pass |
| doctor / verify | ok / ok (snapshot mode) |
| enforce_full_reads probe | 6 of 8 legitimate commands blocked; 21 of 28 bypasses allowed |
| distiller search / find over 894 files | 0.2-0.6 s / 0.13 s |

## Invariants this plan must not break

- The journal is append-only and hash-chained; events are never rewritten.
- Full replay of all journals is the definition of truth. Any applier
  change must leave the projection of EXISTING events unchanged: new
  behaviour is keyed on a payload field that old events do not carry.
- Every fast path (snapshot, anchors) stays provably equal to full replay.
- Capture is full-fidelity; no redaction inside the memory domain.
- Records are never deleted; supersede or close only.
- mem.py and the distiller stay Python stdlib only.
- No `--force`, `git reset --hard`, journal edits, or DB edits by hand.
- Nothing in this repo may contain personal absolute paths, IPs, or emails.

## Findings register

| id | sev | where | finding | closed by |
|---|---|---|---|---|
| F-01 | high | `memdb/journal.py` verify_chain, `memdb/mem.py` cmd_rebuild | A journal truncated at the tail passes verify: no floor against anchor, witness, or manifest seq; a stale anchor falls back to a passing full walk; `save_anchor` then lowers the anchor; `rebuild --verify` treats drift as informational and swaps the shrunken DB in; sync prints ok | S-AUD-01 |
| F-02 | high | `memdb/mem.py` write_event, apply_all | record-episode appends before validating; a list-typed `current_state` or non-list decisions raises at apply; apply_all catches only MissingRef and IntegrityError, so every later rebuild and verify tracebacks and the journal cannot be repaired | S-AUD-02 |
| F-03 | med | `memdb/sync/memdb_sync.sh`, `journal.py` host_id | Foreign-host journals are overwritten unconditionally; `MEMDB_HOST` silently overrides the host-id file; a failed `mv` still advances the last-seen ref; a failed `git checkout` falls through | S-AUD-11 |
| F-04 | med | `memdb/journal.py` iter_lines | A torn last line raises inside every rebuild, verify, and doctor call (traceback, not a loss report) | S-AUD-11 |
| F-05 | med | `memdb/mem.py` apply_episode, cmd_supersede, cmd_close | Blocker auto-close is a substring match on a 60-char slug; supersede accepts cross-project and cross-kind targets; close overwrites a superseded status | S-AUD-12 |
| F-06 | high | `memdb/mem.py` digest_lines | Pinned rows are uncapped (`budget = max(budget, used + 600)`); bodies up to 3,092 chars; 30 global lines repeated in every project digest; FO4RE digest ~32k tokens; the tool result exceeds the harness output cap and is paid twice | S-AUD-04 |
| F-07 | med | `memdb/mem.py` cmd_search | bm25 over OR-joined tokens with no status or recency term: a superseded row ranked first for a natural query about the grep ban and the open constraint was outside the top 5; a migration prefix consumes the 160-char snippet | S-AUD-05 |
| F-08 | med | `memdb/mem.py` apply_episode, consolidate | Every episode status line becomes an open `state` row; no importance gate, no decay; `--expire-states` is opt-in and has run once | S-AUD-06 |
| F-09 | med | core-setup data | 17 rows of disallowed kinds in core-setup parts; 34 projects carry core-setup; case-split slugs (FO4RE/fo4re) inflate digests via NOCASE matching | S-AUD-04 |
| F-10 | low | `memdb/mem.py` record-episode, schema | Transcript provenance on 13 of 2,080 episodes; no origin tier (user-stated vs agent-inferred) | S-AUD-13 |
| F-11 | high | `memdb/hooks/session_start.sh`, settings | No SessionStart hook in user-level settings; the only registration (this repo's `.claude/settings.json`) uses `$CLAUDE_PROJECT_DIR/memdb`, which does not resolve; `basename` on a Windows cwd yields the whole path as slug; default digest is whole-project, not core-setup; open state `workstation:1/6` has said this since 2026-08-15 | S-AUD-03 |
| F-12 | high | user-level settings | `autoMemoryEnabled` not false: the harness injects built-in auto-memory instructions every session and 6 stale MEMORY.md files remain under `~/.claude/projects/*/memory/` | S-AUD-03 |
| F-13 | med | user-level CLAUDE.md, rules | ~7k tokens of standing instructions; the grep policy is stated in five places; the memdb procedure (~1.8k tokens) lives in CLAUDE.md instead of a skill | S-AUD-10 |
| F-14 | med | `<drive-root>/.claude/rules/session-management.md`, `install/memory-persistence-rule.template.md`, Codex rule | A rule prescribes a session-memory MCP that is not configured and prefers offset/limit reads (opposite of the hook); the install template and the Codex rule predate the core-setup layer and runbooks | S-AUD-10 |
| F-15 | med | fleet | laptop 3 events, pi 1; no scheduled sync task; sync is end-of-job only; ~54 MB of stray probe DB copies in `~/.claude/memory/` | S-AUD-14 |
| F-16 | high | `$DISTILL_HOME/distiller/search.py` | The byte prescan is compiled without MULTILINE, so `^`/`$` patterns return 0 matches with exit 0 (`search "^def " distiller -l` -> 0; unanchored -> 61) | S-AUD-07 |
| F-17 | high | `~/.claude/hooks/enforce_full_reads.py`, allowlist | First-token blacklist: blocks `git diff \| head`, `tail -f`, `ls *.py` while allowing `python -c`, `bash -c "grep"`, `perl`, `cut`, `more`, `sqlite3`, `git log -L`, `tree`; the allowlist `path:/scratchpad/` matches anywhere in a command, so a trailing comment unlocks any banned command | S-AUD-08 |
| F-18 | high | `$DISTILL_HOME/distill_hook.py`, `<cus-bms-repo>/.claude/settings.json` | The project hook denies whole reads over 8,000 bytes and allows windows up to 250 lines; the global hook denies windows; in that repo a large file is readable neither way; README rule 4 and the skill rules 2-3 disagree; the whole-file mandate contradicts 2026 consensus (ranged reads in every major agent, 23-90 percent token savings with equal or better task success) | S-AUD-08, S-AUD-09 |
| F-19 | med | `$DISTILL_HOME/distiller/search.py`, `budget.py`, `skeleton.py`, `cli.py` | Only `.gitignore` files at or below the root are loaded (830 ignored files listed from a subdirectory); UTF-16 dropped silently; junction loops followed; invalid regex tracebacks; missing root exits 0; no Markdown or shell outline; truncated output is not persisted; `*` in path globs crosses directories | S-AUD-07 |
| F-20 | low | distiller docs, `budget.py`, `api.py` | Token estimate ~6 percent high vs cl100k; README and DEPLOY test counts stale; MCP `search_repo` exposes fewer options than the CLI | S-AUD-09 |
| F-21 | low | `memdb/journal.py` merged_events | Cross-host order is wall-clock (running max per host); no hybrid logical clock | deferred |
| F-22 | low | workspace layout | The parent folder of this checkout is an untracked directory inside a larger repository, so a bare `git` command from there hits the wrong repo | deferred (documented) |

## Decisions required from the user

- **D-1 (before S-AUD-08)**: read-policy variant. Recommended default P1
  ("locate, then read at the right size") is specified in S-AUD-08; the
  alternative P2 keeps the whole-file mandate. The worker executes P1
  unless the user names P2.
- **D-2 (inside S-AUD-04)**: approve the core-setup lint proposal before
  the cleanup events are written.
- **D-3 (inside S-AUD-06)**: approve the one-time state-expiry report
  before it is applied.
- **D-4 (inside S-AUD-14)**: approve deletion of the two stray probe DB
  files; nothing is deleted without it.
- **D-5 (inside S-AUD-03)**: approve the exact diff to the user-level
  settings file; the worker prepares it and applies only on a yes.

## Steps

### S-AUD-01: verify refuses a journal shorter than its verified head

- **Goal**: A truncated journal tail fails `verify`, `verify --full`,
  `rebuild --verify`, `doctor`, `append`, and therefore the sync, instead
  of being accepted and persisted as the new head.
- **Inputs**: `memdb/journal.py` (`verify_chain`, `load_anchor`,
  `save_anchor`, `witness_checkpoints`, `_check_line_at`, `append_event`),
  `memdb/mem.py` (`chain_report`, `_snapshot_fast_state`, `cmd_rebuild`,
  `cmd_verify`, `cmd_doctor`), `memdb/tests/test_anchors.py` and
  `memdb/tests/test_snapshot.py` as patterns, F-01.
- **Deliverables**:
  - `memdb/journal.py`: `floor_for(host, root=None, manifest_entry=None)`
    returning the maximum of the saved anchor's `seq` (read raw, even when
    `_check_line_at` fails, because a stale anchor still proves the journal
    once reached that seq), the largest witnessed seq from
    `witness_checkpoints(host)`, and the manifest entry's seq when given.
  - `memdb/journal.py`: `verify_chain(path, anchor=None, checkpoints=None,
    floor_seq=0)`; after the walk, `last_seq < floor_seq` returns
    `(False, "journal for <host> ends at seq <last> but a verified head,
    witness or snapshot reached seq <floor>: tail truncated or rewritten")`.
  - `memdb/journal.py`: `save_anchor` refuses to write a lower seq than the
    existing anchor (`SystemExit` naming host, old and new seq);
    `append_event` computes `floor_for` after `tail_info` and refuses to
    append when the tail seq is below it.
  - `memdb/mem.py`: `chain_report`, `_snapshot_fast_state`, and
    `cmd_doctor` pass `floor_seq`; `cmd_rebuild --verify` adds
    `record_regression` (rebuilt record count lower than the live DB's, or
    any host's max seq lower than the live DB's) and on true sets `ok`
    false, does not swap, exits 1; a new flag `--accept-shrink` overrides
    and is echoed in the report. `projection_drift` stays informational.
  - `memdb/sync/memdb_sync.sh`: prints `record_regression` from the
    rebuild report when present (exit path already fails on exit 1).
  - `memdb/tests/test_truncation.py`: (a) `verify --full` after removing
    the last 3 lines of a verified journal fails with the truncation
    message; (b) suffix verify with an anchor present fails the same way;
    (c) `rebuild --verify` exits 1 and the live DB bytes are unchanged;
    (d) the anchor file seq is unchanged after the failed verify;
    (e) `append_event` refuses on the truncated journal; (f) a foreign
    host's journal truncated below another host's witness entry fails with
    the witness message when no local anchor exists; (g) a brand-new host
    with no anchor and no witness verifies ok (no false positive).
- **Acceptance criteria**:
  - Tests (a)-(g) pass; the existing 108 tests pass.
  - `mem verify --full` and `mem rebuild --verify` on the real store are
    green and report no `record_regression`.
  - `python tests/bench_scale.py --events 100000 --tail 1000` meets every
    budget in `memdb/docs/perf-budgets.md` (the floor check is O(1)).
  - The failure message names host, last seq, and expected seq.
- **Gate / review reference**: memdb test suite; full oracle on the real
  store before and after; scale budgets.
- **Definition of done**: a journal shortened by one line cannot pass any
  verify path, and the real-store oracle is green.

### S-AUD-02: episode validation before append; crash-proof replay

- **Goal**: A malformed episode document is rejected before any journal
  append, and any exception inside an applier during replay becomes an
  `unresolved` entry instead of a traceback.
- **Inputs**: `memdb/mem.py` (`cmd_record_episode`, `write_event`,
  `apply_episode`, `as_items`, `_apply_atomic`, `apply_all`),
  `memdb/tests/test_episode.py`, `memdb/tests/test_replay_order.py`,
  constraint `workstation:3176`, F-02.
- **Deliverables**:
  - `memdb/mem.py`: `validate_episode_doc(doc) -> list[str]` with these
    rules: `date` absent or `^\d{4}-\d{2}-\d{2}$`; `achievement`,
    `next_steps`, `blockers`, `decisions_with_rationale` absent, string,
    or list; decision items string or dict with `decision`; blocker items
    string or dict with `blocker` or `text`; `current_state` absent,
    string, or dict; `current_state.status` absent, string, or list;
    `current_state.files_touched` absent or list of strings; every string
    ASCII (report the first offending key and code point); unknown
    top-level keys warn on stderr only. `cmd_record_episode` exits 2 with
    all errors listed before `write_event` is reached.
  - `memdb/mem.py`: `preflight_apply(conn, ev)` runs `apply_event` inside
    `SAVEPOINT preflight` and always rolls back; `write_event` builds a
    provisional event (`seq` = tail + 1, same payload) and preflights it
    under the lock BEFORE `journal.append_event`; any exception exits 2
    and nothing is appended.
  - `memdb/mem.py` `apply_all`: both passes catch `Exception` and record
    `note(ev, "apply error: <type>: <msg>")`; MissingRef keeps its retry
    semantics.
  - `memdb/tests/test_episode_validation.py`: each malformed shape (list
    `current_state`, integer `decisions_with_rationale`, non-ASCII body,
    bad date, dict blocker without text) is rejected with exit 2 and the
    journal byte size is unchanged; a fixture journal holding an already
    malformed episode event replays into `unresolved` with the reason and
    `rebuild --verify` exits 1 with a JSON report; the preflight rollback
    leaves the record count and the uid sequence unchanged.
  - `memdb/hooks/README.md` and
    `install/memory-persistence-rule.template.md`: a table of the
    validated field types under the episode JSON section.
- **Acceptance criteria**:
  - New and existing tests pass.
  - `record-episode` with a valid document on the real store succeeds and
    `mem doctor` shows the head advanced by one.
  - `record-episode` with `"current_state": []` fails before append; the
    head seq reported by `mem doctor` is unchanged.
- **Gate / review reference**: memdb test suite; full oracle.
- **Definition of done**: no malformed document can reach the journal, and
  the malformed-fixture replay yields a loss report, not a traceback.

### S-AUD-03: automatic, capped session-start injection; retire built-in auto memory

- **Goal**: Every Claude Code session on this host starts with the
  core-setup digest injected by a hook, with the project slug resolved
  correctly on Windows, and the harness's built-in auto memory is off.
- **Inputs**: `memdb/hooks/session_start.sh`, `memdb/hooks/README.md`,
  this repo's `.claude/settings.json`, the user-level `~/.claude/settings.json`
  (hooks, `autoMemoryEnabled`), Claude Code hooks docs (SessionStart
  matchers `startup`, `resume`, `clear`, `compact`; stdin JSON carries
  `cwd`, `session_id`, `transcript_path`), F-11, F-12, D-5.
- **Deliverables**:
  - `memdb/mem.py`: `cmd_project_slug` (`mem project-slug --cwd <dir>`):
    resolves `git -C <cwd> rev-parse --show-toplevel` (fallback: the cwd),
    takes the basename treating both `/` and `\` as separators, maps it to
    the canonical spelling with `SELECT project FROM records WHERE project
    COLLATE NOCASE = ? ORDER BY created_at DESC LIMIT 1` (most recently
    written spelling wins; no match returns the basename unchanged), prints
    the slug.
  - `memdb/hooks/session_start.sh`: uses `mem project-slug` instead of
    `basename`; defaults to `--part core-setup` unless `MEMDB_PART` is set
    (`MEMDB_PART=all` means whole project); writes the hook's `session_id`
    and `transcript_path` to `~/.claude/memory/sessions/<session_id>.json`
    (consumed by S-AUD-13); still exits 0 on every path.
  - `memdb/hooks/README.md`: the user-level registration snippet with
    matcher `startup|clear|compact`, a `<memdb-checkout>` placeholder in
    the command, timeout 20, and the `autoMemoryEnabled: false` setting
    with the reason (two memory systems must not compete).
  - This repo's `.claude/settings.json`: the orphaned entry replaced by
    the same snippet with a path relative to this repo root
    (`memdb/hooks/session_start.sh`).
  - User-level `~/.claude/settings.json` (applied only after D-5): the
    `hooks.SessionStart` entry and `"autoMemoryEnabled": false`.
  - Archive of stale built-in memory: every existing
    `~/.claude/projects/*/memory/` directory (6 on 2026-09-13) moved, not
    deleted, to `~/.claude/memory/auto-memory-archive/<yyyy-mm-dd>/<project-dir>/`,
    the list recorded in the step's episode.
  - `memdb/tests/test_project_slug.py`: backslash path, nested
    subdirectory of a repo, non-repo cwd, case-split canonicalisation.
- **Acceptance criteria**:
  - Three fresh sessions (this checkout, a project with many records, a
    project with none) show, in their transcript JSONL, an injected block
    starting `# Memory digest: <canonical-slug>/core-setup`; the empty
    project shows the `[memdb: no records ...]` marker.
  - The injected block's size is recorded in the episode (the cap itself
    lands in S-AUD-04).
  - A fresh session, asked whether it carries an instruction about a
    per-project memory directory, answers no.
  - No `MEMORY.md` remains under `~/.claude/projects/*/memory/`.
  - Tests pass.
- **Gate / review reference**: D-5 (user approves the settings diff);
  memdb test suite.
- **Definition of done**: three fresh sessions show the injected digest
  with the correct slug and the built-in memory instructions are gone.

### S-AUD-04: cap pinned content; render global core-setup as a static rules file

- **Goal**: Per-session pinned memory is bounded (global block <= 25 KB
  and <= 200 lines; per-project digest <= 1,500 tokens) and prompt-cache
  stable, without dropping any record from storage.
- **Inputs**: `memdb/mem.py` (`digest_lines`, `cmd_add`, `gated_insert`,
  `est_tokens`), `memdb/sync/memdb_sync.sh`, `memdb/hooks/session_start.sh`
  (after S-AUD-03), the baseline measurements above, F-06, F-09, D-2.
- **Deliverables**:
  - `memdb/mem.py` `cmd_add`: with `--part core-setup` and kind in
    goal/constraint/preference, a `--body` longer than
    `MEMDB_CORE_BODY_MAX` (default 500 chars) is refused with a message
    that narrative and evidence belong in `--rationale`; runbooks are
    capped at 1,000. Appliers unchanged, so history replays.
  - `memdb/mem.py` `cmd_render_core` (`mem render-core --out <path>`):
    renders project `global` open goal/constraint/preference rows and
    global runbooks in deterministic order (kind, subject), one bullet per
    row, body only, uid as a trailing `[<uid>]` token, under a first line
    `<!-- GENERATED by mem render-core; do not edit -->`; exits 2 without
    writing when the output exceeds 25,000 bytes or 200 lines and lists
    the 10 longest rows; no timestamps anywhere (byte-identical on an
    unchanged DB).
  - `memdb/sync/memdb_sync.sh`: after a green rebuild runs
    `render-core --out "${MEMDB_CORE_RULES:-$HOME/.claude/rules/memdb-core-global.md}"`;
    a render failure is printed but does not fail the sync (the file is a
    view).
  - `memdb/mem.py` `digest_lines`: `--no-global` excludes project
    `global` from anchors and runbooks; project anchors are capped at
    `ANCHOR_BUDGET` (default 1,200 tokens) with deterministic trimming
    (oldest `last_confirmed_at` first) and the marker
    `[N pinned rows omitted - run: mem digest --project <p> --part core-setup --budget-tokens 6000]`;
    `TAIL_RESERVE` logic unchanged. `session_start.sh` passes
    `--no-global` when the rendered core file exists.
  - `memdb/mem.py` `cmd_core_lint` (`mem core-lint`): read-only report
    of (1) core-setup rows with disallowed kinds and the proposed action
    (re-add under the right part, close the core-setup copy), (2) rows
    over the body cap with a proposed split (body = first sentence,
    rationale = remainder), (3) case-split projects with the canonical
    spelling and the rows to re-add; the worker saves it as
    `memdb/docs/audits/<yyyy-mm-dd>-core-setup-lint.md`, the user approves
    (D-2), the worker applies it through `add`/`supersede`/`close` events.
  - `memdb/tests/test_render_core.py`: cap enforcement, determinism,
    exclusion of closed and superseded rows, `--no-global` digest equals
    the anchor set minus global; `memdb/tests/test_digest.py`: anchor cap
    and marker.
  - `memdb/hooks/README.md`: the new two-file flow (static global rules
    file plus per-project digest).
- **Acceptance criteria**:
  - After the D-2 cleanup, `mem render-core` on the real store succeeds
    under 25 KB (before the cleanup it must fail loudly and list the
    offenders; that output is the input to D-2).
  - `mem digest --project FO4RE --part core-setup --no-global` is
    <= 1,500 tokens by `est_tokens`.
  - Two consecutive `render-core` runs on an unchanged DB are
    byte-identical (`sha256` equal).
  - A fresh session shows the rendered core file content in context.
  - Record count after the cleanup is equal or higher (nothing deleted).
- **Gate / review reference**: memdb test suite; D-2; full oracle after
  the cleanup events.
- **Definition of done**: a fresh FO4RE session starts with the rendered
  core file plus a digest under 1,500 tokens, and `render-core` passes its
  cap.

### S-AUD-05: search ranking and a local retrieval eval

- **Goal**: Open, recent records outrank closed and superseded ones for the
  same query, and a repeatable local eval measures recall so later changes
  are gated by numbers.
- **Inputs**: `memdb/mem.py` (`cmd_search`, `fts_query`, `snip`),
  `memdb/schema.sql` (`records_fts`), `memdb/bench/gen_probes.py` as the
  probe pattern, the 2026-09-13 probe query "why is grep blocked, what
  should I use instead" (expected `workstation:3125` or `workstation:3126`
  in the top 3), F-07.
- **Deliverables**:
  - `memdb/mem.py` `cmd_search`: score = `bm25(records_fts, 5.0, 1.0,
    1.0, 0.5) * status_factor * age_factor`, with `status_factor` 1.0 open,
    1.6 closed, 2.5 superseded and `age_factor = 1 + 0.25 * min(age_days,
    730) / 365` (bm25 is lower-is-better; factors above 1 push rows down);
    constants at module top; `--status` still hard-filters; `--open-only`
    alias; `--recent DAYS` filter; deterministic tie-break `ORDER BY
    score, id`; `snip()` strips a leading `[migrated ...]` or
    `[imported ...]` prefix; `fts_query` adds the exact phrase as a
    higher-weight alternative to the token OR-list.
  - `memdb/tests/eval/queries.jsonl`: at least 30 lines of
    `{"query": ..., "expect_uids": [...], "project": optional}` harvested
    from real episodes of the last 60 days (task subjects, user phrasings
    from transcripts) plus the 2026-09-13 probe.
  - `memdb/tests/test_search_eval.py`: runs the eval against a fixture
    store by default and against the real store when `MEMDB_EVAL_REAL=1`;
    asserts hit@5 >= 0.80 and prints hit@1, hit@5, MRR.
  - `memdb/docs/perf-budgets.md`: new gated row `search_hit5 >= 0.80`
    with the measurement date.
- **Acceptance criteria**:
  - The 2026-09-13 probe returns an open record at rank 1 and
    `workstation:3125` or `3126` within the top 3.
  - Eval hit@5 >= 0.80 on the real store.
  - Search p50 stays under 100 ms on the real store (`bench/run_bench.py`
    metric).
  - Existing tests pass.
- **Gate / review reference**: memdb test suite; perf budgets.
- **Definition of done**: the eval file has >= 30 queries and the gate
  passes on the real store.

### S-AUD-06: importance gate at write, decay on a cadence

- **Goal**: Only facts the author marked durable become open rows, and
  stale open rows expire on a schedule, so the open set stops growing
  without bound.
- **Inputs**: `memdb/mem.py` (`apply_episode`, `compute_consolidate`,
  `cmd_consolidate`, `digest_lines`), `memdb/sync/memdb_sync.sh`,
  `install/memory-persistence-rule.template.md`, F-08, D-3.
- **Deliverables**:
  - `memdb/mem.py` `cmd_record_episode`: writes payload field
    `"extract": "explicit"`; `apply_episode` creates `state` rows from
    `current_state.status` items ONLY for dict items carrying `subject`
    when `extract == "explicit"`; events without the field replay with the
    current rule (history unchanged); plain-string items stay in the
    payload and FTS fulltext. Decisions and blockers keep full extraction.
  - `memdb/mem.py` `digest_lines`: blockers older than
    `BLOCKER_STALE_DAYS` (90) render as one line
    `- N blockers older than 90 days omitted (mem search --kind blocker --project <p>)`.
  - `memdb/sync/memdb_sync.sh`: on the weekly full-verify cadence also
    runs `mem consolidate --expire-states 30` (journaled outcome).
  - One-time cleanup: `mem consolidate --dry-run --expire-states 60`
    saved as `memdb/docs/audits/<yyyy-mm-dd>-state-expiry.md`, applied
    after D-3.
  - `install/memory-persistence-rule.template.md`: `status` items that
    must persist as rows are written as `{"subject": ..., "state": ...}`;
    plain strings are narrative.
  - `memdb/tests/test_extract_explicit.py`: legacy event replays
    unchanged; new event with plain strings creates no state rows; dict
    with subject creates one. `memdb/tests/test_digest.py`: stale-blocker
    count line.
- **Acceptance criteria**:
  - After the cleanup, open `state` rows older than 60 days on the real
    store = 0 (one SQL count, recorded in the episode).
  - `mem verify --full` is green after deployment (proves replay safety).
  - The TaktflowBMS digest lists at most 15 blockers plus one count line.
  - Tests pass.
- **Gate / review reference**: memdb test suite; full oracle; D-3.
- **Definition of done**: weekly expiry runs from the sync and the
  one-time cleanup is applied and verified.

### S-AUD-07: distiller correctness

- **Goal**: `search`, `find`, `budget`, `skeleton`, and `slice` return
  correct results or fail loudly for anchored regex, ignored files,
  junction loops, invalid patterns, missing roots, UTF-16 input, Markdown
  and shell outlines, path globs, and truncated output.
- **Inputs**: `$DISTILL_HOME/distiller/search.py`, `core.py`,
  `budget.py`, `skeleton.py`, `slicer.py`, `cli.py`, `api.py`,
  `$DISTILL_HOME/tests/test_distiller.py`, F-16, F-19. Independent of
  S-AUD-01..06.
- **Deliverables** (all under `$DISTILL_HOME/`):
  - `distiller/search.py`: the byte prescan is compiled with
    `re.MULTILINE` and `$` is translated to `(?=\r?$)` so CRLF files
    match; when the pattern contains `\A` or `\Z` the prescan is skipped.
  - `distiller/ignore.py` (new) used by `search.py` and `budget.py`:
    loads `.gitignore` from the search root upward to the nearest
    directory containing `.git` (or the filesystem root) plus
    `.git/info/exclude`; supports `!` negation and `**`; `--no-ignore`
    unchanged; `budget`, `find`, and `search` therefore agree on the tree.
  - Walker guard: a set of `os.path.realpath` for visited directories;
    repeats are skipped (covers Windows junctions and POSIX symlinks).
  - Error paths: invalid regex -> `error: invalid regex: <msg>`, exit 2;
    missing root -> `error: no such path: <p>`, exit 2; `distill_mcp.py`
    and `distill_hook.py` report the same in-band.
  - Encoding: UTF-16 with BOM is decoded, not dropped; a UTF-8 BOM is
    stripped from line 1; the summary line gains `binaries-skipped=N`.
  - `distiller/skeleton.py`: Markdown outline (`#` headings with line
    numbers) and shell outline (`name() {` and `function name`).
  - Restorable truncation: when output is clipped, the full result is
    written to `${DISTILL_OUT:-$TMPDIR/distill}/<sha1(cmd+args)[:12]>.txt`
    and the marker names that path; `--no-persist` opts out.
  - Path globs: `*` no longer crosses `/` (translated to `[^/]*`); `**`
    does.
  - `tests/test_distiller.py`: one test per bullet above (anchored LF and
    CRLF fixtures, ancestor ignore, negation, junction or symlink loop with
    platform skip, invalid regex, missing root, UTF-16, BOM, Markdown and
    shell skeleton, persisted truncation, glob crossing).
  - `README.md`: test count updated.
- **Acceptance criteria**:
  - `search "^def " distiller -l` reports 14 files and 61 matches (the
    unanchored count measured on 2026-09-13).
  - `find "*.yaml" -p memdb` run from inside this checkout lists 0 files
    under a directory ignored by an ancestor `.gitignore`.
  - A junction loop lists each file once.
  - Invalid regex and missing root exit 2 with one line each.
  - All distiller tests pass; search and find timing over this checkout
    stays within 2x of the 2026-09-13 numbers (0.2-0.6 s, 0.13 s).
- **Gate / review reference**: distiller test suite; timing recorded in
  the step's episode.
- **Definition of done**: the six audit probes return correct results and
  the suite is green.

### S-AUD-08: one read policy, one hook

- **Goal**: A single, tested read policy replaces the two contradictory
  hooks, so any file can be read by exactly one sanctioned path, and the
  hook's block/allow table is a regression fixture instead of folklore.
- **Inputs**: `~/.claude/hooks/enforce_full_reads.py`,
  `~/.claude/hooks/full-read-allowlist.txt`,
  `~/.claude/hooks/tests/test_hooks.py`, `$DISTILL_HOME/distill_hook.py`,
  `<cus-bms-repo>/.claude/settings.json`, the 36-payload probe table from
  the audit (re-derive from F-17 if the scratchpad is gone), F-17, F-18,
  D-1.
- **Policy P1 (recommended default)**: Grep, Glob, and the Explore agent
  stay blocked (the distiller is the search path). `Read` without
  offset/limit is allowed at any size. `Read` with offset/limit is allowed
  when the file is larger than 8,000 bytes (windowing a large file after
  `skeleton` or `search` located the region) and blocked for smaller files
  (read those whole). Bash `head`, `tail`, `grep`, `find`, `sed -n`,
  `awk NR` stay blocked, except `tail -f` or `tail -F` on a `*.log` path,
  allowed by a shipped `cmd:` rule. Interpreters (`python -c`, `bash -c`,
  `perl`) are documented as out of scope: the hook stops habit, not
  intent. `distill_hook.py` is retired because P1 subsumes it.
- **Policy P2 (alternative)**: keep the whole-file mandate, retire
  `distill_hook.py`, accept the measured cost (a 65 KB file = 16k tokens
  per read).
- **Deliverables**:
  - `~/.claude/hooks/read_policy.py`: pure functions `verdict_read(path,
    offset, limit, size)`, `verdict_bash(command)`, `verdict_tool(name,
    tool_input)`; `enforce_full_reads.py` becomes a thin shell over it.
  - Allowlist fix in `read_policy.py`: `path:` entries match only the
    tool's path fields and path-like command tokens (tokens containing `/`
    or `\`), never the whole command; `cmd:` regexes unchanged;
    `full-read-allowlist.txt` gains the `tail -f` rule.
  - `<cus-bms-repo>/.claude/settings.json`: the `distill_hook.py` entry
    removed (P1) or replaced by the global hook (P2);
    `$DISTILL_HOME/distill_hook.py` deleted under P1 with README section
    "Enforcing distilled input" rewritten to point at the global policy.
  - `~/.claude/hooks/tests/test_hooks.py`: the 36 probe payloads as
    fixtures in three lists, MUST_BLOCK, MUST_ALLOW, ADVISORY (bypasses
    allowed by design), with the chosen policy named in the file header.
  - memdb: one `add --kind constraint --project global --part core-setup
    --subject read-policy` row (<= 500 chars) describing the policy, then
    `supersede` of `workstation:3125` and `workstation:3126` by it.
- **Acceptance criteria**:
  - `python ~/.claude/hooks/tests/test_hooks.py` green including the new
    fixtures.
  - In a CUS-BMS session a 33 KB file is readable both whole and with
    offset/limit; `Grep` is still blocked; the comment-unlock bypass
    (`grep ... # /scratchpad/`) is blocked; `tail -f build.log` is allowed.
  - `mem digest --project global --part core-setup` shows exactly one
    read-policy row.
- **Gate / review reference**: D-1 recorded in the Status section of this
  file before execution; hook fixture suite.
- **Definition of done**: both repositories reference one policy module
  and the fixture suite encodes the chosen table.

### S-AUD-09: distiller docs alignment

- **Goal**: Every document describing the read policy or the distiller
  says the same thing, and stated test counts match the suite.
- **Inputs**: `$DISTILL_HOME/README.md`, `DEPLOY.md`,
  `TOKEN_ECONOMY_PLAYBOOK.md`, `~/.claude/skills/distill/SKILL.md`,
  `<cus-bms-repo>/.claude/skills/distill/SKILL.md`,
  `<cus-bms-repo>/CLAUDE.md`, the S-AUD-08 outcome, F-18, F-20.
- **Deliverables**:
  - The six files above edited so the policy paragraph is identical and
    carries the line "Policy source of truth: ~/.claude/hooks/read_policy.py".
  - `README.md` test count equals `python -m pytest tests -q` output;
    `DEPLOY.md` likewise.
  - `README.md` MCP section lists the options `search_repo` lacks versus
    the CLI, or `distiller/api.py` gains them (worker's choice, stated in
    the episode).
- **Acceptance criteria**:
  - `python "$DISTILL_HOME/distill.py" search -F "limit <= 250" "$DISTILL_HOME" -l`
    returns 0 files under P1 (the windowed-read exception no longer
    exists), or every hit states the P2 rule identically.
  - The skill rules and README rule 4 no longer contradict each other
    (the worker quotes both in the episode).
- **Gate / review reference**: user reads the README policy section once.
- **Definition of done**: both consistency checks pass.

### S-AUD-10: shrink the instruction surface

- **Goal**: Standing instruction text at session start drops from ~7k
  tokens to <= 3.5k without losing any rule, by moving procedure into a
  skill and removing dead or duplicate rules.
- **Inputs**: `~/.claude/CLAUDE.md` (4,673 tokens on 2026-09-13),
  `~/.claude/rules/*.md`, `<drive-root>/.claude/rules/session-management.md`,
  `install/memory-persistence-rule.template.md`,
  `~/.codex/rules/end_of_job_handoff.md`, `~/.claude/skills/distill/SKILL.md`,
  F-13, F-14.
- **Deliverables**:
  - `~/.claude/skills/memdb/SKILL.md` (<= 200 lines): the full memdb
    procedure now in the CLAUDE.md block (episode shape including the
    S-AUD-02 validation table and the S-AUD-06 explicit-state syntax, slug
    rules, task-start readback, promotion rule, failure behaviour), with
    frontmatter `name: memdb`, `description` naming the two moments it
    applies (task start readback, end-of-job episode), model-invocable.
  - `install/memory-persistence-rule.template.md`: rewritten as the
    <= 15-line block (what the layer is, the two commands, "load the memdb
    skill for the procedure") with a `{{SKILL_PATH}}` placeholder; the
    user-level `~/.claude/CLAUDE.md` memdb block is regenerated from it
    (user applies the diff).
  - `~/.codex/rules/end_of_job_handoff.md` and
    `~/.codex/skills/memdb/SKILL.md`: the same content; Codex has no
    SessionStart hook, so its rule keeps the digest command explicit.
  - `<drive-root>/.claude/rules/session-management.md`: replaced by a
    three-line pointer to the memdb skill (its session-memory MCP is not
    configured; its offset/limit advice contradicts the hook), after the
    user confirms.
  - Grep policy copies reduced to two: `read_policy.py` and the distill
    skill; the CLAUDE.md files link to them.
  - `memdb/docs/audits/<yyyy-mm-dd>-instruction-mapping.md`: a table with
    every heading and rule of the old CLAUDE.md block on the left and its
    new location on the right, no empty cells.
- **Acceptance criteria**:
  - `python "$DISTILL_HOME/distill.py" budget ~/.claude/CLAUDE.md`
    reports <= 2,500 tokens.
  - The mapping table has no gaps (every old rule has a new home).
  - A fresh session invoking the memdb skill shows the procedure.
  - `diff` between the template and the Codex rule is empty apart from
    placeholders and the digest line.
- **Gate / review reference**: user review of the CLAUDE.md diff before
  applying (user file).
- **Definition of done**: CLAUDE.md under 2,500 tokens and the mapping
  table complete.

### S-AUD-11: sync ingest hardening, torn tail, host override

- **Goal**: The sync never overwrites local events, never advances its
  last-seen pointer on a failed materialization, refuses a conflicting
  host identity, and a torn journal tail is reported as a loss signal
  rather than a traceback.
- **Inputs**: `memdb/sync/memdb_sync.sh`, `memdb/journal.py` (`host_id`,
  `iter_lines`, `append_event`), `memdb/mem.py` (`cmd_doctor`,
  `chain_report`), `memdb/docs/hub-config.md`, F-03, F-04. Independent of
  S-AUD-05..10.
- **Deliverables**:
  - `memdb/mem.py` `cmd_journal_head` (`mem journal-head --file <path>`
    or `-` for stdin): prints `{"seq": N, "hash": ...}` of the last line.
  - `memdb/sync/memdb_sync.sh`: before materializing a foreign host's
    file, compares the local head seq with the origin blob's head seq via
    `git show <ref>:journal/<h>/events.jsonl | mem journal-head --file -`;
    local ahead -> `memdb-sync: INTEGRITY local journal for <h> is ahead
    of origin` and FAIL without overwriting; `mv` failure -> FAIL and no
    `seen_file` write; `git checkout` failure -> FAIL exit 1.
  - `memdb/journal.py` `host_id()`: when `MEMDB_HOST` is set and differs
    from the host-id file, raise `SystemExit` naming both, unless
    `MEMDB_HOST_OVERRIDE=1` (tests and benches set both variables).
  - `memdb/journal.py` `iter_lines`: a JSON decode error on the LAST line
    raises `TornTail(path, byte_offset)`; `verify_chain` returns
    `(False, "torn tail at byte <n>")`; `doctor` reports it under
    `chain:<host>`; `append_event` refuses with the byte offset and the
    repair instruction; a decode error on any earlier line stays a hard
    error (corruption, not a crash artifact).
  - `memdb/docs/hub-config.md`: new section "Repairs" describing the
    torn-tail repair (confirm on the hub with `git show` that the partial
    event was never pushed, then truncate the partial line, then verify).
  - `memdb/tests/test_sync_guards.py`: scratch bare hub (pattern from the
    S-MEM-SCALE-06 runs) covering local-ahead refusal, failed `mv`, and
    checkout failure; `memdb/tests/test_journal.py`: torn tail and host
    override cases.
- **Acceptance criteria**:
  - Local-ahead foreign journal: sync exits 1, file bytes unchanged.
  - Torn tail: `doctor` exits 1 with the byte offset, `verify` exits 1,
    `append` refused.
  - `MEMDB_HOST=laptop` on the workstation without the override: refused.
  - One real sync after deployment prints `memdb-sync: ok`.
- **Gate / review reference**: memdb test suite; one real sync.
- **Definition of done**: all three failure simulations refuse loudly and
  the real sync is green.

### S-AUD-12: explicit blocker resolution and CLI guards

- **Goal**: New episodes close only the blockers they name, and the CLI
  refuses cross-project supersede and status downgrades unless forced,
  with the replay of existing events unchanged.
- **Inputs**: `memdb/mem.py` (`apply_episode` close loop, `cmd_supersede`,
  `cmd_close`, `apply_close`), the payload-field pattern from S-AUD-06,
  F-05. Depends on S-AUD-02 (validation) only.
- **Deliverables**:
  - Episode payload field `resolves` (list of blocker uids or subjects):
    `cmd_record_episode` always writes it from `doc["resolves"]` (default
    `[]`); `apply_episode` closes exactly the named blockers when the field
    is present and uses the legacy substring rule only when it is absent;
    `validate_episode_doc` accepts `resolves` as a list of strings.
  - `cmd_supersede`: refuses `old.project != by.project` or `old.kind !=
    by.kind` unless `--cross`; `cmd_close`: refuses a `superseded` record
    unless `--force`; appliers unchanged.
  - `install/memory-persistence-rule.template.md` and the memdb skill:
    `resolves` documented.
  - `memdb/tests/test_episode.py`: legacy event still closes by
    substring; new event with `resolves` closes only the named ones; a new
    event whose blocker subject is `none` closes nothing.
    `memdb/tests/test_cli.py`: both guards.
- **Acceptance criteria**:
  - `mem verify --full` green after deployment (replay unchanged).
  - Tests pass.
- **Gate / review reference**: memdb test suite; full oracle.
- **Definition of done**: a new episode can only close blockers it names.

### S-AUD-13: provenance defaults and origin tier

- **Goal**: Every new episode carries session id and transcript hash
  without the caller typing them, and every record states whether a human
  or an agent asserted it.
- **Inputs**: `memdb/mem.py` (`cmd_record_episode`, `cmd_add`,
  `digest_lines`, `cmd_search`), `memdb/schema.sql`,
  `~/.claude/memory/sessions/<id>.json` written by S-AUD-03, F-10.
- **Deliverables**:
  - `cmd_record_episode`: `--session-id` defaults to
    `CLAUDE_CODE_SESSION_ID`; `--transcript` defaults to `transcript_path`
    from `~/.claude/memory/sessions/<id>.json`, else the first match of
    `~/.claude/projects/*/<id>.jsonl` (stdlib directory walk); the chosen
    source is printed in the result JSON.
  - `cmd_add`: `--origin user|agent|tool` (default `agent`) stored in the
    payload; `memdb/schema.sql` version 4 adds
    `origin TEXT NOT NULL DEFAULT 'agent'`; `apply_add` projects it (old
    events -> `agent`); `SCHEMA_VERSION = 4`; deployment = `mem rebuild
    --full` (schema changes are rebuilds, never migrations).
  - `digest_lines`: rows with `origin = 'user'` render as
    `(c <uid> u)`; `cmd_search` summary includes `origin`.
  - Template and skill: "record what the user stated with `--origin
    user`".
  - `memdb/tests/test_episode.py`: automatic session and transcript
    resolution; `memdb/tests/test_digest.py`: origin marker;
    `memdb/tests/test_init.py`: schema version 4 refusal of a v3 DB.
- **Acceptance criteria**:
  - `record-episode` with no provenance flags in a hooked session records
    both `session_id` and `_transcript` (checked with `mem get`).
  - `mem verify --full` green after the version-4 rebuild.
  - After one week of use, >= 90 percent of new episodes carry
    `_transcript` (one SQL count recorded in the follow-up episode).
- **Gate / review reference**: memdb test suite; full oracle.
- **Definition of done**: a flag-less `record-episode` records both
  provenance fields and the v4 store verifies.

### S-AUD-14: fleet and hygiene

- **Goal**: Replication no longer depends on end-of-job diligence alone,
  the two other hosts run the current contract, and leftover DB copies are
  gone.
- **Inputs**: `memdb/sync/memdb_sync.sh`, `install/AGENT_INSTALL.md`,
  `install/memory-persistence-rule.template.md` (after S-AUD-10),
  `plans/2026-08-15-memdb-hardening-plan.md` S-HARD2-01, the
  `~/.claude/memory/` listing (`mem.db.probe`, `mem.db.probe2`,
  `mem.db.prev`, `mem.db.v1.bak`), F-15, D-4.
- **Deliverables**:
  - Windows scheduled task `memdb-sync-daily` created with
    `Register-ScheduledTask`, daily at an hour the user names, running
    `bash <memdb-checkout>/memdb/sync/memdb_sync.sh` with output appended
    to `~/.claude/memory/sync.log`; the exact command recorded in
    `memdb/docs/hub-config.md` under a new "Cadence" section; laptop and
    pi get the cron line from S-HARD2-01.
  - `install/AGENT_INSTALL.md`: step 8 installs the skill plus the short
    CLAUDE.md block (S-AUD-10); step 10 registers the global SessionStart
    hook (S-AUD-03) instead of "optional per-project".
  - Laptop and pi: pull the memdb code, re-run install steps 8-10, record
    one episode each, sync.
  - Hygiene after D-4: delete `~/.claude/memory/mem.db.probe` and
    `mem.db.probe2`; keep `mem.db.prev` (rotated by `swap_in`) and
    `mem.db.v1.bak` (genesis backup); `cmd_doctor` gains a check listing
    unexpected files in the memory directory.
  - `memdb/docs/hub-config.md`: note that the journal root is
    intentionally untracked apart from `journal/<host>/` (the `.memdb.lock`
    and `derived/` entries are per-clone state), so no `.gitignore` is
    added.
- **Acceptance criteria**:
  - `~/.claude/memory/sync.log` shows `memdb-sync: ok` on two consecutive
    scheduled days.
  - `mem search --project memdb --part install` on the workstation lists
    the new laptop and pi episodes.
  - `mem doctor` reports no unexpected files.
- **Gate / review reference**: user names the hour and approves D-4.
- **Definition of done**: two consecutive automatic syncs are green and
  both hosts' install episodes are present.

## Explicitly deferred (watch items with triggers)

- **Hybrid logical clock for cross-host order (F-21)**: trigger = a
  second host writing >= 50 events per month. Design when triggered:
  per-host Lamport counter in the event, merge key (hlc, host, seq), full
  rebuild after the switch; the snapshot fast path must re-prove tail
  ordering against the new key.
- **Embedding-based hybrid search**: trigger = S-AUD-05 eval hit@5 below
  0.80 after the ranking fix. Design when triggered: vectors from the local
  ollama server already installed on the workstation, stored in a
  projection-only sidecar table, fused with bm25 by reciprocal rank; mem.py
  stays stdlib (HTTP via `urllib`).
- **Bi-temporal validity (`valid_from`, `valid_to`) on facts**: trigger =
  the eval shows answers built from superseded facts. Design when
  triggered: `supersede` events carry `valid_to`, digest renders only rows
  valid now, search can ask "as of".
- **Journal segment rotation**: already S-MEM-SCALE-07 in
  `memdb/docs/plans/plan-scalability.md`; unchanged triggers.
- **Workspace layout (F-22)**: not planned; the hazard is recorded as
  constraint `workstation:2666` (chain `cd <repo> && git ...`, verify
  `git rev-parse --show-toplevel` before committing).

## Status

- 2026-09-13: plan written from audit episode `workstation:3177`. No step
  started. Decisions D-1 to D-5 pending. Baseline table above is the
  reference for every "unchanged" acceptance criterion.
- 2026-09-13: execution started. User answers (verbatim in quotes):
  - D-1: "full" -> Policy P2 (keep the whole-file mandate, retire
    `distill_hook.py`).
  - D-2, D-3, D-5 and the S-AUD-10 CLAUDE.md review: "keep going by
    yourself no question ask" -> the worker applies them without a
    further round-trip and reports each diff in the step episode.
  - D-4 and the S-AUD-14 hour: "do by your self" -> delete the two probe
    DB files; daily sync task at 12:00 with catch-up when missed.
  - Commits: one commit per step on this host's branch, pushed at once;
    the distiller lives in a repository without a host id, so its
    changes stay uncommitted there.
  - The distiller carried ~535 lines of uncommitted changes before
    S-AUD-07; they are treated as the baseline and built upon.
- 2026-09-13: S-AUD-01 done. 122 memdb tests pass (14 new in
  `tests/test_truncation.py`); real store `verify --full` and
  `rebuild --verify` green with `record_regression: false`; bench
  100,000/1,000 inside every budget (append 13.7 ms, snapshot rebuild
  0.81 s, snapshot verify 4.3 s, suffix chain 0.009 s). Deviation from
  the letter of the step: the per-host part of `record_regression`
  compares the live DB's highest uid seq with the journal tail seq (not
  with the rebuilt DB's highest uid seq), because a reordered replay can
  turn a local insert into a confirm and would raise a false alarm. Full
  mode `rebuild` (with or without `--verify`) now refuses to swap in or
  snapshot a projection when a chain check fails. Episode
  `workstation:3181`.
- 2026-09-13: S-AUD-02 done. 135 memdb tests pass (13 new in
  `tests/test_episode_validation.py`). Real store: `record-episode` with
  `"current_state": []` exited 2 and the workstation head stayed at seq
  3180; the valid S-AUD-01 episode then landed as `workstation:3181` and
  the head moved to 3181. Additions beyond the letter of the step:
  `current_state.summary` must be a string when present, null counts as
  absent, non-JSON input exits 2, and `write_event` checks the journal
  floor before the preflight so a truncated journal reports the
  truncation instead of a uid collision.
- 2026-09-13: S-AUD-07 done (distiller changes left uncommitted in its
  repository, as decided). 74 distiller tests pass (62 before);
  `search "^def " distiller -l` now 15 files / 69 matches (was 0);
  invalid regex and missing root print one line and exit 2;
  `find "*.yaml" -p memdb` lists 0 (was 830); search 0.23 s and find
  0.15 s over this checkout. Plan defect: the acceptance line expecting
  the anchored count to equal the unanchored count (61) was wrong,
  because `def ` also matches indented and embedded occurrences
  (69 anchored + 13 non-column-0 lines = 82 unanchored after the step).
  Side effect to know: ancestor ignore files now apply, so a folder inside
  a larger repository inherits that repository's ignore rules (for example
  `*.ps1` and `*.log`); `--no-ignore` shows them.
- 2026-09-13: S-AUD-03 part 1 (code) done: `mem project-slug`, the
  rewritten hook, README, this repository's settings, 11 new tests.
  Deviation: when the git toplevel name is not a known project, the
  resolver also tries the folders below the toplevel (outermost first)
  and above it (innermost first), because this checkout sits in an
  untracked folder of a larger repository (F-22) and its real project
  slug is the parent folder name. The project-level registration carries
  `MEMDB_HOOK_SCOPE=project` and stands down when the user-level hook
  exists, so no session receives the digest twice. The user-level
  settings change and the archive are deferred until S-AUD-04 lands,
  because the uncapped FO4RE core-setup digest measured 130 KB.
- 2026-09-13: S-AUD-04 done. Code: write-time body caps, capped and
  `--no-global` digest, `render-core`, `core-lint`, sync render step,
  hook `--no-global`; 158 memdb tests pass. Plan defect: `render-core`
  on the real store passed its cap BEFORE the cleanup (30 rows, 18,289
  bytes, 40 lines), so the "must fail before cleanup" expectation did
  not hold; the lint report was the D-2 input instead. D-2 (delegated to
  the worker) changed two proposal rules before applying: an over-cap
  body keeps whole sentences up to at least 160 chars (a bare first
  sentence was often only a title) and never cuts inside brackets, and
  open state/blocker rows of disallowed kinds are closed rather than
  re-added (point-in-time status; the parent episode keeps the text).
  Canonical spelling for case splits = the spelling with the most
  records (matches constraint `workstation:2620`: FO4RE, wildlander).
  The saved report `memdb/docs/audits/2026-09-13-core-setup-lint.md`
  lists uids and sizes only. Applied as journaled events: 209 over-cap
  rewrites, 18 case-split re-adds plus supersedes, 9 closes, 5 re-adds.
  Result: records 18,948 -> 19,180; open core-setup anchor text 250,466
  -> 78,285 chars in the same 269 rows; 0 bodies over 500 chars; 0 open
  rows of disallowed kinds; `verify --full` green; rendered
  `memdb-core-global.md` 10,149 bytes / 40 lines, byte-identical across
  runs; `digest --project FO4RE --part core-setup --no-global` 1,202
  tokens.
- 2026-09-13: S-AUD-03 done (part 2). User-level settings now carry
  `autoMemoryEnabled: false` and the SessionStart hook
  (`startup|clear|compact`, timeout 20); the 6 stale built-in memory
  directories (26 files) moved to
  `~/.claude/memory/auto-memory-archive/2026-09-13/`: the Path-of-Exile
  documents folder, D--openbsw, the two workspace_ccstheia folders on
  C:, d--workspace-ccstheia, and the Fallout 4 Steam folder; no
  `MEMORY.md` remains. Three fresh print-mode sessions: this checkout
  injected `# Memory digest: Memory-orchestration/core-setup` (1,138
  chars), TaktflowBMS injected `# Memory digest: TaktflowBMS/core-setup`
  (3,537 chars), an empty non-repo folder injected the
  `[memdb: no records ...]` marker (193 chars); each transcript holds one
  `hook_success` SessionStart attachment carrying the block, each
  session quoted `# memdb global core-setup` from the rendered rules
  file, and each answered "no" to carrying a per-project memory
  directory instruction. The hook now strips carriage returns from the
  digest. Episodes `workstation:3447` (S-AUD-02), `3448` (S-AUD-07),
  `3449` (S-AUD-03), `3450` (S-AUD-04); sync ok.
- 2026-09-13: S-AUD-05 done. `search_rows` ranks by bm25 divided by
  (status factor x age factor) and adds the exact phrase as an OR term;
  `--open-only`, `--recent DAYS`, `ORDER BY score, id`; snippets drop a
  leading migration tag. Deviations: (1) SQLite's bm25 is negative, so
  the factors divide rather than multiply (multiplying would promote
  superseded rows); (2) kind `episode` is exempt from the status factor,
  because episodes are stored closed by construction and a first cut
  that demoted them fell to hit@5 0.771; (3) the probe's expected uids
  are `workstation:3328`/`3329`, the open successors of
  `workstation:3125`/`3126` after the S-AUD-04 cleanup. Real store, 35
  queries in `tests/eval/queries.jsonl`: before hit@1 0.371, hit@5
  0.914, MRR 0.595; after hit@1 0.686, hit@5 0.943, MRR 0.805; search
  p50 26-29 ms. The probe returns open `workstation:3329` at rank 1.
  162 memdb tests pass (real-store eval green with `MEMDB_EVAL_REAL=1`).
  Episode `workstation:3451`.
- 2026-09-13: S-AUD-06 done. `record-episode` writes
  `"extract": "explicit"`; `apply_episode` keys the new rule on that
  field, so `verify --full` with the new applier matched the projection
  built by the old one. The validator rejects a status object that has a
  `subject` but no string `state`/`text`. Digest: open blockers last
  confirmed more than 90 days ago collapse into one count line. Sync: step
  4b runs `consolidate --expire-states 30` after a green full oracle, then
  commits and pushes the event in the same run. D-3 (delegated) applied:
  report `memdb/docs/audits/2026-09-13-state-expiry.md`, 794 state rows
  closed by consolidate event workstation seq 3452, open states older
  than 60 days 794 -> 0. TaktflowBMS default digest: 11 blocker lines
  plus `- 487 blockers older than 90 days omitted ...`. Deviations:
  (1) the count line reads `(mem search --query <words> --kind blocker
  --project <p> --open-only)` because `search` requires `--query`;
  (2) age is measured on `last_confirmed_at`, so a re-reported blocker
  stays listed; (3) the count line renders first in its section, because
  as the last line it was trimmed by the budget on the real store;
  (4) `tests/test_episode.py` now uses a subject-keyed status item for
  its state child. 169 memdb tests pass. Episode `workstation:3453`; the
  sync run right after it forced the full oracle, so step 4b ran for real
  and closed 1,282 open states not confirmed for 30 days.
- 2026-09-13: S-AUD-08 done under P2 (D-1 "full").
  `~/.claude/hooks/read_policy.py` holds the policy (`verdict_read`,
  `verdict_bash`, `verdict_tool`, `POLICY = "P2"`); `enforce_full_reads.py`
  is a thin shell over it. Allowlist fix: a `path:` entry must match every
  path-like operand of the blocked statement, shell comments are dropped
  first, statements split quote-aware, `bash -c "..."` is checked
  recursively, git global options no longer hide `ls-files`/`grep`.
  `full-read-allowlist.txt` gained the `tail -f`/`-F` on `*.log` rule.
  `tests/test_hooks.py`: 36 probes (18 MUST_BLOCK, 12 MUST_ALLOW,
  6 ADVISORY), 168/168 pass (132 before). `<cus-bms-repo>/.claude/settings.json`
  no longer registers `distill_hook.py` (now `{}`; the user-level hook
  covers that repo). Deviation: `distill_hook.py` itself is not deleted,
  because P2 does not require it and the file carries uncommitted changes
  that predate this plan; its README section moves to S-AUD-09. Fresh
  print-mode session in the CUS-BMS repo: whole Read of the 43 KB
  `tests/test_distiller.py` allowed (994 lines), Grep blocked, the
  comment-unlock bypass blocked, `tail -f build.log` allowed (no 33 KB
  file exists in that tree). memdb: constraint `workstation:3455`
  (subject `read-policy`, 470 chars, carries the non-policy guidance of
  3329 in its rationale) superseded `workstation:3328` and `3329`;
  `digest --project global --part core-setup` shows one read-policy row.
  `tests/eval/queries.jsonl` probe now expects 3455; real-store eval
  hit@1 0.657, hit@5 0.943, MRR 0.795 (the probe ranks 3455 second).
  Episode `workstation:3458`.
- 2026-09-13: S-AUD-09 done (CUS-BMS files left uncommitted, as decided).
  The six files carry one byte-identical `## Read policy` block (802
  chars, checked by a script) ending in the source-of-truth line.
  Contradictions removed: README rule 4, both skills and the CUS-BMS
  CLAUDE.md now all say "skeleton/slice to understand, Read the real file
  whole before editing"; window-read, the 8 KB deny and the `output\`
  exemption are gone from every doc; the playbook no longer recommends the
  harness Grep/Glob tools. Test counts: pytest 74 passed (README already
  said 74; DEPLOY said 51 + 5 and now says 74 via pytest, 62 via the
  unittest discovery that `deploy_check.ps1` runs, plus 5 cleaner tests).
  MCP gap documented in the README (a table of the CLI options that
  `search_repo` and `find_files` do not expose) rather than added to
  `api.py`. Acceptance: `search -F "limit <= 250"` still hits one file,
  `distill_hook.py`, whose docstring now opens with a RETIRED banner and
  the source-of-truth line; the remaining text there describes the retired
  code, not a live rule. Not changed (outside the six files):
  `deploy_check.ps1` still pipe-tests the retired hook; DEPLOY.md says it
  proves nothing about enforcement. Found on the way:
  `distiller/ignore.py` (added in S-AUD-07) is untracked and matched by
  the parent repository's `CUS-BMS/` ignore line, while the tracked
  `search.py` imports it. Episode `workstation:3459`.
- 2026-09-13: S-AUD-10 done (CLAUDE.md review delegated, as decided).
  New `install/memdb-skill.template.md` (193 lines) rendered to
  `~/.claude/skills/memdb/SKILL.md` and `~/.codex/skills/memdb/SKILL.md`;
  `install/memory-persistence-rule.template.md` v2 is 13 lines with
  `{{SKILL_PATH}}`; the user-level CLAUDE.md block and the Codex rule were
  regenerated from it (originals under
  `~/.claude/memory/install-backups/2026-09-13-*.bak`, the location
  AGENT_INSTALL step 8 names). `distill.py budget ~/.claude/CLAUDE.md`:
  4,673 -> 2,475 tokens. The template/Codex diff is one line, the digest
  line. A fresh print-mode session loaded the memdb skill through the
  Skill tool and quoted its seven section titles and the subject-keyed
  status syntax. `<drive-root>/.claude/rules/session-management.md` is a
  three-line pointer (tracked in the drive-root repository, left
  uncommitted there). Mapping table:
  `memdb/docs/audits/2026-09-13-instruction-mapping.md`. AGENT_INSTALL
  step 8 and `install/README.md` now cover the skill. Deviations and
  gaps: (1) the goal's "<= 3.5k tokens of standing text" is not met:
  CLAUDE.md 2,475 plus user rules 4,746 (multi-host 1,685, private data
  558, and the rendered `memdb-core-global.md` 2,503 that S-AUD-04 moved
  out of the digest) = 7,221; the acceptance criterion (CLAUDE.md <=
  2,500) is met. (2) The episode trigger now also skips pure
  question-and-answer turns in Claude Code, harmonised with the Codex
  rule. (3) "CLAUDE.md files link to" the policy holds for the user-level
  file (a two-line Read Policy pointer); the CUS-BMS CLAUDE.md keeps the
  identical policy block that S-AUD-09 required. Episode `workstation:3461`.
- 2026-09-13: S-AUD-11 done. `journal.py`: `TornTail` for an unparsable
  last line (an earlier bad line still raises the decode error),
  `verify_chain` returns `torn tail at byte N`, `tail_for_append` refuses
  writes with the repair steps (also when the last line lacks its
  newline), `host_id()` refuses a `MEMDB_HOST` that differs from the
  host-id file unless `MEMDB_HOST_OVERRIDE=1`, `head_of_bytes`. `mem.py`:
  `journal-head --file <path>|-`, doctor reports the torn tail under
  `chain:<host>` and `heads`, `verify --full` stops before replay on a
  torn tail, `main` turns any other `TornTail` into a one-line exit.
  `memdb_sync.sh`: foreign-journal head comparison before materializing
  (local ahead, or same seq with another hash, is an INTEGRITY stop that
  leaves the file untouched; an unreadable head also stops), a failed
  `mv` fails the sync without advancing last-seen, a failed checkout
  exits 1, and the same `MEMDB_HOST` conflict check. `hub-config.md`:
  Repairs section. Tests: 5 new in `tests/test_journal.py`, 4 in
  `tests/test_sync_guards.py` (scratch bare hub, a PATH shim for `mv`, an
  `index.lock` for checkout); conftest and the bench set the override.
  178 memdb tests pass; bench 100,000/1,000 inside budget (append 11.9 ms,
  snapshot rebuild 0.68 s, snapshot verify 3.2 s, suffix chain 0.009 s).
  Real store: `MEMDB_HOST=laptop mem doctor` on the workstation reports
  the conflict and exits 1. Additions beyond the letter: the sync also
  stops on same-seq/different-hash heads and unreadable heads, and the
  missing-final-newline case is treated as a torn tail for writers.
  Episode `workstation:3463`; core-setup constraint `workstation:3464`
  (memdb-host-override).
- 2026-09-13: S-AUD-12 done. `record-episode` always writes payload
  `resolves` (from the document, default empty); with the field present
  `apply_episode` closes exactly the open blockers named by uid or by
  subject within the project and reports `resolves_unmatched`; events
  without it keep the substring rule. `supersede` refuses another project
  or kind without `--cross`; `close` refuses a superseded record without
  `--force`; appliers unchanged. Skill and rule template document
  `resolves` (CLAUDE.md block and Codex rule re-rendered: 2,478 tokens,
  one-line template/Codex diff unchanged; skill 198 lines). Tests: 4 new
  in `tests/test_episode.py` (legacy substring replay, named-only close
  including a uid and an unmatched name, a `none` blocker left open,
  validation), 2 in `tests/test_cli.py`; the S-AUD-06 test now closes via
  `resolves`. 184 memdb tests pass; `verify --full` on the real store with
  the new applier: ok, projection match. Deviation: blockers created by
  the same episode are never closed by its own `resolves`. Episode
  `workstation:3466`.
- 2026-09-13: S-AUD-13 code done. `record-episode` takes the session id
  from `CLAUDE_CODE_SESSION_ID` and the transcript from
  `~/.claude/memory/sessions/<id>.json`, else `~/.claude/projects/*/<id>.jsonl`;
  flags win; the result JSON carries `provenance` sources. `add --origin
  user|agent|tool` (default agent) in the payload; schema v4 adds
  `origin TEXT NOT NULL DEFAULT 'agent'`; `apply_add` projects it (old
  events -> agent) and a user re-statement upgrades an agent row, never
  the reverse. Digest marks user rows `(c <uid> u)`; search summaries
  carry `origin`. Transition safety beyond the letter: `projections_equal`
  treats differing schema versions as drift instead of failing on the
  missing column, and digest tolerates a v3 row, so readers work and
  writes are refused (exit 2, nothing journaled) between the code update
  and the rebuild. Rehearsed on a copy of the real DB: digest on v3 ok,
  a write refused, `rebuild --verify` fell back to full replay with drift
  true and no record regression, `verify --full` ok, 19,249 rows
  origin agent. Tests: provenance defaults, origin marker and upgrade,
  v3 refusal; conftest removes `CLAUDE_CODE_SESSION_ID` and points the
  session and project dirs at tmp. 187 memdb tests pass. Skill 199 lines,
  CLAUDE.md 2,483 tokens. Open acceptance item: >= 90 percent of new
  episodes carry `_transcript` after one week (count due 2026-09-20).
- 2026-09-13: S-AUD-14 done except the two-day acceptance. Workstation:
  task `memdb-sync-daily` registered daily 12:00 with `StartWhenAvailable`
  (catch-up), running `memdb/sync/scheduled_sync.sh` headless through Git
  Bash; its first manual start logged `memdb-sync: ok` and `== exit 0 ==`.
  Deviation: the task calls the wrapper instead of `memdb_sync.sh`
  directly, so each log entry carries a timestamp and exit code. D-4
  applied: `mem.db.probe` and `mem.db.probe2` deleted, `mem.db.prev` and
  `mem.db.v1.bak` kept; doctor `checks.memory_dir` lists unexpected files
  (none now on any host). `AGENT_INSTALL.md` steps 8 and 10 rewritten;
  `hub-config.md` gains Cadence and Journal root layout. Laptop and pi:
  pulled to 75b141b, `rebuild --full` and `verify --full` ok. The laptop
  got the rendered v2 rule block (replacing its v1 block), both skills,
  the Codex rule and AGENTS.md include, the user-level SessionStart hook
  and `autoMemoryEnabled: false`, with backups under
  `~/.claude/memory/install-backups/`; the pi has no harness files.
  Episodes `laptop:4` and `pi:2`, both listed by
  `mem search --project memdb --part install` on the workstation after
  sync. Deviation: both Linux hosts keep their existing 03:17
  `memdb_sync.sh` cron line instead of a second schedule; `hub-config.md`
  Cadence documents that line. Open acceptance item: `sync.log` shows
  `memdb-sync: ok` on two consecutive scheduled days (first scheduled
  runs 2026-09-13 and 2026-09-14 at 12:00).

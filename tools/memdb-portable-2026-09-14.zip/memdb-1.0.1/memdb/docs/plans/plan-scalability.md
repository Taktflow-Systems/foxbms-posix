# memdb scalability plan — speed and correctness first

## How to read this

Audience: a future AI worker landing cold, with no prior conversation
context. Each step below is self-contained: Step ID, Goal, Inputs,
Deliverables (concrete file paths), Acceptance criteria (independently
checkable), Gate, and Definition of done. Execute steps in order unless a
step says it is independent. The gates are the memdb test suite
(`memdb/tests/`) plus the full-replay oracle (`mem rebuild --verify` /
`mem verify`), which this plan deliberately PRESERVES as the source of
truth for every optimization: nothing in this plan changes what "correct"
means — full replay of the journals remains the definition of truth.

Baseline measured 2026-08-31 (workstation, 2,598 events, 7.3 MB journal,
29 MB DB): `digest`/`search` ~0.10 s; `add` 0.18 s; `rebuild --verify`
3.76 s (~1.4 ms/event). Growth ~160 events/day => ~60k events/year
(~170 MB/year journal). All linear-cost paths hit minutes-per-operation
within roughly one year at this pace.

Research basis (2026-08-31 web research; primary sources):
snapshot/checkpoint patterns (kurrentdb.kurrent.io/blog/snapshots-in-event-sourcing,
developer.confluent.io Kafka Streams checkpointing), incremental
hash-chain verification via persisted trust anchors (RFC 6962,
c2sp.org/tlog-checkpoint, sigstore rekor-monitor), SQLite/FTS5 envelopes
(sqlite.org/fts5.html, sqlite.org/wal.html, sqlite.org/howtocorrupt.html),
log segment rotation (kafka.apache.org implementation/log, git-scm.com/docs/git-repack),
git multi-writer replication hazards (git-scm.com/docs/git-gc,
gitlab.com/gitlab-org/gitaly MR 4410).

## Invariants this plan must not break

- The journal is append-only and hash-chained; events are never rewritten.
- Full replay of all journals is the definition of truth; every fast path
  must remain provably equal to it and fall back to it when its own
  artifacts are missing or stale (snapshots/anchors are disposable caches).
- Appends run under the cross-process journal lock; reads stay lock-free.
- uid (`<host>:<seq>`) is the only stable address; local ids are derived.
- `swap_in` atomic replacement of the projection; readers never see a
  missing mem.db. (Corollary from sqlite.org/howtocorrupt.html section 2.5:
  the projection must NOT move to WAL mode while the swap-replace pattern
  exists — WAL sidecar files plus file replacement is a documented
  corruption vector. Keep DELETE journal mode for the projection.)
- Sync fails loudly; silent divergence is never acceptable.

## Status

2026-08-31: S-01 through S-06 IMPLEMENTED, verified (99 pytest green,
100k-event budget gate green: append 18 ms steady-state, snapshot
rebuild 0.94 s vs 91.8 s full = ~100x) and validated on the real store
(full oracle 6.6 s green, routine rebuild/verify in snapshot mode,
scratch-hub non-FF and shallow refusals proven, hub gc config pinned).
Measured numbers: docs/perf-budgets.md. One deviation from the text
below: the head sidecar and anchor live under `<journal-root>/derived/
<host>/` instead of `journal/<host>/` + gitignore - a derived-state
directory outside the replicated tree cannot be committed by accident,
which is strictly stronger than an ignore rule. S-07 remains deferred
behind its trigger (any journal file > 50 MB or sync materialization
> 2 s).

## Steps

### S-MEM-SCALE-01: benchmark harness and scale gates

- **Goal**: Make every later optimization provable — a synthetic-journal
  generator plus timed budget assertions, so speedups are measured and
  regressions fail a test, not a feeling.
- **Inputs**: `memdb/mem.py`, `memdb/journal.py`,
  `memdb/tests/test_concurrency.py` (pattern reference). No production
  journal access: benchmarks run on a temp `MEMDB_JOURNAL`/`MEMDB_PATH`.
- **Deliverables**:
  - `memdb/tests/bench_scale.py` — generates a synthetic journal
    (parameterized: N events across 3 hosts, realistic payload mix of
    ~70% add / ~25% episode / 5% close-supersede), then times: single
    `append_event`, `rebuild`, `rebuild --verify`, `verify`, `digest`,
    `search`; prints a JSON report and asserts budgets.
  - `memdb/docs/perf-budgets.md` — the budget table (initial values
    below) with the measurement environment noted.
- **Acceptance criteria**:
  - Runs on Windows (Git Bash python) and Linux with stdlib only.
  - Budgets at N=100k events (tunable constants at top of file):
    `append_event` < 50 ms; `rebuild` < 60 s pre-S-04 (documented as
    expected-fail marker once S-04 lands, then < 10 s from snapshot);
    `verify` peak RSS < 200 MB once S-02 lands.
  - Never touches `~/.claude/memory` (asserts env override is set).
- **Gate / review reference**: memdb test suite; report reviewed in the
  step's episode record.
- **Definition of done**: `python memdb/tests/bench_scale.py --events 100000`
  emits a budget report with pass/fail per metric on both OS families.

### S-MEM-SCALE-02: O(1) journal append (head sidecar)

- **Goal**: Eliminate the full-file read+parse in `append_event`
  (journal.py `read_events(path)` on every write) — the worst cumulative
  cost (O(n) per write, O(n^2) lifetime).
- **Inputs**: `memdb/journal.py` (`append_event`, `read_events`,
  `verify_chain`), S-01 harness.
- **Deliverables**:
  - `memdb/journal.py` — `append_event` maintains a head sidecar
    `journal/<host>/head.json` `{seq, hash, line_len}` under the existing
    lock; on every append it validates the sidecar against the journal's
    actual last line (seek to tail, read the final line only, compare
    hash) and self-heals by full scan on any mismatch or missing sidecar.
  - `memdb/tests/test_head_sidecar.py` — covers: fresh journal, sidecar
    missing, sidecar stale (simulated crash between append and sidecar
    write), sidecar corrupt JSON, concurrent-append exclusion unchanged.
- **Acceptance criteria**:
  - `append_event` cost is independent of journal length (S-01 shows
    < 50 ms at 100k events).
  - Deleting `head.json` at any point changes no observable behavior
    except one slower append (self-heal path) — proven by test.
  - `verify_chain` and `all_events` semantics unchanged (they still read
    full files; that is S-03/S-04 territory).
  - The sidecar is git-ignored in the journal repo (it is per-clone
    derived state, not part of the replicated record).
- **Gate / review reference**: S-01 budgets + full `mem verify` green on
  the real store after deployment.
- **Definition of done**: benchmark shows flat append latency vs N, and
  the sidecar-deletion test passes.

### S-MEM-SCALE-03: streaming verify comparison

- **Goal**: Replace `normalized_dump` (two full-DB JSON strings in RAM,
  ~2x DB size peak) with an ordered streaming row-by-row comparison,
  O(1) memory, identical verdicts.
- **Inputs**: `memdb/mem.py` (`normalized_dump`, `cmd_verify`,
  `cmd_rebuild`), S-01 harness.
- **Deliverables**:
  - `memdb/mem.py` — `projections_equal(path_a, path_b)` iterating both
    DBs over uid-ordered cursors (records then links), normalizing
    per-row exactly as `normalized_dump` did (ids mapped to uids);
    `cmd_verify`/`cmd_rebuild --verify` switched to it.
  - `memdb/tests/test_streaming_compare.py` — equal DBs, one-row body
    drift, missing row, link drift, superseded_by pointer drift: each
    detected; result identical to the old dump comparison on the same
    fixtures.
- **Acceptance criteria**:
  - Verify peak RSS bounded (< 200 MB at 1M synthetic records, S-01).
  - Differential test: for 50 randomized fixture pairs, new comparator
    verdict == old `normalized_dump` string-equality verdict.
- **Gate / review reference**: S-01 budgets; differential test.
- **Definition of done**: `mem verify` on the real store returns the same
  result before/after, and the 1M-row RSS budget passes.

### S-MEM-SCALE-04: verified-head anchors (incremental chain verify)

- **Goal**: Amortize hash-chain verification: store the last-verified
  `(seq, line hash)` per host; routine verify walks only the suffix;
  full walk stays available and scheduled. Pattern: persisted
  checkpoints / trust anchors (RFC 6962, c2sp tlog-checkpoint,
  rekor-monitor).
- **Inputs**: `memdb/journal.py` (`verify_chain`), `memdb/mem.py`
  (`chain_report`, `cmd_verify`, `cmd_doctor`), S-02 sidecar (shares the
  tail-read utility).
- **Deliverables**:
  - `memdb/journal.py` — `verify_chain(path, anchor=None)` verifying
    from an anchor `(seq, prev_hash)` forward; anchor persistence in
    `journal/<host>/verified-head.json`, updated ONLY after a successful
    verify, never on failure.
  - `memdb/mem.py` — `verify` uses anchors by default; new flag
    `verify --full` forces the whole-chain walk; `doctor` reports anchor
    age (events since last full walk).
  - Anchor replication: this host's verified view of EVERY host's head is
    committed to its own journal branch as
    `journal/<host>/witness-heads.json` (hosts witness each other — a
    rewritten prefix on one host is detected by any other host's stored
    anchor mismatching on next sync).
  - `memdb/tests/test_anchors.py` — suffix verify passes on valid
    append; prefix tampering BELOW the anchor is caught by `--full` and
    by a peer's witness file; anchor never advances past a failure.
- **Acceptance criteria**:
  - Routine `verify` cost proportional to events since last verify.
  - `--full` behavior byte-identical to today's `verify_chain`.
  - Documented trust boundary: suffix verify trusts the anchor; the
    scheduled full walk (see S-06 sync policy) bounds undetected-tamper
    window; witness files bound it across hosts.
- **Gate / review reference**: S-01 budgets; tamper tests.
- **Definition of done**: tamper-below-anchor test demonstrates both
  detection paths (`--full`, witness mismatch), and routine verify time
  no longer grows with total history.

### S-MEM-SCALE-05: snapshot rebuild (O(tail) sync)

- **Goal**: Make routine `rebuild` O(events-since-snapshot) instead of
  O(all events), while full replay remains the oracle. Pattern:
  snapshot + delta with the SAME appliers replaying the tail (identity
  of the fold function is what keeps snapshot state provably equivalent
  to full replay — kurrent snapshot write-up).
- **Inputs**: S-03 (streaming compare), S-04 (anchors — the snapshot
  manifest IS an anchor set), `memdb/mem.py` (`replay`, `cmd_rebuild`).
- **Deliverables**:
  - `memdb/mem.py` — `snapshot` subcommand: full replay into
    `mem.db.snapshot` + manifest `mem.db.snapshot.manifest.json`
    `{schema_version, per-host {seq, hash}, db_content_hash}`; `rebuild`
    gains `--from-snapshot` (default when a valid manifest exists):
    copy snapshot, verify manifest chains as anchors, replay only events
    past each host's snapshot seq with the unchanged appliers, then
    `swap_in`. Snapshot invalidation: schema_version mismatch or any
    manifest/chain mismatch => loud fallback to full replay (never
    silent).
  - `memdb/sync/memdb_sync.sh` — uses snapshot rebuild for routine
    syncs; every Nth sync (or `MEMDB_FULL_VERIFY=1`) runs the full
    replay + streaming compare oracle and refreshes the snapshot.
  - `memdb/tests/test_snapshot.py` — snapshot+tail replay produces a DB
    that the streaming comparator proves equal to full replay (the core
    equivalence proof, run over randomized event mixes); stale-schema
    snapshot falls back loudly; missing snapshot falls back loudly.
- **Acceptance criteria**:
  - S-01 budget: routine rebuild < 10 s at 100k total events with a
    snapshot 1k events old.
  - Equivalence property test green over >= 20 randomized event streams.
  - Journal lock hold time during routine sync drops proportionally
    (measured in S-01 report).
- **Gate / review reference**: S-01 budgets; equivalence property test;
  first real-store deployment must run one full `rebuild --verify`
  before and after.
- **Definition of done**: two consecutive real syncs — one snapshot-based,
  one full-oracle — both green with `projection_match=true`.

### S-MEM-SCALE-06: sync and hub hardening (independent of S-02..05)

- **Goal**: Close the known git-replication failure modes: hub GC
  pruning race, non-fast-forward as undetected tamper/dual-writer
  signal, shallow-clone verification blind spot.
- **Inputs**: `memdb/sync/memdb_sync.sh`, hub repo config (self-hosted).
- **Deliverables**:
  - `memdb/sync/memdb_sync.sh` — asserts `--is-shallow-repository` is
    false (else FAIL); every fetch/materialization asserts the remote
    branch is a fast-forward of the last-seen ref (stored under
    `.git/memdb-last-seen/<host>`), treating non-FF as a stop-and-report
    integrity event, never auto-resolved; push never uses `--force`.
  - `memdb/docs/hub-config.md` — required hub settings and the why:
    `gc.pruneExpire` >= 2 weeks (default; never `now`), `gc.auto 0` with
    manual quiet-time gc, no aggressive-gc cron (git-gc race: a
    concurrent push's objects can be pruned; GitLab/Gitaly ships the
    same mitigation).
  - Full-verify cadence policy written into the same doc: every Nth
    sync and at least weekly, `MEMDB_FULL_VERIFY=1` (ties S-04/S-05
    trust windows to a concrete bound).
- **Acceptance criteria**:
  - Simulated non-FF remote (rewritten test branch in a scratch repo)
    makes sync exit non-zero with an explicit integrity message.
  - Shallow scratch clone makes sync exit non-zero.
  - Hub config verified once against the doc and recorded in the
    episode.
- **Gate / review reference**: scratch-repo integration test run
  documented in the step's episode; no CI exists for the hub itself.
- **Definition of done**: both failure simulations refuse loudly and the
  hub config matches `memdb/docs/hub-config.md`.

### S-MEM-SCALE-07: journal segment rotation (deferred until trigger)

- **Goal**: Bound per-file costs (append tail-read already fixed by
  S-02; remaining: whole-file materialization in sync, git repack cost
  on an ever-growing blob) by rolling the journal into immutable
  segments, Kafka-style.
- **Trigger to activate this step**: any host journal file > 50 MB, or
  measured sync materialization > 2 s. Do not build earlier — S-01
  through S-06 remove all urgent pressure; this is cheap insurance whose
  design is fixed now so the trigger can be executed cold.
- **Inputs**: S-02 sidecar, S-04 anchors (segment boundaries are natural
  anchor points), `memdb/journal.py` (`host_file`, `read_events`,
  `list_hosts`), `memdb/sync/memdb_sync.sh` (per-file materialization).
- **Deliverables**:
  - `memdb/journal.py` — active file rolls at 10k events or 10 MB
    (whichever first) to `events-<first-seq zero-padded 10>.jsonl`;
    closed segments immutable forever; readers iterate segments in name
    order (lexicographic == seq order); hash chain spans segments
    unchanged.
  - `memdb/sync/memdb_sync.sh` — materializes all segment files per
    host; closed segments are skipped when the local copy's hash
    matches.
  - `memdb/tests/test_segments.py` — rotation boundary, chain continuity
    across segments, mixed segmented/unsegmented hosts (migration), and
    `verify --full` across segments.
- **Acceptance criteria**:
  - Rotation never rewrites a closed segment (asserted by mtime+hash in
    test).
  - A pre-segmentation journal keeps working untouched (migration is
    opt-in per host at rotation time, no flag day).
  - No segment may approach git's `core.bigFileThreshold` (512 MB —
    delta compression cutoff); the 10 MB roll bound enforces this by two
    orders of magnitude.
- **Gate / review reference**: memdb test suite; one full
  `verify --full` on a segmented synthetic store.
- **Definition of done**: synthetic 100k-event store rotates into
  segments and passes `verify --full` and snapshot rebuild end-to-end.

## Explicitly deferred (watch items, no step yet)

- **FTS/DB size amplification** (29 MB DB from 7.3 MB journal, ~4x):
  inside SQLite's comfort zone by orders of magnitude
  (sqlite.org/fts5.html; envelopes hold to low-M rows). Revisit only if
  DB > 500 MB: options in priority order are `INSERT INTO
  records_fts(records_fts) VALUES('optimize')` after rebuild,
  `detail=column`, external-content FTS (halves size, but
  trigger-divergence risk gives silently wrong MATCH results — needs its
  own test step). Basis: research 2026-08-31.
- **WAL mode for the projection**: rejected for now, not deferred — see
  Invariants (swap-replace + WAL sidecars is a documented corruption
  vector on Windows). Re-open only if `swap_in` is ever replaced by
  in-place rebuild-within-transaction.
- **Parallel replay**: linear speedup is documented for partitioned
  projections, but our appliers are order-dependent across hosts
  (gated_insert supersede logic); do not parallelize without a
  correctness design. No trigger defined; snapshot rebuild (S-05) makes
  it unnecessary at any projected scale.

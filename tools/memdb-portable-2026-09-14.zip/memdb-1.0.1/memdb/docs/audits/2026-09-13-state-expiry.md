# State expiry: one-time cleanup, 2026-09-13

Plan `memdb/docs/plans/plan-memdb-audit-followup.md`, step S-AUD-06,
finding F-08, decision D-3. Store: the workstation projection of all host
journals.

## Dry run

    mem consolidate --dry-run --expire-states 60

| measure | value |
|---|---|
| records | 19,203 |
| open `state` rows | 4,308 |
| open `state` rows last confirmed 60 or more days ago | 794 |
| rows the run closes | 794, all kind `state`, all confidence `confirmed` |
| by age of last confirmation | 60-89 days: 758; 90-179 days: 36; 180 or more: 0 |
| origin | 794 of 794 are children of an episode (auto-extracted status lines) |
| rows in part `core-setup` | 0 |
| projects touched | 21; the largest single project holds 250 of the rows |
| duplicate merges / contradiction links | 0 / 0 |
| unverified rows demoted by the 90-day rule | 0 |

## Decision D-3

Applied, by the worker under the user's delegation ("keep going by
yourself no question ask"). Rationale: every row is a point-in-time status
line that the pre-S-AUD-06 rule turned into an open record; none is
core-setup; the run merges and supersedes nothing; closing never deletes,
the parent episode keeps the full text, and a fact that still holds comes
back by re-stating it under the same subject.

## Applied

    mem consolidate --expire-states 60

| measure | value |
|---|---|
| journal event | `consolidate`, workstation seq 3452 (its payload lists every closed uid) |
| open `state` rows | 3,514 |
| open `state` rows last confirmed 60 or more days ago | 0 |
| `mem verify --full` with the S-AUD-06 applier | ok, projection match, 4.9 s |

## From here on

- `record-episode` writes payload `"extract": "explicit"`: only
  `current_state.status` objects with a `subject` become `state` rows.
- `memdb_sync.sh` runs `mem consolidate --expire-states 30` after each
  green weekly full oracle (`MEMDB_EXPIRE_STATES_DAYS` overrides 30).

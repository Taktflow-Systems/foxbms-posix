# Fresh-machine acceptance: memdb 1.0.0 from the artifact alone

Date: 2026-09-13. Plan step: S-PKG-05 (fresh-machine half), plan
`memdb/docs/plans/plan-memdb-memory-quality.md`.

## How to read this

Audience: whoever needs evidence that memdb 1.0.0 installs and operates on
a machine that never saw the source checkout. The summary and findings
come first, then two transcripts, one per platform, produced by the same
stdlib driver. Each transcript lists every command, its exit code and
wall time, its output, and the check applied to it. Paths are redacted to
placeholders: `<tmp>` is the run's temp directory, `<release>` the
directory holding the artifacts, and `<interpreter>` the Python running
the `.pyz`.

## What was run

Each run is one temp directory holding two simulated machines. `HOME`,
`USERPROFILE` and `MEMDB_HOME` point into it, `PYTHONPATH` is removed and
`MEMDB_NO_OS_SCHEDULE=1` is set, so the `.pyz` is the only memdb code the
interpreter can import and no real store, harness file or schedule is
touched.

1. `--version`, and the pyz sha256 against its `SHA256SUMS` line.
2. First machine: `install --host fresh --hub "new <tmp>/hub.git" --harness claude-code --yes`.
   The report must show the pyz command form, a passing selftest, a green
   first sync, green verify and doctor, and no warnings.
3. `add` a core-setup constraint, then `record-episode`.
4. `sync`: the last line must be `memdb-sync: ok (host=fresh)`.
5. `verify --full`.
6. The SessionStart hook, run exactly as the harness would: the command
   string registered in `settings.json`, fed Claude-shaped stdin. It must
   inject the constraint.
7. `install` again: no changed file and no new episode.
8. `uninstall --keep-data --yes`: the hook is removed, then `verify --full`
   confirms the journal and DB are intact.
9. Second machine: `install --host second --hub "join <tmp>/hub.git"`,
   then `search` must find the first machine's episode uid.

The same scenario is automated as `memdb/tests/test_fresh_machine.py`
(`MEMDB_RUN_SLOW=1`, and `MEMDB_FRESH_PYZ=<pyz>` on a target).

## Summary

| | Windows (workstation, temp HOME) | Linux (laptop, temp HOME) |
|---|---|---|
| Python | 3.14.6, AMD64 | 3.12.3, x86_64 |
| artifact | release-candidate `.pyz`, sha256 matches `SHA256SUMS` | same `.pyz`, copied by scp, `sha256sum -c` OK for all three artifacts |
| `pyz selftest` from a directory outside any checkout | ok, 2.1 s (also ok under Python 3.13.14, 2.0 s) | ok from `/tmp`, 1.3 s |
| first install (budget 60 s) | 4.3 s | 2.1 s |
| second install (no-op) | 3.7 s | 1.7 s |
| joining machine install | 4.5 s | 1.8 s |
| whole manual run | 15.0 s, 0 failed checks | 6.5 s, 0 failed checks |
| `test_fresh_machine.py` | passed, 17 s | passed, 6 s |
| full test suite | 284 passed, 2 skipped (slow and real-store tests), plus `test_fresh_machine.py` run separately | 284 passed, 2 skipped (Windows task form, real store), in a throwaway venv with `pytest`, `pyyaml` and the wheel |

## Findings from these runs, fixed before the release commit

| # | found by | defect | fix |
|---|---|---|---|
| F-1 | first laptop suite run: 4 failed, 5 errors | the release tests assume a git checkout: `tools/build_release.py` and `CHANGELOG.md` were missing from the portable zip | the portable zip now carries both, so an unpacked tree can rebuild and read its history |
| F-2 | same run | `test_explicit_schedule_uses_the_home_specific_name` looked for the entry name in the scheduler argv; on Linux it is in the crontab text on stdin | the fake scheduler keeps a crontab; a new test drives the cron path on every platform and proves foreign crontab lines survive |
| F-3 | same run | `test_rebuild_survives_a_reader_holding_the_db_open` (pre-existing) asserted a swap retry that only Windows needs: POSIX replaces an open file at once | the retry-time assertion applies on Windows only |
| F-4 | reading the pi before migration | `claude-code` was auto-detected wherever `~/.claude` existed, including a host where only memdb had created `~/.claude/memory` and `rules` | Claude Code counts as present when the `claude` CLI is on PATH or `~/.claude` holds anything besides `memory` and `rules`; otherwise auto-detection falls back to `generic`, which writes nothing |
| F-5 | first laptop suite run | `test_episode.py` needs PyYAML, a test-only dependency, and the throwaway venv lacked it | documented in `memdb/docs/release.md` |

The first manual runs used the 1.0.0 candidate built before F-1 to F-4.
They passed every check on both platforms. The transcripts below are
from the candidate that includes the fixes.

## Transcript: Windows run

- python: 3.14.6
- platform: Windows AMD64
- artifact: `memdb-<version>.pyz`, sha256 computed below

- pyz sha256 matches its SHA256SUMS line: True

- check: pyz sha256 matches SHA256SUMS -> OK

### [first] `python memdb-<version>.pyz --version`

exit 0, 0.13 s

```
memdb 1.0.0
```

- check: --version prints memdb and the version -> OK

### [first] `python memdb-<version>.pyz install --host fresh --hub new <tmp>/hub.git --harness claude-code --yes`

exit 0, 4.29 s

```
{
  "applied": true,
  "changed_files": [
    "<tmp>\\first\\home\\.claude\\memory\\host-id",
    "<tmp>\\first\\home\\.claude\\memory\\bin\\memdb.pyz",
    "<tmp>\\first\\home\\.claude\\memory\\bin\\memdb-1.0.0.pyz",
    "<tmp>\\first\\home\\.claude\\memory\\config.json",
    "journal-repo",
    "agent.host-id",
    "hub",
    "origin",
    "<tmp>\\first\\home\\.claude\\memory\\mem.db",
    "<tmp>\\first\\home\\.claude\\skills\\memdb\\SKILL.md",
    "<tmp>\\first\\home\\.claude\\CLAUDE.md",
    "<tmp>\\first\\home\\.claude\\settings.json"
  ],
  "changes": [
    {
      "applied": true,
      "changed": true,
      "kind": "file",
      "path": "<tmp>\\first\\home\\.claude\\memory\\host-id"
    },
    {
      "changed": true,
      "kind": "file",
      "path": "<tmp>\\first\\home\\.claude\\memory\\bin\\memdb.pyz",
      "source": "<release>\\memdb-1.0.0.pyz"
    },
    {
      "changed": true,
      "kind": "file",
      "path": "<tmp>\\first\\home\\.claude\\memory\\bin\\memdb-1.0.0.pyz",
      "source": "<release>\\memdb-1.0.0.pyz"
    },
    {
      "applied": true,
      "changed": true,
      "kind": "file",
      "path": "<tmp>\\first\\home\\.claude\\memory\\config.json"
    },
    {
      "applied": true,
      "branch": "fresh/journal",
      "changed": true,
      "kind": "git",
      "path": "journal-repo",
      "root": "<tmp>\\first\\home\\.claude\\memory\\journal"
    },
    {
      "changed": true,
      "from": null,
      "kind": "git",
      "path": "agent.host-id",
      "to": "fresh"
    },
    {
      "changed": true,
      "kind": "git",
      "path": "hub",
      "target": "<tmp>\\hub.git"
    },
    {
      "changed": true,
      "from": null,
      "kind": "git",
      "path": "origin",
      "to": "<tmp>/hub.git"
    },
    {
      "action": "init schema",
      "changed": true,
      "kind": "file",
      "path": "<tmp>\\first\\home\\.claude\\memory\\mem.db"
    },
    {
      "changed": false,
      "kind": "run",
      "path": "sync",
      "would_run": true
    },
    {
      "applied": true,
      "backup": null,
      "changed": true,
      "created": true,
      "kind": "file",
      "path": "<tmp>\\first\\home\\.claude\\skills\\memdb\\SKILL.md"
    },
    {
      "applied": true,
      "backup": null,
      "changed": true,
      "created": true,
      "kind": "file",
      "path": "<tmp>\\first\\home\\.claude\\CLAUDE.md"
    },
    {
      "applied": true,
      "backup": null,
      "changed": true,
      "created": true,
      "kind": "file",
      "path": "<tmp>\\first\\home\\.claude\\settings.json"
    },
    {
      "applied": null,
      "changed": false,
      "kind": "schedule",
      "path": "schedule:none:memdb-sync-daily-26a2a10f"
    },
    {
      "changed": false,
      "kind": "run",
      "path": "install-episode",
      "would_run": true
    },
    {
      "changed": false,
      "kind": "run",
      "path": "verify",
      "would_run": true
    },
    {
      "changed": false,
      "kind": "run",
      "path": "doctor",
      "would_run": true
    }
  ],
  "check": false,
  "command_form": "pyz",
  "command_form_detail": "<release>\\memdb-1.0.0.pyz",
  "doctor": {
    "failed": [],
    "ok": true,
    "warnings": []
  },
  "episode": {
    "ok": true,
    "recorded": true,
    "uid": "fresh:1"
  },
  "harness_source": "--harness argument",
  "harnesses": [
    "claude-code"
  ],
  "host": "fresh",
  "hub": {
    "mode": "new",
    "url": "<tmp>/hub.git"
  },
  "memdb_home": "<tmp>\\first\\home\\.claude\\memory",
  "preflight": [
    {
      "check": "python",
      "detail": "3.14.6",
      "ok": true
    },
    {
      "check": "sqlite_fts5",
      "detail": "3.50.4",
      "ok": true
    },
    {
      "check": "git",
      "detail": "C:\\Program Files\\Git\\cmd\\git.EXE",
      "ok": true
    },
    {
      "check": "interpreter",
      "detail": "<interpreter>",
      "ok": true
    },
    {
      "check": "pyz",
      "detail": "<release>\\memdb-1.0.0.pyz (1.0.0)",
      "ok": true
    },
    {
      "check": "hub:<tmp>\\hub.git",
      "detail": "creatable",
      "ok": true
    }
  ],
  "schedule": {
    "kind": "none",
    "name": "memdb-sync-daily-26a2a10f",
    "note": "MEMDB_HOME is set: an OS schedule needs an explicit --schedule HH:MM",
    "time": "12:00"
  },
  "selftest": {
    "detail": "{\"ok\": true, \"version\": \"1.0.0\", \"form\": \"pyz\", \"python\": \"3.14.6\", \"seconds\": 2.148, \"steps\": [{\"step\": \"init\", \"ok\": true, \"ms\": 206}, {\"step\": \"add\", \"ok\": true, \"ms\": 151}, {\"step\": \"record-episode\", \"ok\": true, \"ms\": 156}, {\"step\": \"close\", \"ok\": true, \"ms\": 308}, {\"step\": \"supersede\", \"ok\": true, \"ms\": 471}, {\"step\": \"rebuild --full\", \"ok\": true, \"ms\": 227}, {\"step\": \"verify --full\", \"ok\": true, \"ms\": 226}, {\"step\": \"digest\", \"ok\": true, \"ms\": 130}, {\"step\": \"search\", \"ok\": true, \"ms\": 127}, {\"step\": \"hook session-start\", \"ok\": true, \"ms\": 133}]}",
    "ok": true,
    "ran": true
  },
  "sync": {
    "detail": "memdb-sync: nothing to push yet (no commit on fresh/journal)\n{\"ok\": true, \"mode\": \"full\", \"chains\": {}, \"events\": 0, \"applied\": 0, \"unresolved\": [], \"projection_drift\": false, \"record_regression\": false, \"snapshot\": \"refreshed\", \"records\": 0, \"db\": \"<tmp>\\\\first\\\\home\\\\.claude\\\\memory\\\\mem.db\"}\n{\"merged\": [], \"contradictions\": [], \"demoted\": [], \"dry_run\": false, \"demoted_n\": 0}\nmemdb-sync: ok (host=fresh)",
    "ok": true,
    "ran": true
  },
  "verify": {
    "chains": {
      "fresh": "ok"
    },
    "mode": "snapshot",
    "ok": true,
    "projection_match": true,
    "unresolved": []
  },
  "version": "1.0.0"
}
```

- check: install exit 0, pyz form, selftest, sync, verify and doctor green, no warnings (4.3 s, budget 60 s) -> OK

### [first] `python memdb-<version>.pyz add --kind constraint --project freshproj --part core-setup --subject fresh-rule --body fresh machine rule: artifacts only`

exit 0, 0.15 s

```
{"action": "added", "id": 3, "uid": "fresh:2"}
```

- check: add -> OK

### [first] `python memdb-<version>.pyz record-episode --project freshproj --part work --task fresh --json <tmp>\episode.json`

exit 0, 0.16 s

```
{"episode_id": 4, "uid": "fresh:3", "children": {"decision": 0, "blocker": 0, "state": 0}, "closed_blockers": [], "resolves_unmatched": [], "resolves_ambiguous": [], "provenance": {"session_id": null, "transcript": null}}
```

- check: record-episode returns a fresh: uid -> OK

### [first] `python memdb-<version>.pyz sync`

exit 0, 1.11 s

```
{"ok": true, "chains": {"fresh": "ok"}, "mode": "snapshot", "events": 3, "applied": 3, "unresolved": [], "tail": 3, "projection_drift": false, "record_regression": false, "records": 4, "db": "<tmp>\\first\\home\\.claude\\memory\\mem.db"}
memdb-sync: ok (host=fresh)
```

- check: sync last line is memdb-sync: ok (host=fresh) -> OK

### [first] `python memdb-<version>.pyz verify --full`

exit 0, 0.22 s

```
{"ok": true, "chains": {"fresh": "ok"}, "projection_match": true, "unresolved": [], "mode": "full"}
```

- check: verify --full ok -> OK

### [first] `<interpreter> <tmp>\first\home\.claude\memory\bin\memdb.pyz hook session-start`

exit 0, 0.18 s

```
{"hookSpecificOutput": {"hookEventName": "SessionStart", "additionalContext": "# Memory digest: freshproj/core-setup\n\n## Goals and constraints (always in force)\n- (c fresh:2) fresh machine rule: artifacts only"}}
```

- check: registered hook command injects the constraint -> OK

### [first] `python memdb-<version>.pyz install --host fresh --hub new <tmp>/hub.git --harness claude-code --yes`

exit 0, 3.69 s

```
{
  "applied": true,
  "changed_files": [],
  "changes": [
    {
      "changed": false,
      "kind": "file",
      "path": "<tmp>\\first\\home\\.claude\\memory\\host-id"
    },
    {
      "changed": false,
      "kind": "file",
      "path": "<tmp>\\first\\home\\.claude\\memory\\bin\\memdb.pyz",
      "source": "<release>\\memdb-1.0.0.pyz"
    },
    {
      "changed": false,
      "kind": "file",
      "path": "<tmp>\\first\\home\\.claude\\memory\\bin\\memdb-1.0.0.pyz",
      "source": "<release>\\memdb-1.0.0.pyz"
    },
    {
      "changed": false,
      "kind": "file",
      "path": "<tmp>\\first\\home\\.claude\\memory\\config.json"
    },
    {
      "applied": null,
      "branch": "fresh/journal",
      "changed": false,
      "kind": "git",
      "path": "journal-repo",
      "root": "<tmp>\\first\\home\\.claude\\memory\\journal"
    },
    {
      "changed": false,
      "from": "fresh",
      "kind": "git",
      "path": "agent.host-id",
      "to": "fresh"
    },
    {
      "changed": false,
      "kind": "git",
      "path": "hub",
      "target": "<tmp>\\hub.git"
    },
    {
      "changed": false,
      "from": "<tmp>/hub.git",
      "kind": "git",
      "path": "origin",
      "to": "<tmp>/hub.git"
    },
    {
      "action": "init schema",
      "changed": false,
      "kind": "file",
      "path": "<tmp>\\first\\home\\.claude\\memory\\mem.db"
    },
    {
      "changed": false,
      "kind": "run",
      "path": "sync",
      "would_run": true
    },
 
... (3349 more chars)
```

- check: second install changes nothing and journals nothing -> OK

### [first] `python memdb-<version>.pyz uninstall --keep-data --yes`

exit 0, 0.19 s

```
{
  "changed_files": [
    "<tmp>\\first\\home\\.claude\\settings.json",
    "<tmp>\\first\\home\\.claude\\CLAUDE.md"
  ],
  "changes": [
    {
      "applied": true,
      "backup": "<tmp>\\first\\home\\.claude\\memory\\install-backups\\2026-09-13-settings.json.bak",
      "changed": true,
      "created": false,
      "kind": "file",
      "path": "<tmp>\\first\\home\\.claude\\settings.json"
    },
    {
      "applied": true,
      "backup": "<tmp>\\first\\home\\.claude\\memory\\install-backups\\2026-09-13-CLAUDE.md.bak",
      "changed": true,
      "created": false,
      "kind": "file",
      "path": "<tmp>\\first\\home\\.claude\\CLAUDE.md"
    }
  ],
  "check": false,
  "data": "kept: <tmp>\\first\\home\\.claude\\memory (journal and DB untouched)",
  "host": "fresh"
}
```

- check: uninstall --keep-data removes the hook -> OK

### [first] `python memdb-<version>.pyz verify --full`

exit 0, 0.22 s

```
{"ok": true, "chains": {"fresh": "ok"}, "projection_match": true, "unresolved": [], "mode": "full"}
```

- check: journal and DB intact after uninstall -> OK

### [second] `python memdb-<version>.pyz install --host second --hub join <tmp>/hub.git --harness claude-code --yes`

exit 0, 4.53 s

```
{
  "applied": true,
  "changed_files": [
    "<tmp>\\second\\home\\.claude\\memory\\host-id",
    "<tmp>\\second\\home\\.claude\\memory\\bin\\memdb.pyz",
    "<tmp>\\second\\home\\.claude\\memory\\bin\\memdb-1.0.0.pyz",
    "<tmp>\\second\\home\\.claude\\memory\\config.json",
    "journal-repo",
    "agent.host-id",
    "origin",
    "<tmp>\\second\\home\\.claude\\memory\\mem.db",
    "<tmp>\\second\\home\\.claude\\skills\\memdb\\SKILL.md",
    "<tmp>\\second\\home\\.claude\\CLAUDE.md",
    "<tmp>\\second\\home\\.claude\\settings.json"
  ],
  "changes": [
    {
      "applied": true,
      "changed": true,
      "kind": "file",
      "path": "<tmp>\\second\\home\\.claude\\memory\\host-id"
    },
    {
      "changed": true,
      "kind": "file",
      "path": "<tmp>\\second\\home\\.claude\\memory\\bin\\memdb.pyz",
      "source": "<release>\\memdb-1.0.0.pyz"
    },
    {
      "changed": true,
      "kind": "file",
      "path": "<tmp>\\second\\home\\.claude\\memory\\bin\\memdb-1.0.0.pyz",
      "source": "<release>\\memdb-1.0.0.pyz"
    },
    {
      "applied": true,
      "changed": true,
      "kind": "file",
      "path": "<tmp>\\second\\home\\.claude\\memory\\config.json"
    },
    {
      "applied": true,
      "branch": "second/journal",
      "changed": true,
      "kind": "git",
      "path": "journal-repo",
      "root": "<tmp>\\second\\home\\.claude\\memory\\journal"
    },
    {
      "changed": true,
      "from": null,
      "kind": "git",
      "path": "agen
... (4178 more chars)
```

- check: second machine joins the hub -> OK

### [second] `python memdb-<version>.pyz search --query alpha episode --project freshproj`

exit 0, 0.13 s

```
{"id": 4, "kind": "episode", "origin": "agent", "part": "work", "project": "freshproj", "status": "closed", "subject": "fresh", "summary": "fresh machine alpha episode", "uid": "fresh:3"}
```

- check: second machine finds the first machine's episode -> OK

Total: 15.0 s, 0 failed checks

## Transcript: Linux run

- python: 3.12.3
- platform: Linux x86_64
- artifact: `memdb-<version>.pyz`, sha256 computed below

- pyz sha256 matches its SHA256SUMS line: True

- check: pyz sha256 matches SHA256SUMS -> OK

### [first] `python memdb-<version>.pyz --version`

exit 0, 0.10 s

```
memdb 1.0.0
```

- check: --version prints memdb and the version -> OK

### [first] `python memdb-<version>.pyz install --host fresh --hub new <tmp>/hub.git --harness claude-code --yes`

exit 0, 2.06 s

```
{
  "applied": true,
  "changed_files": [
    "<tmp>/first/home/.claude/memory/host-id",
    "<tmp>/first/home/.claude/memory/bin/memdb.pyz",
    "<tmp>/first/home/.claude/memory/bin/memdb-1.0.0.pyz",
    "<tmp>/first/home/.claude/memory/config.json",
    "journal-repo",
    "agent.host-id",
    "hub",
    "origin",
    "<tmp>/first/home/.claude/memory/mem.db",
    "<tmp>/first/home/.claude/skills/memdb/SKILL.md",
    "<tmp>/first/home/.claude/CLAUDE.md",
    "<tmp>/first/home/.claude/settings.json"
  ],
  "changes": [
    {
      "applied": true,
      "changed": true,
      "kind": "file",
      "path": "<tmp>/first/home/.claude/memory/host-id"
    },
    {
      "changed": true,
      "kind": "file",
      "path": "<tmp>/first/home/.claude/memory/bin/memdb.pyz",
      "source": "<release>/memdb-1.0.0.pyz"
    },
    {
      "changed": true,
      "kind": "file",
      "path": "<tmp>/first/home/.claude/memory/bin/memdb-1.0.0.pyz",
      "source": "<release>/memdb-1.0.0.pyz"
    },
    {
      "applied": true,
      "changed": true,
      "kind": "file",
      "path": "<tmp>/first/home/.claude/memory/config.json"
    },
    {
      "applied": true,
      "branch": "fresh/journal",
      "changed": true,
      "kind": "git",
      "path": "journal-repo",
      "root": "<tmp>/first/home/.claude/memory/journal"
    },
    {
      "changed": true,
      "from": null,
      "kind": "git",
      "path": "agent.host-id",
      "to": "fresh"
    },
    {
      "changed": true,
      "kind": "git",
      "path": "hub",
      "target": "<tmp>/hub.git"
    },
    {
      "changed": true,
      "from": null,
      "kind": "git",
      "path": "origin",
      "to": "<tmp>/hub.git"
    },
    {
      "action": "init schema",
      "changed": true,
      "kind": "file",
      "path": "<tmp>/first/home/.claude/memory/mem.db"
    },
    {
      "changed": false,
      "kind": "run",
      "path": "sync",
      "would_run": true
    },
    {
      "applied": true,
      "backup": null,
      "changed": true,
      "created": true,
      "kind": "file",
      "path": "<tmp>/first/home/.claude/skills/memdb/SKILL.md"
    },
    {
      "applied": true,
      "backup": null,
      "changed": true,
      "created": true,
      "kind": "file",
      "path": "<tmp>/first/home/.claude/CLAUDE.md"
    },
    {
      "applied": true,
      "backup": null,
      "changed": true,
      "created": true,
      "kind": "file",
      "path": "<tmp>/first/home/.claude/settings.json"
    },
    {
      "applied": null,
      "changed": false,
      "kind": "schedule",
      "path": "schedule:none:memdb-sync-daily-8ecb8c70"
    },
    {
      "changed": false,
      "kind": "run",
      "path": "install-episode",
      "would_run": true
    },
    {
      "changed": false,
      "kind": "run",
      "path": "verify",
      "would_run": true
    },
    {
      "changed": false,
      "kind": "run",
      "path": "doctor",
      "would_run": true
    }
  ],
  "check": false,
  "command_form": "pyz",
  "command_form_detail": "<release>/memdb-1.0.0.pyz",
  "doctor": {
    "failed": [],
    "ok": true,
    "warnings": []
  },
  "episode": {
    "ok": true,
    "recorded": true,
    "uid": "fresh:1"
  },
  "harness_source": "--harness argument",
  "harnesses": [
    "claude-code"
  ],
  "host": "fresh",
  "hub": {
    "mode": "new",
    "url": "<tmp>/hub.git"
  },
  "memdb_home": "<tmp>/first/home/.claude/memory",
  "preflight": [
    {
      "check": "python",
      "detail": "3.12.3",
      "ok": true
    },
    {
      "check": "sqlite_fts5",
      "detail": "3.45.1",
      "ok": true
    },
    {
      "check": "git",
      "detail": "/usr/bin/git",
      "ok": true
    },
    {
      "check": "interpreter",
      "detail": "<interpreter>",
      "ok": true
    },
    {
      "check": "pyz",
      "detail": "<release>/memdb-1.0.0.pyz (1.0.0)",
      "ok": true
    },
    {
      "check": "hub:<tmp>/hub.git",
      "detail": "creatable",
      "ok": true
    }
  ],
  "schedule": {
    "kind": "none",
    "name": "memdb-sync-daily-8ecb8c70",
    "note": "MEMDB_HOME is set: an OS schedule needs an explicit --schedule HH:MM",
    "time": "12:00"
  },
  "selftest": {
    "detail": "{\"ok\": true, \"version\": \"1.0.0\", \"form\": \"pyz\", \"python\": \"3.12.3\", \"seconds\": 1.19, \"steps\": [{\"step\": \"init\", \"ok\": true, \"ms\": 138}, {\"step\": \"add\", \"ok\": true, \"ms\": 113}, {\"step\": \"record-episode\", \"ok\": true, \"ms\": 112}, {\"step\": \"close\", \"ok\": true, \"ms\": 177}, {\"step\": \"supersede\", \"ok\": true, \"ms\": 222}, {\"step\": \"rebuild --full\", \"ok\": true, \"ms\": 103}, {\"step\": \"verify --full\", \"ok\": true, \"ms\": 99}, {\"step\": \"digest\", \"ok\": true, \"ms\": 73}, {\"step\": \"search\", \"ok\": true, \"ms\": 69}, {\"step\": \"hook session-start\", \"ok\": true, \"ms\": 74}]}",
    "ok": true,
    "ran": true
  },
  "sync": {
    "detail": "memdb-sync: nothing to push yet (no commit on fresh/journal)\n{\"ok\": true, \"mode\": \"full\", \"chains\": {}, \"events\": 0, \"applied\": 0, \"unresolved\": [], \"projection_drift\": false, \"record_regression\": false, \"snapshot\": \"refreshed\", \"records\": 0, \"db\": \"<tmp>/first/home/.claude/memory/mem.db\"}\n{\"merged\": [], \"contradictions\": [], \"demoted\": [], \"dry_run\": false, \"demoted_n\": 0}\nmemdb-sync: ok (host=fresh)",
    "ok": true,
    "ran": true
  },
  "verify": {
    "chains": {
      "fresh": "ok"
    },
    "mode": "snapshot",
    "ok": true,
    "projection_match": true,
    "unresolved": []
  },
  "version": "1.0.0"
}
```

- check: install exit 0, pyz form, selftest, sync, verify and doctor green, no warnings (2.1 s, budget 60 s) -> OK

### [first] `python memdb-<version>.pyz add --kind constraint --project freshproj --part core-setup --subject fresh-rule --body fresh machine rule: artifacts only`

exit 0, 0.08 s

```
{"action": "added", "id": 3, "uid": "fresh:2"}
```

- check: add -> OK

### [first] `python memdb-<version>.pyz record-episode --project freshproj --part work --task fresh --json <tmp>/episode.json`

exit 0, 0.08 s

```
{"episode_id": 4, "uid": "fresh:3", "children": {"decision": 0, "blocker": 0, "state": 0}, "closed_blockers": [], "resolves_unmatched": [], "resolves_ambiguous": [], "provenance": {"session_id": null, "transcript": null}}
```

- check: record-episode returns a fresh: uid -> OK

### [first] `python memdb-<version>.pyz sync`

exit 0, 0.18 s

```
{"ok": true, "chains": {"fresh": "ok"}, "mode": "snapshot", "events": 3, "applied": 3, "unresolved": [], "tail": 3, "projection_drift": false, "record_regression": false, "records": 4, "db": "<tmp>/first/home/.claude/memory/mem.db"}
memdb-sync: ok (host=fresh)
```

- check: sync last line is memdb-sync: ok (host=fresh) -> OK

### [first] `python memdb-<version>.pyz verify --full`

exit 0, 0.10 s

```
{"ok": true, "chains": {"fresh": "ok"}, "projection_match": true, "unresolved": [], "mode": "full"}
```

- check: verify --full ok -> OK

### [first] `<interpreter> <tmp>/first/home/.claude/memory/bin/memdb.pyz hook session-start`

exit 0, 0.08 s

```
{"hookSpecificOutput": {"hookEventName": "SessionStart", "additionalContext": "# Memory digest: freshproj/core-setup\n\n## Goals and constraints (always in force)\n- (c fresh:2) fresh machine rule: artifacts only"}}
```

- check: registered hook command injects the constraint -> OK

### [first] `python memdb-<version>.pyz install --host fresh --hub new <tmp>/hub.git --harness claude-code --yes`

exit 0, 1.68 s

```
{
  "applied": true,
  "changed_files": [],
  "changes": [
    {
      "changed": false,
      "kind": "file",
      "path": "<tmp>/first/home/.claude/memory/host-id"
    },
    {
      "changed": false,
      "kind": "file",
      "path": "<tmp>/first/home/.claude/memory/bin/memdb.pyz",
      "source": "<release>/memdb-1.0.0.pyz"
    },
    {
      "changed": false,
      "kind": "file",
      "path": "<tmp>/first/home/.claude/memory/bin/memdb-1.0.0.pyz",
      "source": "<release>/memdb-1.0.0.pyz"
    },
    {
      "changed": false,
      "kind": "file",
      "path": "<tmp>/first/home/.claude/memory/config.json"
    },
    {
      "applied": null,
      "branch": "fresh/journal",
      "changed": false,
      "kind": "git",
      "path": "journal-repo",
      "root": "<tmp>/first/home/.claude/memory/journal"
    },
    {
      "changed": false,
      "from": "fresh",
      "kind": "git",
      "path": "agent.host-id",
      "to": "fresh"
    },
    {
      "changed": false,
      "kind": "git",
      "path": "hub",
      "target": "<tmp>/hub.git"
    },
    {
      "changed": false,
      "from": "<tmp>/hub.git",
      "kind": "git",
      "path": "origin",
      "to": "<tmp>/hub.git"
    },
    {
      "action": "init schema",
      "changed": false,
      "kind": "file",
      "path": "<tmp>/first/home/.claude/memory/mem.db"
    },
    {
      "changed": false,
      "kind": "run",
      "path": "sync",
      "would_run": true
    },
    {
      "changed": false,
      
... (3248 more chars)
```

- check: second install changes nothing and journals nothing -> OK

### [first] `python memdb-<version>.pyz uninstall --keep-data --yes`

exit 0, 0.11 s

```
{
  "changed_files": [
    "<tmp>/first/home/.claude/settings.json",
    "<tmp>/first/home/.claude/CLAUDE.md"
  ],
  "changes": [
    {
      "applied": true,
      "backup": "<tmp>/first/home/.claude/memory/install-backups/2026-09-13-settings.json.bak",
      "changed": true,
      "created": false,
      "kind": "file",
      "path": "<tmp>/first/home/.claude/settings.json"
    },
    {
      "applied": true,
      "backup": "<tmp>/first/home/.claude/memory/install-backups/2026-09-13-CLAUDE.md.bak",
      "changed": true,
      "created": false,
      "kind": "file",
      "path": "<tmp>/first/home/.claude/CLAUDE.md"
    }
  ],
  "check": false,
  "data": "kept: <tmp>/first/home/.claude/memory (journal and DB untouched)",
  "host": "fresh"
}
```

- check: uninstall --keep-data removes the hook -> OK

### [first] `python memdb-<version>.pyz verify --full`

exit 0, 0.10 s

```
{"ok": true, "chains": {"fresh": "ok"}, "projection_match": true, "unresolved": [], "mode": "full"}
```

- check: journal and DB intact after uninstall -> OK

### [second] `python memdb-<version>.pyz install --host second --hub join <tmp>/hub.git --harness claude-code --yes`

exit 0, 1.84 s

```
{
  "applied": true,
  "changed_files": [
    "<tmp>/second/home/.claude/memory/host-id",
    "<tmp>/second/home/.claude/memory/bin/memdb.pyz",
    "<tmp>/second/home/.claude/memory/bin/memdb-1.0.0.pyz",
    "<tmp>/second/home/.claude/memory/config.json",
    "journal-repo",
    "agent.host-id",
    "origin",
    "<tmp>/second/home/.claude/memory/mem.db",
    "<tmp>/second/home/.claude/skills/memdb/SKILL.md",
    "<tmp>/second/home/.claude/CLAUDE.md",
    "<tmp>/second/home/.claude/settings.json"
  ],
  "changes": [
    {
      "applied": true,
      "changed": true,
      "kind": "file",
      "path": "<tmp>/second/home/.claude/memory/host-id"
    },
    {
      "changed": true,
      "kind": "file",
      "path": "<tmp>/second/home/.claude/memory/bin/memdb.pyz",
      "source": "<release>/memdb-1.0.0.pyz"
    },
    {
      "changed": true,
      "kind": "file",
      "path": "<tmp>/second/home/.claude/memory/bin/memdb-1.0.0.pyz",
      "source": "<release>/memdb-1.0.0.pyz"
    },
    {
      "applied": true,
      "changed": true,
      "kind": "file",
      "path": "<tmp>/second/home/.claude/memory/config.json"
    },
    {
      "applied": true,
      "branch": "second/journal",
      "changed": true,
      "kind": "git",
      "path": "journal-repo",
      "root": "<tmp>/second/home/.claude/memory/journal"
    },
    {
      "changed": true,
      "from": null,
      "kind": "git",
      "path": "agent.host-id",
      "to": "second"
    },
    {
      "changed": true,
 
... (4037 more chars)
```

- check: second machine joins the hub -> OK

### [second] `python memdb-<version>.pyz search --query alpha episode --project freshproj`

exit 0, 0.07 s

```
{"id": 4, "kind": "episode", "origin": "agent", "part": "work", "project": "freshproj", "status": "closed", "subject": "fresh", "summary": "fresh machine alpha episode", "uid": "fresh:3"}
```

- check: second machine finds the first machine's episode -> OK

Total: 6.5 s, 0 failed checks

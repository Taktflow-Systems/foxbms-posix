# Instruction mapping: memdb rule block to skill (2026-09-13)

Plan `memdb/docs/plans/plan-memdb-audit-followup.md`, step S-AUD-10,
findings F-13 and F-14. Old text: the `memory-persistence-rule v1` block of
the user-level `~/.claude/CLAUDE.md` (backup kept outside this repository
under `~/.claude/memory/install-backups/`). New homes:

- **Rule block**: `install/memory-persistence-rule.template.md` v2, rendered
  into `~/.claude/CLAUDE.md` and (with the Codex digest line)
  `~/.codex/rules/end_of_job_handoff.md`.
- **Skill**: `install/memdb-skill.template.md`, rendered into
  `~/.claude/skills/memdb/SKILL.md` and `~/.codex/skills/memdb/SKILL.md`;
  section numbers below refer to it.

Result: `~/.claude/CLAUDE.md` 4,673 -> 2,475 tokens (`distill.py budget`);
rule block 13 lines; skill 193 lines.

## Old CLAUDE.md block

| old heading / rule | new location |
|---|---|
| Marker `memory-persistence-rule v1` | Rule block marker `memory-persistence-rule v2` |
| Heading "Global End-of-Job Memory Persistence Rule (memdb)" | Rule block heading "Memory Persistence Rule (memdb)" |
| Record every completed job as an episode | Rule block item 2; skill section 5 intro |
| Replaces the handoff rule; YAML handoffs only rendered on explicit request | Skill section 7 bullet 1; skill section 1 bullet 4 (files are views) |
| Global, all projects unless the user says not to record | Rule block "mandatory in every project unless the user says otherwise"; skill section 5 intro |
| Heading "The Memory Layer (log-first)" | Skill section 1 "The layer" |
| Journal is the system of record, replicated via git, one branch per host, hub | Skill section 1 bullet 1 |
| SQLite DB is a disposable projection; rebuild and verify; never edit journal or DB by hand | Skill section 1 bullet 1; rule block sentence 1 |
| Tool path and subcommand list | Rule block sentence 1 (tool path); skill header (subcommands, current list) |
| Host identity file; writes refuse without it | Skill section 1 bullet 2 |
| Address records by uid only; ids reassigned by sync; supersede guards and `--force` | Skill section 1 bullet 3 |
| Handoff YAML and digest files are rendered views, never read back | Skill section 1 bullet 4 |
| Optional SessionStart hook injects the digest | Skill section 2 intro; rule block item 1 |
| Heading "End Of Job: Record An Episode" | Skill section 5 |
| Record after a meaningful task, read-only analysis, code or doc changes, even with no repo change | Skill section 5 intro; rule block item 2 ("read-only analysis included") |
| Skip only when the user says so or the DB is unusable | Skill section 5 intro (also names pure question-and-answer turns, harmonised with the Codex rule) |
| Procedure 1: episode JSON to a scratchpad file, ASCII, shape | Skill section 5 step 2 (shape now shows subject-keyed status items) |
| Procedure 2: `record-episode` command | Rule block item 2; skill section 5 step 5 |
| Procedure 3: auto-extracted children, resolved blockers close, mention id, `--session-id` and `--transcript` | Skill section 5 steps 4, 5 and 7 (status extraction updated to the S-AUD-06 rule) |
| Procedure 4: run the sync; report a failed sync; never skip recording | Rule block item 2; skill section 5 step 6 |
| Project slug rules (real name, external sibling workspace, short and stable) | Skill section 5 "Slug rules", project bullet |
| Part slug rules (narrowest area, named slice, dominant path group, cross-cutting, short and stable) | Skill section 5 "Slug rules", part bullet |
| Content rules for achievement, decisions, current_state, blockers, next_steps | Skill section 5 "Content rules" |
| Update the canonical plan before recording; name it in the episode | Skill section 5 step 1 |
| State explicitly when no repository file changed | Skill section 5 "Content rules" |
| ASCII only | Skill section 5 step 2 and the validation table |
| Heading "Privacy Model" and its rules (lossless capture, no pre-redaction, redact-check at the boundary, render-handoff warning, never weaken patterns) | Skill section 6 |
| Heading "Task Start: Readback Via Digest And Search" | Skill section 2 |
| Readback 1: `digest`, default budget, pinned rows | Skill section 2 step 1 |
| Readback 2: `search` summaries, `get`, never default to `--full` | Skill section 2 step 2 (adds `--open-only`, `--recent`) |
| Readback 3: legacy YAML handoffs are archaeology only | Skill section 2 step 3 |
| Readback 4: always run the core-setup digest first | Rule block item 1; skill section 2 intro |
| Heading "Two Layers: Core Setup vs Handoff" | Skill section 3 |
| memdb is the only store; harness auto-memory retired, stale, archived | Rule block sentence 1; skill section 1 bullet 5 |
| core-setup part: durable facts, allowed kinds, one record per fact, pinned, supersede, global preferences | Skill section 3 bullet 1 (adds runbooks, body caps, `core-lint`) |
| Every other part is the handoff layer | Skill section 3 bullet 2 |
| Promotion rule | Skill section 3 bullet 3 |
| Heading "Semantic Records Outside Episodes": record durable goals, constraints, preferences at once | Rule block line "Record durable goals..."; skill section 4 |
| Close finished items; never delete, supersede | Rule block same line; skill section 4 |
| Heading "Rendering A Handoff File": only on explicit request, never hand-written | Skill section 7 bullet 1 |
| Heading "Failure Behavior": broken DB -> rebuild | Skill section 7 bullet 2 |
| Journal or tool unusable -> report, stopgap YAML handoff, backfill note | Skill section 7 bullet 3 |
| verify or doctor failure -> surface immediately, loss signal | Rule block line "A `mem verify` or `mem doctor` failure..."; skill section 7 bullet 4 |
| A broken memory layer never silently drops a job record | Skill section 7 bullet 4 |
| Heading "Final Response Rule": episode recorded or failure reported, id mentioned | Rule block item 2 (uid in the final response); skill section 5 step 7 |

## Read policy copies

| old copy | new state |
|---|---|
| Hook docstring, distill skill, memdb constraint, distiller docs | Source of truth `~/.claude/hooks/read_policy.py`; the distill skill carries the policy block; `~/.claude/CLAUDE.md` gained a two-line "Read Policy" pointer to both; the memdb row `workstation:3455` and the S-AUD-09 distiller docs point at the same module |

## `<drive-root>/.claude/rules/session-management.md`

Replaced by a three-line pointer to the memdb skill and the read policy
(backup under `~/.claude/memory/install-backups/`).

| old rule | new state |
|---|---|
| 180k token budget; warn at 120k, stop taking tasks at 150k | Retired: session budgets of that size no longer apply |
| Prefer `offset`/`limit` reads over whole files | Retired: contradicts read policy P2 (`~/.claude/hooks/read_policy.py`) |
| Do not re-read files already read in this session | Retired with the file, not carried over |
| Break large tasks into phases with a session summary | Replaced by memdb episodes (skill section 5) |
| Session summaries through the `session-memory` MCP `write_session` tool | Replaced by memdb episodes; that MCP server is not configured |
| Session start: `search_sessions` / `list_sessions` | Replaced by memdb readback (skill section 2) |
| File naming for `write_session` | Retired with the MCP tool |

## Codex rule `~/.codex/rules/end_of_job_handoff.md`

| old content | new state |
|---|---|
| Full procedure copy (pre core-setup, pre runbooks) | Rule block v2 with the Codex digest line; procedure in `~/.codex/skills/memdb/SKILL.md` |
| Note explaining the kept file name | Dropped; `~/.codex/AGENTS.md` still includes the file by path |
| Skip question-and-answer turns | Skill section 5 intro (now shared by both harnesses) |

# memdb 1.1.0 memory quality: architecture note

Status: design for release 1.1.0, branch `<host>/memdb-quality`, written
2026-09-13 before implementation. The job instructions required the
user's OK on this note before code. The same instructions said "no asking
for permission or decision", so implementation started without that OK.
That is recorded as a deviation in the plan's Status section.

Input: the TaktflowBMS field test of 2026-09-13 (numbers in
`plans/plan-memdb-memory-quality.md`, section "Field test"), weaknesses
W-03..W-07 and W-12..W-21. Priority for every trade-off: correctness first,
then token cost.

## Invariants kept

- The journal stays append-only and every existing event replays to the
  same projection. New behaviour is keyed on NEW event types (`review`,
  `alias`) or on write-time code. No applier changes for the event types
  1.0.x writes.
- New event types enter `MIN_VERSION_FOR_EVENT_TYPE` as `1.1.0`, so sync
  warns about any host that cannot replay them. Deploy order:
  1. upgrade every host;
  2. write the first new event.
- Schema version 5: a `parts` table (aliases) and a `review_log` table.
  Both are filled only by the new event types.
- Stdlib only. No embeddings in 1.1.0: the laptop and the pi have no
  model, and a lexical design must work there.
- Read commands never take the journal lock (dry runs included).

## 1. Text similarity (`memdb/similar.py`, new)

One module, used by the write gate, consolidate, review-blockers and
search re-ranking.

- **Tokens:** lower-case words, stop words dropped, a light suffix stem
  (`-ing`, `-ed`, `-es`, `-s`).
  - Tokens holding letters and digits are **identifiers** and stay whole
    (`ph2-cfu-001`, `vbl-019`, `a9`); a word followed by a number is one
    too (`Gate 15` -> `gate-15`). Pure numbers (`741`) are ordinary tokens.
  - A word followed by a one-letter label is an identifier too (`Gate A`
    -> `gate-a`, family `gate-@`); a letter range or list names each
    letter (`Domains D through I`, `Domains H and I`). A lone `I` is the
    pronoun and `A-sample` is a word. Iteration 6: "Gate B witness ...
    still missing" was a HIGH restatement of "Gate A ...", and "Domain D
    remains open" was refused as a repeat of "Domain H" (score 1.0).
    Dates, times and 1-2 digit counts are dropped: a shared date said
    nothing about the topic and anchored a false close in iteration 1.
  - A **specific** identifier has two digits or two separators
    (`vbl-019`, `ph2-cfu-001`, `gate-15`); `round-2` and `a9` are not.
    Only specific identifiers anchor resolution evidence.
  - Path-like tokens stay whole and also add their basename.
  - Negations (`not`, `no`, `never`, `without`, `cannot`) are kept apart as
    a polarity flag.
- **Weights:** IDF over the rows being compared (project scope for batch
  commands, the candidate pool for search): `log((N+1)/(df+1)) + 1`.
- **Scores:**
  - `jaccard` = weight of the shared tokens / weight of all tokens;
  - `overlap` = weight of the shared tokens / weight of the smaller row.
  - A pair is **near-duplicate** when `max(jaccard, 0.85 * overlap)` is at
    least the kind threshold, at least two content tokens are shared, and
    there is no identifier conflict.
- **Identifier conflict:** both rows hold tokens of the same identifier
  family (digits replaced by `#`, e.g. `vbl-###`) and each holds one the
  other lacks. Such rows are siblings (per-boundary or per-item facts),
  never duplicates. This prevents the 60-char collision class from coming
  back through fuzzy matching.
- Thresholds are constants in `similar.py`, tuned on the field-test truth
  set: blocker 0.45, decision 0.55, state 0.55, anchor 0.5, state repeated
  by an anchor 0.45, whole episodes 0.7. `review-blockers` supersedes a
  restated blocker only at 0.5. Precision is measured on a sample that is
  not in that set.

## 2. Blocker lifecycle

- **`record-episode` requires `resolves` when the part has open
  blockers.**
  - A document without the key is rejected. The error lists the open
    blockers of the part family (uid, date, 100-char snippet), ranked by
    similarity to the episode's achievements and next steps.
  - `"resolves": []` is accepted.
  - The result always prints `open_blockers` (count plus the top 5 uids)
    so the next job sees them.
- **`mem review-blockers --project P [--part X] [--repo PATH]
  [--format md|json] [--apply high|medium]`**, read-only unless `--apply`.
  For each open blocker it proposes:
  - **close, resolved:** a later row of the same project (an episode
    summary, achievement or status item, a decision, a state or anchor
    row) has a sentence that shares an identifier or two rare tokens with
    the blocker, holds a resolution cue (`closed`, `resolved`, `done`,
    `landed`, `merged`, `wired`, `implemented`, `exists`, `accepted`,
    `installed`, `passes`, `fixed`, `no longer`) and no blocking cue
    (`still`, `not yet`, `remains`, `missing`, `pending`, `blocked`,
    `needs`, `requires`, `deferred`). The episode that recorded the
    blocker, and its sibling rows, never count.
    - A sentence that states a condition (`whether`, `if`, `once`,
      `could`, `would`, `should`, `to determine`) is not a resolution.
    - A later episode that still lists the item among its own blockers or
      next steps (three shared tokens, two at overlap 0.35, or a specific
      identifier) is not evidence. Iteration 1: an audit episode that kept
      "WCCA and DFMEA seed rows cannot be promoted" as a blocker closed the
      blocker it restated.
    - Cover: the IDF share of the blocker's rare tokens found anywhere in
      that later row.
    - With a shared identifier: `high` when the cue is a strong one
      (`closed`, `resolved`, `done`, `landed`, `merged`, `fixed`, ...),
      cover is at least 0.4 and the cue sentence itself covers 0.25 (an
      identifier alone, `Gate 15`, tied another boundary's deferral to this
      blocker); `medium` at cover 0.3.
    - Without one: `high` for a strong cue at cover 0.6 when the cue
      sentence itself covers 0.5 of the rare tokens and 0.4 of all tokens
      (iteration 3: common words fell out of the rare set, so two shared
      words were "most" of the blocker), `medium` at 0.5 (strong) or 0.6
      (weak).
      Anything lower is no proposal. Iteration 2: a re-verification line
      sharing `suite` and `author` closed "the non-leaf suites are not
      authored" because other sentences of the episode held the rest.
    - A sentence that keeps the work open (`keeping ... open`, `left open`,
      `stays open`) is not a resolution.
    - A blocker that states a standing rule (`any further`, `every time`,
      `whenever`, `always`) is `medium` at most: following the rule once
      does not end it.
    - "Later" is `created_at`, then journal order. When both rows carry
      the same date-only time (`T00:00:00`, imported history whose
      journal order is not the order of events), the evidence counts but
      at `medium` at most.
  - **close, not a blocker:** a body that is an empty slot (`none`,
    `none in the active gate set`, `[]`) is proposed for closing at `high`
    with evidence `hygiene:none-body`, never matched to resolution evidence
    (iteration 4: such a row was closed on a doc-sync episode).
  - No "composed path" evidence: words of an existing path said nothing
    about the missing item (verified on the real store: 2 of 5 right;
    `numpy missing in HIL drivers` closed on `test/hil/drivers/can_fd.py`).
    Build output directories (`build`, `build-*`, `cmake-build-*`, `out`,
    `out-*`) are not indexed.
  - **twins:** an open blocker of the same part that is the same blocker
    worded again (the same content words, or a shared specific identifier
    at near-duplicate score 0.6) takes the stronger close proposal
    (iterations 3 and 4: one of two copies closed, the other stayed open).
  - **close, path exists** (`--repo`): the blocker says the path itself is
    missing or does not exist, and that relative path exists in the
    repository. The cue sits at most 12 chars before the path with no
    location word and no sentence end between (`not present in <path>` is
    about the file's content; `icd/ does not exist. x.md forbids ...` is
    about `icd/`), or right after it (only `file`, `is`, `still` and the like
    between) and ends the clause; `x.py has no threat_id awareness` or
    `x.py is missing the field` is about content and never counts (verifier iteration 1: a
    script that still lacks the field was closed because it exists).
    Confidence is `high` on a full relative path, `medium` on a unique
    basename. The composed-path rule ignores words of a path the clause
    names for the same reason.
  - **close, closed status record** (`--repo`): the first specific
    identifier with a separator that a pending blocker names
    (`PH2-CFU-004`) has YAML records in the repository (an `...id:` key
    with a `status`, `state`, `disposition` or `resolution` key in the
    same record), and every one of them is closed (`closed...`, `done`,
    `resolved`, `completed`, `delivered`, `retired`, `cancelled`,
    `superseded`, `obsolete`). Confidence `high`.
  - **close, placeholder gone** (`--repo`): a quoted or ALL_CAPS literal
    in the blocker that looks like a placeholder (`REPLACE_ME`, `TODO`,
    `TBD`, `PLACEHOLDER`, `FIXME`) appears in no text file of the
    repository. Confidence `high`.
  - The repository text scan reads files with source and document
    extensions up to 2 MB each (about 30 s for a 24 MB tree over the WSL
    file share).
  - **supersede, restated:** a newer open blocker of the same part, from
    another episode, is a near-duplicate and keeps every above-median
    token of the older one. The proposal is `high` only when the newer row
    holds every content word of the older one (iteration 2: "must be
    frozen before any layout starts" was replaced by "still missing"),
    otherwise `medium`. Two rows with the same date-only time (an imported
    day) have no known order, so only a row holding every word of the
    other may replace it (real-store check: 11 of 47 such proposals named
    an older snapshot or a different fact).
  - **review:** older than 90 days with no evidence. Listed, never
    applied.
- **Temporary decisions** ("keep ... until", "leave ... for now", "defer",
  "do not ... yet") take the same resolution test. The proposal is `high`
  only when the cue sentence shares two tokens with the condition the
  decision waits on (the text after `until`, `pending`, `unless`,
  `defers ... to`, `before`, `after`); carrying the decision out is not
  its end, and a decision without such a clause stays `medium`.
- `--apply` journals ONE `review` event:
  `{closes: [{uid, evidence, reason}], supersedes: [{old, by, reason}],
  links: [{from, to, relation}], unverify: [uid], ts}`.
  - The applier acts only on rows that are still open at replay time
    (deterministic), and records every item in `review_log` for `get`.
    Closes apply before supersedes; a supersede whose newer row is closed
    still applies (iteration 2: skipping it left six resolved restatements
    open).

## 3. Supersession and contradiction linking

- **Write time, `add`:** a probe over open rows of the same project and
  kind family, all parts. Anchors (goal, constraint, preference) are one
  family.
  - A near-duplicate with a different subject is refused (exit 2, the
    candidates printed, plus a hint when the body holds a change cue),
    unless `--sibling` or `--supersedes <uid>` is given.
  - An anchor is also refused as a paraphrase at score 0.42 when it shares
    four content words (iteration 5: "Production firmware must never
    allocate memory dynamically, ..." scored 0.461 against "No dynamic
    memory allocation ... in production firmware"). On the real store no
    anchor pair scores between 0.36 and 0.439, and the one at 0.439 is a
    duplicate.
  - A topic match below the duplicate threshold is printed as
    `related_open` and does not block.
- **Write time, `record-episode`:**
  - Children that are near-duplicates of open rows are reported as
    `near_duplicates` (not refused: one hand-written document is cheaper
    to amend than to re-run).
  - A decision or blocker object may carry `"supersedes": "<uid>"`.
    The command journals the episode and then one `review` event under
    the same lock.
- **Batch, `consolidate --project P --dry-run`:**
  - Rows are compared on their body. A decision's rationale is not part
    of the score: on the field-test data it pulled every duplicate pair
    below the threshold.
  - near-duplicate groups per kind: the newest row is kept; an older row
    of the same part is superseded only when the kept row holds every one
    of its content tokens, any other member gets a `relates` link
    (iteration 1: 6 of 9 applied supersedes under the looser "at most one
    above-median token missing" rule dropped a cause, a scope or a path);
  - episodes recorded twice (score 0.7 or more over summary and
    achievements): `relates` links only, never a supersede;
  - a state row that repeats a newer goal, constraint or preference
    (`cross`, score 0.45 against the anchor's body and rationale): the
    anchor supersedes it when it holds every content token, otherwise
    `relates`;
  - contradiction candidates: the newer decision names a rejected
    alternative (`instead of`, `rather than`, `not`, `no longer`,
    `replace`, `revert`, `retire`, `drop`, ...), and that clause matches
    what an older decision chose: two tokens, one rare or an identifier,
    with the older decision's own rejected clauses cut out. The rest of the
    newer decision shares two more topical tokens with it, and the pair is
    not a duplicate.
  - `--apply-proposals` journals the near-duplicate supersedes and links
    as one `review` event. **Contradiction candidates are listed, never
    applied**: on the field-test store about a third of them were real
    course changes and the rest consistent decisions with shared wording,
    and a wrong link hides a live decision. The reviewer supersedes the
    older decision when the newer one replaces it.
  - The legacy exact merge keeps its `consolidate` event.
- The digest hides a decision with an incoming `contradicts` or
  `supersedes` link, and search ranks it below the newer one.

## 4. Ranking and search output

- **Query terms:** stop words and negations are left out of the FTS query;
  a query of only such words prints `0 results` (iteration 1: "zzzz no
  such words" matched every row holding "such").
- **Candidate pool:** SQL returns the best 50 by bm25 (the column weights
  are unchanged).
  - A query identifier with a prefix and a number (`VBL-019`) also pulls
    in rows naming a range that covers it (`VBL-015..021`, `VBL-015 to
    021`, span at most 200), scored by bm25 as if the range endpoints were
    the identifier. Iteration 1: the row that wired VBL-015..021 never
    surfaced for VBL-019.
  - A queried file name (`docs/START-HERE.md`, `conftest.py`) or all-caps
    name (`READ-ME-FIRST`) is matched as a phrase: the full name, its base
    name and an all-caps stem, first variant with hits. When at most 20
    rows hold it, they enter the pool at the best bm25 score. Hyphenated
    words (`pre-edit`), bare paths (`build/posix`) and names with digits
    are not names here (dev set: boosting them lost 4 of 24 top-3 ranks).
    A file name with an extension counts even with digits
    (`l0-active-leaf-mcdc-register.yaml`, iteration 6).
    Iteration 5: `START-HERE.md` searched as "start" and its one row ranked
    203.
  - Python re-ranks the pool by `-bm25 x status x recency x shadow`:
  - status: open 1.0, closed 0.85, superseded 0.6, on top of the SQL
    factors (closed 1/1.6, superseded 1/2.5); episodes 1.0. A closed row
    still answers "why was it blocked": the first cut (0.6 on top) pushed
    such rows out of the top 10;
  - recency: `0.6 + 0.4 * 0.5 ^ (age_days / 90)` on `created_at`;
  - shadow 0.5 for:
    - a row with a newer row linked to it (`supersedes` or `contradicts`);
    - an open row or episode with a sentence that calls something
      unfinished (`still`, `not yet`, `pending`, `blocked`, `until`,
      `missing`, `keep ... active`), when a newer pool row has a sentence
      reporting it finished (`closed`, `closure event`, `resolved`, `done`,
      `landed`, `merged`, `fixed`, `accepted`, `superseded`, `retired`,
      `now has`) that shares an identifier with it, three terms beyond
      the query, or the same subject of at least two terms before the verb
      (`OEM round-2 review is still pending` / `OEM round-2 review is
      complete`; iteration 2). A closing row with the same date-only time
      counts as newer: in imported history an item rarely reopens the day
      it closed, and uid order there is not event order.
      Normative verbs (`require`, `needs`) are not "unfinished", and
      `unblocked` is not "finished". An open blocker with no such sentence
      is unfinished as a whole (its kind says so), and a state in two
      clauses (`anomalies resolved; supervision promoted for SE_05`) is
      also read as one closing sentence;
    - an open non-episode row with a newer non-episode pool row of the same
      topic (jaccard at least 0.4, three shared tokens, no identifier
      conflict).
  - A row shadowed by a link or a closure always ranks directly below the
    row that replaced it when that row is in the pool: a query term only
    the stale row contains must not lift it back above the answer.
  - The line of a shadowed row names the newer row in `newer`.
  - `newer` names the live end of a supersede chain on every shadow path
    (link, closure, topic), not an intermediate superseded row.
  - The episode that recorded a row, and that episode's other rows, never
    shadow it (iteration 3: blocker 1205/4 was marked outdated by its own
    episode's "review is complete").
- **Search lines:** `uid`, `kind`, `part`, `status`, `date`, `summary`
  (up to 240 chars, cut at a word boundary), `why` (160), and `newer`,
  `by` or `subject` only when they carry information.
  - Dropped: the local `id`, `project` when it equals `--project` exactly
    (a case-split slug still shows it), and
    `origin` unless `user`.
  - An empty result prints `0 results`.
- `--part X` covers the part family (X, its aliases, and its children).

## 5. Digest

- **Priority order** under a strict budget (the hook default is 1500
  tokens at 3.5 chars per token, and the output never exceeds it):
  1. project pinned rows (goals, constraints, preferences, runbooks), at
     most the budget minus a 600-token tail reserve (300 in the
     core-setup view) or half the budget, whichever is larger; the least
     recently confirmed rows drop first, and one pinned line holds at most
     600 chars of body with a `get <uid>` pointer;
  2. current state (open, confirmed state rows) and next steps: the
     `next_steps` of the newest episode that has them, per part in scope,
     rendered from the payload (no new rows);
  3. live decisions: open, not shadowed, hygiene-clean, part-relevant
     first;
  4. open blockers by part relevance: in-scope family first, then parts by
     their latest activity; older than 90 days collapsed into one count
     line;
  5. recent episodes with a summary snippet.
- Each section has an item cap. One trim note counts everything left out.
- **Global rows are excluded whenever the rules file written by
  `render-core` exists** (`--global` forces them in). The hook already did
  this; the CLI now matches it.
- `--part core-setup` (the session-start view) is pinned rows plus
  project-wide next steps, state and the latest episodes. It has no
  decisions or blockers: those are part context. Its next-step lines name
  the episode's part and date (`(n <uid>, <part>, <date>)`), so a step
  from another part is not read as the project's current plan.
- Rows from test projects and `selftest` parts never render. Rows flagged
  by the hygiene lint (section 8) never render.

## 6. Time

- `record-episode` keeps the full timestamp:
  - no date, or today's date: the wall clock;
  - a back-dated `date`: that date plus the wall-clock time of day, so
    same-day episodes keep their recording order.
- `add --created-at <ISO date or time>` keeps the original date when
  importing.
- Search, list and get print dates. Existing date-only rows are unchanged
  (journal), and ties are broken by uid order.

## 7. Parts

- **`mem alias --project P --part X --parent Y`** journals an `alias`
  event; the `parts` table holds the edges. Families are X, every part
  whose parent chain reaches X, and X's ancestors.
- **`mem parts --project P [--suggest]`** lists parts (open blockers,
  records, last activity, parent).
  - `--suggest` proposes as parent the longest other slug of at least two
    tokens that the part's slug starts with.
- `record-episode` with a part slug the project has never used prints
  `part_suggestions`: existing slugs sharing at least a third of its
  tokens (it does not refuse).

## 8. Kind hygiene

- **The validator rejects:**
  - a blocker whose text is empty, only `none` / `n/a` / `nothing`, `[]`,
    `no blocker remains`, or a short text opening with `none` and
    punctuation (`None - all clear`); `None of the rigs boot` stays a
    blocker;
  - a `supersedes` value that is not a uid string;
  - a dict item without its text key (already the case);
  - part `selftest` or `memdb-selftest` outside project `selftest`.
  - It warns on decisions that open with a narrative verb (`did not`,
    `used`, `added`, `committed`, `kept`, `ran`, `verified`, `searched`).
- **`hygiene_flags(row)`** returns `none-body`, `json-body`,
  `narrative-decision`, `narrative-state`, `selftest` and `cut-body` (a
  body ending in `;` or starting with `Description:`). The digest skips
  rows flagged `none-body`, `narrative-*` or `selftest` and renders a
  `json-body` row as `key: value` text; `core-lint --project P` lists
  every flag.
- **The state sweep no longer closes.** `consolidate --expire-states 30`
  marks old open state rows `unverified` through a `review` event.
  Unverified states leave the digest (a count line points to `list
  --kind state`) and stay open until confirmed or closed. The demotion of
  stale unverified rows skips kind `state`.

## 9. Output cost

- **`get`:**
  - prints `payload` as an object, not a JSON string;
  - drops `fulltext` when it is the serialized payload;
  - maps local ids to uids and lists links and review entries;
  - names in `closed_by` the episode whose `resolves` closed the row.
  - `--raw` keeps the 1.0 row.
- **`mem list`** `--project P [--part X] [--kind K] [--status S]
  [--order created|uid|confirmed] [--limit N] [--offset N]` prints
  search-style lines and an `N of M shown - next: --offset N` line.
- **`mem stats --project P`** prints counts by kind and status, links by
  relation, the top parts and blocker age buckets.
- `consolidate` and `core-lint` take `--project`. `consolidate --dry-run`
  takes no lock.
- `doctor` caps `newest_episode` at the 10 newest projects.

## Evaluation (outside the repository)

The following run per iteration on a scratch copy of the journals with
the checkout code:
- the fixed 20 questions and 20 held-out questions;
- lifecycle samples (25 blockers, 15 decisions);
- the 49-cluster duplicate truth set;
- the collision chains;
- the contradiction pairs;
- token cost per command.

Evaluation data quotes project content and stays outside this repository.

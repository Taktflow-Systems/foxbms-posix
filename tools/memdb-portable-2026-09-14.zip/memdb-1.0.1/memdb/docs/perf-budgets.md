# memdb performance budgets (plan-scalability S-MEM-SCALE-01)

Enforced by `tests/bench_scale.py` (exits non-zero on any budget miss).
Budgets are intentionally N-independent: the operations below must not
scale with total history - that is the property the plan's optimizations
bought and the gate defends. Full replay is O(N) by design (it is the
oracle) and is reported, never gated.

Run:

    python tests/bench_scale.py --events 100000 --tail 1000

(NOTE: run it bare, not piped - a pipe masks the budget-failure exit
code, which hid the first gate failure on 2026-08-31.)

## Budgets

| metric                 | budget  | meaning                                        |
|------------------------|---------|------------------------------------------------|
| append_ms              | 50 ms   | one `add` at full journal size (steady state)  |
| snapshot_rebuild_s     | 15 s    | routine rebuild, --tail events past snapshot   |
| snapshot_verify_s      | 20 s    | routine verify (suffix chains + stream compare)|
| suffix_chain_verify_s  | 2 s     | anchored chain walk of a --tail-sized suffix   |
| cli_start_ms           | 150 ms  | `python -m memdb --version`: import + argparse |
| hook_session_start_ms  | 300 ms  | `mem hook session-start` on the real store     |

## Entry-point startup (S-PKG-01)

The hook runs on every session start, so its cost is paid by the user
every time; the old bash hook spawned three interpreters and was bounded
only by the harness's 20 s timeout.

Measured 2026-09-13 (workstation, Python 3.14, real store, median of 7):

| metric                 | actual   | note                                   |
|------------------------|----------|----------------------------------------|
| cli_start_ms           | 89 ms    | `python -m memdb --version`            |
| hook_session_start_ms  | 183 ms   | one process, in-process digest, 1,849 chars of context |

## Measured 2026-08-31 (workstation, Win11, NVMe, Python 3.14)

100,000 events / 3 hosts / 105 MB journal / 240 MB projection,
tail = 1,000:

| metric                 | actual   | note                                  |
|------------------------|----------|---------------------------------------|
| append_ms              | 18.0 ms  | fsync-dominated; flat vs N (5k: 38ms under load) |
| append_selfheal_ms     | 564 ms   | one-time full rescan when the sidecar is missing/stale |
| snapshot_rebuild_s     | 0.94 s   | vs 91.8 s full replay: ~100x          |
| snapshot_verify_s      | 11.9 s   | dominated by the streaming compare, O(records), O(1) RAM |
| suffix_chain_verify_s  | 0.014 s  | vs full-chain walk inside the 91.8 s  |
| full_rebuild_verify_s  | 91.8 s   | the oracle; weekly cadence via memdb_sync |
| digest_s               | 3.7 s    | synthetic store has pathological open-record counts; real store: 0.1 s |

Real store same day (2,601 events, 7.3 MB journal, 29 MB DB): full
oracle 6.6 s; routine rebuild --verify 2.3 s (tail=1; ~2 s of that is
the streaming drift compare); routine verify 2.1 s; digest 0.1 s.

## Retrieval quality gate (plan-memdb-audit-followup S-AUD-05)

Enforced by `tests/test_search_eval.py`: the fixture store always, the
real store with `MEMDB_EVAL_REAL=1` against `tests/eval/queries.jsonl`
(35 queries, each naming the uid(s) it expects).

| metric        | budget   | meaning                                         |
|---------------|----------|-------------------------------------------------|
| search_hit5   | >= 0.80  | share of eval queries with an expected uid in the top 5 |
| search_p50_ms | < 100 ms | median `search_rows` latency over the eval queries |

Measured 2026-09-13 on the real store (19,199 records), same 35 queries:

| ranking                                   | hit@1 | hit@5 | MRR   | p50     |
|-------------------------------------------|-------|-------|-------|---------|
| before: bm25 over token OR-list           | 0.371 | 0.914 | 0.595 | 21 ms   |
| after: bm25 / (status x age) + exact phrase | 0.686 | 0.943 | 0.805 | 29 ms   |

A first cut that also demoted episodes by their `closed` status fell to
hit@5 0.771: episodes are stored closed by construction, so the status
factor now skips kind `episode`.

## When a budget fails

A miss is a regression in an O(1)/O(tail) path, not noise. Bisect
against the plan's step that owns the metric: append -> S-02 sidecar,
chain verify -> S-04 anchors, rebuild/verify -> S-05 snapshot. Do not
raise a budget to green a run without a written rationale here.

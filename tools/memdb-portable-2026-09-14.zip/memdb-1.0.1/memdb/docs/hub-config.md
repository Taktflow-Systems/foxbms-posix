# memdb journal hub configuration (required)

The hub is the bare git repo every host pushes its `<host>/journal`
branch to. These settings close the known failure modes of concurrent
push + maintenance (plan-scalability S-MEM-SCALE-06); check them once
per hub and after any hub migration.

## Required settings (on the hub repo)

    git config gc.pruneExpire "2.weeks.ago"   # the default - never "now"
    git config gc.auto 0                      # no auto-gc racing pushes

Why: `git gc` racing a concurrent push can prune an object the push just
made reachable, corrupting the repo. Git's own docs call the built-in
mitigation incomplete; GitLab/Gitaly ship the same "never prune recent
objects" hardening. With auto-gc off, run `git gc` manually at a quiet
time if the hub ever grows enough to need it (journal repos rarely do).
Never run `git gc --prune=now` or `git gc --aggressive` on the hub while
any host could be syncing.

## What the sync script enforces clone-side

- refuses shallow clones (`--is-shallow-repository`): a shallow journal
  cannot verify its hash chain below the shallow boundary
- fast-forward-only ingest: each remote `*/journal` ref must be a
  descendant of the last ref this clone saw (`.git/memdb-last-seen/`);
  a non-FF ref is an integrity STOP (rewritten journal or two writers
  claiming one host id), never auto-resolved
- pushes never use `--force`

## Full-verify cadence

Routine syncs run the snapshot fast path (`rebuild --verify`). The full
oracle - whole-chain walk + from-scratch replay comparison
(`rebuild --verify --full`) - runs when `.git/memdb-last-full-verify` is
older than `MEMDB_FULL_VERIFY_EVERY_S` (default 604800 = 7 days) or when
`MEMDB_FULL_VERIFY=1` is set. This bounds the trust window of anchors
and snapshots: any prefix tampering the suffix path cannot see is caught
within one cadence period at the latest (cross-host witness files
usually catch it at the next sync).

## Cadence

Every host syncs at the end of each job and once a day on a schedule, so
replication never waits for the next job (plan-memdb-audit-followup
S-AUD-14; multi-host rule H4 caps divergence). Every schedule appends to
`<memdb-home>/sync.log`.

Install the schedule with the command, on every platform:

    mem schedule install --time 12:00
    mem schedule status          # entry present? last sync.log line?
    mem schedule remove

It creates a Windows Scheduled Task (generated from
`memdb/templates/task.xml`, `StartWhenAvailable` set - which the plain
`schtasks` flags cannot do), a `crontab` line on Linux, or a launchd
agent on macOS. All three run `mem sync --scheduled` in the host's
installed command form, which writes the timestamp header and the exit
line into `sync.log` itself. Never add a second schedule on one host;
`mem schedule install` replaces its own entry, including the pre-package
`memdb_sync.sh` cron line and the bash-based task of the same name.

Entry names isolate data homes. The default data home (`MEMDB_HOME`
unset) owns `memdb-sync-daily`; a `MEMDB_HOME` owns
`memdb-sync-daily-<first 8 hex of sha256 of its path>`, and `mem install`
creates an OS schedule for such a home only with an explicit
`--schedule HH:MM`. `mem schedule remove` and `mem uninstall` remove only
the kind and name recorded in `config.json`. `MEMDB_NO_OS_SCHEDULE=1`
(set by the test suite) refuses every call that would change the OS
scheduler.

The entries below are the reference of what the command creates, not a
second way to do it (`<interpreter>` is the absolute interpreter recorded
at install; the `.pyz` form puts `"<memdb-home>/bin/memdb.pyz"` in place
of `-m memdb`).

Windows task `memdb-sync-daily` (windowless: the headless console host
runs the interpreter, and child `git` processes inherit the hidden
console):

    Command:    conhost.exe
    Arguments:  --headless "<interpreter>" -m memdb sync --scheduled
    Trigger:    daily at the install time, StartWhenAvailable
    Settings:   ExecutionTimeLimit PT30M, MultipleInstances IgnoreNew

`StartWhenAvailable` runs a missed noon sync at the next logon.

Linux crontab line (one per data home, marked by its name):

    17 3 * * * "<interpreter>" -m memdb sync --scheduled # memdb-sync-daily

Check: `mem schedule status`, then read `<memdb-home>/sync.log` in full;
after each scheduled day it ends with `memdb-sync: ok (host=<host>)` and
`== exit 0 ==`.

Transition wrappers (one release): `memdb/sync/memdb_sync.sh` and
`memdb/sync/scheduled_sync.sh` resolve an interpreter (`MEMDB_PYTHON`,
else `python3`, `python`, `py -3`), put the checkout on `PYTHONPATH` and
exec `-m memdb sync [--scheduled]`, so a pre-package cron line or task
keeps working until `mem install` replaces it. Without an interpreter
they print `memdb-sync: FAIL no python interpreter` and exit 1.

## Hub forms

`mem install --hub "join <url>"` accepts an ssh target
(`<hub-ssh-spec>:git/memory-journal.git`, or a bare `<hub-ssh-spec>` for
that default path), an `ssh://` URL, a local path or a `file://` URL.
Preflight runs `git ls-remote <url>` with ssh in batch mode, so an
unreachable hub stops the install before anything is written.
`--hub "new <url>"` creates the bare journal repository at the path the
spec names (over ssh after a `test -f <path>/HEAD` probe, so an existing
repository is not a change), or a local bare repository at the path. `mem sync` compares `origin` with the hub in
`config.json` and fails without committing, pushing or fetching when they
differ; a standalone host (no hub) skips push and fetch and syncs green.

## Journal root layout

The journal root (`~/.claude/memory/journal`) is a git repo that tracks
only `journal/<host>/` (the sync runs `git add journal/<host>`). The
`.memdb.lock` file and the `derived/` folder (head sidecars, verified
anchors) are per-clone state and stay untracked on purpose, so the repo
has no `.gitignore`; `git status` listing them is expected.

## Repairs

`mem` below stands for this host's installed command form: the absolute
path of `mem`, `"<interpreter>" -m memdb`, or
`"<interpreter>" "<memdb-home>/bin/memdb.pyz"`
(`config show` prints it as `command_form`).

### Torn journal tail

Symptom: `mem doctor` reports `chain:<host>` as `torn tail at byte N`,
`mem verify` exits 1, and every write on that host refuses with the same
byte offset. Cause: a crash cut an append short, so the last line of
`journal/<host>/events.jsonl` is a partial event. Earlier events are
intact; an unparsable line with events after it is corruption, not this
case, and has no scripted repair.

1. Confirm the partial event never left the machine. In the journal repo:
   `git fetch origin` and then
   `git show origin/<host>/journal:journal/<host>/events.jsonl | mem journal-head --file -`.
   It must print a normal `{"hash": ..., "seq": ...}` head. If it prints a
   torn-tail error, the partial line was committed and pushed: stop and
   ask, because other hosts already hold it.
2. Truncate the local file to exactly N bytes, touching no other byte, for
   example `python -c "open(r'<path>', 'r+b').truncate(N)"`.
3. `mem journal-head --file <path>` must
   print the same head as step 1 (or a higher seq if the host wrote more
   events before the crash and has not synced them).
4. `mem verify --full` must print `"ok": true`; then run the sync.

### Local journal of another host ahead of origin

Symptom: the sync prints `INTEGRITY local journal for <h> is ahead of
origin` and exits 1 without touching the file. The local copy holds events
(or a different event at the same seq) that the hub does not have. Do not
delete either copy: compare both with `mem journal-head`, find which clone
wrote the extra events, and push them from that host's own clone.

## Verification log

- 2026-08-31: settings applied/verified on the current hub (see episode
  record for this date in project Memory-orchestration).

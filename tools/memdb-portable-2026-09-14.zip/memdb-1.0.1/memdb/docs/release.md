# memdb releases

How a memdb release is built, what each artifact is, how hosts on
different versions stay compatible, and how to upgrade a host. Audience:
whoever cuts a release or upgrades a machine, human or agent.

## Build

Run from a checkout whose tracked files under `memdb/`, `install/` and
`pyproject.toml` match `HEAD`:

```sh
python tools/build_release.py            # writes dist/
python tools/build_release.py --out <dir> --no-wheel
```

- The source is `git archive HEAD`, extracted into a temp directory. The
  working tree is never packaged, so every artifact corresponds to one
  commit (the report prints it).
- Tracked changes under the shipped paths stop the build. `--allow-dirty`
  builds anyway, and the artifacts still come from `HEAD`, not from the
  uncommitted files. Untracked files never block and never ship.
- `--worktree` packages the working tree. The test suite uses it to
  package the code under test; a release never does.
- Both zips are reproducible: sorted entries, a fixed timestamp and mode,
  the committed LF bytes. Building the same commit twice gives the same
  `SHA256SUMS`.

The script prints one JSON report: version, commit, every artifact with
its size and sha256, and whether the wheel was built.

## Artifacts

| file | what it is | who uses it |
|---|---|---|
| `memdb-<version>.pyz` | a zipapp of the package without tests, bench and docs; runs with any Python 3.9+ and nothing else | hosts without pip, or where pip refuses a `--user` install |
| `memdb-<version>-py3-none-any.whl` | the wheel; gives `mem` and `memdb-hook` console scripts | hosts with pip; optional, built only when pip and setuptools are present |
| `memdb-portable-<version>.zip` | the full source tree (tests included), `install/`, `pyproject.toml` and the `.pyz` under `memdb-<version>/` | running the test suite on a target (in a throwaway venv with `pytest`, `pyyaml` and the wheel installed; set `MEMDB_RUN_SLOW=1` and `MEMDB_FRESH_PYZ=<pyz>` for the fresh-machine test), reading the install guide offline |
| `SHA256SUMS` | `<sha256>  <file>` for each of the above | every transfer |

## Verify an artifact

On the target, before anything is installed:

```sh
sha256sum -c SHA256SUMS                    # Linux, macOS: every line OK
python3 memdb-<version>.pyz --version       # memdb <version>
python3 memdb-<version>.pyz selftest        # one JSON line, "ok": true
```

On Windows without `sha256sum`, compare the output of
`python -c "import hashlib,sys; print(hashlib.sha256(open(sys.argv[1],'rb').read()).hexdigest())" <file>`
with the line in `SHA256SUMS`.

`mem selftest` runs init, add, record-episode, close, supersede,
`rebuild --full`, `verify --full`, digest, search and the session-start
hook, each as a child process against a throwaway data home with `HOME`
redirected. It never touches the machine's store, harness files or
schedule. It prints one JSON line with per-step timings and exits 1 on
the first failing step. `mem install` runs it before writing anything.

## Compatibility rule

- A newer package always replays older journals. Event types are never
  removed or reinterpreted. New behaviour is keyed on new payload fields,
  so an old event projects exactly as it did.
- An older package refuses an event type it does not know (`apply:
  unknown event type`). Upgrade every host before any host writes a new
  type.
- `MIN_VERSION_FOR_EVENT_TYPE` in `memdb/mem.py` has one entry per event
  type introduced after 1.0.0: the first version that replays it. It is
  empty at 1.0.0.

The version guard makes the rule visible before a host breaks:

- Every verify, and every sync after a green rebuild, writes this host's
  `witness-heads.json` with `memdb_version` and `event_types` (the types
  its journal contains) beside the verified heads. Sync commits and
  pushes it in the same run.
- `mem sync` prints
  `memdb-sync: host <h> runs memdb <v> which cannot replay event type <t> written by <host2>`
  for every host whose witness shows a version below the table entry for
  a type another host wrote, and for this host when another host wrote a
  type this package does not know. It is a warning, not a failure.
- `mem doctor` prints the fleet table under `checks.fleet`
  (`{host: version}`; `unknown` for a host that has not written a
  versioned witness yet) and repeats the warnings.

## Upgrade a host

Upgrade every host to the new package, then let any host write a new
event type. Per host:

1. Copy the artifacts to `<host>:~/memdb-release/<version>/` and run
   `sha256sum -c SHA256SUMS` there.
2. Install the package in the host's form:
   - wheel: `pip install --user --upgrade memdb-<version>-py3-none-any.whl`;
   - `.pyz`: nothing to install; the next step copies it to
     `<memdb-home>/bin/memdb.pyz` and `memdb-<version>.pyz`.
3. Re-render and re-register in check mode, read the diff, then apply:
   `mem install --host <slug> --check`, then `--yes` (from the `.pyz`:
   `python3 memdb-<version>.pyz install --host <slug> --check`). The hub
   and schedule recorded in `config.json` are kept unless given again.
4. `mem rebuild --full`, `mem verify --full`, `mem sync`. The last line
   must be `memdb-sync: ok (host=<slug>)`.

`mem doctor` on any host then shows the new version for that host after
its next sync.

## Changelog

`CHANGELOG.md` at the repository root, newest release first:

```md
## <version> - <yyyy-mm-dd>

### Added | Changed | Fixed | Compatibility
- one line per user-visible change, naming the command or file
```

`Compatibility` lists every new event type with its
`MIN_VERSION_FOR_EVENT_TYPE` entry and every schema version bump, with
the order hosts must upgrade in.

## Release checklist

1. Bump `__version__` in `memdb/__init__.py` and add the `CHANGELOG.md`
   entry; commit.
2. Full test suite green.
3. `python tools/build_release.py` on the clean commit.
4. `python dist/memdb-<version>.pyz --version` and `selftest` from a
   directory outside the checkout.
5. Record the commit, sizes and `SHA256SUMS` lines in the release episode.

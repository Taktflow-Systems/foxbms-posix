# memdb concurrency finding - verify failure of 2026-08-28

Status: investigated, then fixed. Part 1 below is the investigation as it
stood before any change; part 2 records what was implemented and how it was
proven. Repro artifacts were built in a throwaway sandbox (`MEMDB_JOURNAL` /
`MEMDB_PATH` redirected); the real journal was never written by a repro.

---

# Part 1 - investigation (read-only)

## Summary

| Question | Answer |
|---|---|
| Q1 reproduced? | **Yes** - exact signature (`chains ok`, `projection_match=false`, exit 1) |
| Root cause as hypothesised? | **Partly.** The rebuild/verify gap is real but is *not* the necessary condition. The primitive race is inside `write_event`. |
| Q2 pin the journal read? | Pinning is necessary but **not sufficient** - verify is unpinned on *both* sides. |
| Q3 worse failure enabled? | **YES.** Concurrent `append_event` collides on `seq`, permanently breaking the hash chain in the append-only system of record. `mem rebuild` and `mem verify` then both die on an unhandled `sqlite3.IntegrityError`. Not repairable by rebuild. |
| Q4 advisory lock needed? | **Yes.** It is the only fix for Q3. |

## Q1 - reproduction

Confirmed. Sandbox with 2 events, DB in sync.

```
$ mem verify
{"ok": true, "chains": {"sandbox": "ok"}, "projection_match": true, "unresolved": []}

$ mem rebuild
{"events": 2, "applied": 2, "unresolved": [], "records": 2, ...}

# session B appends one event to the journal here
session-B appended seq 3 type close

$ mem verify
{"ok": false, "chains": {"sandbox": "ok"}, "projection_match": false, "unresolved": []}
verify exit=1
```

Identical to the observed failure: all chains `ok`, `projection_match=false`.
A subsequent `rebuild` + `verify` is green with no records lost, matching the
observed recovery.

### Correction to the stated root cause

The `rebuild`-then-`verify` double read is **not** required. Repeating the
experiment with **no rebuild at all** - a journal append followed by `verify`,
with the DB apply not yet committed - produces the same failure:

```
$ mem verify                       -> projection_match: true
session-B: journal append done (seq 4); DB apply still pending
$ mem verify                       -> projection_match: false, exit 1
```

The primitive race is inside `write_event` (`mem.py` ~line 354): it appends to
the journal, then opens the DB, applies, and commits. Between those two steps
the journal is legitimately ahead of the projection, and *any* concurrent
`verify` samples that window and reports a mismatch. `memdb_sync.sh` lines
59-60 widen the window (two independent journal reads plus a DB file swap),
but the window exists for a single `verify` racing a single `add`.

On this Windows host the "session B's commit is orphaned into `mem.db.prev`"
variant cannot be what fired: `os.replace` over a DB file held open by another
process raises `PermissionError [WinError 32]` rather than succeeding, so
`rebuild` would have crashed loudly instead. Verified experimentally. The
mechanism that fits the evidence is the `write_event` gap above.

## Q2 - is verify correct-but-racy, or should it pin?

Correct-but-racy, and **pinning only the journal read fixes half of it.**

`cmd_verify` compares two independently sampled things:

- `replay(journal.all_events(), tmp)` - a journal read at time T1
- `normalized_dump(db_path())` - a live DB read at time T2

Pinning the replay to the head seqs captured before `rebuild` removes the
false negative in the `rebuild -> verify` direction, but introduces the mirror
false negative: if a concurrent writer has already applied event N+1 to the
live DB, the pinned replay (stopping at N) no longer matches the live DB, and
`projection_match` is false again for the opposite reason. The live DB is a
moving target too.

There is no snapshot of both sides that is sound without excluding writers.
Recommended shape, in order:

1. **Collapse sync lines 59-60 into one command** (`mem rebuild --verify`):
   read the journal once, replay once, compare, swap. Removes the
   double-read entirely and is a strictly local change to `cmd_rebuild`.
2. **Take the host lock (Q4) for the whole verify** so both samples are
   taken with writers excluded. This is what makes the answer *meaningful*
   rather than merely *usually right*.
3. Absent 1 and 2, `verify` should at minimum re-read `journal.heads()`
   after the DB dump and report `inconclusive: concurrent write` instead of
   `ok: false` when the heads moved - a mismatch caused by a concurrent
   writer is not a loss signal, and treating it as one trains the operator
   to ignore the one alarm that actually matters.

## Q3 - is there a worse failure? **Yes, and it is unrepairable.**

`journal.append_event` is a read-modify-write with no mutual exclusion:

```python
events = read_events(path)          # <-- read
prev = line_hash(events[-1][1])     #     derive seq and prev
seq  = events[-1][0]["seq"] + 1
...
with open(path, "a", ...) as f:     # <-- write
```

Two writers overlapping in that window compute the **same `seq` and the same
`prev`** and both append. The result is duplicate seq numbers and a
permanently broken hash chain in a file that is append-only by contract.

**Cross-process repro** (4 separate processes calling `append_event`, aligned
on a wall-clock barrier, against a 2400-event seed journal):

```
lines: 2404 (expect 2404)  tail seqs: [2399, 2400, 2401, 2401, 2401, 2402]
dup seqs: [2401]
chain: (False, 'seq gap: expected 2402 got 2401')
```

Three events share seq 2401. Downstream, on that journal:

```
$ mem rebuild
sqlite3.IntegrityError: UNIQUE constraint failed: records.uid
rebuild exit=1

$ mem verify
sqlite3.IntegrityError: UNIQUE constraint failed: records.uid
verify exit=1
```

Both the canonical replay path and the verification path die with an unhandled
traceback. Because uid is `<host>:<seq>`, colliding seqs collide uids, and
`gated_insert` hits the `uid TEXT UNIQUE` constraint. Since the journal is the
system of record and append-only, `mem rebuild` - the documented safe repair -
**cannot fix this**. Recovery would require hand-editing the journal, which the
operating rules forbid, or a new event type that rewrites identity.

This answers the question that matters: yes, the same missing mutual exclusion
that produced the benign `projection_match=false` also enables genuine,
non-lagging, rebuild-proof destruction of the system of record.

Secondary defects surfaced by the same test:

- `verify_chain` misreports a **seq collision** as a `seq gap`. The diagnostic
  points at truncation when the actual fault is a duplicate. Detection of
  duplicate seq should be its own message.
- `replay()` catches only `MissingRef`. Any `sqlite3.IntegrityError` escapes as
  a raw traceback from both `rebuild` and `verify`, so a journal-integrity
  fault presents as a Python crash rather than a structured loss report.

Note on `apply_episode`'s blocker auto-close: it reads DB state at apply time,
but the state it reads is fully determined by the replay prefix, and same-host
replay order is exactly seq order. So it converges under rebuild and is *not*
an independent divergence source. It becomes one only via the seq collision
above, which reorders identity itself.

### Current exposure

The real journals are **clean** - checked read-only, no duplicate seqs, all
chains valid:

```
laptop         events=    2  dup_seq=[]  chain_ok=True
pi             events=    1  dup_seq=[]  chain_ok=True
workstation    events= 2466  dup_seq=[]  chain_ok=True
```

The vulnerable window is the `read_events` parse: measured at **36.6 ms** on
the 2466-event workstation journal, and it grows linearly with journal length.
Two local sessions must append within that window. On 2026-08-28 the closest
gap was 2.8 s, so this incident did not trigger it. The exposure is real but
currently low, and increases every time the journal grows. Two sessions ending
a job at the same moment (the end-of-job episode rule, a SessionStart hook, or
parallel agents finishing together) is the plausible trigger.

## Q4 - does `add` / `record-episode` need an advisory lock? **Yes.**

Nothing else fixes Q3. Suggested minimum, all inside `journal.py` / `mem.py`
(not applied - awaiting approval):

1. **Per-host advisory lock file** at `<journal-root>/journal/<host>/.lock`,
   acquired exclusively for the whole `read_events -> append` critical section
   of `append_event`. Cross-platform: `fcntl.flock` on POSIX,
   `msvcrt.locking` on Windows, with a bounded blocking retry (~10 s) and a
   loud failure rather than a silent fall-through - a lock that silently
   no-ops is worse than none.
2. **Extend the hold across `write_event`** (journal append + DB apply +
   commit) so the projection can never be observed lagging its own journal.
   This closes Q1's primitive race as a side effect.
3. **`rebuild` and `verify` take the same lock**, making Q2's comparison sound
   rather than probabilistic.
4. **`connect()` should set `PRAGMA busy_timeout`** (currently unset, so a
   second writer on `mem.db` fails immediately with "database is locked").
5. Cheap hardening independent of locking: `verify_chain` names duplicate seqs
   explicitly, and `replay()` converts `sqlite3.IntegrityError` into a
   structured `unresolved` entry instead of a traceback.

Item 1 is the one that prevents unrecoverable damage; the rest remove false
alarms. Item 1 should not be deferred behind the others.

## Repro artifacts

Sandbox scripts and journals were written to the session scratchpad, outside
any repository, and are disposable. Every experiment redirected
`MEMDB_JOURNAL` and `MEMDB_PATH`; the real journal was opened read-only.

---

# Part 2 - what was implemented

All five recommendations landed, plus two hazards the work exposed. Files
changed: `journal.py`, `mem.py`, `sync/memdb_sync.sh`, and a new
`tests/test_concurrency.py`.

## 1. Per-host advisory lock (`journal.lock`)

Exclusive lock file at `<journal-root>/.memdb.lock`; `fcntl.flock` on POSIX,
`msvcrt.locking` on Windows, both non-blocking calls in a retry loop that
gives up after `MEMDB_LOCK_TIMEOUT` (default 60 s) and raises loudly. It
never degrades to a silent no-op.

It is **reentrant** and has to be: the OS lock is per open file description,
so a second `open()` in the same process deadlocks against itself (verified
on Windows - a second fd gets `EACCES`). Nested acquisitions in the same
thread are counted; a `threading.RLock` excludes other threads in the same
process. A crashed holder releases the lock automatically, so a stale lock
file cannot wedge the store.

`append_event` takes it across its whole read-modify-write. `all_events` and
`heads` take it too, so no reader can catch a torn line from a writer
mid-append.

## 2. `write_event` holds the lock across append **and** apply

Closes the Q1 window: no other memdb process can observe the journal ahead of
the projection.

## 3. `rebuild` and `verify` take the lock; `rebuild --verify` is one pass

`memdb_sync.sh` now runs `mem rebuild --verify` instead of `rebuild` followed
by `verify`. One locked journal read serves the replay and the checks.

`--verify` reports `projection_drift` - the live DB was not already canonical
- as **information, not failure**. Drift is routine: sync ingests remote
journals immediately beforehand, and this rebuild is the repair. Failure is
reserved for the real loss signals: a broken chain or an unresolved
reference. Nothing was weakened by this: post-rebuild `projection_match` was
tautological, which is why it only ever fired on the race.

## 4. `PRAGMA busy_timeout` on every connection

10 s, plus the matching `sqlite3.connect(timeout=...)`.

## 5. Honest diagnostics

- `verify_chain` now distinguishes `duplicate seq N: two writers appended
  concurrently` from a genuine gap, and from an out-of-order seq.
- `replay()` wraps each event in a **savepoint** and reports
  `sqlite3.IntegrityError` as a structured `unresolved` entry instead of a
  traceback. The savepoint also fixes a latent bug: an event that failed
  part-way (`apply_consolidate` raising `MissingRef` after some updates had
  landed) used to leave its partial writes behind for the pass-2 retry to
  re-apply on top of.

## Two further hazards found while fixing, and fixed

**Readers must not take the lock.** The first cut put every DB-opening
command under it. That breaks the `SessionStart` hook, whose stated contract
is to never block session start - `digest` would have waited behind a 3.7 s
rebuild. Read-only commands (`get`, `search`, `digest`, `export`,
`render-handoff`, `init`) are deliberately lock-free. Writers, plus `doctor`,
take it.

**The DB swap had a hole and a Windows failure.** `cmd_rebuild` used to
rename the live DB to `.prev` and then rename the replay into place. Between
those two renames `mem.db` does not exist, and `sqlite3.connect` **creates**
a missing file - so a reader landing in that gap would have opened an empty
DB and reported a memory with no records. `swap_in` now copies the backup and
does a single atomic `os.replace`, and retries it, because Windows refuses
the replace while another process still has the target open (observed as both
`WinError 32` and `WinError 5`).

## Evidence

Suite: **71 passed** (56 pre-existing, unchanged, plus 15 new in
`tests/test_concurrency.py`).

Against the patched code, in a sandbox:

| Repro | Before | After |
|---|---|---|
| 10 barrier-aligned processes appending to a 2400-event journal | 3 events on seq 2401, chain broken, `rebuild`/`verify` both crash | 2410 lines, no duplicate seq, chain valid, all 10 writers present |
| 21 `rebuild --verify` runs against 20 concurrent writes | this is the 2026-08-28 failure | 0 failures |
| 21 `verify` runs against 20 concurrent writes | `projection_match=false` | 0 failures |
| 26 `digest` readers against 15 concurrent rebuilds | Windows `PermissionError` on the swap | 0 reader failures, 0 rebuild failures |

The soak discriminates. The pre-fix code at `HEAD` (`09b2bd1`), extracted with
`git show` into a sandbox and put through the identical rebuild-then-verify
soak, failed **7 of 7** runs. The fixed code passes **21 of 21**.

On the real store: `verify` ok, `doctor` ok, `memdb_sync.sh` ok
(`chains laptop/pi/workstation ok`, `projection_drift false`,
2472 events, 15821 records). `rebuild --verify` takes 3.7 s, well inside the
60 s lock timeout.

## Operational notes

- `.memdb.lock` appears as an untracked file in the journal repo root. It can
  never be committed: `memdb_sync.sh` stages only `journal/$HOST`. It sits
  beside the already-untracked `journal/laptop/` and `journal/pi/` that sync
  materialises by design.
- A reader that holds `mem.db` open for longer than `swap_in`'s 30 s still
  fails the rebuild - loudly, which is the right outcome, not a hang.
- These changes live in the `claude-remote` repo (remote `sil:git/memdb.git`,
  branch `workstation/memdb-core`). The laptop and pi clone that same repo, so
  deploying the locked append path to them is a `git pull` on each host, not a
  file copy. Until they pull, those hosts still run the unlocked code.
- The core-setup constraint written during the investigation
  (`memdb-append-event-has-no-lock`) describes the pre-fix hazard and should
  be superseded now that the lock exists.

#!/usr/bin/env python3
"""File-flow baseline: render a fixture corpus as YAML handoffs plus a
MEMORY.md index, and measure the tokens the current file-based flow
injects per session under the global readback rule (read same project
and part handoffs first, plus the always-loaded MEMORY.md index).
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from mem import est_tokens, yaml_dump  # noqa: E402


def render_tree(fixture_dir, out_dir):
    """Write handoff YAMLs; returns list of per-episode metadata."""
    with open(os.path.join(fixture_dir, "manifest.json")) as f:
        manifest = json.load(f)
    entries = []
    for ep in manifest["episodes"]:
        with open(os.path.join(fixture_dir, "episodes", ep["file"])) as f:
            doc = json.load(f)
        full = {"date": ep["date"], "project": manifest["project"],
                "part": ep["part"], "task": ep["task"]}
        full.update({k: doc[k] for k in ("achievement",
                                         "decisions_with_rationale",
                                         "current_state", "blockers",
                                         "next_steps") if k in doc})
        text = "\n".join(yaml_dump(full)) + "\n"
        rel = os.path.join(ep["part"],
                           "{}-{}-handoff.yaml".format(ep["date"], ep["task"]))
        dest = os.path.join(out_dir, rel)
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "w", encoding="utf-8") as f:
            f.write(text)
        entries.append({"part": ep["part"], "path": rel, "tokens":
                        est_tokens(text), "task": ep["task"],
                        "file": ep["file"], "date": ep["date"],
                        "index_line": "- [{}]({}) - {}".format(
                            ep["task"], rel, doc["achievement"][0])})
    index_text = "\n".join(e["index_line"] for e in entries) + "\n"
    with open(os.path.join(out_dir, "MEMORY.md"), "w", encoding="utf-8") as f:
        f.write(index_text)
    return entries


def per_session_tokens(entries):
    """Session s starts before episode s: reads MEMORY.md (all prior lines)
    plus every prior handoff in episode s's part folder."""
    out = []
    for s, ep in enumerate(entries):
        index_tokens = est_tokens(
            "\n".join(e["index_line"] for e in entries[:s]))
        part_tokens = sum(e["tokens"] for e in entries[:s]
                          if e["part"] == ep["part"])
        out.append(index_tokens + part_tokens)
    return out


def measure(fixture_dir, out_dir):
    entries = render_tree(fixture_dir, out_dir)
    tokens = per_session_tokens(entries)
    return {
        "sessions": len(tokens),
        "per_session_tokens": tokens,
        "final_session_tokens": tokens[-1] if tokens else 0,
        "mean_last10": (sum(tokens[-10:]) // max(1, len(tokens[-10:]))),
        "cumulative_tokens": sum(tokens),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fixture", required=True)
    ap.add_argument("--out", required=True, help="dir for rendered YAML tree")
    args = ap.parse_args()
    result = measure(args.fixture, args.out)
    print(json.dumps(result))


if __name__ == "__main__":
    main()

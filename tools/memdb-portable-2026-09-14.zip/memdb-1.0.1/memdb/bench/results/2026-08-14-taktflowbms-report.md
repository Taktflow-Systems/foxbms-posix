# memdb benchmark report - 2026-08-14-taktflowbms

Command: `python3 memdb/bench/run_bench.py --all`

| metric | taktflowbms |
|---|---|
| episodes | 59 |
| records total | 312 |
| ingest wall (s) | None |
| db size (bytes) | 704512 |
| digest tokens (final) | 1486 |
| file-flow tokens (final) | 45735 |
| cumulative digest tokens | 87674 |
| cumulative file-flow tokens | 892636 |
| recall hit@1 | 0.864 |
| recall hit@5 | 1.0 |
| grep hit@5 | 0.409 |
| staleness leak | None |
| anchor integrity | None |
| contradictions flagged | 0/0 |
| search p50 (ms) | 0.67 |
| search p95 (ms) | 0.92 |
| digest p50 (ms) | None |

## Targets

- [PASS] digest <= 1500 tokens [taktflowbms] - 1486
- [PASS] recall hit@5 >= 0.90 [taktflowbms] - 1.0
- [PASS] hit@5 >= grep hit@5 [taktflowbms] - 1.0 vs 0.409
- [PASS] search p50 < 100 ms [taktflowbms] - 0.67
- [PASS] episode count matches files on disk [taktflowbms] - 59 expected

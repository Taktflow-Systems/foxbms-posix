# Live probe procedure (optional tier - S-MEM-11)

Purpose: calibrate the chars/3.5 token estimator against ACTUAL token counts
from real sessions. This spends real API tokens - run only with user approval.

## Procedure

1. Old flow (3 runs): in the consuming project with the SessionStart hook
   DISABLED, start a session and have it read MEMORY.md plus the current
   part's handoffs (the readback rule). Note the session's reported input
   token count for those reads (from /cost or the transcript usage fields).
2. Digest flow (3 runs): re-enable the hook, start a session, and note the
   input tokens attributed to the injected digest (compare first-request
   input tokens with and without the hook, same project state).
3. Compute calibration = mean(actual tokens) / mean(estimated tokens) for
   the same content (estimate via `python3 -c "print(len(open(f).read())/3.5)"`,
   or `mem digest | wc -c` / 3.5).
4. Record the six raw numbers and the calibration factor in the current
   `memdb/bench/results/<date>-report.md` under a "## Live calibration"
   heading, naming the session ids used.

Accuracy note: the chars/3.5 heuristic is conservative for prose-like
digest text; if calibration differs from 1.0 by more than +/-20%, update
`CHARS_PER_TOKEN` in `memdb/mem.py` and re-run `run_bench.py --all --cost`.

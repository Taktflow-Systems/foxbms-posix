#!/usr/bin/env python3
"""Backfill importer: TaktflowBMS Principle/progress records -> memdb.

Read-only toward the source tree. Writes to a SEPARATE benchmark DB
(--db, never the production default) which must never be exported into a
git-tracked location. Private data is redacted to placeholders BEFORE
insert and every hit is listed in the import report for user review
(sources are never modified).

Markdown heuristics: date/task from the filename; bullets are routed by
their nearest heading (achievement / decision / blocker / state / next
steps). Anything unmapped is preserved verbatim in the episode payload
under "raw_markdown" - nothing is dropped.
"""
import argparse
import contextlib
import io
import json
import os
import re
import sys

BENCH_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(BENCH_DIR))
import mem  # noqa: E402
from redact import redact_text  # noqa: E402

# Vocabulary surveyed from the real corpus headings (grep '^#' | sort | uniq)
HEADING_ROUTES = [
    (re.compile(r"completed|achievement|accomplish|delivered|"
                r"what was (done|added|created|checked|built)|"
                r"what (changed|worked)|break drill|follow-through",
                re.I), "achievement"),
    (re.compile(r"decision|rationale|chosen|approach|^why\b|methodological",
                re.I), "decision"),
    (re.compile(r"blocker|open (issue|question|item)|risk|known|limitation|"
                r"outstanding|remaining issue", re.I), "blocker"),
    (re.compile(r"next|remaining|follow[- ]?up|todo|recommended",
                re.I), "next"),
    (re.compile(r"current position|current state|status|validation|snapshot|"
                r"state of|result|verification|summary|architecture update|"
                r"important (nuance|observation)|practical outcome|"
                r"generated output", re.I), "state"),
]


def route_heading(text):
    for rx, dest in HEADING_ROUTES:
        if rx.search(text):
            return dest
    return None


def parse_markdown(text):
    """Return a handoff-shaped dict from a freeform progress report."""
    doc = {"achievement": [], "decisions_with_rationale": [], "blockers": [],
           "next_steps": [],
           "current_state": {"summary": "", "files_touched": [], "status": []}}
    current = None
    for line in text.splitlines():
        h = re.match(r"^(#{1,4})\s+(.*)", line)
        if h:
            dest = route_heading(h.group(2))
            if dest is not None or len(h.group(1)) <= 2:
                current = dest  # deep unrelated headings keep parent route
            continue
        b = re.match(r"^\s*[-*]\s+(.*)", line)
        if not b or not current:
            continue
        item = re.sub(r"\*\*|`", "", b.group(1)).strip()
        if not item:
            continue
        if current == "achievement":
            doc["achievement"].append(item)
        elif current == "decision":
            doc["decisions_with_rationale"].append({"decision": item})
        elif current == "blocker":
            doc["blockers"].append(item)
        elif current == "next":
            doc["next_steps"].append(item)
        elif current == "state":
            doc["current_state"]["status"].append(item)
    m = re.search(r"^\*\*Focus\*\*:\s*(.+)$", text, re.M)
    doc["current_state"]["summary"] = (m.group(1).strip() if m else "")
    return doc


def redact_doc(doc, hits_out, fname):
    """Depth-first placeholder redaction; hits recorded per file."""
    if isinstance(doc, str):
        red, hits = redact_text(doc)
        for h in hits:
            # No excerpts in the report: the report file must stay free of
            # the private data it flags. Reviewers grep the source file.
            hits_out.append({"file": fname, "pattern": h["pattern"],
                             "chars": h["end"] - h["start"]})
        return red
    if isinstance(doc, list):
        return [redact_doc(x, hits_out, fname) for x in doc]
    if isinstance(doc, dict):
        return {k: redact_doc(v, hits_out, fname) for k, v in doc.items()}
    return doc


def run_cli(argv):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        mem.main(argv)
    return json.loads(buf.getvalue().strip().splitlines()[-1])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", default=os.path.join(
        os.path.expanduser("~"), "TaktflowBMS", "Principle", "progress"))
    ap.add_argument("--db", required=True,
                    help="benchmark DB path (must NOT be the production DB)")
    ap.add_argument("--project", default="taktflowbms")
    ap.add_argument("--report", default=os.path.join(
        BENCH_DIR, "results", "taktflowbms-import-report.json"))
    args = ap.parse_args()

    os.environ["MEMDB_PATH"] = args.db
    run_cli(["init"])

    files = sorted(f for f in os.listdir(args.source)
                   if f.endswith((".md", ".yaml")))
    hits, episodes, warnings = [], [], []
    for fname in files:
        raw = open(os.path.join(args.source, fname), encoding="utf-8").read()
        date = fname[:10]
        task = re.sub(r"-(handoff|progress|handoff-progress)$", "",
                      fname[11:].rsplit(".", 1)[0])
        if fname.endswith(".yaml"):
            import yaml  # bench-only dependency; core memdb stays stdlib
            try:
                parsed = yaml.safe_load(raw)
            except yaml.YAMLError as e:
                # Real corpus contains hand-written YAML that pyyaml rejects
                # (unquoted colons). Preserve verbatim rather than drop.
                warnings.append("{}: YAML parse failed ({}) - payload-only"
                                .format(fname, type(e).__name__))
                parsed = {}
            doc = {k: parsed.get(k) for k in
                   ("achievement", "decisions_with_rationale",
                    "current_state", "blockers", "next_steps")}
            doc = {k: v for k, v in doc.items() if v is not None}
            if not doc:
                doc = {"raw_yaml": raw}
            part = str(parsed.get("part") or "cross-cutting")
            date = str(parsed.get("date") or date)
        else:
            doc = parse_markdown(raw)
            doc["raw_markdown"] = raw
            part = "cross-cutting"
            if not any([doc["achievement"], doc["blockers"],
                        doc["current_state"]["status"]]):
                warnings.append("{}: no bullets routed - payload-only"
                                .format(fname))
        doc["date"] = date
        doc = redact_doc(doc, hits, fname)

        tmp = os.path.join("/tmp", "memdb-import-episode.json")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(doc, f)
        out = run_cli(["record-episode", "--project", args.project,
                       "--part", part, "--task", task, "--date", date,
                       "--json", tmp])
        episodes.append({"file": fname, "episode_id": out["episode_id"],
                         "children": out["children"],
                         "closed_blockers": out["closed_blockers"]})
    os.remove(tmp)

    conn = mem.connect(args.db)
    ep_count = conn.execute(
        "SELECT count(*) FROM records WHERE kind='episode'").fetchone()[0]
    report = {
        "source": "<taktflowbms>/Principle/progress",
        "files_on_disk": len(files),
        "episodes_in_db": ep_count,
        "count_matches": ep_count == len(files),
        "date_range": [files[0][:10], files[-1][:10]],
        "records_total": conn.execute(
            "SELECT count(*) FROM records").fetchone()[0],
        "redaction_hits": hits,
        "redaction_hit_count": len(hits),
        "warnings": warnings,
        "episodes": episodes,
    }
    os.makedirs(os.path.dirname(args.report), exist_ok=True)
    with open(args.report, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=1)
    print(json.dumps({"files": len(files), "episodes": ep_count,
                      "count_matches": report["count_matches"],
                      "redaction_hits": len(hits),
                      "warnings": len(warnings), "report": args.report}))


if __name__ == "__main__":
    main()

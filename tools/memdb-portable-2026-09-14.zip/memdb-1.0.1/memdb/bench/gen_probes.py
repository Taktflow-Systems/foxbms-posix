#!/usr/bin/env python3
"""Derive gold recall probes from a fixture manifest's ground truth.

Probes target subjects with >= 2 revisions (so stale distractors exist)
plus a sample of blockers (open and resolved). Deterministic per seed.
"""
import argparse
import json
import os
import random

N_FACT_PROBES = 24
N_BLOCKER_PROBES = 6


def build(manifest, seed):
    rng = random.Random(seed)
    gt = manifest["ground_truth"]
    open_at_end = set(manifest["open_blockers_at_end"])

    facts = sorted(k for k, v in gt.items()
                   if v["kind"] in ("decision", "state") and v["revisions"] >= 2)
    blockers = sorted(k for k, v in gt.items() if v["kind"] == "blocker")
    rng.shuffle(facts)
    rng.shuffle(blockers)

    probes = []
    templates = {"decision": "current decision on {comp} {aspect}",
                 "state": "latest state of {comp} {aspect}"}
    for key in facts[:N_FACT_PROBES]:
        v = gt[key]
        words = v["subject"].replace("state-", "").split("-")
        comp, aspect = "-".join(words[:-1]), words[-1]
        probes.append({
            "probe_id": "probe-{:03d}".format(len(probes)),
            "kind": v["kind"], "subject": v["subject"],
            "query": templates[v["kind"]].format(
                comp=comp.replace("-", " "), aspect=aspect),
            "expect_body": v["final_body"],
            "superseded_bodies": v["superseded_bodies"],
            "gold_file": v["gold_file"],
        })
    for key in blockers[:N_BLOCKER_PROBES]:
        v = gt[key]
        probes.append({
            "probe_id": "probe-{:03d}".format(len(probes)),
            "kind": "blocker", "subject": v["subject"],
            "query": "blocker " + " ".join(v["subject"].split("-")[:4]),
            "expect_body": v["final_body"],
            "expect_status": "open" if v["subject"] in open_at_end else "closed",
            "superseded_bodies": [],
            "gold_file": v["gold_file"],
        })
    return probes


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fixture", required=True, help="fixture dir with manifest.json")
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()
    with open(os.path.join(args.fixture, "manifest.json")) as f:
        manifest = json.load(f)
    probes = build(manifest, args.seed)
    out = os.path.join(args.fixture, "probes.jsonl")
    with open(out, "w", encoding="utf-8") as f:
        for p in probes:
            f.write(json.dumps(p, sort_keys=True) + "\n")
    print(json.dumps({"probes": len(probes), "out": out}))


if __name__ == "__main__":
    main()

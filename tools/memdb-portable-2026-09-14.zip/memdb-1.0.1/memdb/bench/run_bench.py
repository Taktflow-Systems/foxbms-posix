#!/usr/bin/env python3
"""memdb benchmark runner (S-MEM-10/11).

Ingests a fixture corpus into a fresh DB, measures inject-tokens vs the
file-flow baseline, recall vs grep, staleness, anchor-integrity, latency,
contradiction detection, and DB size. Emits results JSON + markdown report
under bench/results/. With --cost, converts token metrics to currency via
pricing.json (never hardcoded prices).
"""
import argparse
import contextlib
import datetime
import io
import json
import os
import re
import shutil
import statistics
import sys
import time

BENCH_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(BENCH_DIR))
import file_flow  # noqa: E402
import gen_fixture  # noqa: E402
import gen_probes  # noqa: E402
import mem  # noqa: E402

RESULTS_DIR = os.path.join(BENCH_DIR, "results")
WORK_DIR = os.path.join(BENCH_DIR, "work")
BUDGET = 1500


def run_cli(argv):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        mem.main(argv)
    lines = buf.getvalue().strip().splitlines()
    return [json.loads(l) for l in lines] if lines else []


def search_rows(conn, query, project, kind=None, status=None, limit=5):
    sql = ("SELECT r.*, bm25(records_fts, 5.0, 1.0, 1.0, 0.5) AS rank "
           "FROM records_fts JOIN records r ON r.id = records_fts.rowid "
           "WHERE records_fts MATCH ? AND r.project=?")
    params = [mem.fts_query(query), project]
    if kind:
        sql += " AND r.kind=?"
        params.append(kind)
    if status:
        sql += " AND r.status=?"
        params.append(status)
    sql += " ORDER BY rank LIMIT ?"
    params.append(limit)
    return conn.execute(sql, params).fetchall()


def grep_rank(yaml_dir, entries, query):
    """Rank rendered YAML files by query-token occurrence count."""
    tokens = [t.lower() for t in re.findall(r"[A-Za-z0-9_]+", query)]
    scored = []
    for e in entries:
        text = open(os.path.join(yaml_dir, e["path"]), encoding="utf-8"
                    ).read().lower()
        score = sum(text.count(t) for t in tokens)
        if score > 0:
            scored.append((score, e["path"], e["file"]))
    scored.sort(key=lambda x: (-x[0], x[1]))
    return scored


def percentile(values, pct):
    if not values:
        return 0.0
    values = sorted(values)
    idx = min(len(values) - 1, int(round(pct / 100 * (len(values) - 1))))
    return values[idx]


def bench_profile(profile, seed):
    fixture_dir = os.path.join(BENCH_DIR, "fixtures", profile)
    if not os.path.exists(os.path.join(fixture_dir, "manifest.json")):
        print("[gen] fixture {} missing - generating (seed {})".format(
            profile, seed))
        gen_fixture.gen(profile, seed, fixture_dir)
    with open(os.path.join(fixture_dir, "manifest.json")) as f:
        manifest = json.load(f)
    probes_path = os.path.join(fixture_dir, "probes.jsonl")
    if not os.path.exists(probes_path):
        probes = gen_probes.build(manifest, 7)
        with open(probes_path, "w") as f:
            for p in probes:
                f.write(json.dumps(p, sort_keys=True) + "\n")
    probes = [json.loads(l) for l in open(probes_path)]
    project = manifest["project"]

    work = os.path.join(WORK_DIR, profile)
    shutil.rmtree(work, ignore_errors=True)
    os.makedirs(work)
    os.environ["MEMDB_PATH"] = os.path.join(work, "mem.db")
    # Isolate the journal too: bench events must never touch the
    # production journal, and replay needs a host identity.
    os.environ["MEMDB_JOURNAL"] = os.path.join(work, "journal-root")
    os.environ.setdefault("MEMDB_HOST", "bench")
    run_cli(["init"])

    for a in manifest["anchors"]:
        run_cli(["add", "--kind", a["kind"], "--project", project,
                 "--part", "cross-cutting", "--subject", a["subject"],
                 "--body", a["body"]])
    anchor_bodies = [a["body"] for a in manifest["anchors"]]

    # ingest + per-session digest curve
    digest_tokens, anchor_ok = [], 0
    t0 = time.perf_counter()
    conn = mem.connect()
    for ep in manifest["episodes"]:
        run_cli(["record-episode", "--project", project, "--part", ep["part"],
                 "--task", ep["task"],
                 "--json", os.path.join(fixture_dir, "episodes", ep["file"])])
        text = "\n".join(mem.digest_lines(conn, project, None, BUDGET))
        digest_tokens.append(mem.est_tokens(text))
        anchor_ok += all(b in text for b in anchor_bodies)
    ingest_wall = time.perf_counter() - t0

    n_eps = len(manifest["episodes"])
    ep_count = conn.execute(
        "SELECT count(*) FROM records WHERE kind='episode'").fetchone()[0]

    # Conflicting same-subject pairs via the normal gated write path.
    # Log-first semantics: write-gating supersedes the earlier body at
    # apply time (including replay), so the measured invariant is
    # CONVERGENCE - exactly one open row per conflicted subject with the
    # loser retained as superseded. This replaces the pre-log-first
    # "contradiction flagging" target, which gating makes structurally
    # unreachable (raw gate-bypassing inserts are no longer legal: rows
    # without a journal uid cannot exist).
    for c in manifest["contradictions"]:
        for body in (c["body_a"], c["body_b"]):
            run_cli(["add", "--kind", c["kind"], "--project", project,
                     "--part", c["part"], "--subject", c["subject"],
                     "--body", body])
    t0 = time.perf_counter()
    consolidate_report = run_cli(["consolidate"])[0]
    consolidate_wall = time.perf_counter() - t0
    resolved_subjects = set()
    for c in manifest["contradictions"]:
        counts = {r["status"]: r["n"] for r in conn.execute(
            "SELECT status, count(*) AS n FROM records WHERE project=? "
            "AND subject=? GROUP BY status", (project, c["subject"]))}
        if counts.get("open", 0) == 1 and counts.get("superseded", 0) >= 1:
            resolved_subjects.add(c["subject"])
    injected_subjects = {c["subject"] for c in manifest["contradictions"]}

    # file-flow baseline
    yaml_dir = os.path.join(work, "yaml")
    entries = file_flow.render_tree(fixture_dir, yaml_dir)
    ff_tokens = file_flow.per_session_tokens(entries)
    file_by_src = {}
    for e in entries:
        file_by_src[e["file"]] = e["path"]

    # probes: mem search vs grep
    hits1 = hits5 = ghits5 = stale = 0
    search_times = []
    for p in probes:
        t0 = time.perf_counter()
        if p["kind"] == "blocker":
            rows = search_rows(conn, p["query"], project, kind="blocker",
                               limit=5)
            match = [r for r in rows if r["subject"] == p["subject"]]
            ok = bool(match) and match[0]["status"] == p["expect_status"]
            hits5 += ok
            hits1 += ok and rows and rows[0]["subject"] == p["subject"]
        else:
            rows = search_rows(conn, p["query"], project, kind=p["kind"],
                               status="open", limit=5)
            want = mem.norm_body(p["expect_body"])
            got = [mem.norm_body(r["body"]) for r in rows]
            hits1 += bool(got) and got[0] == want
            hits5 += want in got
            stale += bool(got) and got[0] in [mem.norm_body(b) for b in
                                              p["superseded_bodies"]]
        search_times.append(time.perf_counter() - t0)
        ranked = grep_rank(yaml_dir, entries, p["query"])
        gold = file_by_src.get(p["gold_file"])
        ghits5 += gold in [r[1] for r in ranked[:5]]

    digest_times = []
    for _ in range(10):
        t0 = time.perf_counter()
        mem.digest_lines(conn, project, None, BUDGET)
        digest_times.append(time.perf_counter() - t0)

    n = len(probes)
    result = {
        "profile": profile,
        "episodes": n_eps,
        "records_total": conn.execute("SELECT count(*) FROM records"
                                      ).fetchone()[0],
        "episode_count_matches": ep_count == n_eps,
        "ingest_wall_s": round(ingest_wall, 2),
        "consolidate_wall_s": round(consolidate_wall, 2),
        "db_bytes": os.path.getsize(os.environ["MEMDB_PATH"]),
        "digest_tokens_final": digest_tokens[-1],
        "digest_tokens_curve": digest_tokens[:: max(1, n_eps // 20)],
        "fileflow_tokens_final": ff_tokens[-1],
        "fileflow_tokens_mean_last10": sum(ff_tokens[-10:]) // 10,
        "cumulative_digest_tokens": sum(digest_tokens),
        "cumulative_fileflow_tokens": sum(ff_tokens),
        "anchor_integrity": round(anchor_ok / n_eps, 4),
        "recall": {"n_probes": n, "hit1": round(hits1 / n, 3),
                   "hit5": round(hits5 / n, 3),
                   "grep_hit5": round(ghits5 / n, 3),
                   "staleness_leak": round(stale / n, 4)},
        "contradictions": {
            "injected": len(injected_subjects),
            "resolved": len(resolved_subjects)},
        "latency_ms": {
            "search_p50": round(percentile(search_times, 50) * 1000, 2),
            "search_p95": round(percentile(search_times, 95) * 1000, 2),
            "digest_p50": round(percentile(digest_times, 50) * 1000, 2)},
    }
    conn.close()
    return result


def bench_taktflowbms():
    """Real-corpus benchmark (S-MEM-12): DB imported by import_taktflowbms.py,
    probes authored against the real files. Never exported to git."""
    db = os.path.join(WORK_DIR, "taktflowbms.db")
    probes_path = os.path.join(BENCH_DIR, "fixtures", "taktflowbms-probes.jsonl")
    import_report = os.path.join(RESULTS_DIR, "taktflowbms-import-report.json")
    source = os.path.join(os.path.expanduser("~"), "TaktflowBMS",
                          "Principle", "progress")
    for path in (db, probes_path, import_report):
        if not os.path.exists(path):
            raise SystemExit("missing {} - run import_taktflowbms.py / "
                             "author probes first".format(path))
    os.environ["MEMDB_PATH"] = db
    os.environ.setdefault("MEMDB_JOURNAL",
                          os.path.join(os.path.dirname(db), "journal-root"))
    os.environ.setdefault("MEMDB_HOST", "bench")
    conn = mem.connect(db)
    imp = json.load(open(import_report))
    file_of_episode = {e["episode_id"]: e["file"] for e in imp["episodes"]}
    probes = [json.loads(l) for l in open(probes_path)]

    def episode_file(row):
        if row["kind"] == "episode":
            return file_of_episode.get(row["id"])
        return file_of_episode.get(row["source_record"])

    # digest + real file-flow tokens
    digest_text = "\n".join(mem.digest_lines(conn, "taktflowbms", None, BUDGET))
    files = sorted(f for f in os.listdir(source) if f.endswith((".md", ".yaml")))
    file_tokens = [mem.est_tokens(open(os.path.join(source, f),
                                       encoding="utf-8").read())
                   for f in files]
    ff_per_session = [sum(file_tokens[:i]) for i in range(len(files))]

    hits1 = hits5 = ghits5 = 0
    search_times = []
    entries = [{"path": f, "file": f} for f in files]
    for p in probes:
        t0 = time.perf_counter()
        rows = search_rows(conn, p["query"], "taktflowbms", limit=5)
        search_times.append(time.perf_counter() - t0)
        got_files = [episode_file(r) for r in rows]
        hits1 += bool(got_files) and got_files[0] == p["gold_file"]
        hits5 += p["gold_file"] in got_files
        ranked = grep_rank(source, entries, p["query"])
        ghits5 += p["gold_file"] in [r[1] for r in ranked[:5]]

    n = len(probes)
    result = {
        "profile": "taktflowbms",
        "episodes": len(files),
        "records_total": conn.execute("SELECT count(*) FROM records"
                                      ).fetchone()[0],
        "episode_count_matches": imp["count_matches"],
        "ingest_wall_s": None,
        "db_bytes": os.path.getsize(db),
        "digest_tokens_final": mem.est_tokens(digest_text),
        "fileflow_tokens_final": sum(file_tokens),
        "cumulative_digest_tokens": mem.est_tokens(digest_text) * len(files),
        "cumulative_fileflow_tokens": sum(ff_per_session),
        "anchor_integrity": None,  # real corpus predates goal records
        "recall": {"n_probes": n, "hit1": round(hits1 / n, 3),
                   "hit5": round(hits5 / n, 3),
                   "grep_hit5": round(ghits5 / n, 3),
                   "staleness_leak": None},
        "contradictions": {"injected": 0, "resolved": 0},
        "latency_ms": {
            "search_p50": round(percentile(search_times, 50) * 1000, 2),
            "search_p95": round(percentile(search_times, 95) * 1000, 2),
            "digest_p50": None},
        "redaction_hits": imp["redaction_hit_count"],
    }
    checks = [
        ("digest <= {} tokens [taktflowbms]".format(BUDGET),
         result["digest_tokens_final"] <= BUDGET,
         str(result["digest_tokens_final"])),
        ("recall hit@5 >= 0.90 [taktflowbms]",
         result["recall"]["hit5"] >= 0.90, str(result["recall"]["hit5"])),
        ("hit@5 >= grep hit@5 [taktflowbms]",
         result["recall"]["hit5"] >= result["recall"]["grep_hit5"],
         "{} vs {}".format(result["recall"]["hit5"],
                           result["recall"]["grep_hit5"])),
        ("search p50 < 100 ms [taktflowbms]",
         result["latency_ms"]["search_p50"] < 100,
         str(result["latency_ms"]["search_p50"])),
        ("episode count matches files on disk [taktflowbms]",
         result["episode_count_matches"], "59 expected"),
    ]
    return result, checks


def evaluate_targets(results):
    """Returns list of (target, ok, detail) across all profiles."""
    checks = []
    for r in results:
        p = r["profile"]
        checks.append(("digest <= {} tokens [{}]".format(BUDGET, p),
                       r["digest_tokens_final"] <= BUDGET,
                       str(r["digest_tokens_final"])))
        checks.append(("recall hit@5 >= 0.90 [{}]".format(p),
                       r["recall"]["hit5"] >= 0.90, str(r["recall"]["hit5"])))
        checks.append(("hit@5 >= grep hit@5 [{}]".format(p),
                       r["recall"]["hit5"] >= r["recall"]["grep_hit5"],
                       "{} vs {}".format(r["recall"]["hit5"],
                                         r["recall"]["grep_hit5"])))
        checks.append(("staleness-leak = 0 [{}]".format(p),
                       r["recall"]["staleness_leak"] == 0,
                       str(r["recall"]["staleness_leak"])))
        checks.append(("anchor-integrity = 1.0 [{}]".format(p),
                       r["anchor_integrity"] == 1.0,
                       str(r["anchor_integrity"])))
        checks.append(("conflict pairs 100% converged [{}]".format(p),
                       r["contradictions"]["resolved"] ==
                       r["contradictions"]["injected"],
                       "{}/{}".format(r["contradictions"]["resolved"],
                                      r["contradictions"]["injected"])))
    by_profile = {r["profile"]: r for r in results}
    if "p6000" in by_profile:
        r = by_profile["p6000"]
        checks.append(("search p50 < 100 ms [p6000]",
                       r["latency_ms"]["search_p50"] < 100,
                       str(r["latency_ms"]["search_p50"])))
        checks.append(("digest p50 < 200 ms [p6000]",
                       r["latency_ms"]["digest_p50"] < 200,
                       str(r["latency_ms"]["digest_p50"])))
        checks.append(("fileflow >= 5x digest tokens [p6000]",
                       r["fileflow_tokens_final"] >=
                       5 * r["digest_tokens_final"],
                       "{} vs {}".format(r["fileflow_tokens_final"],
                                         r["digest_tokens_final"])))
        if "p60" in by_profile:
            r60 = by_profile["p60"]
            checks.append(("flat curve: p6000 digest <= 1.2x p60",
                           r["digest_tokens_final"] <=
                           1.2 * r60["digest_tokens_final"],
                           "{} vs {}".format(r["digest_tokens_final"],
                                             r60["digest_tokens_final"])))
    return checks


def cost_section(results, pricing, sessions_per_day):
    with open(pricing) as f:
        p = json.load(f)
    mtok = 1_000_000
    lines = ["", "## Cost model", "",
             "Pricing basis: {} (model: {})".format(
                 p["pricing_basis"], p["model"]), ""]
    lines.append("| profile | flow | tokens/session | $/session | "
                 "$/session (cache read) | $/month @ {}/day | cumulative $ |"
                 .format(sessions_per_day))
    lines.append("|---|---|---|---|---|---|---|")
    for r in results:
        for flow, tok, cum in (
                ("file readback", r["fileflow_tokens_final"],
                 r["cumulative_fileflow_tokens"]),
                ("mem digest", r["digest_tokens_final"],
                 r["cumulative_digest_tokens"])):
            base = tok * p["input_per_mtok"] / mtok
            cached = tok * p["cache_read_per_mtok"] / mtok
            monthly = base * sessions_per_day * 30
            lines.append(
                "| {} | {} | {} | ${:.6f} | ${:.6f} | ${:.4f} | ${:.4f} |"
                .format(r["profile"], flow, tok, base, cached, monthly,
                        cum * p["input_per_mtok"] / mtok))
    return lines


def write_report(results, checks, cost_lines, run_date):
    os.makedirs(RESULTS_DIR, exist_ok=True)
    for r in results:
        path = os.path.join(RESULTS_DIR,
                            "{}-{}.json".format(run_date, r["profile"]))
        with open(path, "w") as f:
            json.dump(r, f, indent=1, sort_keys=True)
    lines = ["# memdb benchmark report - {}".format(run_date), "",
             "Command: `python3 memdb/bench/run_bench.py --all`", "",
             "| metric | " + " | ".join(r["profile"] for r in results) + " |",
             "|---|" + "---|" * len(results)]
    keys = [("episodes", lambda r: r["episodes"]),
            ("records total", lambda r: r["records_total"]),
            ("ingest wall (s)", lambda r: r["ingest_wall_s"]),
            ("db size (bytes)", lambda r: r["db_bytes"]),
            ("digest tokens (final)", lambda r: r["digest_tokens_final"]),
            ("file-flow tokens (final)", lambda r: r["fileflow_tokens_final"]),
            ("cumulative digest tokens", lambda r: r["cumulative_digest_tokens"]),
            ("cumulative file-flow tokens", lambda r: r["cumulative_fileflow_tokens"]),
            ("recall hit@1", lambda r: r["recall"]["hit1"]),
            ("recall hit@5", lambda r: r["recall"]["hit5"]),
            ("grep hit@5", lambda r: r["recall"]["grep_hit5"]),
            ("staleness leak", lambda r: r["recall"]["staleness_leak"]),
            ("anchor integrity", lambda r: r["anchor_integrity"]),
            ("conflict pairs converged", lambda r: "{}/{}".format(
                r["contradictions"]["resolved"],
                r["contradictions"]["injected"])),
            ("search p50 (ms)", lambda r: r["latency_ms"]["search_p50"]),
            ("search p95 (ms)", lambda r: r["latency_ms"]["search_p95"]),
            ("digest p50 (ms)", lambda r: r["latency_ms"]["digest_p50"])]
    for label, fn in keys:
        lines.append("| {} | {} |".format(
            label, " | ".join(str(fn(r)) for r in results)))
    lines += ["", "## Targets", ""]
    for target, ok, detail in checks:
        lines.append("- [{}] {} - {}".format("PASS" if ok else "FAIL",
                                             target, detail))
    lines += cost_lines
    report = os.path.join(RESULTS_DIR, "{}-report.md".format(run_date))
    with open(report, "w") as f:
        f.write("\n".join(lines) + "\n")
    return report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", choices=sorted(gen_fixture.PROFILES))
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--corpus", choices=["taktflowbms"])
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--cost", action="store_true")
    ap.add_argument("--pricing", default=os.path.join(BENCH_DIR, "pricing.json"))
    ap.add_argument("--sessions-per-day", type=int, default=10)
    args = ap.parse_args()

    if args.corpus == "taktflowbms":
        print("[bench] running real corpus: taktflowbms ...")
        result, checks = bench_taktflowbms()
        results, profiles = [result], ["taktflowbms"]
    else:
        profiles = sorted(gen_fixture.PROFILES) if args.all else [args.profile]
        if not profiles or profiles == [None]:
            ap.error("need --profile or --all")
        results = []
        for prof in profiles:
            print("[bench] running {} ...".format(prof))
            results.append(bench_profile(prof, args.seed))
        checks = evaluate_targets(results)
    cost_lines = []
    if args.cost:
        cost_lines = cost_section(results, args.pricing,
                                  args.sessions_per_day)
    run_date = datetime.date.today().isoformat()
    if args.corpus:
        run_date += "-" + args.corpus  # keep synthetic report file separate
    report = write_report(results, checks, cost_lines, run_date)
    fails = [c for c in checks if not c[1]]
    print(json.dumps({"report": report, "profiles": profiles,
                      "targets_passed": len(checks) - len(fails),
                      "targets_failed": len(fails)}))
    for target, ok, detail in fails:
        print("FAIL: {} ({})".format(target, detail))


if __name__ == "__main__":
    main()

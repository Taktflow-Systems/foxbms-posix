#!/usr/bin/env python3
"""Deterministic synthetic corpus generator for the memdb benchmark.

Simulates a project timeline of end-of-job episodes: decisions that
supersede earlier ones, blockers that open and resolve, recurring state
subjects, goals/constraints set at episode 1, and gate-bypassing
contradiction pairs at known positions. Emits episode JSON files plus
manifest.json carrying the full ground truth.

Profiles: p60 ~ 60 episodes, p600 ~ 600 records, p6000 ~ 6000 records.
Same seed -> byte-identical output tree.
"""
import argparse
import datetime
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from mem import slug  # noqa: E402

PROFILES = {"p60": 60, "p600": 70, "p6000": 700}
PARTS = ["bms-core", "hil", "infra"]
COMPONENTS = ["voltage-evaluator", "watchdog", "safe-state", "cell-balancer",
              "soc-estimator", "can-gateway", "contactor-driver",
              "thermal-monitor", "bootloader", "telemetry-link"]
ASPECTS = ["threshold", "timeout", "calibration", "retry-policy",
           "sampling-rate", "fault-latch", "startup-order", "checksum",
           "buffer-size", "logging"]
CHOICES = ["fixed-window", "sliding-window", "dual-slope", "kalman-filter",
           "median-of-3", "crc32-guard", "table-lookup", "linear-interp",
           "hysteresis-band", "double-buffer"]
ISSUES = ["rig offline", "spec pending", "vendor silence", "flaky fixture",
          "missing calibration data"]
ANCHORS = [
    {"kind": "goal", "subject": "release-gate",
     "body": "reach release gate A3 with all trace closures green"},
    {"kind": "goal", "subject": "sil-parity",
     "body": "keep sil results bit-identical to hil reference runs"},
    {"kind": "constraint", "subject": "no-heap",
     "body": "no dynamic allocation in target firmware paths"},
    {"kind": "constraint", "subject": "single-source-config",
     "body": "all limits come from the canonical config table only"},
]
N_CONTRADICTIONS = 5


def gen(profile, seed, out_dir):
    rng = random.Random(seed)
    n_episodes = PROFILES[profile]
    start = datetime.date(2024, 1, 1)
    os.makedirs(os.path.join(out_dir, "episodes"), exist_ok=True)

    subjects = [(c, a) for c in COMPONENTS for a in ASPECTS]
    history = {}          # (kind, subject) -> list of {episode, body, file}
    open_blockers = {}    # subject -> {body, opened_ep, resolve_ep}
    episode_files = []
    record_count = 0

    for i in range(n_episodes):
        date = (start + datetime.timedelta(days=i * 3)).isoformat()
        part = PARTS[i % len(PARTS)]
        task = "job-{:04d}".format(i)
        fname = "{}-{}.json".format(date, task)
        achievements = ["completed {} work package {}".format(part, i)]
        decisions, blockers, states = [], [], []

        for _ in range(rng.randint(2, 4)):
            comp, aspect = subjects[rng.randrange(len(subjects))]
            subject = "{}-{}".format(comp, aspect)
            rev = len(history.get(("decision", subject), []))
            choice = CHOICES[(rng.randrange(len(CHOICES)) + rev) % len(CHOICES)]
            body = "use {} for {} {} (decision rev {})".format(
                choice, comp, aspect, rev)
            decisions.append({"decision": body, "subject": subject,
                              "rationale": "chosen after {} bench sweep {}"
                              .format(aspect, i)})
            history.setdefault(("decision", subject), []).append(
                {"episode": i, "body": body, "file": fname})
            record_count += 1

        # resolve blockers scheduled for this episode
        for subj in [s for s, b in list(open_blockers.items())
                     if b["resolve_ep"] == i]:
            achievements.append("resolved: " + open_blockers[subj]["body"])
            del open_blockers[subj]

        if rng.random() < 0.4:
            comp, aspect = subjects[rng.randrange(len(subjects))]
            issue = ISSUES[rng.randrange(len(ISSUES))]
            body = "{} {} blocked: {}".format(comp, aspect, issue)
            subject = slug(body)
            if subject not in open_blockers:
                resolve = i + rng.randint(2, 6)
                open_blockers[subject] = {"body": body, "opened_ep": i,
                                          "resolve_ep": resolve}
                blockers.append({"text": body, "subject": subject})
                history.setdefault(("blocker", subject), []).append(
                    {"episode": i, "body": body, "file": fname})
                record_count += 1

        for _ in range(rng.randint(2, 3)):
            comp, aspect = subjects[rng.randrange(len(subjects))]
            subject = "state-{}-{}".format(comp, aspect)
            rev = len(history.get(("state", subject), []))
            body = "{} {} now at rev {} verified on bench".format(
                comp, aspect, rev)
            states.append({"text": body, "subject": subject})
            history.setdefault(("state", subject), []).append(
                {"episode": i, "body": body, "file": fname})
            record_count += 1

        doc = {
            "date": date,
            "achievement": achievements,
            "decisions_with_rationale": decisions,
            "current_state": {
                "summary": "episode {} of {} timeline".format(i, profile),
                "files_touched": [], "status": states},
            "blockers": blockers,
            "next_steps": ["continue toward release gate"],
        }
        with open(os.path.join(out_dir, "episodes", fname), "w",
                  encoding="utf-8") as f:
            json.dump(doc, f, indent=1, sort_keys=True)
        episode_files.append({"file": fname, "date": date, "part": part,
                              "task": task})
        record_count += 1  # the episode row itself

    contradictions = []
    for k in range(N_CONTRADICTIONS):
        contradictions.append({
            "kind": "state", "part": "cross-cutting",
            "subject": "ghost-channel-{}".format(k),
            "body_a": "ghost channel {} reads plausible-high".format(k),
            "body_b": "ghost channel {} reads plausible-low".format(k)})

    ground_truth = {}
    for (kind, subject), writes in sorted(history.items()):
        ground_truth["{}:{}".format(kind, subject)] = {
            "kind": kind, "subject": subject,
            "final_body": writes[-1]["body"],
            "gold_file": writes[-1]["file"],
            "revisions": len(writes),
            "superseded_bodies": [w["body"] for w in writes[:-1]],
        }

    manifest = {
        "profile": profile, "seed": seed, "project": "bench-" + profile,
        "episodes": episode_files, "anchors": ANCHORS,
        "contradictions": contradictions,
        "expected_record_count": record_count,
        "open_blockers_at_end": sorted(open_blockers),
        "ground_truth": ground_truth,
    }
    with open(os.path.join(out_dir, "manifest.json"), "w",
              encoding="utf-8") as f:
        json.dump(manifest, f, indent=1, sort_keys=True)
    return manifest


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", required=True, choices=sorted(PROFILES))
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", help="output dir (default fixtures/<profile>)")
    args = ap.parse_args()
    out = args.out or os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                   "fixtures", args.profile)
    m = gen(args.profile, args.seed, out)
    print(json.dumps({"profile": args.profile, "episodes": len(m["episodes"]),
                      "expected_records": m["expected_record_count"],
                      "subjects": len(m["ground_truth"]), "out": out}))


if __name__ == "__main__":
    main()

# memdb portable package

Log-first, lossless memory layer for AI agent harnesses (Claude Code,
Codex, or similar). Python 3.9+ stdlib and git; nothing else. No bash,
on any platform.

- System of record: per-host append-only hash-chained event journals,
  optionally replicated between machines via a git hub (per-host
  branches). SQLite is a rebuildable projection; `mem verify` proves
  nothing was lost or tampered with.

## The artifacts

| artifact | when to use it | how to run memdb afterwards |
|---|---|---|
| `memdb-<version>-py3-none-any.whl` | the machine has pip | `mem <cmd>`, or `python -m memdb <cmd>` where the scripts directory is not on PATH |
| `memdb-<version>.pyz` | no pip, no install rights, or pip refuses a `--user` install | `python3 memdb-<version>.pyz <cmd>` |
| `memdb-portable-<version>.zip` | the source tree with its tests and this guide, plus the `.pyz` | read offline, or run the test suite on the target |

`SHA256SUMS` covers all of them. Verify it, then run
`python3 memdb-<version>.pyz selftest`, before installing anything. How a
release is built and how a host is upgraded: `memdb/docs/release.md`.

## Installing

One command, documented in `install/AGENT_INSTALL.md`:

    mem install --host <slug> --hub "join <hub>" --check   # look
    mem install --host <slug> --hub "join <hub>" --yes     # apply

`<hub>` is an ssh target, an `ssh://` URL, a local path or a `file://`
URL. It does identity, the journal repo, the hub remote, schema init, the
first sync, the skill, the harness rule block, the SessionStart hook, the
daily sync schedule, the install episode and a final verify and doctor,
backing up every user-owned file it rewrites. Without `--yes` it writes
nothing. Re-running it changes nothing and journals nothing.

- `install/AGENT_INSTALL.md` - the guide for the agent doing the install.
- `install/PROMPT.txt` - the short prompt the human pastes to start it.
- `memdb/templates/` - the skill and the rule block the installer
  renders; `{{MEM}}` is the only command placeholder, so no rendered
  file ever names the checkout it came from.
- `memdb/` - the package (mem.py, journal.py, config.py, install.py,
  paths.py, schema.sql, hooks/, harness/, templates/, tests/).

Release 1.0.0 (2026-09-13): installs, records, syncs, verifies and fires
its hook from the `.pyz` alone on a machine that never saw the checkout,
on Windows and on Linux (`memdb/docs/audits/2026-09-13-fresh-machine.md`).

Origin: Taktflow memory-orchestration workspace, 2026-08-15. Benchmarked
at 22/22 targets: session-start digest flat at ~1.5k tokens from 60 to
6000 records, recall hit@5 1.0 vs grep 0.1-0.33, verify chain+projection
green, search p50 3.2 ms at 6k records.

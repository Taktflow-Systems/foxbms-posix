# memdb install guide (for the AI agent on the target system)

You are an AI agent (Claude Code, Codex, or similar) on a NEW system. The
user has given you a memdb release and asked you to install it. The whole
installation is one command; your job is to get its three parameters
right, run it, and read its report back to the user.

Where a parameter needs a value only the user can provide, use the value
from the user's install prompt; if one is missing, ASK - never guess.

## What you are installing (context)

memdb replaces end-of-job "handoff files" and ad-hoc memory notes with:
- an append-only, hash-chained per-host EVENT JOURNAL as the system of
  record (`<memdb-home>/journal/journal/<host>/events.jsonl`);
- a SQLite projection (`<memdb-home>/mem.db`) that `mem rebuild`
  reproduces from journals alone - the DB is disposable;
- `mem verify` proving chain integrity + projection match (loss is
  detectable, never silent);
- optional multi-machine sync through a git hub (per-host branches);
- a skill and a global rule block for the harness, so agents record an
  episode at the end of every job and read memory back at task start.

`<memdb-home>` is `~/.claude/memory` unless `MEMDB_HOME` says otherwise.
Records get stable uids `<host>:<seq>` (children `<host>:<seq>/<n>`).
Memory content is FULL-FIDELITY (private domain); redaction applies only
to artifacts leaving the private domain (`mem redact-check`).

## Parameters (from the user's prompt)

- HOST_SLUG: one short word identifying this machine (e.g. workstation,
  laptop, office-pc). The HUMAN chooses it. Never invent one. A host
  never changes its slug: it owns a journal branch.
- HUB: one of
  - `join <hub>` - an existing hub: an ssh target
    (`<hub-ssh-spec>:git/memory-journal.git`, or a bare `<hub-ssh-spec>`
    for that default path), an `ssh://` URL, a local path or a `file://`
    URL of the journal repository,
  - `new <hub>` - create the bare journal repository at the path the
    hub names (a bare `<hub-ssh-spec>` means `git/memory-journal.git`
    under the ssh user's home; a local path is used as it is), unless it
    already exists,
  - `standalone` - no hub; the sync skips push and fetch (can be joined
    later).
- HARNESS (optional): `claude-code`, `codex`, `generic`, or a
  comma-separated list. Left out, memdb installs for every harness it
  finds on the machine.

## Install

1. **Get the tool on the machine.** Either form works; pick by what the
   machine has:
   - with pip: `pip install --user memdb-<version>-py3-none-any.whl`;
   - without pip, or where pip refuses a `--user` install (an externally
     managed system Python): keep `memdb-<version>.pyz` anywhere and call
     it as `python3 memdb-<version>.pyz <cmd>`. Never pass
     `--break-system-packages`.
   Verify the checksum from `SHA256SUMS` before either. Never install
   from a bare source checkout: preflight runs the recorded command from
   a temporary directory without `PYTHONPATH` and stops when it cannot
   start memdb of this version, because the hook and the schedule would
   fail the same way.

2. **Look before it writes.** Run the install in check mode first; it
   prints the unified diff of every file it would change, lists every
   other side effect (config.json, the journal repository, `origin`,
   `agent.host-id`, the schedule entry against the current one, the
   first sync, the install episode, the final verify and doctor) and
   writes nothing. A run with neither `--check` nor `--yes` is also a
   check:

   ```sh
   mem install --host <HOST_SLUG> --hub "<HUB>" --check
   ```

   (`python -m memdb install ...` or `python memdb-<version>.pyz
   install ...` if `mem` is not on PATH.) Show that diff to the user if
   it touches a file they wrote.

3. **Apply it.**

   ```sh
   mem install --host <HOST_SLUG> --hub "<HUB>" --yes
   ```

   One command does all of it: preflight (Python 3.9+, sqlite3 with
   FTS5, git, and for a hub `git ls-remote` or an `ssh` probe), self-test,
   host identity, journal git repo on branch `<HOST_SLUG>/journal`, hub
   remote (creating the bare repos for `new`), schema init, first sync,
   the skill and rule block for each harness, the SessionStart hook
   registration, the daily sync schedule, an install episode in the
   journal, and a final `verify` and `doctor`. Re-running it changes
   nothing, journals nothing, and says so.

4. **Read the report.** `mem install` prints one JSON object: version,
   host, command form, hub, harnesses and how they were chosen
   (`harness_source`), every change record with its backup path, the
   schedule, the install episode uid, the preflight results, and the
   verify and doctor results. Give the user that summary. The install
   exits 1 when verify or doctor is not green.

5. **Confirm health.** `mem doctor` must exit 0 with no warnings and
   `mem verify` must print `"ok": true`.

## Useful flags

| flag | effect |
|---|---|
| `--check` | print every diff, write nothing |
| `--harness a,b` | install for these harnesses only |
| `--schedule HH:MM` / `--schedule none` | daily sync time, or no schedule (a hub member defaults to 12:00; with `MEMDB_HOME` set there is no OS schedule unless this flag gives a time) |
| `--pyz <path>` | the `.pyz` command form (no pip on this machine): copies the artifact to `<memdb-home>/bin/memdb.pyz` plus `memdb-<version>.pyz`; running `python memdb-<version>.pyz install` selects it by itself |
| `--embed off` | never call the embedding backend on this host |

Host-specific text for the rendered skill or rule block (a local handoff
folder, a site convention) goes in `<memdb-home>/local/skill.md` or
`<memdb-home>/local/rule.md`; every install renders it into the file, so
it is never lost on a re-render.

`mem uninstall` reverses the harness wiring and the schedule. It never
touches journals or the DB unless you pass `--purge-data --yes`.

## Safety rules (binding)

- `mem install` backs every user-owned file up under
  `<memdb-home>/install-backups/<date>-<name>.bak` before rewriting it,
  and only ever replaces memdb's own rule block inside a larger
  document. If you edit a harness file by hand, you are doing it wrong.
- Never guess HOST_SLUG or the hub URL; ask.
- Memory content is private-domain: never commit journals or the DB to
  any third-party remote, and never point origin at one without the
  user's explicit say-so.
- If any step fails, stop, report the exact error, and leave the system
  as it is - a half-install must be visible, not hidden.

## Final report checklist

Report to the user: memdb version and command form; HOST_SLUG; hub mode
and remote; every changed file with its backup; the schedule entry; the
install episode uid; `doctor` and `verify` output.

# Changelog

memdb releases, newest first. Format and rules: `memdb/docs/release.md`.

## 1.1.0 - unreleased

Memory quality. Design: `memdb/docs/architecture-memory-quality.md`.

### Added
- `mem review-blockers --project P [--part X] [--repo PATH]`: proposals
  to close open blockers that a later row reports resolved or whose
  "missing" path exists in the repository, and to supersede blockers a
  newer one restates, each with evidence and confidence. `--apply
  high|medium` journals one `review` event.
- `consolidate --project P`: near-duplicate groups (per kind, episodes
  recorded twice, states repeated by a constraint) as supersede and
  relates proposals, journaled by `--apply-proposals`; contradiction
  candidates listed for review, never applied.
- Write gate: `add` refuses a body that repeats an open row of the same
  project and kind under another subject; `--supersedes <uid>` replaces
  that row, `--sibling` keeps both. `record-episode` reports such items
  as `near_duplicates`; a decision or blocker object may name the row it
  replaces with `"supersedes"`.
- `mem list`, `mem stats`, `mem parts [--suggest]`, `mem alias` (part
  families: `--part` covers a part's aliases in digest, search and list).
- `add --created-at` for imported facts; `get --raw`; `digest --global`;
  `core-lint --project`.

### Changed
- `record-episode` requires `resolves` (`[]` allowed) when the part has
  open blockers, rejects `none` blockers and `selftest` parts outside
  project `selftest`, keeps the wall-clock time on back-dated episodes,
  and prints `open_blockers`.
- Search re-ranks by status, age and shadowing (a row with a newer linked
  or same-topic row ranks below it). Lines carry kind, part, status, date,
  a 240-char summary cut at a word, and `by`/`newer` when they apply;
  `id` and a repeated `project` are gone. No hit prints `0 results`.
- `get` prints the payload as an object once, uids instead of local ids,
  links and review history.
- Digest: strict budget; order pinned, state, next steps, live
  decisions, open blockers, episodes; hygiene-flagged, superseded or
  contradicted rows hidden; global rows left out when the rules file
  exists. One trim note counts everything omitted.
- `consolidate --expire-states` marks stale states `unverified` instead
  of closing them; `consolidate --dry-run` takes no lock.

### Fixed
- `install` with a `join` or `new` hub stops in preflight when git has no
  user name or email, and exits 1 when its first sync fails; a failed
  sync commit prints git's reason.
- Search ignores stop words when the query has a content word, so a query
  whose only content word matches nothing prints `0 results`.
- `record-episode` lists `closed_blockers` as uids, not local ids.
- `review-blockers` no longer takes a conditional sentence, an episode that
  still lists the item, or a lone shared identifier as `high` evidence, and
  a temporary decision closes at `high` only when its condition is
  reported; with `--repo` it also closes a blocker whose identifier has
  only closed YAML status records, or whose quoted placeholder is gone.
- `consolidate` supersedes a near-duplicate only when the kept row holds
  every content word of the older one; otherwise it links them.
- `review-blockers` treats "x.py has no ..." and "frames are not present
  in x.dbc" as complaints about the file's content: an existing path no
  longer closes them, nor does a path named after a sentence end. Words of
  an existing path are no longer evidence at all ("repo now has" is gone).
  An empty-slot blocker ("none in the gate set") is proposed for closing as
  not a blocker. Without a shared identifier, a `high` close
  needs the cue sentence itself to name half of the blocker; a sentence that
  keeps the work open is not a resolution, and a standing rule ("any
  further change requires ...") never closes at `high`. A restated
  blocker is superseded at `high` only when the newer one holds every
  content word, and a supersede onto a row closed in the same review
  still applies. The same blocker worded twice in one part gets the same
  close. Rows of one imported day (date-only times) are superseded only
  by a row holding every word, since their order is unknown.
- Search never marks a row outdated by the episode that recorded it, and
  `newer` always names a live row, never an intermediate superseded one.
- Search: a queried file name (`START-HERE.md`, `l0-register.yaml`) or
  all-caps name finds the rows holding it even when its words are common.
- A one-letter label is part of what a row names: "Gate A" and "Gate B"
  are different gates for the write gate, consolidate and review-blockers,
  while "Domains H and I" still restates "Domains D through I".
- The write gate also refuses an anchor reworded in other words (score at
  least 0.42 with four shared content words).
- The SessionStart hook reads its input as UTF-8 with or without a byte
  order mark, and says so in the context when the input is not a JSON
  object. A handoff whose next step is "none" shows no next step.
- Search: a query of only stop words prints `0 results`; a queried
  identifier (`VBL-019`) also finds rows naming a range that covers it
  (`VBL-015..021`); a same-day closure and "now has" shadow the row that
  calls the item pending, and so does a later row reporting the same
  subject complete ("OEM round-2 review is complete"). A blocker counts
  as pending by its kind, and a two-clause state closes what either
  clause names.
- The interpreter command form runs `python -P -m memdb` on Python 3.11+
  (`safe_path` in config.json), so a hook or schedule started inside a
  memdb checkout no longer imports that checkout's code; re-run
  `mem install` to rewrite the hook and the task.
- A working directory under a repository at a drive root (`X:/` a git
  repo) resolves to the folder below the drive, not to the drive `X:`.
- `add --supersedes` no longer lists the row it just superseded as a near
  duplicate; the install git-identity check shows git's last error line.
- `get` names the episode whose `resolves` closed a row (`closed_by`); the
  core-setup digest labels next steps with their part and date; `[]` and
  "no blocker remains" are not blockers.
- `review-blockers --repo`: a placeholder counts as gone only when no
  non-binary file holds it, hidden directories and any extension included
  (only `.git` is skipped); when a file could not be read the close is
  `medium` at most.
- `review-blockers`: a blocker that names two or more specific identifiers
  ("VBL-019 and VBL-020") closes only on a row naming all of them.
- A blocker opening with "nothing" and a preposition ("Nothing on the
  bench boots ...") is a real blocker: accepted by `record-episode`, shown
  in the digest, never closed as an empty slot. "none" stays an empty slot
  only before "for" or "in".
- `review-blockers --repo`: a missing relative path closes at `high` only
  when that exact path exists; one deeper match (`memdb/tests/conftest.py`
  for `tests/conftest.py`) is `medium`, several are no proposal.
- `review-blockers --repo`: a YAML status record starts only at an `id:`
  key; `requirement_id` or `parent_id` no longer end the record or start
  another one, so an open item is not read as closed.
- A part family is the part, its descendants and its ancestor chain; a
  sibling under the same parent is no longer in it, so its blockers no
  longer refuse `record-episode` or fill `digest --part`.
- Search: an all-caps query word of two or more letters (`CAN`, `OUT`,
  `ALL`) is an acronym, never a dropped stop word.
- Search: only a newer open row of the same kind family shadows a row by
  topic; a closed row, or a row of another kind (a closed blocker against
  an open constraint), no longer halves it or appears as its `newer`.
- `record-episode`: an item's `supersedes` must be a uid of an existing
  record in the same project and kind family, checked before anything is
  journaled (exit 2); `"supersedes": "1"` no longer resolves as a local id
  and supersedes a row of another project.
- `record-episode` never stores a time later than now: a `date` one day
  ahead of UTC is clamped, so the next handoff's next steps win the
  digest.
- `record-episode` counts every open blocker of the part family in
  `open_blockers.count` and in the missing-`resolves` refusal; both stopped
  at 10, the length of the ranked list.
- A month name or "since" before a year ("July 2026", "since 2026") is a
  date, never an identifier, so a shared month no longer anchors a close.
- `add --created-at` stores a full time in UTC, and review-blockers,
  consolidate and search order rows by parsed time instead of by string,
  so an offset time (`-05:00`) sorts where it happened.

### Compatibility
- New event types `review` and `alias`, `MIN_VERSION_FOR_EVENT_TYPE`
  1.1.0: upgrade every host before any host writes one. Existing events
  replay unchanged. Schema version 5 (tables `parts`, `review_log`):
  `mem install` rebuilds the projection from the journals.
- Scripts parsing `search` output: `0 results` is not JSON, and `id`
  and `project` (with `--project`) are no longer in the lines.

## 1.0.1 - 2026-09-13

### Fixed
- Windows: every command line memdb writes (the SessionStart hook in
  `settings.json`, the rendered skill and rule block, the scheduled task)
  uses forward slashes, and drive-letter paths are quoted. 1.0.0 wrote
  `C:\...\python.exe -m memdb hook session-start`. Claude Code runs hooks
  through Git Bash, which dropped the backslashes, so every session
  started without the memdb digest (a non-blocking hook error). A test
  now runs the registered command through both Git Bash and cmd.exe.

### Compatibility
- No new event type, schema version 4. Re-run `mem install` to rewrite
  the hook, the skill, the rule block and the task. On Linux and macOS the
  rendered text is the same as in 1.0.0.

## 1.0.0 - 2026-09-13

First packaged release.

### Added
- One installable package `memdb` with the console scripts `mem` and
  `memdb-hook`, `python -m memdb`, and a stdlib zipapp
  `memdb-<version>.pyz` that runs with any Python 3.9+.
- `mem install` / `mem uninstall`: identity, journal repository, hub
  remote (`join`, `new` or `standalone`), schema, first sync, skill and
  rule block per harness (Claude Code, Codex, generic), SessionStart hook
  registration, daily sync schedule, install episode, final verify and
  doctor. Nothing is written without `--yes`; `--check` lists every side
  effect with its diff; re-running changes nothing.
- `<memdb-home>/config.json` with `mem config show|get|set`; the command
  form (`mem`, interpreter, `.pyz`) recorded once and used by every
  rendered file, hook and schedule.
- `mem schedule install|remove|status`: Windows task (windowless), cron
  or launchd, one entry per data home.
- `mem sync` in Python (integrity guards unchanged); `--scheduled`
  writes `sync.log`. Standalone hosts sync green.
- `mem hook session-start` in Python, markers naming the installed
  command form.
- `mem selftest`, `tools/build_release.py`, `SHA256SUMS`, and the
  cross-host version guard (witness `memdb_version` and `event_types`,
  sync warnings, doctor fleet table).

### Changed
- Auto-derived subjects of decisions and blockers are
  `<readable slug>-<hash of the text>`: different facts with a long
  common prefix no longer supersede each other.
- `close` and `supersede` refuse a bare local id unless `--local-id`.
- `memdb/sync/memdb_sync.sh` and `scheduled_sync.sh` are transition
  wrappers that run the Python sync; they go away in the next release.

### Compatibility
- No new event type; `MIN_VERSION_FOR_EVENT_TYPE` is empty. Schema
  version 4. Episodes recorded before this release replay unchanged:
  the hashed subject rule applies only to events carrying
  `"subject_rule": "hash"`.

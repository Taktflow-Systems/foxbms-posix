#!/usr/bin/env python3
"""MCP server (stdio) exposing the distiller as model-callable tools.

Zero-install like everything else here: it speaks MCP's newline-delimited
JSON-RPC 2.0 directly over stdin/stdout -- no MCP SDK, no pip. Register it
in Claude Code with a .mcp.json at the repo root:

    {
      "mcpServers": {
        "text-distiller": {
          "command": "python",
          "args": ["tools/text_distiller/distill_mcp.py"]
        }
      }
    }

Tools follow the toolkit's own playbook: few of them, small schemas, every
result token-budgeted server-side. The CLI/GUI remain the preferred shells
for deterministic work (zero schema tax); enable this server when a hosted
model needs to call the distillers as tools.
"""

from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from distiller import __version__
from distiller.api import KINDS, budget_report, distill_any, find_files, search_text
from distiller.core import read_text

PROTOCOL_VERSION = "2024-11-05"

TOOLS = [
    {
        "name": "search_repo",
        "description": "Find which files contain a regex pattern. "
                       "Deterministic and token-budgeted; use this instead of "
                       "reading files one by one to locate code or strings.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "regex to find"},
                "path": {"type": "string",
                         "description": "file or directory to search "
                                        "(default: working directory)"},
                "glob": {"type": "string",
                         "description": "restrict to globs, ';'-separated, "
                                        "e.g. '*.c;*.h'"},
                "files_only": {"type": "boolean",
                               "description": "list files with counts only "
                                              "(default true)"},
                "ignore_case": {"type": "boolean"},
                "word": {"type": "boolean", "description": "whole-word match"},
                "context": {"type": "integer",
                            "description": "context lines when files_only "
                                           "is false"},
                "fixed": {"type": "boolean",
                          "description": "pattern is literal text, not regex"},
                "types": {"type": "string",
                          "description": "file-type shortcuts, ';'-separated, "
                                         "e.g. 'c;py'"},
                "max_tokens": {"type": "integer",
                               "description": "output cap (default 2000)"},
            },
            "required": ["pattern"],
        },
    },
    {
        "name": "find_files",
        "description": "List files matching a glob under a directory, sorted, "
                       "with sizes; .gitignore-aware. Use instead of find/glob.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string",
                            "description": "globs, ';'-separated: basename like "
                                           "'*.c' or path like 'src/*/*.h'"},
                "path": {"type": "string",
                         "description": "directory (default: working directory)"},
                "types": {"type": "string",
                          "description": "file-type shortcuts, ';'-separated"},
                "max_tokens": {"type": "integer"},
            },
        },
    },
    {
        "name": "distill_text",
        "description": "Compress noisy text (logs, build output, test "
                       "reports, JSON, CSV, diffs, code) into a compact "
                       "summary. kind='auto' detects the content type.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "text": {"type": "string"},
                "kind": {"type": "string",
                         "enum": ["auto", *KINDS],
                         "description": "what the text is (default auto)"},
                "filename_hint": {"type": "string",
                                  "description": "drives language detection "
                                                 "for code, e.g. 'foo.c'"},
                "max_tokens": {"type": "integer",
                               "description": "output cap (default 2000)"},
            },
            "required": ["text"],
        },
    },
    {
        "name": "distill_file",
        "description": "Like distill_text but reads a file path. Use after "
                       "token_budget flags a file as too expensive to read.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "kind": {"type": "string", "enum": ["auto", *KINDS]},
                "max_tokens": {"type": "integer"},
            },
            "required": ["path"],
        },
    },
    {
        "name": "token_budget",
        "description": "Token-cost table for files/dirs/globs, biggest "
                       "first. Run before reading anything big.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "paths": {"type": "array", "items": {"type": "string"}},
                "max_tokens": {"type": "integer"},
            },
            "required": ["paths"],
        },
    },
]


def call_tool(name: str, a: dict) -> str:
    if name == "search_repo":
        return search_text(a["pattern"], a.get("path", "."),
                           a.get("glob", ""), a.get("files_only", True),
                           a.get("ignore_case", False), a.get("word", False),
                           a.get("context", 0), a.get("max_tokens", 2000),
                           a.get("fixed", False), a.get("types", ""))
    if name == "find_files":
        return find_files(a.get("pattern", ""), a.get("path", "."),
                          a.get("types", ""), a.get("max_tokens", 2000))
    if name == "distill_text":
        return distill_any(a["text"], a.get("kind", "auto"),
                           a.get("filename_hint", ""),
                           a.get("max_tokens", 2000))
    if name == "distill_file":
        return distill_any(read_text(a["path"]), a.get("kind", "auto"),
                           a["path"], a.get("max_tokens", 2000))
    if name == "token_budget":
        return budget_report(a["paths"], a.get("max_tokens", 2000))
    raise ValueError(f"unknown tool: {name}")


def handle_request(req: dict) -> dict | None:
    """Handle one JSON-RPC message; None for notifications (no reply)."""
    method = req.get("method")
    rid = req.get("id")
    if rid is None:
        return None  # notification, e.g. notifications/initialized
    try:
        if method == "initialize":
            client_version = (req.get("params") or {}).get(
                "protocolVersion", PROTOCOL_VERSION)
            result = {
                "protocolVersion": client_version,
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "text-distiller",
                               "version": __version__},
            }
        elif method == "ping":
            result = {}
        elif method == "tools/list":
            result = {"tools": TOOLS}
        elif method == "tools/call":
            params = req.get("params") or {}
            text = call_tool(params.get("name", ""),
                             params.get("arguments") or {})
            result = {"content": [{"type": "text", "text": text}],
                      "isError": False}
        else:
            return {"jsonrpc": "2.0", "id": rid,
                    "error": {"code": -32601,
                              "message": f"method not found: {method}"}}
        return {"jsonrpc": "2.0", "id": rid, "result": result}
    except Exception as exc:  # tool failures go in-band so the model can react
        if method == "tools/call":
            return {"jsonrpc": "2.0", "id": rid,
                    "result": {"content": [{"type": "text",
                                            "text": f"error: {exc}"}],
                               "isError": True}}
        return {"jsonrpc": "2.0", "id": rid,
                "error": {"code": -32603, "message": str(exc)}}


def main() -> None:
    try:
        # utf-8-sig swallows BOMs (PowerShell pipes prepend one); newline=""
        # keeps us from emitting \r\n, which would confuse strict clients
        sys.stdin.reconfigure(encoding="utf-8-sig", errors="replace")
        sys.stdout.reconfigure(encoding="utf-8", newline="\n")
    except (AttributeError, ValueError):
        pass
    for line in sys.stdin:
        line = line.strip().lstrip("\ufeff")
        if not line:
            continue
        try:
            req = json.loads(line)
        except ValueError:
            print(f"text-distiller: ignoring non-JSON line: {line[:80]!r}",
                  file=sys.stderr)
            continue
        resp = handle_request(req)
        if resp is not None:
            sys.stdout.write(json.dumps(resp) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    main()

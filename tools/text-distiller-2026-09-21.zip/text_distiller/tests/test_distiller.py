"""Unit tests for text_distiller. Run from tools/text_distiller with:

    python -m pytest tests -q

(unittest classes plus pytest-style tests that use the tmp_path fixture;
`python -m unittest` would skip the latter.) Tree-walking fixtures carry a
`.git` marker so the ancestor .gitignore lookup never reaches a real repo.
"""

import codecs
import contextlib
import hashlib
import io
import json
import os
import sys
import tempfile
import unittest

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from distiller import budget, build, core, diffs, jsondata, logs, search, \
    skeleton, slicer, tabular, testreport
from distiller.detect import detect_kind
from distiller.cli import main


class TestCore(unittest.TestCase):
    def test_mask_timestamps_hex_uuid(self):
        line = ("2026-06-12 10:11:12.345 INFO node 0xDEADBEEF "
                "id=123e4567-e89b-42d3-a456-426614174000 took 17ms")
        masked = core.mask_line(line)
        self.assertIn("<TS>", masked)
        self.assertIn("<HEX>", masked)
        self.assertIn("<UUID>", masked)
        self.assertIn("17ms", masked)  # plain numbers kept by default
        self.assertNotIn("<N>", masked)
        self.assertIn("<N>", core.mask_line(line, mask_numbers=True))

    def test_est_tokens(self):
        self.assertEqual(core.est_tokens(""), 0)
        self.assertEqual(core.est_tokens("abcd"), 1)
        self.assertEqual(core.est_tokens("abcde"), 2)

    def test_clip_to_budget(self):
        lines = ["x" * 40] * 100  # ~11 tokens per line
        clipped = core.clip_to_budget(lines, 50)
        self.assertLess(len(clipped), 10)
        self.assertIn("truncated", clipped[-1])
        self.assertEqual(core.clip_to_budget(lines, None), lines)


class TestLogs(unittest.TestCase):
    LOG = "\n".join(
        [f"2026-06-12 10:00:{s:02d} INFO heartbeat ok seq=0x{s:08x}" for s in range(50)]
        + ["2026-06-12 10:01:00 ERROR CAN bus-off on channel 2"]
        + [f"2026-06-12 10:01:{s:02d} WARN retry connect" for s in range(3)]
    )

    def test_dedupe_counts(self):
        body = logs.distill_log(self.LOG)
        joined = "\n".join(body)
        self.assertIn("lines=54", body[0])
        self.assertIn("    50x", joined)
        self.assertIn("     3x", joined)
        self.assertIn("ERROR CAN bus-off", joined)

    def test_level_filter(self):
        body = logs.distill_log(self.LOG, level="error")
        joined = "\n".join(body)
        self.assertIn("ERROR CAN bus-off", joined)
        self.assertNotIn("heartbeat", joined)
        self.assertNotIn("retry", joined)

    def test_deterministic(self):
        self.assertEqual(logs.distill_log(self.LOG), logs.distill_log(self.LOG))


class TestBuild(unittest.TestCase):
    def test_gcc_and_dedupe(self):
        out = "\n".join([
            "src/bms.c:42:5: error: 'cell_v' undeclared (first use)",
            "src/bms.c:42:5: error: 'cell_v' undeclared (first use)",
            "src/bms.c:99:1: warning: unused variable 'tmp' [-Wunused]",
            "compiling src/other.c ...",
        ])
        body = "\n".join(build.distill_build(out))
        self.assertIn("errors=2 warnings=1", body)
        self.assertIn("src/bms.c:42: 'cell_v' undeclared (first use)  [x2]", body)
        self.assertNotIn("compiling", body)

    def test_msvc_and_linker(self):
        out = "\n".join([
            r"C:\work\bms\src\can.c(17,9) : error C2065: 'frame': undeclared identifier",
            "main.obj : error LNK2019: unresolved external symbol _can_init",
            "collect2: undefined reference to `bms_init'",
        ])
        body = "\n".join(build.distill_build(out))
        self.assertIn("C2065", body)
        self.assertIn("LNK2019", body)
        self.assertIn("undefined reference to `bms_init'", body)

    def test_python_traceback(self):
        out = "\n".join([
            "Traceback (most recent call last):",
            '  File "tool.py", line 10, in <module>',
            "    run()",
            '  File "tool.py", line 7, in run',
            "    1 / 0",
            "ZeroDivisionError: division by zero",
        ])
        body = "\n".join(build.distill_build(out))
        self.assertIn("python: ZeroDivisionError: division by zero (at tool.py:7)", body)

    def test_python_syntax_error_without_traceback_header(self):
        out = "\n".join([
            '  File "broken_bms.py", line 7',
            "    for c in cells",
            "                  ^",
            "SyntaxError: expected ':'",
        ])
        body = "\n".join(build.distill_build(out))
        self.assertIn("errors=1", body)
        self.assertIn("python: SyntaxError: expected ':' (at broken_bms.py:7)",
                      body)

    def test_clean_build(self):
        body = "\n".join(build.distill_build("compiling...\nlinking...\ndone."))
        self.assertIn("errors=0 warnings=0", body)


class TestTestreport(unittest.TestCase):
    JUNIT = """<?xml version="1.0"?>
<testsuites>
  <testsuite name="bms" tests="3">
    <testcase classname="test_soc" name="test_ocv_lookup"/>
    <testcase classname="test_soc" name="test_coulomb_counting">
      <failure message="assert 49.9 == 50.0">traceback line 1
line 2</failure>
    </testcase>
    <testcase classname="test_can" name="test_busoff"><skipped/></testcase>
  </testsuite>
</testsuites>"""

    def test_junit(self):
        body = "\n".join(testreport.distill_testreport(self.JUNIT))
        self.assertIn("tests=3 passed=1 failed=1 errors=0 skipped=1", body)
        self.assertIn("FAILURE test_soc::test_coulomb_counting -- assert 49.9 == 50.0", body)

    def test_pytest_text(self):
        out = "\n".join([
            "tests/test_soc.py::test_ocv PASSED",
            "E   assert 49.9 == 50.0",
            "FAILED tests/test_soc.py::test_cc - assert 49.9 == 50.0",
            "=========== 1 failed, 12 passed in 0.34s ===========",
        ])
        body = "\n".join(testreport.distill_testreport(out))
        self.assertIn("1 failed, 12 passed", body)
        self.assertIn("FAILED tests/test_soc.py::test_cc", body)
        self.assertIn("E   assert 49.9 == 50.0", body)


class TestSkeleton(unittest.TestCase):
    def test_python(self):
        src = "\n".join([
            "import os",
            "from sys import path",
            "MAX_CELLS = 96",
            "class Pack:",
            "    def voltage(self) -> float:",
            "        return sum(self.cells)",
            "def main():",
            "    pass",
            "if __name__ == '__main__':",
            "    main()",
        ])
        body = "\n".join(skeleton.distill_skeleton(src, "pack.py"))
        self.assertIn("imports: os, sys", body)
        self.assertIn("MAX_CELLS = …", body)
        self.assertIn("class Pack:", body)
        self.assertIn("def voltage(self) -> float:", body)
        self.assertIn("def main():", body)
        self.assertNotIn("return sum", body)

    def test_c(self):
        src = "\n".join([
            "#include <stdint.h>",
            "#define MAX_CELLS 96",
            "typedef struct { uint16_t mv; } cell_t;",
            "static uint32_t pack_voltage(const cell_t *cells, int n)",
            "{",
            "    if (n > MAX_CELLS) {",
            "        return 0;",
            "    }",
            "    return 42;",
            "}",
        ])
        body = "\n".join(skeleton.distill_skeleton(src, "pack.c"))
        self.assertIn("#include <stdint.h>", body)
        self.assertIn("pack_voltage", body)
        self.assertNotIn("return 42", body)
        self.assertNotIn("if (n > MAX_CELLS)", body)


class TestSlicer(unittest.TestCase):
    TEXT = "\n".join(f"line {i}" for i in range(1, 101))

    def test_pattern_with_context_and_gaps(self):
        body = slicer.distill_slice(self.TEXT, [r"line 50\b"], context=1)
        joined = "\n".join(body)
        self.assertIn("matches=1", body[0])
        self.assertIn("49|line49", joined.replace(" ", ""))
        self.assertIn("51|line51", joined.replace(" ", ""))
        self.assertIn("lines skipped", joined)
        self.assertNotIn("line 60", joined)

    def test_no_match(self):
        body = slicer.distill_slice(self.TEXT, ["nonexistent"])
        self.assertIn("nothing matched", "\n".join(body))

    def test_line_range(self):
        body = slicer.distill_slice(self.TEXT, [], line_range=(10, 12))
        joined = "\n".join(body)
        self.assertIn("line 10", joined)
        self.assertIn("line 12", joined)
        self.assertNotIn("line 13", joined)


class TestJson(unittest.TestCase):
    def test_object_schema(self):
        text = ('{"name": "pack", "cells": [{"mv": 3712, "t": 21.5},'
                ' {"mv": 3708}], "ok": true}')
        body = "\n".join(jsondata.distill_json(text))
        self.assertIn("root: object (3 keys)", body)
        self.assertIn("cells: array[2] of dict", body)
        self.assertIn("mv: int 3712", body)
        self.assertIn("t  (in 1/2): float 21.5", body)
        self.assertIn("ok: bool true", body)

    def test_jsonl_autodetect(self):
        text = '{"a": 1}\n{"a": 2, "b": "x"}\n{"a": 3}\n'
        body = "\n".join(jsondata.distill_json(text))
        self.assertIn("jsonl records=3", body)
        self.assertIn("b  (in 1/3)", body)


class TestCsv(unittest.TestCase):
    def test_stats(self):
        text = "id,voltage_mv,state\n1,3712,ok\n2,3708,ok\n3,,fault\n"
        body = "\n".join(tabular.distill_csv(text))
        self.assertIn("rows=3 cols=3", body)
        self.assertIn("[0] id: int distinct=3", body)
        self.assertIn("[1] voltage_mv: int distinct=2 empty=1", body)
        self.assertIn("[2] state: str distinct=2", body)


class TestDiff(unittest.TestCase):
    DIFF = "\n".join([
        "diff --git a/src/bms.c b/src/bms.c",
        "index 111..222 100644",
        "--- a/src/bms.c",
        "+++ b/src/bms.c",
        "@@ -10,7 +10,9 @@ static void can_init(void)",
        " context",
        "-old line",
        "+new line",
        "+another new line",
        "diff --git a/README.md b/README.md",
        "new file mode 100644",
        "--- /dev/null",
        "+++ b/README.md",
        "@@ -0,0 +1,2 @@",
        "+hello",
        "+world",
    ])

    def test_stats_and_hunks(self):
        body = "\n".join(diffs.distill_diff(self.DIFF))
        self.assertIn("files=2 +4 -1", body)
        self.assertIn("M src/bms.c  +2 -1  [@10 static void can_init(void)]", body)
        self.assertIn("A README.md  +2 -0", body)
        self.assertNotIn("another new line", body)

    def test_full_glob(self):
        body = "\n".join(diffs.distill_diff(self.DIFF, full_globs=["src/*"]))
        self.assertIn("another new line", body)
        self.assertNotIn("+hello", body)


class TestCleanIntegration(unittest.TestCase):
    """The merged toolkit: distill.py wrapping the sibling character cleaner."""

    def test_clean_subcommand(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "raw.txt")
            with open(path, "w", encoding="utf-8") as f:
                f.write("\x1b[31mERROR\x1b[0m: failed\n======\nvalue=42\n")
            out, err = io.StringIO(), io.StringIO()
            with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                rc = main(["clean", path])
            self.assertEqual(rc, 0)
            self.assertEqual(out.getvalue(), "ERROR: failed\nvalue=42\n")
            self.assertIn("# distill:clean", err.getvalue())  # header on stderr

    def test_build_with_clean_prepass(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "build.log")
            with open(path, "w", encoding="utf-8") as f:
                f.write("\x1b[1msrc/bms.c:42:5:\x1b[0m \x1b[31merror:\x1b[0m"
                        " 'cell_v' undeclared\n")
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                rc = main(["build", path, "--clean"])
            self.assertEqual(rc, 0)
            text = out.getvalue()
            self.assertIn("errors=1", text)
            self.assertIn("src/bms.c:42: 'cell_v' undeclared", text)
            # without --clean the ANSI codes hide the error from the parser
            out2 = io.StringIO()
            with contextlib.redirect_stdout(out2):
                main(["build", path])
            self.assertIn("errors=0", out2.getvalue())


class TestHook(unittest.TestCase):
    """The PreToolUse Read gate (distill_hook.decide), exercised headless."""

    def _payload(self, path, **extra):
        return {"tool_name": "Read", "tool_input": {"file_path": path, **extra}}

    def test_big_file_denied_small_file_allowed(self):
        import distill_hook
        with tempfile.TemporaryDirectory() as tmp:
            big = os.path.join(tmp, "big.txt")
            with open(big, "w", encoding="utf-8") as f:
                f.write("x" * 20_000)
            small = os.path.join(tmp, "small.txt")
            with open(small, "w", encoding="utf-8") as f:
                f.write("tiny")
            decision = distill_hook.decide(self._payload(big))
            self.assertEqual(
                decision["hookSpecificOutput"]["permissionDecision"], "deny")
            self.assertIn("distill.py auto",
                          decision["hookSpecificOutput"]["permissionDecisionReason"])
            self.assertIsNone(distill_hook.decide(self._payload(small)))

    def test_windowed_read_and_native_formats_allowed(self):
        import distill_hook
        with tempfile.TemporaryDirectory() as tmp:
            big = os.path.join(tmp, "big.c")
            with open(big, "w", encoding="utf-8") as f:
                f.write("y" * 20_000)
            self.assertIsNone(
                distill_hook.decide(self._payload(big, offset=100, limit=80)))
            self.assertIsNone(
                distill_hook.decide(self._payload(os.path.join(tmp, "scan.pdf"))))

    def test_output_folder_and_other_tools_allowed(self):
        import distill_hook
        with tempfile.TemporaryDirectory() as tmp:
            outdir = os.path.join(tmp, "output")
            os.makedirs(outdir)
            distilled = os.path.join(outdir, "bench.log.txt")
            with open(distilled, "w", encoding="utf-8") as f:
                f.write("z" * 20_000)
            self.assertIsNone(distill_hook.decide(self._payload(distilled)))
        self.assertIsNone(distill_hook.decide(
            {"tool_name": "Grep", "tool_input": {"pattern": "x"}}))


class TestMcpServer(unittest.TestCase):
    """The stdlib MCP server's request handler, exercised in-process."""

    def _rpc(self, method, params=None, rid=1):
        import distill_mcp
        return distill_mcp.handle_request(
            {"jsonrpc": "2.0", "id": rid, "method": method,
             "params": params or {}})

    def test_initialize_and_list(self):
        resp = self._rpc("initialize", {"protocolVersion": "2024-11-05"})
        self.assertEqual(resp["result"]["serverInfo"]["name"], "text-distiller")
        resp = self._rpc("tools/list")
        names = [t["name"] for t in resp["result"]["tools"]]
        self.assertEqual(names, ["search_repo", "find_files", "distill_text",
                                 "distill_file", "token_budget"])

    def test_call_find_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            with open(os.path.join(tmp, "a.c"), "w", encoding="utf-8") as f:
                f.write("int x;\n")
            with open(os.path.join(tmp, "b.py"), "w", encoding="utf-8") as f:
                f.write("x = 1\n")
            resp = self._rpc("tools/call", {
                "name": "find_files",
                "arguments": {"pattern": "*.c", "path": tmp}})
            text = resp["result"]["content"][0]["text"]
            self.assertIn("files-listed=1", text)
            self.assertIn("a.c", text)
            self.assertNotIn("b.py", text)

    def test_notification_gets_no_reply(self):
        import distill_mcp
        self.assertIsNone(distill_mcp.handle_request(
            {"jsonrpc": "2.0", "method": "notifications/initialized"}))

    def test_call_distill_text_auto(self):
        resp = self._rpc("tools/call", {
            "name": "distill_text",
            "arguments": {"text": "src/bms.c:42:5: error: 'x' undeclared\n"}})
        text = resp["result"]["content"][0]["text"]
        self.assertFalse(resp["result"]["isError"])
        self.assertIn("detected: build", text)
        self.assertIn("errors=1", text)

    def test_call_search_repo(self):
        with tempfile.TemporaryDirectory() as tmp:
            with open(os.path.join(tmp, "a.c"), "w", encoding="utf-8") as f:
                f.write("void can_init(void);\n")
            resp = self._rpc("tools/call", {
                "name": "search_repo",
                "arguments": {"pattern": "can_init", "path": tmp}})
            self.assertIn("files-matched=1",
                          resp["result"]["content"][0]["text"])

    def test_bad_tool_reports_in_band(self):
        resp = self._rpc("tools/call", {"name": "nope", "arguments": {}})
        self.assertTrue(resp["result"]["isError"])
        self.assertIn("unknown tool", resp["result"]["content"][0]["text"])


class TestBudgetAndCli(unittest.TestCase):
    def test_budget_and_cli_log(self):
        with tempfile.TemporaryDirectory() as tmp:
            os.makedirs(os.path.join(tmp, ".git"))  # stop ancestor .gitignore lookup
            log_path = os.path.join(tmp, "big.txt")
            with open(log_path, "w", encoding="utf-8") as f:
                for i in range(200):
                    f.write(f"2026-06-12 10:00:00 INFO heartbeat {i}\n")

            body = "\n".join(budget.distill_budget([tmp]))
            self.assertIn("big.txt", body)
            self.assertIn("total: 1 files", body)

            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                rc = main(["log", log_path, "--mask-numbers"])
            self.assertEqual(rc, 0)
            text = out.getvalue()
            self.assertIn("# distill:log", text)
            self.assertIn("saved 9", text)  # >= 90 % reduction
            self.assertIn("   200x", text)


class TestDetect(unittest.TestCase):
    def _kind(self, text, hint=""):
        return detect_kind(text, hint)[0]

    def test_content_detection(self):
        self.assertEqual(self._kind(TestDiff.DIFF), "diff")
        self.assertEqual(self._kind(TestTestreport.JUNIT), "test")
        self.assertEqual(self._kind(
            "FAILED tests/test_a.py::test_x - assert 1 == 2\n"
            "=== 1 failed, 3 passed in 0.1s ==="), "test")
        self.assertEqual(self._kind('{"a": 1, "b": [2, 3]}'), "json")
        self.assertEqual(self._kind('{"a": 1}\n{"a": 2}\n'), "json")
        self.assertEqual(self._kind(
            "src/bms.c:42:5: error: 'x' undeclared\n"), "build")
        self.assertEqual(self._kind(
            "id,voltage,state\n1,3712,ok\n2,3708,ok\n"), "csv")
        self.assertEqual(self._kind(
            "import os\nimport sys\ndef main():\n    pass\n"
            "class Foo:\n    pass\n"), "skeleton")
        self.assertEqual(self._kind(
            "2026-06-12 10:00:00 INFO boot\n"
            "2026-06-12 10:00:01 INFO ready\n"), "log")
        self.assertEqual(self._kind("just some plain words\nand more\n"), "log")

    def test_hint_wins(self):
        self.assertEqual(self._kind("anything", "data.json"), "json")
        kind, _, pseudo = detect_kind("anything", "module.c")
        self.assertEqual((kind, pseudo), ("skeleton", "module.c"))

    def test_python_code_gets_py_pseudo_name(self):
        kind, _, pseudo = detect_kind(
            "import os\ndef a():\n    pass\ndef b():\n    pass\n")
        self.assertEqual((kind, pseudo), ("skeleton", "input.py"))

    def test_cli_auto(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "out.txt")
            with open(path, "w", encoding="utf-8") as f:
                f.write("src/bms.c:42:5: error: 'x' undeclared\n")
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                rc = main(["auto", path])
            self.assertEqual(rc, 0)
            text = out.getvalue()
            self.assertIn("detected: build", text)
            self.assertIn("errors=1", text)

    def test_gui_run_auto(self):
        import distill_gui
        result = distill_gui.run_auto(
            "src/bms.c:42:5: error: 'x' undeclared\n", {"strip_ansi": True})
        self.assertIn("# auto-detected: build", result)
        self.assertIn("errors=1", result)


class TestSearch(unittest.TestCase):
    def _make_tree(self, tmp):
        os.makedirs(os.path.join(tmp, "src"))
        os.makedirs(os.path.join(tmp, ".git"))
        with open(os.path.join(tmp, "src", "a.c"), "w", encoding="utf-8") as f:
            f.write("void can_init(void) {}\n/* can_init is called at boot */\n")
        with open(os.path.join(tmp, "src", "b.h"), "w", encoding="utf-8") as f:
            f.write("extern void can_init(void);\n")
        with open(os.path.join(tmp, "notes.md"), "w", encoding="utf-8") as f:
            f.write("unrelated text\n")
        with open(os.path.join(tmp, ".git", "config"), "w", encoding="utf-8") as f:
            f.write("can_init mentioned in git internals\n")
        with open(os.path.join(tmp, "blob.bin"), "wb") as f:
            f.write(b"can_init\0binary")

    def test_finds_files_excludes_git_and_binary(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._make_tree(tmp)
            body = search.distill_search("can_init", [tmp])
            joined = "\n".join(body)
            self.assertIn("files-matched=2 matches=3", body[0])
            self.assertIn("a.c (2 matches)", joined)
            self.assertIn("b.h (1 matches)", joined)
            self.assertNotIn(".git", joined)
            self.assertNotIn("blob.bin", joined)

    def test_files_only_with_glob(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._make_tree(tmp)
            body = search.distill_search("can_init", [tmp], globs=["*.h"],
                                         files_only=True)
            joined = "\n".join(body)
            self.assertIn("files-matched=1", body[0])
            self.assertIn("    1x", joined)
            self.assertNotIn("a.c", joined)

    def test_word_boundary(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._make_tree(tmp)
            body = search.distill_search("can", [tmp], word=True)
            self.assertIn("matches=0", body[0])  # can_init is not the word "can"

    def test_cli_search(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._make_tree(tmp)
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                rc = main(["search", "can_init", tmp, "-l"])
            self.assertEqual(rc, 0)
            text = out.getvalue()
            self.assertTrue(text.startswith("files-scanned="))  # no header line
            self.assertIn("b.h", text)

    def test_fixed_strings_and_type_filter(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._make_tree(tmp)
            with open(os.path.join(tmp, "src", "c.py"), "w", encoding="utf-8") as f:
                f.write("x = a[0] + can_init()\n")
            body = search.distill_search("a[0]", [tmp], fixed=True)
            self.assertIn("files-matched=1 matches=1", body[0])
            body = search.distill_search("a[0]", [tmp])
            self.assertIn("matches=0", body[0])  # as a regex, [0] is a class
            body = search.distill_search("can_init", [tmp], types=["py"], files_only=True)
            self.assertIn("files-matched=1", body[0])
            self.assertIn("c.py", "\n".join(body))
            with self.assertRaises(ValueError):
                search.distill_search("x", [tmp], types=["nope"])

    def test_gitignore_honoured_unless_no_ignore(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._make_tree(tmp)
            os.makedirs(os.path.join(tmp, "build", "obj"))
            with open(os.path.join(tmp, ".gitignore"), "w", encoding="utf-8") as f:
                f.write("# comment\nbuild/\n*.map\n/top.log\n")
            with open(os.path.join(tmp, "build", "obj", "x.c"), "w", encoding="utf-8") as f:
                f.write("can_init in build tree\n")
            with open(os.path.join(tmp, "src", "sc.map"), "w", encoding="utf-8") as f:
                f.write("can_init symbol\n")
            with open(os.path.join(tmp, "top.log"), "w", encoding="utf-8") as f:
                f.write("can_init log\n")
            with open(os.path.join(tmp, "src", "top.log"), "w", encoding="utf-8") as f:
                f.write("can_init nested log\n")
            joined = "\n".join(search.distill_search("can_init", [tmp], files_only=True))
            self.assertNotIn("build", joined)
            self.assertNotIn("sc.map", joined)
            self.assertNotIn(f"{tmp}\\top.log", joined.replace("/", "\\"))
            self.assertIn("nested log", "\n".join(search.distill_search("nested", [tmp])))
            joined = "\n".join(search.distill_search("can_init", [tmp],
                                                     files_only=True, no_ignore=True))
            self.assertIn("x.c", joined)
            self.assertIn("sc.map", joined)

    def test_binary_ext_skipped_without_open_and_sort_count(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._make_tree(tmp)
            with open(os.path.join(tmp, "src", "lib.o"), "w", encoding="utf-8") as f:
                f.write("can_init can_init can_init\n")
            body = search.distill_search("can_init", [tmp], files_only=True, sort="count")
            self.assertNotIn("lib.o", "\n".join(body))
            self.assertIn("a.c", body[1])  # 2 matches sorts before b.h with 1

    def test_non_ascii_pattern_and_exclude(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._make_tree(tmp)
            with open(os.path.join(tmp, "src", "u.md"), "w", encoding="utf-8") as f:
                f.write("Größe des Packs\n")
            body = search.distill_search("Größe", [tmp])
            self.assertIn("files-matched=1 matches=1", body[0])
            body = search.distill_search("can_init", [tmp], excludes=["src"])
            self.assertIn("matches=0", body[0])

    def test_deterministic_across_runs(self):
        with tempfile.TemporaryDirectory() as tmp:
            for i in range(40):
                with open(os.path.join(tmp, f"f{i:02d}.c"), "w", encoding="utf-8") as f:
                    f.write(f"void fn{i}(void); /* can_init ref {i} */\n")
            a = search.distill_search("can_init", [tmp])
            b = search.distill_search("can_init", [tmp])
            self.assertEqual(a, b)
            self.assertIn("files-matched=40", a[0])


class TestFind(unittest.TestCase):
    def _tree(self, tmp):
        os.makedirs(os.path.join(tmp, "src", "bsw"))
        os.makedirs(os.path.join(tmp, "build"))
        os.makedirs(os.path.join(tmp, ".git"))  # stop ancestor .gitignore lookup
        for rel in ("src/a.c", "src/a.h", "src/bsw/b.c", "src/bsw/CMakeLists.txt",
                    "build/gen.c", "README.md"):
            p = os.path.join(tmp, *rel.split("/"))
            with open(p, "w", encoding="utf-8") as f:
                f.write("x\n")
        with open(os.path.join(tmp, ".gitignore"), "w", encoding="utf-8") as f:
            f.write("build/\n")

    def test_basename_glob_and_types(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._tree(tmp)
            body = search.distill_find(["*.c"], [tmp])
            joined = "\n".join(body)
            self.assertIn("files-listed=2", body[0])
            self.assertIn("a.c", joined)
            self.assertIn("b.c", joined)
            self.assertNotIn("gen.c", joined)  # build/ ignored
            body = search.distill_find([], [tmp], types=["cmake"])
            self.assertIn("files-listed=1", body[0])
            self.assertIn("CMakeLists.txt", "\n".join(body))

    def test_path_glob_and_no_ignore(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._tree(tmp)
            body = search.distill_find(["src/bsw/*.c"], [tmp])
            self.assertIn("files-listed=1", body[0])
            self.assertIn("b.c", "\n".join(body))
            body = search.distill_find(["*.c"], [tmp], no_ignore=True)
            self.assertIn("files-listed=3", body[0])

    def test_everything_and_no_match(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._tree(tmp)
            body = search.distill_find([], [tmp])
            self.assertIn("files-listed=6", body[0])  # .gitignore itself + 5 files
            body = search.distill_find(["*.zzz"], [tmp])
            self.assertIn("files-listed=0", body[0])
            self.assertIn("no files matched", body[1])

    def test_cli_find(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._tree(tmp)
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                rc = main(["find", "*.h", "-p", tmp, "--no-sizes"])
            self.assertEqual(rc, 0)
            text = out.getvalue()
            self.assertTrue(text.startswith("files-listed=1"))
            self.assertIn("a.h", text)
            self.assertNotIn("# distill", text)


class TestFileOutput(unittest.TestCase):
    def test_output_flag(self):
        with tempfile.TemporaryDirectory() as tmp:
            src = os.path.join(tmp, "build.log")
            with open(src, "w", encoding="utf-8") as f:
                f.write("src/bms.c:42:5: error: 'cell_v' undeclared\n")
            dst = os.path.join(tmp, "result.txt")
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                rc = main(["build", src, "-o", dst])
            self.assertEqual(rc, 0)
            with open(dst, encoding="utf-8") as f:
                self.assertIn("errors=1", f.read())
            self.assertIn("# distill:build", out.getvalue())
            self.assertIn("wrote:", out.getvalue())

    def test_save_flag_creates_output_subfolder(self):
        cwd = os.getcwd()
        with tempfile.TemporaryDirectory() as tmp:
            try:
                os.chdir(tmp)
                with open("bench.log", "w", encoding="utf-8") as f:
                    f.write("ERROR x\nERROR x\n")
                out = io.StringIO()
                with contextlib.redirect_stdout(out):
                    rc = main(["log", "bench.log", "--save"])
                self.assertEqual(rc, 0)
                expected = os.path.join("output", "bench.log.txt")
                self.assertTrue(os.path.isfile(expected))
                with open(expected, encoding="utf-8") as f:
                    self.assertIn("2x", f.read())
            finally:
                os.chdir(cwd)


class TestGuiCore(unittest.TestCase):
    """GUI logic without tkinter: run_distill/compose_argv are headless."""

    def test_compose_argv(self):
        import distill_gui
        self.assertEqual(
            distill_gui.compose_argv("log", "--level error", "in.txt"),
            ["log", "--level", "error", "in.txt"])

    def test_run_distill_pasted_text(self):
        import distill_gui
        result = distill_gui.run_distill("log", "", "ERROR x\nERROR x\n")
        self.assertIn("# distill:log", result)
        self.assertIn("2x", result)

    def test_run_distill_skeleton_uses_hint(self):
        import distill_gui
        result = distill_gui.run_distill(
            "skeleton", "", "def main():\n    pass\n", filename_hint="foo.py")
        self.assertIn("def main():", result)

    def test_run_distill_bad_options_reports_usage(self):
        import distill_gui
        result = distill_gui.run_distill("log", "--no-such-flag", "x\n")
        self.assertIn("usage:", result)

    def test_build_distill_flags_gated_by_command(self):
        import distill_gui
        checks = {"errors_only": True, "mask_numbers": True,
                  "sort_count": False, "strip_ansi": True}
        self.assertEqual(
            distill_gui.build_distill_flags("log", checks),
            ["--level", "error", "--mask-numbers", "--clean"])
        # build does not support log-only flags; must not produce them
        self.assertEqual(distill_gui.build_distill_flags("build", checks),
                         ["--clean"])
        # json supports none of the checkboxes
        self.assertEqual(distill_gui.build_distill_flags("json", checks), [])

    def test_build_search_argv(self):
        import distill_gui
        argv = distill_gui.build_search_argv(
            "can_init", "src",
            {"ignore_case": True, "word": True, "files_only": True,
             "search_all": False},
            file_filter="*.c;*.h", context=2)
        self.assertEqual(argv, ["search", "can_init", "src", "-i", "-w", "-l",
                                "-g", "*.c", "-g", "*.h", "-C", "2"])

    def test_run_search(self):
        import distill_gui
        with tempfile.TemporaryDirectory() as tmp:
            with open(os.path.join(tmp, "a.c"), "w", encoding="utf-8") as f:
                f.write("void can_init(void);\n")
            result = distill_gui.run_search("can_init", tmp,
                                            {"files_only": True})
            self.assertIn("files-matched=1", result)
            self.assertIn("a.c", result)


# ---------------------------------------------------------------------------
# S-AUD-07 correctness probes (pytest style, hermetic tmp_path fixtures)

def _repo(tmp_path, name="repo"):
    root = tmp_path / name
    (root / ".git").mkdir(parents=True)
    return root


def _write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, bytes):
        path.write_bytes(data)
    else:
        path.write_text(data, encoding="utf-8", newline="")


def _make_dir_link(link, target):
    """Junction first on Windows (os.walk follows those), else a symlink."""
    if os.name == "nt":
        try:
            import _winapi
            _winapi.CreateJunction(str(target), str(link))
            return True
        except (ImportError, AttributeError, OSError):
            pass
    try:
        os.symlink(target, link, target_is_directory=True)
        return True
    except (OSError, NotImplementedError, AttributeError):
        return False


def test_anchored_regex_matches_lf_and_crlf(tmp_path):
    root = _repo(tmp_path)
    src = "def a():\n    def inner():\n        pass\nx = 'def '\ndef b():  # end\n"
    _write(root / "lf.py", src)
    _write(root / "crlf.py", src.replace("\n", "\r\n"))
    assert (root / "crlf.py").read_bytes().count(b"\r\n") == 5
    body = search.distill_search("^def ", [str(root)], files_only=True)
    assert "files-matched=2 matches=4 " in body[0]
    body = search.distill_search("def ", [str(root)], files_only=True)
    assert "files-matched=2 matches=8 " in body[0]
    assert "files-matched=2 matches=2 " in search.distill_search("end$", [str(root)])[0]
    assert "files-matched=2 matches=2 " in search.distill_search(r"^\s*pass$", [str(root)])[0]
    body = search.distill_search(r"\Adef b\(\):  # end\Z", [str(root)])
    assert "files-matched=2 matches=2 " in body[0]  # \A/\Z skip the prescan, anchor per line
    assert search._prescan_source(r"a$[$]\$") == r"a(?=\r?$)[$]\$"
    assert search._prescan_source(r"\Afoo") is None


def test_ancestor_gitignore_and_info_exclude_apply_below_root(tmp_path):
    root = _repo(tmp_path)
    _write(root / ".gitignore", "sub/work/\n*.tmp\n")
    _write(root / ".git" / "info" / "exclude", "secret.txt\n")
    for rel in ("sub/keep.yaml", "sub/work/gen.yaml", "sub/scratch.tmp", "sub/secret.txt"):
        _write(root / rel, "needle\n")
    sub = str(root / "sub")
    listed = "\n".join(search.distill_find([], [sub]))
    assert "files-listed=1 " in listed and "keep.yaml" in listed
    found = "\n".join(search.distill_search("needle", [sub], files_only=True))
    assert "files-matched=1 " in found and "keep.yaml" in found
    budgeted = "\n".join(budget.distill_budget([sub]))
    assert "total: 1 files" in budgeted and "gen.yaml" not in budgeted
    assert "files-listed=4 " in search.distill_find([], [sub], no_ignore=True)[0]
    assert "total: 4 files" in "\n".join(budget.distill_budget([sub], no_ignore=True))


def test_gitignore_negation_double_star_and_nested_base(tmp_path):
    root = _repo(tmp_path)
    _write(root / ".gitignore", "*.log\n!keep.log\n**/gen/**\ndocs/**/*.bak\n")
    _write(root / "pkg" / ".gitignore", "/only_here.txt\nlib/tmp.txt\n")
    for rel in ("a.log", "deep/keep.log", "deep/gen/out.c", "docs/a/b/old.bak",
                "other/old.bak", "pkg/only_here.txt", "pkg/nested/only_here.txt",
                "pkg/lib/tmp.txt", "lib/tmp.txt"):
        _write(root / rel, "x\n")
    names = {p.relative_to(root).as_posix() for p in search.iter_files([str(root)])}
    assert names == {".gitignore", "deep/keep.log", "other/old.bak", "pkg/.gitignore",
                     "pkg/nested/only_here.txt", "lib/tmp.txt"}


def test_directory_loop_lists_each_file_once(tmp_path):
    root = _repo(tmp_path)
    _write(root / "a" / "f.txt", "needle\n")
    if not _make_dir_link(root / "a" / "loop", root):
        pytest.skip("cannot create a junction or symlink here")
    files = search.iter_files([str(root)])
    assert [p.name for p in files] == ["f.txt"]
    assert "files-matched=1 matches=1 " in search.distill_search("needle", [str(root)])[0]
    assert "files-listed=1 " in search.distill_find([], [str(root)])[0]


def test_invalid_regex_exits_2_with_one_line(tmp_path, capsys):
    root = _repo(tmp_path)
    _write(root / "a.txt", "x\n")
    for argv in (["search", "foo(", str(root)], ["slice", str(root / "a.txt"), "-p", "[x"]):
        assert main(argv) == 2
        out, err = capsys.readouterr()
        assert out == ""
        assert err.startswith("error: invalid regex: ") and err.count("\n") == 1


def test_missing_root_exits_2_with_one_line(tmp_path, capsys):
    missing = str(tmp_path / "nope")
    for argv in (["search", "x", missing], ["find", "*.c", "-p", missing],
                 ["budget", missing], ["skeleton", missing], ["slice", missing, "-p", "x"]):
        assert main(argv) == 2
        out, err = capsys.readouterr()
        assert (out, err) == ("", f"error: no such path: {missing}\n")


def test_mcp_and_hook_report_errors_in_band(tmp_path, monkeypatch, capsys):
    import distill_hook
    import distill_mcp

    def call(name, arguments):
        resp = distill_mcp.handle_request({"jsonrpc": "2.0", "id": 1, "method": "tools/call",
                                           "params": {"name": name, "arguments": arguments}})
        return resp["result"]["isError"], resp["result"]["content"][0]["text"]

    is_err, text = call("search_repo", {"pattern": "foo(", "path": str(tmp_path)})
    assert is_err and text.startswith("error: invalid regex: ") and "\n" not in text
    missing = str(tmp_path / "nope")
    assert call("find_files", {"pattern": "*.c", "path": missing}) == \
        (True, f"error: no such path: {missing}")
    assert call("distill_file", {"path": missing}) == (True, f"error: no such path: {missing}")
    monkeypatch.setattr(sys, "stdin", io.StringIO('{"tool_name": "Read", "tool_input": "x"}'))
    assert distill_hook.main() == 0
    msg = json.loads(capsys.readouterr().out)["systemMessage"]
    assert msg.startswith("error: distill_hook: ") and "\n" not in msg


def test_utf16_with_bom_is_decoded_and_binaries_counted(tmp_path):
    root = _repo(tmp_path)
    _write(root / "le.txt", codecs.BOM_UTF16_LE + "first\r\nneedle here\r\n".encode("utf-16-le"))
    _write(root / "be.txt", codecs.BOM_UTF16_BE + "needle\n".encode("utf-16-be"))
    _write(root / "blob.raw", b"needle\0\0binary")
    body = search.distill_search("^needle", [str(root)])
    assert "files-matched=2 matches=2 binaries-skipped=1" in body[0]
    assert "needle here" in "\n".join(body)
    report = "\n".join(budget.distill_budget([str(root)]))
    assert "binaries-skipped=1" in report and "total: 3 files" in report
    assert core.read_text(str(root / "le.txt")) == "first\r\nneedle here\r\n"


def test_utf8_bom_stripped_from_line_one(tmp_path, capsys):
    root = _repo(tmp_path)
    path = root / "bom.py"
    _write(path, codecs.BOM_UTF8 + b"def first():\n    pass\n")
    body = "\n".join(search.distill_search("^def first", [str(root)]))
    assert "files-matched=1 matches=1 " in body
    assert "1: def first():" in body and chr(0xFEFF) not in body
    assert main(["skeleton", str(path)]) == 0
    out = capsys.readouterr().out
    assert "    1: def first():" in out and "parse failed" not in out


def test_markdown_and_shell_skeleton():
    md = ("# Title\n\nintro\n## Section A\n```\n# not a heading\n```\n"
          "### Deep ###\n#hashtag\n")
    assert skeleton.distill_skeleton(md, "notes.md") == [
        "    1: # Title", "    4:   ## Section A", "    8:     ### Deep"]
    sh = ("#!/usr/bin/env bash\n# helper() { commented }\nhelper() {\n  echo hi\n}\n"
          "function deploy {\n  helper\n}\nfunction cleanup() {\n  :\n}\nmain \"$@\"\n")
    expected = ["    3: helper() {", "    6: function deploy {", "    9: function cleanup() {"]
    assert skeleton.distill_skeleton(sh, "run.sh") == expected
    assert skeleton.distill_skeleton(sh, "run") == expected  # shebang detection


def test_truncation_persists_full_output(tmp_path, monkeypatch, capsys):
    root = _repo(tmp_path)
    for i in range(60):
        _write(root / f"f{i:02d}.txt", "needle\n")
    out_dir = tmp_path / "persist"
    monkeypatch.setenv("DISTILL_OUT", str(out_dir))
    argv = ["search", "needle", str(root), "-l", "--max-tokens", "80"]
    assert main(argv) == 0
    text = capsys.readouterr().out
    saved = out_dir / (hashlib.sha1("\0".join(argv).encode()).hexdigest()[:12] + ".txt")
    assert f"Full output: {saved}." in text
    full = saved.read_text(encoding="utf-8").splitlines()
    assert len(full) == 61 and full[0].startswith("files-scanned=60 ")
    saved.unlink()
    assert main(argv + ["--no-persist"]) == 0
    text = capsys.readouterr().out
    assert "[truncated at ~80 tokens" in text and "Full output" not in text
    assert list(out_dir.iterdir()) == []


def test_path_glob_star_stays_in_one_directory(tmp_path):
    root = _repo(tmp_path)
    for rel in ("src/a.c", "src/bsw/b.c", "src/bsw/deep/c.c"):
        _write(root / rel, "needle\n")

    def listed(pattern):
        return search.distill_find([pattern], [str(root)])[0]

    assert "files-listed=1 " in listed("src/*.c")
    assert "files-listed=1 " in listed("src\\*.c")  # backslashes normalised
    assert "files-listed=1 " in listed("src/*/*.c")
    assert "files-listed=3 " in listed("src/**/*.c")
    assert "files-listed=2 " in listed("bsw/**")
    body = search.distill_search("needle", [str(root)], globs=["src/*.c"], files_only=True)
    assert "files-matched=1 " in body[0]


def test_search_clips_long_lines(tmp_path):
    root = tmp_path / "clip"
    root.mkdir()
    (root / "big.txt").write_text("head tag " + "x" * 5000 + " needle tail\n",
                                  encoding="utf-8")
    body = "\n".join(search.distill_search("needle", [str(root)]))
    assert "chars]" in body and "clipped to 240 chars" in body
    assert max(len(line) for line in body.splitlines()) < 400
    whole = "\n".join(search.distill_search("needle", [str(root)], max_line_chars=0))
    assert "x" * 5000 in whole


def test_search_clip_keeps_head_and_match(tmp_path):
    root = tmp_path / "cliphead"
    root.mkdir()
    (root / "a.txt").write_text("2026-01-01 [DEBUG] tag " + "y" * 4000 + " needle\n",
                                encoding="utf-8")
    hit = [ln for ln in search.distill_search("needle", [str(root)]) if "needle" in ln][0]
    assert "2026-01-01 [DEBUG] tag" in hit


def test_search_tail_shows_last_matches(tmp_path):
    root = tmp_path / "tailmode"
    root.mkdir()
    (root / "a.txt").write_text("".join(f"needle {i}\n" for i in range(20)),
                                encoding="utf-8")
    first = "\n".join(search.distill_search("needle", [str(root)], max_per_file=3))
    last = "\n".join(search.distill_search("needle", [str(root)], max_per_file=3,
                                           tail=True))
    assert "needle 0" in first and "needle 19" not in first
    assert "needle 19" in last and "needle 0" not in last
    assert "earlier matches" in last


if __name__ == "__main__":
    unittest.main()

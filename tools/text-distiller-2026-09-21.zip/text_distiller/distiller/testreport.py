"""Compress test output (JUnit XML, pytest text, CTest text) to failures only."""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET

_PYTEST_FAILED = re.compile(r"^(FAILED|ERROR)\s+\S+")
_PYTEST_ASSERT = re.compile(r"^E\s{1,3}\S")
_PYTEST_SUMMARY = re.compile(
    r"^=+\s.*\b(passed|failed|error|skipped|deselected|no tests ran)\b.*=+\s*$"
)
_CTEST_FAILED = re.compile(r"^\s*\d+\s*-\s*\S+\s*\((?:Failed|Timeout|.*Exception.*)\)\s*$")
_CTEST_SUMMARY = re.compile(r"^\d+% tests passed")


def distill_testreport(text: str, max_failure_lines: int = 3) -> list[str]:
    stripped = text.lstrip()
    if stripped.startswith("<"):
        return _from_junit(text, max_failure_lines)
    return _from_text(text)


def _from_junit(text: str, max_failure_lines: int) -> list[str]:
    root = ET.fromstring(text)
    suites = [root] if root.tag == "testsuite" else list(root.iter("testsuite"))

    total = failed = errored = skipped = 0
    failures: list[str] = []
    for suite in suites:
        for case in suite.iter("testcase"):
            total += 1
            for kind in ("failure", "error", "skipped"):
                node = case.find(kind)
                if node is None:
                    continue
                if kind == "skipped":
                    skipped += 1
                    break
                if kind == "failure":
                    failed += 1
                else:
                    errored += 1
                name = f"{case.get('classname', '?')}::{case.get('name', '?')}"
                message = (node.get("message") or "").splitlines()
                first = message[0].strip() if message else ""
                failures.append(f"  {kind.upper()} {name}" + (f" -- {first}" if first else ""))
                detail = (node.text or "").strip().splitlines()
                for line in [d.strip() for d in detail if d.strip()][:max_failure_lines]:
                    failures.append(f"      {line}")
                break

    passed = total - failed - errored - skipped
    body = [f"tests={total} passed={passed} failed={failed} errors={errored} skipped={skipped}"]
    if failures:
        body.extend(failures)
    else:
        body.append("(all tests passed)")
    return body


def _from_text(text: str) -> list[str]:
    lines = text.splitlines()
    failed_lines: list[str] = []
    assert_lines: list[str] = []
    seen_asserts: set[str] = set()
    summary: list[str] = []

    for raw in lines:
        line = raw.rstrip()
        s = line.strip()
        if _PYTEST_FAILED.match(s) or _CTEST_FAILED.match(line):
            failed_lines.append(f"  {s}")
        elif _PYTEST_ASSERT.match(s):
            if s not in seen_asserts and len(assert_lines) < 20:
                seen_asserts.add(s)
                assert_lines.append(f"  {s}")
        elif _PYTEST_SUMMARY.match(s) or _CTEST_SUMMARY.match(s):
            summary.append(s.strip("= "))

    body: list[str] = []
    if summary:
        body.append("summary: " + "; ".join(dict.fromkeys(summary)))
    if failed_lines:
        body.append("failed:")
        body.extend(dict.fromkeys(failed_lines))
    if assert_lines:
        body.append("assertions:")
        body.extend(assert_lines)
    if not body:
        body.append("(no failures or recognised summary found in the output)")
    return body

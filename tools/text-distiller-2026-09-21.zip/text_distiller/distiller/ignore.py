"""Gitignore matching shared by the tree walkers (search, find, budget).

Semantics follow git: rules load from the walk root UPWARD to the nearest
directory holding `.git` (or the filesystem root), plus `.git/info/exclude`;
deeper files override shallower ones and the last matching line wins; `!`
negates; a trailing `/` matches directories only; a pattern with a `/` at the
start or middle is relative to the directory of its .gitignore, otherwise it
matches the basename at any depth; `*` and `?` stop at `/`, `**` crosses
directories. Entering a nested repository (a subdirectory holding `.git`)
starts a fresh rule stack, mirroring the upward stop. Matching is
case-insensitive on Windows (git's core.ignorecase default there).

Path globs for find/--glob use the same translation (`glob_regex`).
"""

from __future__ import annotations

import os
import re

NOCASE = os.name == "nt"
_FLAGS = re.IGNORECASE if NOCASE else 0


def translate(pat: str, escapes: bool = True) -> str:
    """Glob -> regex source: `*`/`?` stay inside one path segment, `**` spans segments."""
    out: list[str] = []
    i, n = 0, len(pat)
    while i < n:
        c = pat[i]
        if c == "*":
            j = i
            while j < n and pat[j] == "*":
                j += 1
            at_seg_start = i == 0 or pat[i - 1] == "/"
            at_seg_end = j == n or pat[j] == "/"
            if j - i >= 2 and at_seg_start and at_seg_end:
                if j == n:
                    out.append(".*")
                else:
                    out.append("(?:.*/)?")
                    j += 1  # the slash is part of the zero-or-more-dirs group
            else:
                out.append("[^/]*")
            i = j
            continue
        if c == "?":
            out.append("[^/]")
        elif c == "[":
            j = i + 1
            if j < n and pat[j] in "!^":
                j += 1
            if j < n and pat[j] == "]":
                j += 1
            while j < n and pat[j] != "]":
                j += 1
            if j >= n:
                out.append(re.escape(c))
            else:
                body = pat[i + 1:j]
                if body.startswith("!"):
                    body = "^" + body[1:]
                out.append("[" + body.replace("\\", "\\\\") + "]")
                i = j + 1
                continue
        elif c == "\\" and escapes and i + 1 < n:
            out.append(re.escape(pat[i + 1]))
            i += 2
            continue
        else:
            out.append(re.escape(c))
        i += 1
    return "".join(out)


def glob_regex(pattern: str) -> tuple[re.Pattern[str], bool]:
    """Compile a find/--glob pattern; returns (regex, matches_full_path)."""
    pattern = pattern.replace("\\", "/")
    if "/" in pattern:
        src = "(?:.*/)?" + translate(pattern.lstrip("/"), escapes=False)
        return re.compile(src + r"\Z", _FLAGS), True
    return re.compile(translate(pattern, escapes=False) + r"\Z", _FLAGS), False


def glob_match(compiled: list[tuple[re.Pattern[str], bool]], name: str, posix_path: str) -> bool:
    return any(rx.match(posix_path if full else name) for rx, full in compiled)


# ---------------------------------------------------------------------------
# rule files

class _Segment:
    """Consecutive rules sharing one verdict; order inside a segment is irrelevant."""
    __slots__ = ("negate", "name_any", "name_dir", "path_any", "path_dir")

    def __init__(self, negate: bool, groups: dict[tuple[bool, bool], list[str]]):
        self.negate = negate

        def comb(key):
            srcs = groups.get(key)
            if not srcs:
                return None
            return re.compile("(?:" + "|".join(f"(?:{s})" for s in srcs) + r")\Z", _FLAGS)

        self.name_any = comb((False, False))
        self.name_dir = comb((False, True))
        self.path_any = comb((True, False))
        self.path_dir = comb((True, True))


def parse_rules(lines: list[str]) -> list[_Segment]:
    segments: list[_Segment] = []
    cur_negate: bool | None = None
    groups: dict[tuple[bool, bool], list[str]] = {}
    for line in lines:
        if not line or line.startswith("#"):
            continue
        s = line.rstrip(" ")
        if s.endswith("\\") and len(s) < len(line):
            s += " "  # "\ " keeps one escaped trailing space
        negate = s.startswith("!")
        if negate:
            s = s[1:]
        dir_only = s.endswith("/")
        s = s.rstrip("/")
        if not s:
            continue
        is_path = "/" in s
        if is_path:
            s = s.lstrip("/")
            if not s:
                continue
        try:
            src = translate(s)
            re.compile(src)
        except re.error:
            continue  # git skips malformed patterns too
        if negate != cur_negate and groups:
            segments.append(_Segment(bool(cur_negate), groups))
            groups = {}
        cur_negate = negate
        groups.setdefault((is_path, dir_only), []).append(src)
    if groups:
        segments.append(_Segment(bool(cur_negate), groups))
    return segments


def _read_rules(path: str) -> list[_Segment]:
    try:
        with open(path, encoding="utf-8-sig", errors="replace") as fh:
            return parse_rules(fh.read().splitlines())
    except OSError:
        return []


def _git_dir(top: str) -> str | None:
    dotgit = os.path.join(top, ".git")
    if os.path.isdir(dotgit):
        return dotgit
    try:
        with open(dotgit, encoding="utf-8", errors="replace") as fh:
            first = fh.readline().strip()
    except OSError:
        return None
    if first.startswith("gitdir:"):
        target = first[len("gitdir:"):].strip()
        return os.path.normpath(os.path.join(top, target))
    return None


class IgnoreStack:
    """Rule files in precedence order (lowest first), each with a posix base relative to top."""
    __slots__ = ("layers",)

    def __init__(self, layers: tuple[tuple[str, list[_Segment]], ...] = ()):
        self.layers = layers

    @classmethod
    def for_root(cls, root: str) -> tuple["IgnoreStack", str]:
        """Load exclude + .gitignore files from the repo top down to root; returns (stack, root_rel)."""
        root_abs = os.path.abspath(root)
        chain = [root_abs]
        d = root_abs
        while not os.path.exists(os.path.join(d, ".git")):
            parent = os.path.dirname(d)
            if parent == d:
                break
            d = parent
            chain.append(d)
        top = d
        layers: list[tuple[str, list[_Segment]]] = []
        gd = _git_dir(top)
        if gd:
            segs = _read_rules(os.path.join(gd, "info", "exclude"))
            if segs:
                layers.append(("", segs))
        for directory in reversed(chain):
            segs = _read_rules(os.path.join(directory, ".gitignore"))
            if segs:
                layers.append((_rel(directory, top), segs))
        return cls(tuple(layers)), _rel(root_abs, top)

    def child(self, directory: str, rel: str) -> "IgnoreStack":
        segs = _read_rules(os.path.join(directory, ".gitignore"))
        if not segs:
            return self
        return IgnoreStack(self.layers + ((rel, segs),))

    def ignored(self, rel: str, name: str, is_dir: bool) -> bool:
        """rel is the entry's posix path relative to the repo top."""
        for base, segments in reversed(self.layers):
            sub = rel[len(base) + 1:] if base else rel
            for seg in reversed(segments):
                if (seg.name_any is not None and seg.name_any.match(name)) or \
                        (is_dir and seg.name_dir is not None and seg.name_dir.match(name)) or \
                        (seg.path_any is not None and seg.path_any.match(sub)) or \
                        (is_dir and seg.path_dir is not None and seg.path_dir.match(sub)):
                    return not seg.negate
        return False


def _rel(path: str, top: str) -> str:
    rel = os.path.relpath(path, top).replace("\\", "/")
    return "" if rel == "." else rel

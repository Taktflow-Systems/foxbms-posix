"""Collapse repetitive log files into unique patterns with counts.

Lines are grouped after masking volatile fields (timestamps, hex, UUIDs,
optionally all numbers), so 10 000 retries become one line with `10000x`.
"""

from __future__ import annotations

import re

from .core import mask_line

_LEVEL_RES = {
    "error": re.compile(
        r"\b(error|err|fatal|fail(?:ed|ure)?|exception|critical|panic|assert)\b",
        re.IGNORECASE,
    ),
    "warn": re.compile(
        r"\b(error|err|fatal|fail(?:ed|ure)?|exception|critical|panic|assert"
        r"|warn(?:ing)?)\b",
        re.IGNORECASE,
    ),
}


def distill_log(
    text: str,
    level: str | None = None,
    mask_numbers: bool = False,
    min_count: int = 1,
    sort_by_count: bool = False,
) -> list[str]:
    lines = text.splitlines()
    sev = _LEVEL_RES[level] if level else None

    entries: dict[str, list] = {}  # masked -> [count, first_lineno, first_raw]
    order: list[str] = []
    kept = 0
    for lineno, raw in enumerate(lines, 1):
        stripped = raw.strip()
        if not stripped:
            continue
        if sev and not sev.search(stripped):
            continue
        kept += 1
        key = mask_line(stripped, mask_numbers)
        entry = entries.get(key)
        if entry is None:
            entries[key] = [1, lineno, stripped]
            order.append(key)
        else:
            entry[0] += 1

    if sort_by_count:
        order.sort(key=lambda k: -entries[k][0])  # stable: ties keep order

    body = [
        f"lines={len(lines)} matched={kept} unique-patterns={len(order)}"
        + (f" level>={level}" if level else "")
    ]
    shown = 0
    for key in order:
        count, first, raw = entries[key]
        if count < min_count:
            continue
        shown += 1
        # collapsed groups show the masked pattern; singletons show raw text
        display = key if count > 1 else raw
        body.append(f"{count:>6}x  L{first:<7d} {display}")
    if shown == 0:
        body.append("(no lines matched)")
    return body

"""Deterministic content sniffer: what kind of text is this?

Used by `distill.py auto` and the GUI's Auto-detect mode. Pure heuristics,
ordered from most to least specific; same input always classifies the same.
Never returns "clean" (payload-style output doesn't mix with auto's report);
generic text falls back to "log", whose dedupe is the safe default.
"""

from __future__ import annotations

import json as _json
import os
import re

from . import build as _build

_EXT_MAP = {
    ".json": "json", ".jsonl": "json", ".csv": "csv", ".tsv": "csv",
    ".diff": "diff", ".patch": "diff", ".log": "log",
}
_CODE_EXTS = {".py", ".c", ".h", ".cpp", ".hpp", ".cc", ".hh", ".cxx",
              ".ino", ".js", ".ts", ".rs", ".go", ".java"}

_TEST_MARKER = re.compile(
    r"^(FAILED|ERROR)\s+\S+::|^\d+% tests passed|short test summary"
    r"|=+ .*\d+ (passed|failed)")
_CODE_DECL = re.compile(
    r"^\s*(def |class |#include|import |from \w+(\.\w+)* import |void |int |"
    r"static |typedef|function |struct |const \w+ =)")
_PY_DECL = re.compile(r"^\s*(def |class |import |from \w+)")
_LOG_PREFIX = re.compile(
    r"^\W*\d{4}-\d{2}-\d{2}|^\W*\d{2}:\d{2}:\d{2}"
    r"|\b(INFO|DEBUG|WARN|WARNING|ERROR|TRACE|FATAL)\b")


def detect_kind(text: str, filename_hint: str = "") -> tuple[str, str, str]:
    """Return (command, reason, pseudo_filename).

    pseudo_filename matters only for `skeleton` (language detection); it is
    the hint itself when one was given.
    """
    hint = filename_hint.strip().lower()
    ext = os.path.splitext(hint)[1]
    if ext in _EXT_MAP:
        return _EXT_MAP[ext], f"filename hint '{ext}'", filename_hint
    if ext in _CODE_EXTS:
        return "skeleton", f"filename hint '{ext}'", filename_hint
    if ext == ".xml" and "<testsuite" in text[:2000]:
        return "test", "JUnit XML", filename_hint

    stripped = text.lstrip()
    lines = text.splitlines()
    head = lines[:200]

    if any(l.startswith("diff --git ") for l in head) or (
            any(l.startswith("--- ") for l in head)
            and any(l.startswith("+++ ") for l in head)
            and any(l.startswith("@@") for l in head)):
        return "diff", "unified diff markers", filename_hint

    if stripped.startswith("<") and "<testsuite" in text[:2000]:
        return "test", "JUnit XML", filename_hint

    test_hits = sum(1 for l in head if _TEST_MARKER.search(l.strip()))
    if test_hits:
        return "test", f"{test_hits} test-runner markers", filename_hint

    if stripped[:1] in "{[":
        try:
            _json.loads(text)
            return "json", "parses as JSON", filename_hint
        except ValueError:
            try:
                _json.loads(stripped.splitlines()[0])
                return "json", "JSON lines", filename_hint
            except ValueError:
                pass

    build_hits = sum(
        1 for l in head
        if _build._GCC.match(l) or _build._MSVC.match(l)
        or _build._LNK.search(l) or _build._PY_TB_START.match(l)
        or _build._PY_TB_FILE.match(l)
        or "undefined reference to" in l)
    if build_hits:
        return "build", f"{build_hits} compiler/traceback diagnostics", filename_hint

    nonempty = [l for l in head if l.strip()]
    if len(nonempty) >= 3:
        for delim in (",", ";", "\t", "|"):
            counts = [l.count(delim) for l in nonempty[:10]]
            if counts[0] >= 2 and len(set(counts)) == 1:
                delim_repr = {"\t": "\\t"}.get(delim, delim)
                return "csv", f"consistent '{delim_repr}'-separated columns", filename_hint

    code_hits = sum(1 for l in head if _CODE_DECL.match(l))
    if code_hits >= 3:
        pseudo = filename_hint or (
            "input.py" if any(_PY_DECL.match(l) for l in head) else "input.c")
        return "skeleton", f"{code_hits} code declarations", pseudo

    log_hits = sum(1 for l in head if _LOG_PREFIX.search(l))
    if nonempty and log_hits >= max(2, len(nonempty) // 5):
        return "log", "timestamp/level prefixes", filename_hint

    return "log", "generic text fallback (collapse repeats)", filename_hint

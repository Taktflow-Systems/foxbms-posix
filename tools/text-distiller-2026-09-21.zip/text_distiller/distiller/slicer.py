"""Targeted extraction: only the lines that match, plus context.

The grep-with-context + line-range tool an agent should use after `skeleton`
or `budget` told it where to look, instead of reading a whole file.
"""

from __future__ import annotations

import re

from .core import compile_regex


def distill_slice(
    text: str,
    patterns: list[str],
    context: int = 2,
    line_range: tuple[int, int] | None = None,
    ignore_case: bool = False,
) -> list[str]:
    lines = text.splitlines()
    n = len(lines)
    keep: set[int] = set()
    matches = 0

    if line_range:
        start, end = line_range
        keep.update(range(max(1, start), min(n, end) + 1))

    flags = re.IGNORECASE if ignore_case else 0
    for pattern in patterns:
        rx = compile_regex(pattern, flags)
        for i, line in enumerate(lines, 1):
            if rx.search(line):
                matches += 1
                keep.update(range(max(1, i - context), min(n, i + context) + 1))

    body = [f"file-lines={n} matches={matches} emitted={len(keep)}"]
    if not keep:
        body.append("(nothing matched -- check the pattern, or try --ignore-case)")
        return body

    prev = 0
    for i in sorted(keep):
        if i > prev + 1:
            body.append(f"   ... ({i - prev - 1} lines skipped)")
        body.append(f"{i:>6}|{lines[i - 1]}")
        prev = i
    if prev < n:
        body.append(f"   ... ({n - prev} lines skipped)")
    return body

"""Command-line interface for text_distiller.

Usage:  python tools\\text_distiller\\distill.py <command> [options]

Every command prints a one-line `# distill:<cmd>` header with the achieved
token reduction, then the distilled body, truncated to --max-tokens. A
truncated body is saved in full to ${DISTILL_OUT:-$TMPDIR/distill}/<key>.txt
and the truncation marker names that file (--no-persist opts out).
Bad input (invalid regex, missing path) prints `error: <msg>` on stderr, exit 2.
"""

from __future__ import annotations

import argparse
import hashlib
import os
import sys
import tempfile
from pathlib import Path

from . import __version__
from .budget import distill_budget
from .build import distill_build
from .core import UsageError, clip_to_budget, header, read_text
from .detect import detect_kind
from .diffs import distill_diff
from .jsondata import distill_json
from .logs import distill_log
from .search import TYPES, distill_find, distill_search
from .skeleton import distill_skeleton
from .slicer import distill_slice
from .tabular import distill_csv
from .testreport import distill_testreport


def _add_common(p: argparse.ArgumentParser) -> None:
    p.add_argument("--max-tokens", type=int, default=4000, metavar="N",
                   help="hard cap on output size, approx tokens (default 4000)")


def _add_clean_flag(p: argparse.ArgumentParser) -> None:
    p.add_argument("--clean", action="store_true",
                   help="strip ANSI escapes and control characters first "
                        "(structure-preserving; for the full character-level "
                        "clean, pipe through `distill.py clean` instead)")


def _add_tree_filters(p: argparse.ArgumentParser) -> None:
    p.add_argument("--type", "-t", action="append", default=[], metavar="TYPE",
                   choices=sorted(TYPES),
                   help="file-type shortcut, repeatable: " + ", ".join(sorted(TYPES)))
    p.add_argument("--exclude", "-x", action="append", default=[], metavar="DIR",
                   help="directory name to skip anywhere in the tree (repeatable)")
    p.add_argument("--no-ignore", action="store_true",
                   help="do not honour .gitignore patterns")
    p.add_argument("--no-default-excludes", action="store_true",
                   help="also search .git, __pycache__, node_modules, ...")


def _load_cleaner():
    """Import the sibling character-level cleaner (text_distiller.py)."""
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from text_distiller import distill_text, strip_ansi_and_controls
    return distill_text, strip_ansi_and_controls


def _resolve_output_path(args: argparse.Namespace) -> Path | None:
    if getattr(args, "output", None):
        return Path(args.output)
    if getattr(args, "save", False):
        if args.cmd in ("budget", "search", "find"):
            return Path("output") / f"{args.cmd}.txt"
        src = getattr(args, "file", None)
        stem = "stdin" if src in (None, "-") else Path(src).stem
        return Path("output") / f"{stem}.{args.cmd}.txt"
    return None


def persist_dir() -> str:
    base = os.environ.get("DISTILL_OUT")
    if base:
        return base
    return os.path.join(os.environ.get("TMPDIR") or tempfile.gettempdir(), "distill")


def _persister(argv: list[str]):
    """Callable for clip_to_budget: writes the full body to <sha1(cmd+args)[:12]>.txt."""
    def save(lines: list[str]) -> str | None:
        key = hashlib.sha1("\0".join(argv).encode("utf-8", "replace")).hexdigest()[:12]
        base = persist_dir()
        path = os.path.join(base, f"{key}.txt")
        try:
            os.makedirs(base, exist_ok=True)
            with open(path, "w", encoding="utf-8", newline="\n") as fh:
                fh.write("\n".join(lines) + "\n")
        except OSError:
            return None
        return path
    return save


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="distill",
        description="Deterministic text compression for AI workflows -- "
                    "turn big artifacts into small, high-signal summaries.",
    )
    parser.add_argument("--version", action="version", version=__version__)
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("budget", help="token cost report for files/dirs/globs "
                                      "(run this BEFORE reading anything big)")
    p.add_argument("paths", nargs="+", help="files, directories, or globs")
    p.add_argument("--no-ignore", action="store_true",
                   help="do not honour .gitignore patterns")
    p.add_argument("--no-default-excludes", action="store_true",
                   help="also count .git, __pycache__, node_modules, ...")
    _add_common(p)

    p = sub.add_parser("search", help="recursive text search, pure-Python "
                                      "rg-lite: which files contain this "
                                      "pattern (no install needed)")
    p.add_argument("pattern", help="regex to search for")
    p.add_argument("paths", nargs="*", default=["."],
                   help="files, directories, or globs (default: current dir)")
    p.add_argument("--glob", "-g", action="append", default=[], metavar="GLOB",
                   help="only search files matching GLOB, e.g. -g *.c "
                        "(repeatable)")
    p.add_argument("--ignore-case", "-i", action="store_true")
    p.add_argument("--word", "-w", action="store_true",
                   help="match whole words only")
    p.add_argument("--files-only", "-l", action="store_true",
                   help="list matching files with counts, no match lines")
    p.add_argument("--context", "-C", type=int, default=0, metavar="N",
                   help="context lines around each match (default 0)")
    p.add_argument("--max-per-file", type=int, default=5, metavar="N",
                   help="match lines shown per file (default 5)")
    p.add_argument("--tail", action="store_true",
                   help="show the LAST --max-per-file matches per file instead "
                        "of the first (on logs the answer is at the end)")
    p.add_argument("--max-line-chars", type=int, default=240, metavar="N",
                   help="clip long lines to N chars around the match "
                        "(default 240; 0 = print whole lines)")
    p.add_argument("--fixed-strings", "-F", action="store_true",
                   help="treat PATTERN as literal text, not a regex")
    p.add_argument("--sort", choices=("path", "count"), default="path",
                   help="order results by path (default) or most matches first")
    p.add_argument("--max-filesize", type=int, default=2_000_000, metavar="B",
                   help="skip files larger than B bytes (default 2000000; "
                        "0 = no limit)")
    _add_tree_filters(p)
    _add_common(p)

    p = sub.add_parser("find", help="list files matching a glob (controlled "
                                    "replacement for find/glob): sizes, sorted, "
                                    "budgeted, .gitignore-aware")
    p.add_argument("patterns", nargs="*", default=[], metavar="GLOB",
                   help="basename glob like *.c, or a path glob like src/*/*.h; "
                        "none = every file")
    p.add_argument("--path", "-p", action="append", default=[], metavar="DIR",
                   help="directory to list (repeatable; default: current dir)")
    p.add_argument("--no-sizes", action="store_true", help="paths only")
    _add_tree_filters(p)
    _add_common(p)

    p = sub.add_parser("auto", help="detect what the input is (log/build/test/"
                                    "json/csv/diff/code) and run the right "
                                    "distiller with default options")
    p.add_argument("file", help="file, or - for stdin")
    _add_clean_flag(p)
    _add_common(p)

    p = sub.add_parser("clean", help="character-level clean: remove ANSI/control "
                                     "noise, box-drawing chrome, prompt prefixes "
                                     "(wraps text_distiller.py; output is the "
                                     "cleaned text itself, header goes to stderr)")
    p.add_argument("file", help="text file, or - for stdin")
    p.add_argument("--profile", choices=("debug", "prompt"), default="debug",
                   help="debug preserves more code/log punctuation; "
                        "prompt is more compact")
    p.add_argument("--keep-fences", action="store_true",
                   help="keep Markdown code-fence marker lines")
    p.add_argument("--max-tokens", type=int, default=None, metavar="N",
                   help="optional output cap (default: none -- cleaned text "
                        "is a payload, not a summary)")

    p = sub.add_parser("log", help="collapse repetitive logs into unique "
                                   "patterns with counts")
    p.add_argument("file", help="log file, or - for stdin")
    p.add_argument("--level", choices=["error", "warn"],
                   help="keep only lines matching this severity or worse")
    p.add_argument("--mask-numbers", action="store_true",
                   help="also mask plain numbers when grouping")
    p.add_argument("--min-count", type=int, default=1, metavar="N",
                   help="hide patterns occurring fewer than N times")
    p.add_argument("--sort-count", action="store_true",
                   help="most frequent first (default: first-seen order)")
    _add_clean_flag(p)
    _add_common(p)

    p = sub.add_parser("build", help="extract errors/warnings from compiler "
                                     "and build output (gcc/clang/msvc/cmake/"
                                     "make/ninja/python)")
    p.add_argument("file", help="build log, or - for stdin")
    p.add_argument("--notes", action="store_true", help="include compiler notes")
    _add_clean_flag(p)
    _add_common(p)

    p = sub.add_parser("test", help="compress test output to failures only "
                                    "(JUnit XML, pytest, ctest)")
    p.add_argument("file", help="report file, or - for stdin")
    p.add_argument("--failure-lines", type=int, default=3, metavar="N",
                   help="detail lines kept per failure (default 3)")
    _add_clean_flag(p)
    _add_common(p)

    p = sub.add_parser("skeleton", help="structural outline of a source file "
                                        "(signatures only, with line numbers)")
    p.add_argument("file", help="source file (.py exact; C/C++ heuristic; "
                                "other languages generic)")
    _add_common(p)

    p = sub.add_parser("slice", help="extract only matching lines + context "
                                     "from a big file")
    p.add_argument("file", help="file, or - for stdin")
    p.add_argument("--pattern", "-p", action="append", default=[],
                   metavar="REGEX", help="regex to match (repeatable)")
    p.add_argument("--context", "-c", type=int, default=2, metavar="N",
                   help="context lines around each match (default 2)")
    p.add_argument("--lines", metavar="A:B",
                   help="also keep an explicit line range, e.g. 120:180")
    p.add_argument("--ignore-case", "-i", action="store_true")
    _add_clean_flag(p)
    _add_common(p)

    p = sub.add_parser("json", help="schema summary of a JSON/JSONL file "
                                    "instead of its content")
    p.add_argument("file", help="json/jsonl file, or - for stdin")
    p.add_argument("--jsonl", action="store_true",
                   help="force JSON-lines mode (auto-detected otherwise)")
    _add_common(p)

    p = sub.add_parser("csv", help="shape + per-column stats of a CSV/TSV")
    p.add_argument("file", help="csv file, or - for stdin")
    p.add_argument("--delimiter", help="field delimiter (auto-sniffed otherwise)")
    p.add_argument("--sample", type=int, default=5, metavar="N",
                   help="sample rows to show (default 5)")
    p.add_argument("--no-header", action="store_true",
                   help="first row is data, not a header")
    _add_common(p)

    p = sub.add_parser("diff", help="compress a unified diff to per-file "
                                    "stats + hunk headers")
    p.add_argument("file", help="diff file, or - for stdin (e.g. git diff | …)")
    p.add_argument("--full", action="append", default=[], metavar="GLOB",
                   help="emit full hunks for paths matching GLOB (repeatable)")
    _add_clean_flag(p)
    _add_common(p)

    for sp in sub.choices.values():
        sp.add_argument("-o", "--output", metavar="PATH",
                        help="write the result to PATH instead of stdout")
        sp.add_argument("--save", action="store_true",
                        help="write the result to output\\<input-stem>.<cmd>.txt "
                             "(folder created if missing)")
        sp.add_argument("--no-persist", action="store_true",
                        help="on truncation, do not save the full result to "
                             "$DISTILL_OUT (default: <tmp>/distill)")

    return parser


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    args = build_parser().parse_args(argv)
    try:
        return _run(args, argv)
    except UsageError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


def _run(args: argparse.Namespace, argv: list[str]) -> int:
    if args.cmd == "budget":
        in_text = ""  # budget never reads content into the report
        body = distill_budget(args.paths, no_ignore=args.no_ignore,
                              no_default_excludes=args.no_default_excludes)
    elif args.cmd == "search":
        in_text = ""
        body = distill_search(args.pattern, args.paths, globs=args.glob,
                              ignore_case=args.ignore_case, word=args.word,
                              files_only=args.files_only,
                              context=args.context,
                              max_per_file=args.max_per_file,
                              no_default_excludes=args.no_default_excludes,
                              max_filesize=args.max_filesize,
                              fixed=args.fixed_strings, types=args.type,
                              excludes=args.exclude, no_ignore=args.no_ignore,
                              sort=args.sort, tail=args.tail,
                              max_line_chars=args.max_line_chars)
    elif args.cmd == "find":
        in_text = ""
        body = distill_find(args.patterns, args.path or ["."], types=args.type,
                            no_default_excludes=args.no_default_excludes,
                            no_ignore=args.no_ignore, excludes=args.exclude,
                            sizes=not args.no_sizes)
    else:
        in_text = read_text(args.file)
        if getattr(args, "clean", False):
            _, strip_ansi_and_controls = _load_cleaner()
            in_text = strip_ansi_and_controls(in_text)
        if args.cmd == "auto":
            from .api import run_kind
            hint = "" if args.file == "-" else args.file
            detected, reason, pseudo = detect_kind(in_text, hint)
            body = [f"detected: {detected} ({reason})"] \
                + run_kind(detected, in_text, pseudo or args.file)
        elif args.cmd == "clean":
            distill_text, _ = _load_cleaner()
            result = distill_text(in_text, profile=args.profile,
                                  keep_fences=args.keep_fences)
            body = result.text.splitlines()
        elif args.cmd == "log":
            body = distill_log(in_text, level=args.level,
                               mask_numbers=args.mask_numbers,
                               min_count=args.min_count,
                               sort_by_count=args.sort_count)
        elif args.cmd == "build":
            body = distill_build(in_text, include_notes=args.notes)
        elif args.cmd == "test":
            body = distill_testreport(in_text, max_failure_lines=args.failure_lines)
        elif args.cmd == "skeleton":
            body = distill_skeleton(in_text, args.file)
        elif args.cmd == "slice":
            line_range = None
            if args.lines:
                start, _, end = args.lines.partition(":")
                line_range = (int(start), int(end or start))
            if not args.pattern and not line_range:
                print("slice: provide --pattern and/or --lines", file=sys.stderr)
                return 2
            body = distill_slice(in_text, args.pattern, context=args.context,
                                 line_range=line_range,
                                 ignore_case=args.ignore_case)
        elif args.cmd == "json":
            body = distill_json(in_text, jsonl=args.jsonl)
        elif args.cmd == "csv":
            body = distill_csv(in_text, delimiter=args.delimiter,
                               sample_rows=args.sample,
                               no_header=args.no_header)
        elif args.cmd == "diff":
            body = distill_diff(in_text, full_globs=args.full)
        else:  # pragma: no cover
            raise SystemExit(f"unknown command {args.cmd}")

    persist = None if args.no_persist else _persister(argv)
    body = clip_to_budget(body, args.max_tokens, persist=persist)
    text = "\n".join(body)
    # budget/search/find take file trees, not one input: no reduction header
    head = None if args.cmd in ("budget", "search", "find") \
        else header(args.cmd, in_text, text)

    out_path = _resolve_output_path(args)
    if out_path is not None:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(text + "\n", encoding="utf-8")
        if head:
            print(head)
        print(f"wrote: {out_path}")
        return 0

    if args.cmd == "clean":
        # cleaned text is a payload meant for piping: keep stdout pure
        print(head, file=sys.stderr)
    elif head:
        print(head)
    print(text)
    return 0

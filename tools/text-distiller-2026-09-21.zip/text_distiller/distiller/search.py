"""Recursive text search and file finder -- pure-Python rg-lite for zero-install sites.

Answers "which files contain this pattern" (search) and "which files match this
glob" (find) without any third-party binary. Output is token-budgeted like every
other distiller, so it is the controlled replacement for grep/rg/find/glob.

Speed: files are scanned with ONE regex pass over the raw bytes; only files that
match are decoded and split into lines. Reads run on a thread pool. Binary
extensions are skipped without opening. .gitignore files are honoured with git
semantics (ancestors up to the repo top, info/exclude, negation, `**`; see
ignore.py), so build trees stay out of the way like ripgrep does. Directory
junctions and symlink loops are walked once (realpath guard). Results are always
sorted by path, so output is deterministic regardless of thread scheduling.

Anchors: the byte prescan runs in MULTILINE mode with `$` widened to `(?=\\r?$)`
so CRLF files match; patterns using \\A or \\Z skip the prescan. Invalid regexes
and missing paths raise core.UsageError (CLI: `error: ...`, exit 2).
"""

from __future__ import annotations

import glob as _glob
import os
import re
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .core import UTF8_BOM, UsageError, compile_regex, wide_encoding
from .ignore import IgnoreStack, glob_match, glob_regex

DEFAULT_EXCLUDED_DIRS = {
    ".git", ".svn", ".hg", "__pycache__", "node_modules",
    ".venv", "venv", ".tox", ".mypy_cache", ".pytest_cache", ".idea",
}

BINARY_EXTS = {
    ".o", ".obj", ".a", ".lib", ".so", ".dll", ".dylib", ".exe", ".pdb",
    ".rlib", ".rmeta", ".bin", ".elf", ".out", ".pyc", ".pyo", ".class",
    ".jar", ".wasm", ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".webp",
    ".pdf", ".zip", ".7z", ".gz", ".tgz", ".xz", ".bz2", ".tar", ".rar",
    ".ttf", ".otf", ".woff", ".woff2", ".mp3", ".mp4", ".wav", ".avi", ".mkv",
    ".db", ".sqlite", ".sqlite3", ".dat", ".iso", ".img", ".dmg", ".msi",
    ".docx", ".xlsx", ".pptx", ".doc", ".xls", ".ppt", ".lz4", ".zst",
}

# generated blobs (report HTML with embedded base64 etc.) read as "text" but
# are huge; skipping them by default keeps search fast and output relevant
MAX_FILESIZE_DEFAULT = 2_000_000

# One matched line can be a whole minified JSON document; printing it defeats
# --max-tokens, so match lines are clipped to a window around the match.
MAX_LINE_CHARS_DEFAULT = 240
CLIP_LEAD = 40
CLIP_HEAD = 80

TYPES: dict[str, list[str]] = {
    "c": ["*.c", "*.h"],
    "cpp": ["*.cpp", "*.hpp", "*.cc", "*.hh", "*.cxx", "*.hxx", "*.c", "*.h"],
    "py": ["*.py", "*.pyi"],
    "rs": ["*.rs"],
    "js": ["*.js", "*.jsx", "*.mjs", "*.cjs"],
    "ts": ["*.ts", "*.tsx"],
    "md": ["*.md", "*.markdown", "*.rst"],
    "yaml": ["*.yml", "*.yaml"],
    "json": ["*.json", "*.jsonl"],
    "xml": ["*.xml", "*.arxml", "*.xsd"],
    "sh": ["*.sh", "*.bash"],
    "ps1": ["*.ps1", "*.psm1"],
    "cmake": ["CMakeLists.txt", "*.cmake"],
    "make": ["Makefile", "makefile", "GNUmakefile", "*.mk"],
    "html": ["*.html", "*.htm"],
    "sql": ["*.sql"],
    "txt": ["*.txt", "*.log"],
    "asm": ["*.s", "*.S", "*.asm"],
    "ld": ["*.ld", "*.lds", "*.icf", "*.cmd"],
    "dbc": ["*.dbc"],
    "toml": ["*.toml", "*.ini", "*.cfg"],
}


def expand_types(types: list[str] | None) -> list[str]:
    globs: list[str] = []
    for t in types or []:
        if t not in TYPES:
            raise ValueError(f"unknown type {t!r}; known: {', '.join(sorted(TYPES))}")
        globs.extend(TYPES[t])
    return globs


# ---------------------------------------------------------------------------
# file enumeration

def _walk(root: Path, excluded: set[str], no_ignore: bool) -> list[Path]:
    out: list[Path] = []
    root_s = str(root)
    if no_ignore:
        pending: dict[str, tuple[str, IgnoreStack | None]] = {root_s: ("", None)}
    else:
        stack, root_rel = IgnoreStack.for_root(root_s)
        pending = {root_s: (root_rel, stack)}
    seen: set[str] = set()
    for dirpath, dirnames, filenames in os.walk(root_s):
        rel, rules = pending.pop(dirpath)
        real = os.path.normcase(os.path.realpath(dirpath))
        if real in seen:  # junction or symlink back into visited ground
            dirnames[:] = []
            continue
        seen.add(real)
        if rules is not None and dirpath != root_s:
            if ".git" in dirnames or ".git" in filenames:
                rules, _ = IgnoreStack.for_root(dirpath)
                rel = ""
            elif ".gitignore" in filenames:
                rules = rules.child(dirpath, rel)
        prefix = rel + "/" if rel else ""
        keep = []
        for d in sorted(dirnames):
            if d in excluded:
                continue
            if rules is not None and rules.layers and rules.ignored(prefix + d, d, True):
                continue
            keep.append(d)
            pending[os.path.join(dirpath, d)] = (prefix + d, rules)
        dirnames[:] = keep
        for name in sorted(filenames):
            if rules is not None and rules.layers and rules.ignored(prefix + name, name, False):
                continue
            out.append(Path(os.path.join(dirpath, name)))
    return out


def iter_files(paths: list[str], no_default_excludes: bool = False,
               no_ignore: bool = False, excludes: list[str] | None = None) -> list[Path]:
    excluded = set() if no_default_excludes else set(DEFAULT_EXCLUDED_DIRS)
    excluded.update(excludes or [])
    files: list[Path] = []
    for spec in paths:
        p = Path(spec)
        if p.is_file():
            files.append(p)
        elif p.is_dir():
            files.extend(_walk(p, excluded, no_ignore))
        elif any(ch in spec for ch in "*?["):
            files.extend(Path(m) for m in sorted(_glob.glob(spec, recursive=True))
                         if Path(m).is_file())
        else:
            raise UsageError(f"no such path: {spec}")
    return sorted(set(files), key=str)


def _compile_globs(globs: list[str] | None):
    return [glob_regex(g) for g in globs or []]


def _apply_globs(files: list[Path], globs: list[str] | None) -> list[Path]:
    if not globs:
        return files
    compiled = _compile_globs(globs)
    return [f for f in files if glob_match(compiled, f.name, str(f).replace("\\", "/"))]


# ---------------------------------------------------------------------------
# search

def _prescan_source(pattern: str) -> str | None:
    """Byte-prescan form of pattern: `$` -> `(?=\\r?$)`; None when \\A or \\Z forbid a prescan."""
    out: list[str] = []
    i, n = 0, len(pattern)
    in_class = False
    while i < n:
        c = pattern[i]
        if c == "\\" and i + 1 < n:
            if not in_class and pattern[i + 1] in "AZ":
                return None
            out.append(pattern[i:i + 2])
            i += 2
            continue
        if in_class:
            if c == "]":
                in_class = False
            out.append(c)
        elif c == "[":
            in_class = True
            out.append(c)
            j = i + 1
            if j < n and pattern[j] == "^":
                out.append("^")
                j += 1
            if j < n and pattern[j] == "]":
                out.append("]")  # a leading ] is literal inside a class
                j += 1
            i = j
            continue
        elif c == "$":
            out.append(r"(?=\r?$)")
        else:
            out.append(c)
        i += 1
    return "".join(out)


def _compile(pattern: str, ignore_case: bool, word: bool, fixed: bool):
    if fixed:
        pattern = re.escape(pattern)
    if word:
        pattern = rf"\b(?:{pattern})\b"
    flags = re.IGNORECASE if ignore_case else 0
    rx_str = compile_regex(pattern, flags)
    rx_bytes = None
    prescan = _prescan_source(pattern) if pattern.isascii() else None
    if prescan is not None:
        try:
            rx_bytes = re.compile(prescan.encode("ascii"), flags | re.MULTILINE)
        except re.error:
            rx_bytes = None
    return rx_str, rx_bytes


def _scan_one(path: Path, rx_str, rx_bytes, max_filesize: int):
    if path.suffix.lower() in BINARY_EXTS:
        return "binary", path, None
    try:
        if max_filesize and path.stat().st_size > max_filesize:
            return "large", path, None
        with open(path, "rb") as fh:
            raw = fh.read()
    except OSError:
        return "error", path, None
    enc = wide_encoding(raw)
    if enc:
        text = raw.decode(enc, errors="replace")
    else:
        if b"\0" in raw[:8192]:
            return "binary", path, None
        if raw.startswith(UTF8_BOM):
            raw = raw[3:]
        if rx_bytes is not None and rx_bytes.search(raw) is None:
            return "scanned", path, None
        text = raw.decode("utf-8", errors="replace")
    lines = text.splitlines()
    hits = [i for i, line in enumerate(lines, 1) if rx_str.search(line)]
    return "scanned", path, ((hits, lines) if hits else None)


def _pool_size(n: int) -> int:
    return max(1, min(16, (os.cpu_count() or 4) * 2, n))


def _clip_line(line: str, limit: int, rx=None) -> str:
    """Clip to `limit` chars keeping the head (timestamp/tag) and the match."""
    if limit <= 0 or len(line) <= limit:
        return line
    start = 0
    if rx is not None:
        m = rx.search(line)
        if m is not None:
            start = max(0, m.start() - CLIP_LEAD)
    hlen = 0
    if start:
        hlen = min(CLIP_HEAD, limit // 3)
        if start <= hlen:  # match already sits in the head
            start = hlen = 0
    budget = limit - hlen
    if start + budget > len(line):
        start = max(0, len(line) - budget)
    chunk = line[start:start + budget]
    head = f"{line[:hlen]} ... " if hlen else ""
    return f"{head}{chunk}... [+{len(line) - hlen - len(chunk)} chars]"


def distill_search(
    pattern: str,
    paths: list[str],
    globs: list[str] | None = None,
    ignore_case: bool = False,
    word: bool = False,
    files_only: bool = False,
    context: int = 0,
    max_per_file: int = 5,
    no_default_excludes: bool = False,
    max_filesize: int = MAX_FILESIZE_DEFAULT,
    fixed: bool = False,
    types: list[str] | None = None,
    excludes: list[str] | None = None,
    no_ignore: bool = False,
    sort: str = "path",
    max_line_chars: int = MAX_LINE_CHARS_DEFAULT,
    tail: bool = False,
) -> list[str]:
    rx_str, rx_bytes = _compile(pattern, ignore_case, word, fixed)
    globs = list(globs or []) + expand_types(types)
    files = _apply_globs(iter_files(paths, no_default_excludes, no_ignore, excludes), globs)

    scanned = skipped_large = skipped_binary = 0
    results: list[tuple[Path, list[int], list[str]]] = []
    if files:
        with ThreadPoolExecutor(max_workers=_pool_size(len(files))) as ex:
            for status, f, payload in ex.map(
                    lambda p: _scan_one(p, rx_str, rx_bytes, max_filesize), files,
                    chunksize=8):
                if status == "large":
                    skipped_large += 1
                elif status == "binary":
                    skipped_binary += 1
                elif status == "scanned":
                    scanned += 1
                    if payload:
                        results.append((f, payload[0], payload[1]))
    if sort == "count":
        results.sort(key=lambda r: (-len(r[1]), str(r[0])))

    total = sum(len(h) for _, h, _ in results)
    summary = (f"files-scanned={scanned} files-matched={len(results)} matches={total}"
               f" binaries-skipped={skipped_binary}")
    if skipped_large:
        summary += (f" skipped-large={skipped_large}"
                    f" (>{max_filesize} bytes; raise --max-filesize)")
    body = [summary]
    if not results:
        if fixed and "|" in pattern:
            body.append("(no matches -- -F makes '|' a literal character; drop -F"
                        " for regex alternation)")
        else:
            body.append("(no matches -- try -i, a shorter substring, -F for literal"
                        " text, or check --glob/--type filters)")
        return body

    clipped = 0
    for f, hits, lines in results:
        if files_only:
            body.append(f"{len(hits):>5}x  {f}")
            continue
        body.append(f"{f} ({len(hits)} matches)")
        shown = hits[-max_per_file:] if tail else hits[:max_per_file]
        keep: set[int] = set()
        for i in shown:
            keep.update(range(max(1, i - context), min(len(lines), i + context) + 1))
        prev = 0
        hitset = set(hits)
        for i in sorted(keep):
            if i > prev + 1:
                body.append("     ...")
            is_hit = i in hitset
            marker = ":" if is_hit else "-"
            raw = lines[i - 1]
            text = _clip_line(raw, max_line_chars, rx_str if is_hit else None)
            clipped += text is not raw
            body.append(f"  {i:>6}{marker} {text}")
            prev = i
        if len(hits) > len(shown):
            where = "earlier" if tail else "more"
            body.append(f"     ... +{len(hits) - len(shown)} {where} matches"
                        f" in this file (raise --max-per-file"
                        f"{'' if tail else ', or --tail for the last ones'})")
    if clipped:
        body.append(f"({clipped} long line(s) clipped to {max_line_chars} chars;"
                    f" --max-line-chars 0 prints them whole)")
    return body


# ---------------------------------------------------------------------------
# find

def distill_find(
    patterns: list[str],
    paths: list[str],
    types: list[str] | None = None,
    no_default_excludes: bool = False,
    no_ignore: bool = False,
    excludes: list[str] | None = None,
    sizes: bool = True,
) -> list[str]:
    globs = list(patterns) + expand_types(types)
    files = iter_files(paths, no_default_excludes, no_ignore, excludes)
    matched = _apply_globs(files, globs)
    body = [f"files-listed={len(matched)} files-considered={len(files)}"]
    if not matched:
        body.append("(no files matched -- patterns match the basename, or the path"
                    " when they contain '/' (* stays in one directory, ** crosses);"
                    " try --no-ignore)")
        return body
    for f in matched:
        if sizes:
            try:
                size = f.stat().st_size
            except OSError:
                size = -1
            body.append(f"{size:>10}  {f}")
        else:
            body.append(str(f))
    return body

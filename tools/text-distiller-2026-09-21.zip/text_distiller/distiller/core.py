"""Shared helpers: input reading, token estimation, masking, output budgets.

Determinism contract (applies to every distiller):
- no wall-clock time, no randomness, no environment-dependent output
- stable ordering (first-seen or explicit sort key, ties keep input order)
- UTF-8 input with errors="replace", LF line handling; UTF-16/32 decoded when
  they carry a BOM; a UTF-8 BOM is stripped
"""

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Callable


class UsageError(ValueError):
    """Input the caller can fix; shells print `error: <msg>` (CLI exit 2)."""

    def __init__(self, msg: str):
        super().__init__(" ".join(str(msg).split("\n")))


def compile_regex(pattern: str | bytes, flags: int = 0) -> re.Pattern:
    try:
        return re.compile(pattern, flags)
    except re.error as exc:
        raise UsageError(f"invalid regex: {exc}") from None


# ---------------------------------------------------------------------------
# input

UTF8_BOM = b"\xef\xbb\xbf"
_WIDE_BOMS = ((b"\xff\xfe\x00\x00", "utf-32"), (b"\x00\x00\xfe\xff", "utf-32"),
              (b"\xff\xfe", "utf-16"), (b"\xfe\xff", "utf-16"))


def wide_encoding(raw: bytes) -> str | None:
    """'utf-16'/'utf-32' when raw starts with that BOM, else None."""
    for bom, enc in _WIDE_BOMS:
        if raw.startswith(bom):
            return enc
    return None


def decode_bytes(raw: bytes) -> str | None:
    """BOM-aware decode; None when the bytes look binary (NUL in the first 8 KB)."""
    enc = wide_encoding(raw)
    if enc:
        return raw.decode(enc, errors="replace")
    if b"\0" in raw[:8192]:
        return None
    if raw.startswith(UTF8_BOM):
        raw = raw[3:]
    return raw.decode("utf-8", errors="replace")


def read_text(path: str) -> str:
    """Read a file as text (lossy on bad bytes). '-' reads stdin."""
    if path == "-":
        text = sys.stdin.read()
        return text[1:] if text[:1] == chr(0xFEFF) else text
    try:
        raw = Path(path).read_bytes()
    except FileNotFoundError:
        raise UsageError(f"no such path: {path}") from None
    text = decode_bytes(raw)
    return raw.decode("utf-8", errors="replace") if text is None else text


# ---------------------------------------------------------------------------
# token accounting

def est_tokens(text: str) -> int:
    """Heuristic token estimate (~4 chars/token, same rule everywhere)."""
    return (len(text) + 3) // 4


def human_count(n: int) -> str:
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.1f}k"
    return str(n)


def header(tool: str, in_text: str, body: str) -> str:
    """One-line provenance header showing the token reduction achieved."""
    tin = est_tokens(in_text)
    tout = est_tokens(body)
    saved = 0 if tin == 0 else max(0, 100 * (tin - tout) // tin)
    return (
        f"# distill:{tool} | input ~{human_count(tin)} tok"
        f" -> output ~{human_count(tout)} tok | saved {saved}%"
    )


def clip_to_budget(lines: list[str], max_tokens: int | None,
                   persist: Callable[[list[str]], str | None] | None = None) -> list[str]:
    """Deterministically truncate a body to a token budget, with a marker.

    persist, when given, stores the full body on truncation and returns its path.
    """
    if max_tokens is None:
        return lines
    out: list[str] = []
    used = 0
    for i, line in enumerate(lines):
        cost = est_tokens(line) + 1  # +1 for the newline
        if used + cost > max_tokens:
            remaining = len(lines) - i
            saved = persist(lines) if persist is not None else None
            where = f" Full output: {saved}." if saved else ""
            out.append(
                f"[truncated at ~{max_tokens} tokens: {remaining} more lines.{where}"
                f" Raise --max-tokens or narrow the query.]"
            )
            return out
        out.append(line)
        used += cost
    return out


# ---------------------------------------------------------------------------
# masking (used to group log lines that differ only in volatile fields)

_MASKS: list[tuple[re.Pattern[str], str]] = [
    # full timestamps before bare dates/times
    (re.compile(
        r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:[.,]\d+)?(?:Z|[+-]\d{2}:?\d{2})?"
    ), "<TS>"),
    (re.compile(r"\b\d{2}:\d{2}:\d{2}(?:[.,]\d+)?\b"), "<TIME>"),
    (re.compile(r"\b\d{4}-\d{2}-\d{2}\b"), "<DATE>"),
    (re.compile(
        r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}"
        r"-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b"
    ), "<UUID>"),
    (re.compile(r"\b0[xX][0-9a-fA-F]+\b"), "<HEX>"),
    (re.compile(r"\b[0-9a-fA-F]{8,}\b"), "<HEX>"),
]

# no trailing \b so attached units mask too ("17ms" -> "<N>ms")
_NUM_MASK = (re.compile(r"\b\d+(?:\.\d+)?"), "<N>")


def mask_line(line: str, mask_numbers: bool = False) -> str:
    """Replace volatile fields (timestamps, hex, UUIDs) with placeholders."""
    for rx, repl in _MASKS:
        line = rx.sub(repl, line)
    if mask_numbers:
        line = _NUM_MASK[0].sub(_NUM_MASK[1], line)
    return line


# ---------------------------------------------------------------------------
# misc

def truncate_value(value: str, width: int = 48) -> str:
    value = value.replace("\n", "\\n")
    if len(value) <= width:
        return value
    return value[: width - 1] + "…"

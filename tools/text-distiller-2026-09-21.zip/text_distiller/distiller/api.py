"""High-level embedding API -- one call per capability, plain strings out.

This is the layer shells build on (CLI, GUI, MCP server): pure functions,
no argparse, no printing. Keep new shells thin by adding logic here.
"""

from __future__ import annotations

from .budget import distill_budget
from .build import distill_build
from .core import clip_to_budget, header
from .detect import detect_kind
from .diffs import distill_diff
from .jsondata import distill_json
from .logs import distill_log
from .search import distill_find, distill_search
from .skeleton import distill_skeleton
from .tabular import distill_csv
from .testreport import distill_testreport

KINDS = ("log", "build", "test", "json", "csv", "diff", "skeleton")


def run_kind(kind: str, text: str, pseudo_name: str = "") -> list[str]:
    """Run one distiller by name; returns body lines."""
    if kind == "log":
        return distill_log(text)
    if kind == "build":
        return distill_build(text)
    if kind == "test":
        return distill_testreport(text)
    if kind == "json":
        return distill_json(text)
    if kind == "csv":
        return distill_csv(text)
    if kind == "diff":
        return distill_diff(text)
    if kind == "skeleton":
        return distill_skeleton(text, pseudo_name or "input.txt")
    raise ValueError(f"unknown kind: {kind!r} (expected auto or one of {KINDS})")


def distill_any(text: str, kind: str = "auto", filename_hint: str = "",
                max_tokens: int = 2000) -> str:
    """Distill text; kind='auto' sniffs the content type first."""
    body: list[str] = []
    pseudo = filename_hint
    if kind == "auto":
        kind, reason, pseudo = detect_kind(text, filename_hint)
        body.append(f"detected: {kind} ({reason})")
    body += run_kind(kind, text, pseudo)
    body = clip_to_budget(body, max_tokens)
    out = "\n".join(body)
    return header(kind, text, out) + "\n" + out


def _split(spec: str) -> list[str]:
    return [g.strip() for g in spec.replace(",", ";").split(";") if g.strip()]


def search_text(pattern: str, path: str = ".", glob: str = "",
                files_only: bool = True, ignore_case: bool = False,
                word: bool = False, context: int = 0,
                max_tokens: int = 2000, fixed: bool = False,
                types: str = "") -> str:
    body = distill_search(pattern, [path], globs=_split(glob) or None,
                          ignore_case=ignore_case, word=word,
                          files_only=files_only, context=context,
                          fixed=fixed, types=_split(types) or None)
    return "\n".join(clip_to_budget(body, max_tokens))


def find_files(pattern: str = "", path: str = ".", types: str = "",
               max_tokens: int = 2000) -> str:
    body = distill_find(_split(pattern), [path], types=_split(types) or None)
    return "\n".join(clip_to_budget(body, max_tokens))


def budget_report(paths: list[str], max_tokens: int = 2000) -> str:
    return "\n".join(clip_to_budget(distill_budget(paths), max_tokens))

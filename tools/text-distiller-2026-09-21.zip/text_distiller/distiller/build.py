"""Extract errors/warnings from compiler and build-tool output.

Understands GCC/Clang/armclang, MSVC, GNU ld / MSVC link, CMake, make/ninja
and Python tracebacks. Everything else is dropped -- that is the point.
"""

from __future__ import annotations

import re

_GCC = re.compile(
    r"^(?P<file>(?:[A-Za-z]:)?[^:]+?):(?P<line>\d+):(?:(?P<col>\d+):)?"
    r"\s*(?P<level>fatal error|error|warning|note):\s*(?P<msg>.*)$"
)
_MSVC = re.compile(
    r"^(?P<file>.+?)\((?P<line>\d+)(?:,(?P<col>\d+))?\)\s*:\s*"
    r"(?P<level>fatal error|error|warning)\s+(?P<code>[A-Z]+\d+)\s*:\s*(?P<msg>.*)$"
)
_LD_UNDEF = re.compile(r"undefined reference to\s+(?P<sym>.+)$")
_LNK = re.compile(r"\b(?P<level>error|warning)\s+(?P<code>LNK\d+)\s*:\s*(?P<msg>.*)$")
_CMAKE = re.compile(
    r"^CMake (?P<level>Error|Warning)(?: at (?P<file>[^:]+):(?P<line>\d+))?"
)
_MAKE = re.compile(r"^(?:make(?:\[\d+\])?|ninja): \*\*\*\s*(?P<msg>.*)$|^ninja: error: (?P<msg2>.*)$")
_PY_TB_START = re.compile(r"^Traceback \(most recent call last\):")
_PY_TB_FILE = re.compile(r'^\s+File "(?P<file>[^"]+)", line (?P<line>\d+)')
# SyntaxError blocks have NO "Traceback" header: bare File-line, code, caret,
# then the exception line at column 0
_PY_EXC = re.compile(r"^[A-Za-z_][\w.]*(?:Error|Exception)\b.*$")


def distill_build(text: str, include_notes: bool = False) -> list[str]:
    lines = text.splitlines()
    # finding key -> [count]; key = (level, rendered message line)
    findings: dict[tuple[str, str], int] = {}
    order: list[tuple[str, str]] = []
    raw_matches = 0

    def add(level: str, rendered: str) -> None:
        nonlocal raw_matches
        raw_matches += 1
        key = (level, rendered)
        if key in findings:
            findings[key] += 1
        else:
            findings[key] = 1
            order.append(key)

    i = 0
    n = len(lines)
    while i < n:
        line = lines[i].rstrip()

        m = _GCC.match(line)
        if m:
            level = "error" if "error" in m["level"] else m["level"]
            if level != "note" or include_notes:
                add(level, f"{m['file']}:{m['line']}: {m['msg']}")
            i += 1
            continue

        m = _MSVC.match(line)
        if m:
            level = "error" if "error" in m["level"] else "warning"
            add(level, f"{m['file']}({m['line']}): {m['code']}: {m['msg']}")
            i += 1
            continue

        m = _LNK.search(line)
        if m:
            add(m["level"], f"link: {m['code']}: {m['msg']}")
            i += 1
            continue

        m = _LD_UNDEF.search(line)
        if m:
            add("error", f"link: undefined reference to {m['sym']}")
            i += 1
            continue

        m = _CMAKE.match(line)
        if m:
            level = m["level"].lower()
            loc = f"{m['file']}:{m['line']}: " if m["file"] else ""
            # first non-empty following line is the message body
            msg = ""
            j = i + 1
            while j < n and j < i + 6:
                if lines[j].strip():
                    msg = lines[j].strip()
                    break
                j += 1
            add(level, f"cmake: {loc}{msg}")
            i += 1
            continue

        m = _MAKE.match(line)
        if m:
            add("error", f"build: {m['msg'] or m['msg2']}")
            i += 1
            continue

        m = _PY_TB_FILE.match(line)
        if m:  # headerless block (SyntaxError and friends)
            loc = f"{m['file']}:{m['line']}"
            exc = ""
            j = i + 1
            while j < n and j < i + 8:
                if _PY_EXC.match(lines[j]):
                    exc = lines[j].strip()
                    break
                j += 1
            if exc:
                add("error", f"python: {exc} (at {loc})")
                i = j + 1
                continue

        if _PY_TB_START.match(line):
            last_file = ""
            j = i + 1
            while j < n:
                fm = _PY_TB_FILE.match(lines[j])
                if fm:
                    last_file = f"{fm['file']}:{fm['line']}"
                    j += 1
                elif lines[j].startswith((" ", "\t")) or not lines[j].strip():
                    j += 1
                else:
                    break  # exception line reached
            exc = lines[j].strip() if j < n else "(traceback cut off)"
            at = f" (at {last_file})" if last_file else ""
            add("error", f"python: {exc}{at}")
            i = j + 1
            continue

        i += 1

    by_level: dict[str, list[tuple[str, int]]] = {}
    for (level, rendered) in order:
        by_level.setdefault(level, []).append((rendered, findings[(level, rendered)]))

    n_err = sum(c for _, c in by_level.get("error", []))
    n_warn = sum(c for _, c in by_level.get("warning", []))
    body = [
        f"errors={n_err} warnings={n_warn}"
        f" (unique: {len(by_level.get('error', []))} errors,"
        f" {len(by_level.get('warning', []))} warnings; raw matches={raw_matches})"
    ]
    for level in ("error", "warning", "note"):
        items = by_level.get(level)
        if not items:
            continue
        body.append(f"{level}s:")
        for rendered, count in items:
            suffix = f"  [x{count}]" if count > 1 else ""
            body.append(f"  {rendered}{suffix}")
    if raw_matches == 0:
        body.append("(no errors or warnings recognised -- build looks clean,"
                    " or the tool's format is not supported yet)")
    return body

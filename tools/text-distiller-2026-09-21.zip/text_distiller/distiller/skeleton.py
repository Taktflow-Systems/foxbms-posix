"""Extract the structural outline of a source file (signatures, no bodies).

An agent that needs "what's in this file" should read the skeleton (cheap),
then use `slice` to pull only the function bodies it actually needs.

Python files are parsed with ast (exact). C/C++/headers use a brace-depth
heuristic (approximate but deterministic). Markdown gives the `#` heading
outline (fenced code skipped); shell scripts (.sh/.bash/... or a shell shebang)
list `name() {` and `function name` definitions. Everything else falls back to
a keyword/indent heuristic.
"""

from __future__ import annotations

import ast
import re

_C_EXTS = {".c", ".h", ".cpp", ".hpp", ".cc", ".hh", ".cxx", ".ino"}
_MD_EXTS = {".md", ".markdown", ".mdown", ".mkd"}
_SH_EXTS = {".sh", ".bash", ".zsh", ".ksh"}
_SH_SHEBANG = re.compile(r"^#!.*\b(?:ba|z|k|da)?sh\b")
_MD_HEADING = re.compile(r"^ {0,3}(#{1,6})(?:[ \t]+(.*?))?(?:[ \t]+#+)?[ \t]*$")
_MD_FENCE = re.compile(r"^ {0,3}(`{3,}|~{3,})")
_SH_FUNC = re.compile(
    r"^\s*(?:function\s+([\w.:@+-]+)\s*(?:\(\s*\))?|([\w.:@+-]+)\s*\(\s*\))\s*(?:\{|\(|$)"
)
_C_KEYWORDS_NOT_FUNC = re.compile(
    r"^\s*(if|else|while|for|switch|return|do|case|sizeof)\b"
)
_GENERIC_DECL = re.compile(
    r"^\s*(export\s+|pub(?:\(\w+\))?\s+|public\s+|private\s+|protected\s+|static\s+|async\s+)*"
    r"(function|class|interface|enum|struct|trait|impl|fn|type|module|namespace|def)\b"
)


def distill_skeleton(text: str, filename: str) -> list[str]:
    lower = filename.lower()
    if lower.endswith(".py"):
        try:
            return _python_skeleton(text)
        except SyntaxError as exc:
            return [f"(python parse failed: {exc.msg} at line {exc.lineno};"
                    " falling back to generic outline)"] + _generic_skeleton(text)
    if any(lower.endswith(ext) for ext in _C_EXTS):
        return _c_skeleton(text)
    if any(lower.endswith(ext) for ext in _MD_EXTS):
        return _markdown_skeleton(text)
    if any(lower.endswith(ext) for ext in _SH_EXTS) or _SH_SHEBANG.match(text[:200]):
        return _shell_skeleton(text)
    return _generic_skeleton(text)


# ---------------------------------------------------------------------------

def _markdown_skeleton(text: str) -> list[str]:
    out: list[str] = []
    fence: str | None = None
    for lineno, raw in enumerate(text.splitlines(), 1):
        m = _MD_FENCE.match(raw)
        if m:
            mark = m.group(1)
            if fence is None:
                fence = mark
            elif mark[0] == fence[0] and len(mark) >= len(fence):
                fence = None
            continue
        if fence is not None:
            continue
        h = _MD_HEADING.match(raw)
        if h:
            level = len(h.group(1))
            out.append(f"{lineno:>5}: {'  ' * (level - 1)}{h.group(1)} {h.group(2) or ''}".rstrip())
    if not out:
        out.append("(no # headings found -- use `slice` with a pattern instead)")
    return out


def _shell_skeleton(text: str) -> list[str]:
    out: list[str] = []
    for lineno, raw in enumerate(text.splitlines(), 1):
        s = raw.strip()
        if not s or s.startswith("#"):
            continue
        if _SH_FUNC.match(raw):
            out.append(f"{lineno:>5}: {s}")
    if not out:
        out.append("(no shell functions found -- use `slice` with a pattern instead)")
    return out


# ---------------------------------------------------------------------------

def _python_skeleton(text: str) -> list[str]:
    tree = ast.parse(text)
    src = text.splitlines()
    out: list[str] = []

    imports: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(a.name for a in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.append(node.module or ".")
    if imports:
        shown = sorted(set(imports))
        head = ", ".join(shown[:20]) + (" …" if len(shown) > 20 else "")
        out.append(f"imports: {head}")

    def visit(node: ast.AST, depth: int) -> None:
        for child in ast.iter_child_nodes(node):
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                line = src[child.lineno - 1].strip()
                out.append(f"{child.lineno:>5}: {'  ' * depth}{line}")
                visit(child, depth + 1)
            elif depth == 0 and isinstance(child, ast.Assign):
                # module-level CONSTANTS are part of the file's interface
                names = [t.id for t in child.targets
                         if isinstance(t, ast.Name) and t.id.isupper()]
                if names:
                    out.append(f"{child.lineno:>5}: {', '.join(names)} = …")
            elif isinstance(child, (ast.If, ast.Try, ast.With)):
                visit(child, depth)  # catch defs under `if __name__`, try, with

    visit(tree, 0)
    if not out:
        out.append("(no top-level definitions found)")
    return out


# ---------------------------------------------------------------------------

def _c_skeleton(text: str) -> list[str]:
    out: list[str] = []
    depth = 0
    in_block_comment = False
    for lineno, raw in enumerate(text.splitlines(), 1):
        s = raw.strip()
        if in_block_comment:
            if "*/" in s:
                in_block_comment = False
            continue
        if s.startswith("/*") and "*/" not in s:
            in_block_comment = True
            continue
        if not s or s.startswith(("//", "*", "/*")):
            continue

        if depth == 0:
            if s.startswith(("#include", "#define", "typedef", "extern")):
                out.append(f"{lineno:>5}: {s}")
            elif re.match(r"^(static\s+|const\s+)*(struct|union|enum|class)\b", s):
                out.append(f"{lineno:>5}: {s}")
            elif _looks_like_c_function(s):
                out.append(f"{lineno:>5}: {s}")

        depth += raw.count("{") - raw.count("}")
        if depth < 0:
            depth = 0  # tolerate unbalanced input
    if not out:
        out.append("(no top-level declarations found)")
    return out


def _looks_like_c_function(s: str) -> bool:
    if "(" not in s or _C_KEYWORDS_NOT_FUNC.match(s):
        return False
    return s.endswith(("{", ")", ");", ",")) or ") {" in s


# ---------------------------------------------------------------------------

def _generic_skeleton(text: str) -> list[str]:
    out: list[str] = []
    for lineno, raw in enumerate(text.splitlines(), 1):
        s = raw.strip()
        if not s:
            continue
        indent = len(raw) - len(raw.lstrip())
        if _GENERIC_DECL.match(raw) and indent <= 4:
            out.append(f"{lineno:>5}: {s}")
    if not out:
        out.append("(no declarations recognised -- use `slice` with a pattern instead)")
    return out

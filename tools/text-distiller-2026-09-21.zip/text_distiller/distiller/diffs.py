"""Compress a unified diff to per-file stats + hunk headers.

Feed it `git diff` / `git show` output. Use --full <glob> to keep full hunks
for the files that actually matter.
"""

from __future__ import annotations

import fnmatch
import re

_DIFF_GIT = re.compile(r"^diff --git a/(?P<a>.+?) b/(?P<b>.+)$")
_PLUS_FILE = re.compile(r"^\+\+\+ (?:b/)?(?P<path>.+)$")
_HUNK = re.compile(r"^@@ -\d+(?:,\d+)? \+(?P<start>\d+)(?:,\d+)? @@ ?(?P<ctx>.*)$")


def distill_diff(text: str, full_globs: list[str] | None = None) -> list[str]:
    full_globs = full_globs or []
    files: list[dict] = []
    current: dict | None = None

    for line in text.splitlines():
        m = _DIFF_GIT.match(line)
        if m:
            current = {"path": m["b"], "added": 0, "removed": 0,
                       "hunks": [], "status": "M", "lines": [line]}
            files.append(current)
            continue
        if current is None:
            m = _PLUS_FILE.match(line)
            if m and m["path"] != "/dev/null":
                # plain (non-git) unified diff
                current = {"path": m["path"], "added": 0, "removed": 0,
                           "hunks": [], "status": "M", "lines": [line]}
                files.append(current)
                continue
        if current is None:
            continue

        current["lines"].append(line)
        if line.startswith("new file mode"):
            current["status"] = "A"
        elif line.startswith("deleted file mode"):
            current["status"] = "D"
        elif line.startswith("rename to "):
            current["status"] = "R"
        else:
            m = _HUNK.match(line)
            if m:
                ctx = m["ctx"].strip()
                current["hunks"].append(
                    f"@{m['start']}" + (f" {ctx}" if ctx else "")
                )
            elif line.startswith("+") and not line.startswith("+++"):
                current["added"] += 1
            elif line.startswith("-") and not line.startswith("---"):
                current["removed"] += 1

    total_add = sum(f["added"] for f in files)
    total_rem = sum(f["removed"] for f in files)
    body = [f"files={len(files)} +{total_add} -{total_rem}"]
    if not files:
        body.append("(no diff content recognised)")
        return body

    for f in files:
        hunks = "; ".join(f["hunks"][:8])
        if len(f["hunks"]) > 8:
            hunks += f"; …+{len(f['hunks']) - 8} more"
        body.append(f"  {f['status']} {f['path']}  +{f['added']} -{f['removed']}"
                    + (f"  [{hunks}]" if hunks else ""))

    shown_full = [f for f in files
                  if any(fnmatch.fnmatch(f["path"], g) for g in full_globs)]
    for f in shown_full:
        body.append(f"--- full diff: {f['path']} ---")
        body.extend(f["lines"])
    return body

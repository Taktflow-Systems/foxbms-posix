"""Token budget report: estimate cost-to-read before reading anything.

Points an agent at the expensive files so it can distill instead of Read.
Directories are enumerated with the same walker as search/find (default
excludes, .gitignore rules, loop guard), so the three commands agree on the tree.
"""

from __future__ import annotations

from pathlib import Path

from .core import decode_bytes, est_tokens, wide_encoding
from .search import iter_files

_WARN_TOKENS = 25_000


def distill_budget(paths: list[str], no_ignore: bool = False,
                   no_default_excludes: bool = False) -> list[str]:
    files: list[Path] = iter_files(paths, no_default_excludes, no_ignore)

    rows: list[tuple[int, str]] = []  # (tokens, rendered) for sorting
    total_tokens = 0
    total_lines = 0
    binaries = 0
    for f in files:
        try:
            with open(f, "rb") as fh:
                head = fh.read(8192)
                if b"\0" in head and wide_encoding(head) is None:
                    binaries += 1
                    size = f.stat().st_size
                    rows.append((0, f"      -       - {size:>10} {f}  (binary, skipped)"))
                    continue
                raw = head + fh.read()
        except OSError as exc:
            rows.append((0, f"      -       -          - {f}  (unreadable: {exc.strerror})"))
            continue
        text = decode_bytes(raw)
        tokens = est_tokens(text)
        lines = text.count("\n") + (1 if text and not text.endswith("\n") else 0)
        total_tokens += tokens
        total_lines += lines
        flag = " !" if tokens > _WARN_TOKENS else ""
        rows.append((tokens, f"{tokens:>7} {lines:>7} {len(raw):>10} {f}{flag}"))

    rows.sort(key=lambda r: -r[0])
    body = [f"{'~tokens':>7} {'lines':>7} {'bytes':>10} path   (! = >{_WARN_TOKENS} tok: distill, don't read)"]
    body.extend(r[1] for r in rows)
    body.append(f"total: {len(files)} files, ~{total_tokens} tokens, {total_lines} lines,"
                f" binaries-skipped={binaries}")
    return body

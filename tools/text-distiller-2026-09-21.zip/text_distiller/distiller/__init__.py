"""text_distiller -- deterministic text compression tools for AI workflows.

Every command turns a large text artifact (log, build output, test report,
source file, JSON, CSV, diff) into a compact, lossless-where-it-matters
summary so an agent spends tokens on signal, not noise. No LLM calls, no
network, no randomness: same input always produces the same output.
"""

__version__ = "0.1.0"

"""Summarise the structure of JSON / JSONL files instead of dumping them.

Output is a bounded schema tree with types, array lengths, key-presence
counts for arrays of objects, and one truncated sample value per leaf.
"""

from __future__ import annotations

import json

from .core import truncate_value

_MAX_DEPTH = 5
_MAX_KEYS = 40
_MAX_LIST_SAMPLE = 50


def distill_json(text: str, jsonl: bool = False) -> list[str]:
    if jsonl or _looks_like_jsonl(text):
        values = []
        total = 0
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            total += 1
            if len(values) < _MAX_LIST_SAMPLE:
                values.append(json.loads(line))
        body = [f"jsonl records={total} (schema from first {len(values)})"]
        _render(values, "record[]", 1, body, is_jsonl_root=True)
        return body

    value = json.loads(text)
    body: list[str] = []
    _render(value, "root", 0, body)
    return body


def _looks_like_jsonl(text: str) -> bool:
    lines = [l for l in text.splitlines() if l.strip()]
    if len(lines) < 2:
        return False
    first, second = lines[0].strip(), lines[1].strip()
    return first.startswith(("{", "[")) and first.endswith(("}", "]")) \
        and second.startswith(("{", "["))


def _type_name(value) -> str:
    if value is None:
        return "null"
    return {bool: "bool", int: "int", float: "float", str: "str"}.get(
        type(value), type(value).__name__
    )


def _render(value, label: str, depth: int, out: list[str], is_jsonl_root: bool = False) -> None:
    pad = "  " * depth
    if isinstance(value, dict):
        out.append(f"{pad}{label}: object ({len(value)} keys)")
        if depth >= _MAX_DEPTH:
            out.append(f"{pad}  … (max depth)")
            return
        for i, key in enumerate(value):
            if i >= _MAX_KEYS:
                out.append(f"{pad}  … +{len(value) - _MAX_KEYS} more keys")
                break
            _render(value[key], key, depth + 1, out)
    elif isinstance(value, list):
        if not is_jsonl_root:
            elem_types = sorted({_type_name(v) for v in value[:_MAX_LIST_SAMPLE]}) or ["?"]
            out.append(f"{pad}{label}: array[{len(value)}] of {'|'.join(elem_types)}")
        else:
            out.append(f"{pad}{label}:")
        if depth >= _MAX_DEPTH:
            return
        sample = value[:_MAX_LIST_SAMPLE]
        if sample and all(isinstance(v, dict) for v in sample):
            merged = _merge_object_keys(sample)
            for i, (key, (count, example)) in enumerate(merged.items()):
                if i >= _MAX_KEYS:
                    out.append(f"{pad}  … +{len(merged) - _MAX_KEYS} more keys")
                    break
                opt = "" if count == len(sample) else f"  (in {count}/{len(sample)})"
                _render(example, key + opt, depth + 1, out)
        elif sample and any(isinstance(v, (dict, list)) for v in sample):
            _render(sample[0], "[0]", depth + 1, out)
    else:
        sample = truncate_value(json.dumps(value, ensure_ascii=False))
        out.append(f"{pad}{label}: {_type_name(value)} {sample}")


def _merge_object_keys(objs: list[dict]) -> dict:
    """key -> (presence count, first example value), key order = first seen."""
    merged: dict = {}
    for obj in objs:
        for key, val in obj.items():
            if key in merged:
                merged[key][0] += 1
            else:
                merged[key] = [1, val]
    return {k: (c, v) for k, (c, v) in merged.items()}

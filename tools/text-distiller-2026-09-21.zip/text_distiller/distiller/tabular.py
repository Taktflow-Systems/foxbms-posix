"""Summarise CSV/TSV files: shape, per-column type/distinct stats, samples."""

from __future__ import annotations

import csv
import io

from .core import truncate_value

_DISTINCT_CAP = 1000


def distill_csv(text: str, delimiter: str | None = None,
                sample_rows: int = 5, no_header: bool = False) -> list[str]:
    if delimiter is None:
        delimiter = _sniff_delimiter(text)
    reader = csv.reader(io.StringIO(text), delimiter=delimiter)

    rows = iter(reader)
    try:
        first = next(rows)
    except StopIteration:
        return ["(empty file)"]

    if no_header:
        header = [f"col{i}" for i in range(len(first))]
        first_data: list[list[str]] | None = [first]
    else:
        header = first
        first_data = None

    ncols = len(header)
    distinct: list[set] = [set() for _ in range(ncols)]
    examples: list[list[str]] = [[] for _ in range(ncols)]
    all_int = [True] * ncols
    all_float = [True] * ncols
    n_empty = [0] * ncols
    samples: list[list[str]] = []
    nrows = 0

    def feed(row: list[str]) -> None:
        nonlocal nrows
        nrows += 1
        if len(samples) < sample_rows:
            samples.append(row)
        for i in range(min(len(row), ncols)):
            value = row[i].strip()
            if not value:
                n_empty[i] += 1
                continue
            if len(distinct[i]) <= _DISTINCT_CAP:
                if value not in distinct[i] and len(examples[i]) < 4:
                    examples[i].append(value)
                distinct[i].add(value)
            if all_int[i] and not _is_int(value):
                all_int[i] = False
            if all_float[i] and not _is_float(value):
                all_float[i] = False

    if first_data:
        for row in first_data:
            feed(row)
    for row in rows:
        if row:
            feed(row)

    delim_repr = {"\t": "\\t"}.get(delimiter, delimiter)
    body = [f"rows={nrows} cols={ncols} delimiter='{delim_repr}'", "columns:"]
    for i, name in enumerate(header):
        filled = nrows - n_empty[i]
        if filled == 0:
            ctype = "empty"
        elif all_int[i]:
            ctype = "int"
        elif all_float[i]:
            ctype = "float"
        else:
            ctype = "str"
        nd = len(distinct[i])
        nd_repr = f"{_DISTINCT_CAP}+" if nd > _DISTINCT_CAP else str(nd)
        ex = ", ".join(truncate_value(e, 32) for e in examples[i])
        empty_note = f" empty={n_empty[i]}" if n_empty[i] else ""
        body.append(f"  [{i}] {name}: {ctype} distinct={nd_repr}{empty_note}  e.g. {ex}")

    if samples:
        body.append(f"first {len(samples)} rows:")
        for row in samples:
            body.append("  " + delimiter.join(truncate_value(v, 24) for v in row))
    return body


def _sniff_delimiter(text: str) -> str:
    head = text[:4096]
    try:
        return csv.Sniffer().sniff(head, delimiters=",;\t|").delimiter
    except csv.Error:
        return ","


def _is_int(value: str) -> bool:
    try:
        int(value)
        return True
    except ValueError:
        return False


def _is_float(value: str) -> bool:
    try:
        float(value)
        return True
    except ValueError:
        return False

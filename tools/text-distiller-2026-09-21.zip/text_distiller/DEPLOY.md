# Deploying the text_distiller workflow to a new PC

The bundle is the complete token-discipline setup for a Claude Code
workstation: deterministic distillers, repo search, GUI, MCP server, agent
rules (CLAUDE.md), and the /distill skill. Read enforcement is not in the
bundle: it is the user-level read-policy hook described below.

## What's in the bundle

```
CLAUDE.md                      agent rules (token discipline, read policy)
.mcp.json                      MCP server registration (text-distiller)
.claude/settings.json          project settings (no hooks: the read policy is user-level)
.claude/skills/distill/SKILL.md   /distill recipe card
tools/text_distiller/          the toolkit (CLI, GUI, MCP, tests, docs)
```

## Read policy

Policy P2, the whole-file mandate. The user-level PreToolUse hook
`~/.claude/hooks/enforce_full_reads.py` blocks the Grep and Glob tools, the
Explore agent, `Read` with offset or limit, and shell `grep`, `rg`, `find`,
`head`, `tail`, `sed -n`, `awk NR`, `git grep`, `git ls-files` and wildcard
`ls` (also inside `bash -c`). Locate with `distill.py search` or `find`;
`skeleton`, `slice` and `budget` help decide what to read; then `Read` the
chosen files whole, at any size. Exceptions: `tail -f` on a `*.log` file,
and lines in `~/.claude/hooks/full-read-allowlist.txt` (ask the user before
adding one). The project hook `distill_hook.py` is retired and no longer
registered. Without the user-level hook these rules are advisory.
Policy source of truth: ~/.claude/hooks/read_policy.py

To enforce it on the target PC, that user profile needs `read_policy.py`,
`enforce_full_reads.py` and `full-read-allowlist.txt` in `~/.claude/hooks/`,
registered in the user settings on the matcher
`Grep|Glob|Read|Bash|PowerShell|Agent`. Those files are maintained outside
this bundle; copy them from a workstation that already has them.

## Requirements on the target PC

- Python 3.9+ on PATH (tested on 3.14). Nothing else — no pip packages,
  no binaries. tkinter ships with the standard Windows Python installer.
- Claude Code opens the folder these files land in as its project root
  (all paths are relative to it).

## Install

1. Unzip the bundle into the project folder Claude Code will open
   (or merge into the existing repo clone there — same relative layout).
2. From that folder, verify:

   ```powershell
   powershell -File tools\text_distiller\deploy_check.ps1
   python -m pytest tools\text_distiller\tests -q
   ```

   Expect from the script: the Python version, the distill-layer tests via
   unittest discovery (62 of the 74; the other 12 use pytest's `tmp_path`
   fixture), 5 cleaner tests OK, `ok:` for each config file. Its hook
   pipe-test still exercises the retired `distill_hook.py` and proves
   nothing about enforcement. Expect from pytest: `74 passed`.
3. Start Claude Code in that folder.
4. Acceptance test, only where the user-level hook is installed: a `Grep`
   tool call is blocked with the distiller redirect message, and a whole
   `Read` of a text file larger than 8 KB succeeds.

## Optional

- **MCP server**: on first session Claude Code asks to approve the
  `text-distiller` server from `.mcp.json`. Approve it only if a tool-only
  model needs it; agents with shell access should keep using the CLI
  (zero schema cost).
- **GUI for humans**: `python tools\text_distiller\distill_gui.py`

## Known limits

- Interpreters and slicing tools (`python -c`, `perl`, `cut`, `more`,
  `sqlite3`, `git log -L`, `tree`) are out of scope for the hook by design:
  it stops habit, not intent.
- `tools/text_distiller/README.md` and `TOKEN_ECONOMY_PLAYBOOK.md` document
  everything else (commands, MCP tools, usage policy).

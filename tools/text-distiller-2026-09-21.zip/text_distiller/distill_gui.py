#!/usr/bin/env python3
"""Text Distiller GUI -- run it, tick the options you want, press the button.

    python tools\\text_distiller\\distill_gui.py

Two functions, one tab each:
  * Search repo        -- which files contain this pattern (checkbox options)
  * Distill pasted text -- paste into the input pane, pick a command, distill

A thin shell over the same CLI (distiller.cli.main): every button builds the
equivalent command line, so GUI and CLI can never behave differently.
Stdlib tkinter only, no dependencies.
"""

from __future__ import annotations

import contextlib
import io
import os
import shlex
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# commands that make sense on pasted text (budget/search/slice are path- or
# pattern-driven; search has its own tab)
COMMANDS = ["clean", "log", "build", "test", "skeleton", "json", "csv", "diff"]

# which checkbox is translated to a flag for which command
FLAG_SUPPORT = {
    "errors_only": {"log"},
    "mask_numbers": {"log"},
    "sort_count": {"log"},
    "strip_ansi": {"log", "build", "test", "slice", "diff"},
}


# ---------------------------------------------------------------------------
# headless core (unit-tested; no tkinter)

def compose_argv(command: str, options: str, input_path: str) -> list[str]:
    return [command] + shlex.split(options) + [input_path]


def build_distill_flags(command: str, checks: dict) -> list[str]:
    """Translate ticked checkboxes into CLI flags valid for `command`."""
    flags: list[str] = []
    if checks.get("errors_only") and command in FLAG_SUPPORT["errors_only"]:
        flags += ["--level", "error"]
    if checks.get("mask_numbers") and command in FLAG_SUPPORT["mask_numbers"]:
        flags.append("--mask-numbers")
    if checks.get("sort_count") and command in FLAG_SUPPORT["sort_count"]:
        flags.append("--sort-count")
    if checks.get("strip_ansi") and command in FLAG_SUPPORT["strip_ansi"]:
        flags.append("--clean")
    return flags


def build_search_argv(pattern: str, folder: str, checks: dict,
                      file_filter: str = "", context: int = 0) -> list[str]:
    argv = ["search", pattern, folder]
    if checks.get("ignore_case"):
        argv.append("-i")
    if checks.get("word"):
        argv.append("-w")
    if checks.get("files_only"):
        argv.append("-l")
    if checks.get("search_all"):
        argv.append("--no-default-excludes")
    for g in file_filter.replace(",", ";").split(";"):
        if g.strip():
            argv += ["-g", g.strip()]
    if context:
        argv += ["-C", str(context)]
    return argv


def _run_cli(argv: list[str]) -> str:
    from distiller.cli import main
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        try:
            main(argv)
        except SystemExit:
            pass  # argparse already wrote its message to stderr
    # stderr first: clean's header and any usage errors
    return err.getvalue() + out.getvalue()


def run_distill(command: str, options: str, text: str,
                filename_hint: str = "") -> str:
    """Run a distill command on pasted text; returns combined output.

    The hint's extension drives language detection for `skeleton`
    (e.g. "foo.c" -> C outline).
    """
    suffix = os.path.splitext(filename_hint)[1] or ".txt"
    tmp = tempfile.NamedTemporaryFile("w", suffix=suffix, delete=False,
                                      encoding="utf-8")
    try:
        tmp.write(text)
        tmp.close()
        return _run_cli(compose_argv(command, options, tmp.name)).replace(
            tmp.name, "<input>")
    finally:
        os.unlink(tmp.name)


def run_search(pattern: str, folder: str, checks: dict,
               file_filter: str = "", context: int = 0) -> str:
    return _run_cli(build_search_argv(pattern, folder, checks,
                                      file_filter, context))


def run_auto(text: str, checks: dict, filename_hint: str = "") -> str:
    """Detect what the text is, then distill it with the gated options."""
    from distiller.detect import detect_kind
    command, reason, pseudo = detect_kind(text, filename_hint)
    flags = build_distill_flags(command, checks)
    result = run_distill(command, " ".join(flags), text,
                         filename_hint or pseudo)
    return f"# auto-detected: {command} ({reason})\n{result}"


# ---------------------------------------------------------------------------
# GUI

def main_gui() -> None:
    import tkinter as tk
    from tkinter import filedialog, ttk

    root = tk.Tk()
    root.title("Text Distiller")
    root.geometry("1000x740")

    status_var = tk.StringVar(value="ready")

    def make_output(parent) -> tk.Text:
        frame = ttk.LabelFrame(parent, text="Output")
        text = tk.Text(frame, wrap="none", font=("Consolas", 10))
        ys = ttk.Scrollbar(frame, orient="vertical", command=text.yview)
        xs = ttk.Scrollbar(frame, orient="horizontal", command=text.xview)
        text.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        ys.pack(side="right", fill="y")
        xs.pack(side="bottom", fill="x")
        text.pack(fill="both", expand=True)
        frame.pack(fill="both", expand=True, padx=4, pady=4)
        return text

    def show(widget: tk.Text, result: str) -> None:
        widget.delete("1.0", "end")
        widget.insert("1.0", result)
        first = result.splitlines()[0] if result.strip() else "(empty output)"
        status_var.set(first)

    def save(widget: tk.Text, name: str) -> None:
        content = widget.get("1.0", "end-1c")
        if not content.strip():
            status_var.set("nothing to save -- run first")
            return
        os.makedirs("output", exist_ok=True)
        path = os.path.join("output", name)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content + ("\n" if not content.endswith("\n") else ""))
        status_var.set(f"wrote: {os.path.abspath(path)}")

    notebook = ttk.Notebook(root)
    notebook.pack(fill="both", expand=True)

    # ------------------------------------------------------------------ tab 1
    search_tab = ttk.Frame(notebook)
    notebook.add(search_tab, text="  Search repo  ")

    form = ttk.Frame(search_tab, padding=4)
    form.pack(fill="x")
    ttk.Label(form, text="Find text:").grid(row=0, column=0, sticky="w")
    pattern_var = tk.StringVar()
    ttk.Entry(form, textvariable=pattern_var, width=50).grid(
        row=0, column=1, sticky="we", padx=4)
    ttk.Label(form, text="In folder:").grid(row=1, column=0, sticky="w")
    folder_var = tk.StringVar(value=os.getcwd())
    ttk.Entry(form, textvariable=folder_var, width=50).grid(
        row=1, column=1, sticky="we", padx=4)

    def browse() -> None:
        path = filedialog.askdirectory(initialdir=folder_var.get() or ".")
        if path:
            folder_var.set(path)

    ttk.Button(form, text="Browse…", command=browse).grid(row=1, column=2)
    ttk.Label(form, text="File types:").grid(row=2, column=0, sticky="w")
    filter_var = tk.StringVar()
    ttk.Entry(form, textvariable=filter_var, width=50).grid(
        row=2, column=1, sticky="we", padx=4)
    ttk.Label(form, text="e.g. *.c;*.h (empty = all)").grid(
        row=2, column=2, sticky="w")
    form.columnconfigure(1, weight=1)

    checks_frame = ttk.LabelFrame(search_tab, text="Options", padding=4)
    checks_frame.pack(fill="x", padx=4)
    search_checks = {
        "ignore_case": tk.BooleanVar(value=True),
        "word": tk.BooleanVar(),
        "files_only": tk.BooleanVar(value=True),
        "search_all": tk.BooleanVar(),
    }
    labels = [("ignore_case", "Ignore case"),
              ("word", "Whole word only"),
              ("files_only", "List files only (no match lines)"),
              ("search_all", "Also search .git / node_modules / caches")]
    for i, (key, label) in enumerate(labels):
        ttk.Checkbutton(checks_frame, text=label,
                        variable=search_checks[key]).grid(
            row=i // 2, column=i % 2, sticky="w", padx=8)
    ttk.Label(checks_frame, text="Context lines:").grid(
        row=2, column=0, sticky="w", padx=8)
    context_var = tk.IntVar(value=0)
    ttk.Spinbox(checks_frame, from_=0, to=10, textvariable=context_var,
                width=4).grid(row=2, column=1, sticky="w")

    search_out = make_output(search_tab)

    def do_search() -> None:
        if not pattern_var.get().strip():
            status_var.set("enter a search text first")
            return
        result = run_search(
            pattern_var.get(), folder_var.get() or ".",
            {k: v.get() for k, v in search_checks.items()},
            filter_var.get(), context_var.get())
        show(search_out, result)

    buttons = ttk.Frame(search_tab, padding=4)
    buttons.pack(fill="x", before=search_out.master)
    ttk.Button(buttons, text="Search", command=do_search).pack(side="left")
    ttk.Button(buttons, text="Save output",
               command=lambda: save(search_out, "search.txt")).pack(
        side="left", padx=6)

    # ------------------------------------------------------------------ tab 2
    distill_tab = ttk.Frame(notebook)
    notebook.add(distill_tab, text="  Distill pasted text  ")

    cmd_frame = ttk.LabelFrame(distill_tab, text="What is the pasted text?",
                               padding=4)
    cmd_frame.pack(fill="x", padx=4, pady=(4, 0))
    command_var = tk.StringVar(value="auto")
    cmd_labels = [("auto", "Auto detect"),
                  ("log", "Log file (collapse repeats)"),
                  ("build", "Build/compiler output (errors only)"),
                  ("test", "Test output (failures only)"),
                  ("clean", "Messy text (strip terminal noise)"),
                  ("skeleton", "Source code (outline only)"),
                  ("json", "JSON (schema summary)"),
                  ("csv", "CSV (column stats)"),
                  ("diff", "Diff (per-file stats)")]
    for i, (value, label) in enumerate(cmd_labels):
        ttk.Radiobutton(cmd_frame, text=label, value=value,
                        variable=command_var).grid(
            row=i // 4, column=i % 4, sticky="w", padx=6)

    opt_frame = ttk.LabelFrame(
        distill_tab, text="Options (applied when the command supports them)",
        padding=4)
    opt_frame.pack(fill="x", padx=4)
    distill_checks = {
        "errors_only": tk.BooleanVar(),
        "mask_numbers": tk.BooleanVar(),
        "sort_count": tk.BooleanVar(),
        "strip_ansi": tk.BooleanVar(value=True),
    }
    opt_labels = [("errors_only", "Errors/failures only (log)"),
                  ("mask_numbers", "Mask numbers when grouping (log)"),
                  ("sort_count", "Most frequent first (log)"),
                  ("strip_ansi", "Strip ANSI colors first")]
    for i, (key, label) in enumerate(opt_labels):
        ttk.Checkbutton(opt_frame, text=label,
                        variable=distill_checks[key]).grid(
            row=0, column=i, sticky="w", padx=6)
    ttk.Label(opt_frame, text="Filename hint (for code):").grid(
        row=1, column=0, columnspan=2, sticky="w", padx=6)
    hint_var = tk.StringVar()
    ttk.Entry(opt_frame, textvariable=hint_var, width=16).grid(
        row=1, column=2, sticky="w")

    in_frame = ttk.LabelFrame(distill_tab, text="Input (paste here, or Open file…)")
    input_text = tk.Text(in_frame, wrap="none", height=12, undo=True,
                         font=("Consolas", 10))
    in_ys = ttk.Scrollbar(in_frame, orient="vertical", command=input_text.yview)
    input_text.configure(yscrollcommand=in_ys.set)
    in_ys.pack(side="right", fill="y")
    input_text.pack(fill="both", expand=True)
    in_frame.pack(fill="both", expand=True, padx=4, pady=4)

    def open_file() -> None:
        path = filedialog.askopenfilename()
        if not path:
            return
        with open(path, encoding="utf-8", errors="replace") as f:
            content = f.read()
        input_text.delete("1.0", "end")
        input_text.insert("1.0", content)
        hint_var.set(os.path.basename(path))
        status_var.set(f"loaded: {path}")

    def do_distill() -> None:
        command = command_var.get()
        checks = {k: v.get() for k, v in distill_checks.items()}
        text = input_text.get("1.0", "end-1c")
        if command == "auto":
            result = run_auto(text, checks, hint_var.get())
        else:
            flags = build_distill_flags(command, checks)
            result = run_distill(command, " ".join(flags), text, hint_var.get())
        show(distill_out, result)

    d_buttons = ttk.Frame(distill_tab, padding=4)
    d_buttons.pack(fill="x")
    ttk.Button(d_buttons, text="Open file…", command=open_file).pack(side="left")
    ttk.Button(d_buttons, text="Distill", command=do_distill).pack(
        side="left", padx=6)

    distill_out = make_output(distill_tab)
    ttk.Button(
        d_buttons, text="Save output",
        command=lambda: save(
            distill_out,
            f"{os.path.splitext(hint_var.get() or 'pasted')[0] or 'pasted'}"
            f".{command_var.get()}.txt")).pack(side="left")

    root.bind("<F5>", lambda _e: do_search()
              if notebook.index("current") == 0 else do_distill())

    ttk.Label(root, textvariable=status_var, padding=(6, 2),
              relief="sunken").pack(fill="x", side="bottom")

    root.mainloop()


if __name__ == "__main__":
    main_gui()

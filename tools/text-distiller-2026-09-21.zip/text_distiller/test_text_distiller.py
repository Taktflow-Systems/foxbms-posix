#!/usr/bin/env python3
"""Unit tests for the text distiller."""

import unittest

from text_distiller import distill_text


class TestTextDistiller(unittest.TestCase):
    def test_strips_ansi_fences_and_decorative_separators(self):
        raw = "\x1b[31mERROR\x1b[0m: failed\n```\n======\nvalue=42\n```\n"

        result = distill_text(raw)

        self.assertEqual(result.text, "ERROR: failed\nvalue=42")
        self.assertEqual(result.stats.output_lines, 2)

    def test_removes_box_drawing_chrome_but_keeps_content(self):
        raw = "┌────────────┐\n│ Status: WARN │\n│ path: src/app.py:12 │\n└────────────┘\n"

        result = distill_text(raw)

        self.assertEqual(result.text, "Status: WARN\npath: src/app.py:12")

    def test_preserves_debug_punctuation_and_caret_marker(self):
        raw = "Traceback:\n  File \"app.py\", line 4\nx != y && path == a/b\n     ^^^^\n"

        result = distill_text(raw)

        self.assertIn("x != y && path == a/b", result.text)
        self.assertIn("^^^", result.text)

    def test_prompt_profile_collapses_whitespace_and_symbol_noise(self):
        raw = "   Hello     world!!!     🔥🔥\n***\n"

        result = distill_text(raw, profile="prompt")

        self.assertEqual(result.text, "Hello world!!!")

    def test_shell_prompt_prefix_is_removed(self):
        raw = "PS C:\\repo> python tool.py --flag\n$ echo done\n"

        result = distill_text(raw)

        self.assertEqual(result.text, "python tool.py --flag\necho done")


if __name__ == "__main__":
    unittest.main()

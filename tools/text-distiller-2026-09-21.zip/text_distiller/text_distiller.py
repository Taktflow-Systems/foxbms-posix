#!/usr/bin/env python3
"""Distill pasted text, logs, or prompts into a cleaner debugging payload.

The tool removes terminal/control noise, decorative separators, box-drawing
chrome, and low-information symbol clutter while preserving punctuation that is
usually useful in commands, stack traces, file paths, code, and key/value logs.
"""

from __future__ import annotations

import argparse
import re
import sys
import unicodedata
from dataclasses import dataclass
from pathlib import Path


ANSI_RE = re.compile(
    r"""
    \x1b\[[0-?]*[ -/]*[@-~]          # CSI sequences
    |\x1b\][^\x07]*(?:\x07|\x1b\\)  # OSC sequences
    |\x1b[@-_]                       # single-char ESC sequences
    """,
    re.VERBOSE,
)

BACKSPACE_RE = re.compile(r".\x08")
CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
FENCE_RE = re.compile(r"^\s*(?:`{3,}|~{3,})(?:\w+)?\s*$")
SHELL_PROMPT_RE = re.compile(r"^\s*(?:PS\s+[^>\n]{1,120}>|[$#>])\s+")
DECORATIVE_PREFIX_RE = re.compile(
    r"^\s*(?:[|>]\s+|[+|][\-+=]{2,}[+|]?\s*|[•◦▪▫◆◇▶►]\s+)"
)
REPEATED_SYMBOL_RE = re.compile(r"([!?.=*_~#\-])\1{3,}")

BOX_DRAWING_RANGES = (
    (0x2500, 0x257F),
    (0x2580, 0x259F),
)

USEFUL_ASCII_SYMBOLS = set(
    "_-/\\.:%@#=&+*<>[]{}()$'\"`,;!?|~^"
)

USEFUL_DECORATIVE_ONLY = set("^")


@dataclass(frozen=True)
class DistillStats:
    input_lines: int
    output_lines: int
    dropped_lines: int
    input_chars: int
    output_chars: int


@dataclass(frozen=True)
class DistillResult:
    text: str
    stats: DistillStats


def strip_ansi_and_controls(text: str) -> str:
    """Remove terminal escape sequences and non-content control characters."""
    text = ANSI_RE.sub("", text)
    while "\b" in text:
        next_text = BACKSPACE_RE.sub("", text)
        if next_text == text:
            text = text.replace("\b", "")
            break
        text = next_text
    return CONTROL_RE.sub("", text)


def normalize_symbol(char: str, aggressive: bool) -> str:
    """Return a content-safe representation of one character."""
    if char in "\n\t ":
        return char
    if char.isascii():
        if char.isalnum() or char in USEFUL_ASCII_SYMBOLS:
            return char
        return " "

    codepoint = ord(char)
    if any(start <= codepoint <= end for start, end in BOX_DRAWING_RANGES):
        return " "

    category = unicodedata.category(char)
    if category == "Cf":
        return ""
    if category[0] in {"L", "N"}:
        return char
    if category.startswith("P"):
        replacement = {
            "\u2018": "'",
            "\u2019": "'",
            "\u201c": '"',
            "\u201d": '"',
            "\u2013": "-",
            "\u2014": "-",
            "\u2026": "...",
        }.get(char)
        return replacement if replacement is not None else (" " if aggressive else char)
    if category.startswith("S"):
        return " "
    return " "


def normalize_symbols(text: str, aggressive: bool) -> str:
    text = unicodedata.normalize("NFKC", text)
    return "".join(normalize_symbol(char, aggressive) for char in text)


def is_separator_line(line: str, keep_debug_markers: bool) -> bool:
    stripped = line.strip()
    if not stripped:
        return False
    if any(char.isalnum() for char in stripped):
        return False
    if keep_debug_markers and set(stripped) <= USEFUL_DECORATIVE_ONLY:
        return False
    compact = re.sub(r"\s+", "", stripped)
    if len(compact) < 3:
        return False
    distinct = set(compact)
    if distinct <= set("-_=*~.#:;+|\\/[]{}()<>"):
        return True
    return len(distinct) <= 2 and all(not char.isalnum() for char in distinct)


def clean_line(line: str, profile: str, keep_fences: bool) -> str | None:
    if not keep_fences and FENCE_RE.match(line):
        return None

    line = line.expandtabs(4).rstrip()
    line = SHELL_PROMPT_RE.sub("", line)
    line = DECORATIVE_PREFIX_RE.sub("", line)
    line = line.strip()
    line = REPEATED_SYMBOL_RE.sub(r"\1\1\1", line)

    if is_separator_line(line, keep_debug_markers=(profile == "debug")):
        return None
    if profile == "prompt":
        line = re.sub(r"\s+", " ", line)
    return line


def distill_text(text: str, profile: str = "debug", keep_fences: bool = False) -> DistillResult:
    """Clean text while retaining prompt/debugging information."""
    if profile not in {"debug", "prompt"}:
        raise ValueError("profile must be 'debug' or 'prompt'")

    original_lines = text.splitlines()
    cleaned = strip_ansi_and_controls(text).replace("\r\n", "\n").replace("\r", "\n")
    cleaned = normalize_symbols(cleaned, aggressive=(profile == "prompt"))

    output_lines: list[str] = []
    blank_pending = False
    dropped_lines = 0
    for raw_line in cleaned.split("\n"):
        line = clean_line(raw_line, profile=profile, keep_fences=keep_fences)
        if line is None:
            dropped_lines += 1
            continue
        if not line:
            if output_lines and not blank_pending:
                output_lines.append("")
                blank_pending = True
            continue
        output_lines.append(line)
        blank_pending = False

    while output_lines and output_lines[-1] == "":
        output_lines.pop()

    distilled = "\n".join(output_lines)
    stats = DistillStats(
        input_lines=len(original_lines),
        output_lines=len(output_lines),
        dropped_lines=dropped_lines,
        input_chars=len(text),
        output_chars=len(distilled),
    )
    return DistillResult(text=distilled, stats=stats)


def read_input(path: Path | None) -> str:
    if path is None:
        return sys.stdin.read()
    return path.read_text(encoding="utf-8")


def write_output(path: Path | None, text: str) -> None:
    if path is None:
        sys.stdout.write(text)
        if text and not text.endswith("\n"):
            sys.stdout.write("\n")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text + ("\n" if text and not text.endswith("\n") else ""), encoding="utf-8")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Distill prompt/debug text by removing terminal and symbol noise."
    )
    parser.add_argument("input", nargs="?", type=Path, help="input file; defaults to stdin")
    parser.add_argument("-o", "--output", type=Path, help="output file; defaults to stdout")
    parser.add_argument(
        "--profile",
        choices=("debug", "prompt"),
        default="debug",
        help="debug preserves more code/log punctuation; prompt is more compact",
    )
    parser.add_argument(
        "--keep-fences",
        action="store_true",
        help="keep Markdown code-fence marker lines",
    )
    parser.add_argument(
        "--stats",
        action="store_true",
        help="print size reduction stats to stderr",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    result = distill_text(
        read_input(args.input),
        profile=args.profile,
        keep_fences=args.keep_fences,
    )
    write_output(args.output, result.text)
    if args.stats:
        stats = result.stats
        print(
            "distilled "
            f"{stats.input_lines}->{stats.output_lines} lines, "
            f"{stats.input_chars}->{stats.output_chars} chars, "
            f"dropped {stats.dropped_lines} lines",
            file=sys.stderr,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

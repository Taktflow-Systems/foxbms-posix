# Token Economy Playbook — on-site AI workflows

Goal: keep token spend low **without** lowering the quality of the work.
The lever is always the same: control what enters a model's context, and never
pay a model to do what a script can do.

This playbook covers four things: the tool ladder, agent usage, model
selection, and MCP usage — plus the OSS tools worth installing. The local
deterministic toolkit it refers to is documented in `README.md`.

## Read policy

Policy P2, the whole-file mandate. The user-level PreToolUse hook
`~/.claude/hooks/enforce_full_reads.py` blocks the Grep and Glob tools, the
Explore agent, `Read` with offset or limit, and shell `grep`, `rg`, `find`,
`head`, `tail`, `sed -n`, `awk NR`, `git grep`, `git ls-files` and wildcard
`ls` (also inside `bash -c`). Locate with `distill.py search` or `find`;
`skeleton`, `slice` and `budget` help decide what to read; then `Read` the
chosen files whole, at any size. Exceptions: `tail -f` on a `*.log` file,
and lines in `~/.claude/hooks/full-read-allowlist.txt` (ask the user before
adding one). The project hook `distill_hook.py` is retired and no longer
registered. Without the user-level hook these rules are advisory.
Policy source of truth: ~/.claude/hooks/read_policy.py

---

## 1. The tool ladder

Work down this ladder; stop at the first rung that solves the problem.
Each rung is ~10x cheaper than the one below it.

1. **Don't read it.** `distill.py budget` first. If the answer doesn't need
   the artifact in context, it never enters context.
2. **Deterministic tool.** `distill.py`, `jq`, DuckDB, ctags. Zero
   tokens, exact, repeatable, testable. If the operation has a right answer
   computable by code, a model should never do it "by hand".
3. **Cheap model on distilled input.** Classification, extraction,
   reformatting, simple summaries — a small model over a 300-token distillate,
   not a frontier model over a 50k-token dump.
4. **Subagent with scoped context.** When judgment over many files is needed,
   fence the raw reading inside a disposable context (see §2).
5. **Frontier model for synthesis only.** Architecture, root-cause reasoning,
   design trade-offs — fed conclusions and distillates, not raw artifacts.

Anti-pattern to ban on site: pasting raw build logs, full source files, or
whole JSON payloads into a chat "so the model has everything". That is rung 5
doing rung 2's job at rung-5 prices — and quality usually *drops*, because the
signal is buried.

## 2. Agents

- **Subagents are context firewalls.** A subagent burns its own disposable
  context reading files and returns only conclusions. The orchestrator's
  context stays small and stays cached. Rule: raw artifacts live in subagent
  contexts; only distillates and verdicts live in the main context.
- **Put the tool discipline in the agent prompt.** Agents don't economize by
  default. Every dispatched agent prompt should include: "Run
  `python tools\text_distiller\distill.py budget <paths>` before reading
  anything; use `search`/`skeleton`/`slice` to decide what to read, then Read
  the chosen files whole; pipe build and test output through
  `distill.py build` / `distill.py test`."
- **Demand structured returns.** Ask agents for a short JSON/YAML result
  (finding, file:line, confidence), not a narrative. Prose padding is pure
  token waste and harder to verify.
- **Read-only explorers for search.** "Where is X handled?" goes to a
  read-only search agent that returns paths and line numbers — never a
  read-write agent that might also "helpfully" edit.
- **Fresh context beats long context.** A conversation that has accumulated
  hundreds of k of history pays for it on every turn. End jobs with a small
  handoff file (achievement / state / blockers / next steps) and start the
  next job clean from the handoff, not from the bloated session.
- **Parallelize only independent work.** Fan-out is for coverage (N files, N
  dimensions), not for speed-running a sequential task; dependent steps in one
  agent, independent sweeps in parallel agents.
- **Don't poll.** Background long jobs and act on completion; polling turns
  idle waiting into context growth.

## 3. Models

Right-size by task, not by habit. Rough mapping (Claude family; same logic
applies to any provider):

| Task shape | Tier | Examples |
|---|---|---|
| Extraction, classification, formatting, routing, simple Q&A over a distillate | small (Haiku-class) | "Which of these 40 deduped errors are in our code vs vendor code?" |
| Routine coding, code review, summarizing distilled artifacts, test writing | mid (Sonnet-class) | "Fix the 3 errors in this build distillate" |
| Architecture, cross-cutting root cause, ambiguous requirements, final synthesis | large (Opus/Fable-class) | "Given these 5 subagent verdicts, what is the actual fault?" |

Mechanics that cut spend with zero quality loss:

- **Prompt caching.** Order prompts stable-first (system prompt, tool
  definitions, reference docs), volatile-last (the current question). Keep
  iteration cadence inside the cache TTL (5 min for Anthropic) during active
  loops; cached input tokens cost ~10 % of fresh ones.
- **Batch API** for anything non-interactive (nightly triage, bulk
  classification): ~50 % off.
- **Cap output.** Set `max_tokens` to what the answer needs; instruct terse
  formats ("table only", "JSON only", "no preamble").
- **Don't resend what the model already produced.** Reference earlier results
  by name/path; keep large outputs in files, not in the conversation.
- **Verify cheap, then escalate.** Run the cheap model; only escalate the
  cases it flags as uncertain. An eval set (see promptfoo, §5) makes the
  substitution safe instead of hopeful.

## 4. MCP

- **Schemas are a standing tax.** Every connected MCP server's tool schemas
  ride along in requests. Connect only the servers the current workflow uses;
  prefer harnesses that defer tool-schema loading until a tool is actually
  needed (Claude Code does this via on-demand tool search).
- **CLI beats MCP for deterministic operations.** A CLI called through the
  shell costs no schema tokens, is versionable, and is testable offline.
  Reserve MCP for what a CLI can't do well: stateful sessions, interactive
  auth, browser control, long-lived indexes (RAG) — or harnesses that can
  only call tools, not run shell commands. The toolkit ships both shells
  over the same functions: `distill.py` (preferred) and `distill_mcp.py`
  (a zero-dependency MCP stdio server; registration in `README.md`).
- **Distill server-side.** When you do own an MCP server, make its tools
  return summaries with drill-down parameters (pagination, field selection,
  `max_results`) — never unbounded payloads. A tool that can return 100k
  tokens will, eventually, in the worst moment.
- **One good tool beats five overlapping ones.** Overlapping tools waste
  schema tokens and cause the model to dither between them.

## 5. Deterministic tools (rung 2 of the ladder)

### Zero-install first (customer-site rule)

At customer sites, installing third-party binaries is not an option — Python
is normally the only thing reliably present. Everything in rung 2 must
therefore come from **Python stdlib + this toolkit + what is already on the
machine** (git, and the AI harness itself; the harness's built-in Grep/Glob
tools are blocked by the read policy above).

| Need | Zero-install answer |
|---|---|
| "which files contain this string" | `distill.py search <regex> -l` (pure-Python rg-lite: glob filters `-g *.c`, word match `-w`, context `-C`, skips .git/node_modules/binaries/huge blobs) |
| find files by name/glob | `distill.py find "*.c" -p <dir>`, or `distill.py budget <glob>` for sizes |
| extract fields from JSON | `distill.py json` for shape; `python -c "import json,..."` for exact fields |
| SQL over CSV/data | **sqlite3 is in the stdlib** — `import sqlite3` + the `csv` module replaces DuckDB for most questions |
| code structure / symbol outline | `distill.py skeleton`; `python ast` for exact Python analysis |
| "who references symbol X" | `distill.py search -w X -g *.c -g *.h -l` |
| codebase size inventory | `distill.py budget <dir>` |
| string history ("when did X appear") | `git log -S "X" --oneline` / `git log -G regex` (git is already in the workflow) |
| readable diffs | `git diff` piped into `distill.py diff -` |

### If installs ARE allowed (home lab / own infrastructure)

Worth having where policy permits — faster and stronger than the stdlib
equivalents, but never a dependency of the workflow itself:

| Tool | Replaces | Note |
|---|---|---|
| **ripgrep** (`rg`) | "agent, read these files and find X" | the single highest-leverage install |
| **fd** | recursive file finding | fast, sane defaults |
| **jq** / **yq** | model parsing of JSON/YAML | exact field extraction, zero tokens |
| **DuckDB** | "summarize this CSV/JSONL" | SQL over CSV/Parquet/JSONL in-place; answers analytics questions exactly |
| **Miller** (`mlr`) or **qsv** | CSV cleanup/stats | streaming, handles big files |
| **universal-ctags** | whole-file reads for structure | symbol index; `distill.py skeleton` covers the common cases without install |
| **ast-grep** (`sg`) | regex-guessing code edits | structural (AST) search & rewrite, deterministic refactors |
| **semgrep** | "agent, scan the codebase for pattern X" | rule-based, repeatable, CI-friendly |
| **tokei** or **scc** | "how big is this codebase?" | instant inventory by language |
| **lnav** | interactive log digging | for the human; agents use `distill.py log` |
| **Repomix** or **code2prompt** | hand-assembling code context | when bulk code *must* enter context, pack it once, deliberately |
| **rtk** (rtk-ai/rtk) | raw Bash output reaching the model | Rust CLI proxy; its Claude Code hook rewrites Bash commands (`git status` → `rtk git status`) and compresses output 60–90 %. Same philosophy as this toolkit at the command-output layer; needs a binary install, so home-lab only |
| **promptfoo** | hoping a cheaper model is good enough | eval harness; proves quality is preserved before you downshift a tier |

Where the user-level read-policy hook is installed, agents are blocked from
`rg` and `fd` just like `grep` and `find`; they stay useful for humans.

Overlap note: Repomix/code2prompt solve "put a repo *into* context";
`distill.py` solves "keep artifacts *out of* context". Use both — distill by
default, pack deliberately when a task genuinely needs broad code context.

## 6. Recipes (copy-paste)

```powershell
# Build-fix loop (agent never sees raw compiler output)
cmake --build build 2>&1 | python tools\text_distiller\distill.py build -

# Test-fix loop
python -m pytest --junitxml=report.xml; python tools\text_distiller\distill.py test report.xml

# Log triage on the bench
python tools\text_distiller\distill.py log bench.log --level error --sort-count

# Code understanding: outline -> targeted read
python tools\text_distiller\distill.py budget src
python tools\text_distiller\distill.py skeleton src\bms_state.c
python tools\text_distiller\distill.py slice src\bms_state.c -p "transition" -c 8

# Data question: exact answer, zero model tokens
duckdb -c "SELECT state, count(*) FROM 'telemetry.jsonl' GROUP BY state"

# Diff review
git diff | python tools\text_distiller\distill.py diff - --full "src/*"
```

## 7. Measure it

- Every `distill.py` call prints its own before/after token estimate — keep
  the headers in the transcript; they are the audit trail.
- Provider usage fields (`input_tokens`, `cache_read_input_tokens`,
  `output_tokens`) tell you whether caching is actually hitting. A healthy
  interactive loop shows mostly cache reads.
- Anthropic's `count_tokens` endpoint is free — measure a prompt before
  sending it, not after the invoice.
- Weekly: sort spend by workflow step; the top step is the next distiller to
  write.

# Text Distiller

Dependency-free Python toolkit that shrinks text before it reaches a model
(or a human). Two layers, one package:

- **clean** — character-level noise removal: ANSI escape sequences, control
  characters, box-drawing chrome, decorative separators, shell prompt
  prefixes. (`text_distiller.py`, also exposed as `distill.py clean`.)
- **distill** — structural compression: logs, build output, test reports,
  source files, JSON, CSV, diffs become compact high-signal summaries.
  (`distill.py` with 10 subcommands.)

Clean fixes *how text looks*; distill shrinks *what text says*. Both are pure
stdlib, deterministic (same input, same output), no install, no network, no
LLM calls. **Zero-install by design**: Python is the only requirement, so the
toolkit works at customer sites where third-party binaries cannot be
downloaded.

## Quick start

```powershell
# Character-level clean (standalone tool, stdout is the cleaned text)
Get-Content .\raw-log.txt | python .\tools\text_distiller\text_distiller.py

# Same cleaner via the unified CLI (token-savings header goes to stderr)
python .\tools\text_distiller\distill.py clean .\raw-log.txt

# Both layers at once: strip ANSI noise, then collapse repeats
python .\tools\text_distiller\distill.py log bench.log --clean --level error

# GUI: paste input, pick a command, read the output pane (stdlib tkinter)
python .\tools\text_distiller\distill_gui.py
```

## The cleaning layer

Removes:

- ANSI terminal escape sequences
- control characters and backspace overstrike output
- Markdown fence marker lines
- decorative separators and box-drawing chrome
- low-information emoji/symbol clutter
- common shell prompt prefixes

It keeps punctuation that is usually useful for debugging, including file
paths, line numbers, key/value separators, comparison operators, brackets,
and caret markers.

Standalone usage (supports `-o` output file and `--stats`):

```powershell
python .\tools\text_distiller\text_distiller.py .\raw-log.txt -o .\clean-log.txt --stats
python .\tools\text_distiller\text_distiller.py .\notes.txt --profile prompt
```

`--profile debug` (default) preserves more code/log punctuation;
`--profile prompt` is more compact.

## The distilling layer

```powershell
python tools\text_distiller\distill.py <command> [options]
```

| Command    | Input                          | Output                                              | Typical reduction |
|------------|--------------------------------|-----------------------------------------------------|-------------------|
| `auto`     | any text                       | detects what the input is (log/build/test/json/csv/diff/code) and runs the right distiller; first line reports the decision and why | as detected |
| `budget`   | files / dirs / globs           | token-cost table, biggest first                     | n/a (planning)    |
| `search`   | regex + files / dirs / globs   | which files contain the pattern (pure-Python rg-lite: `-l` files-only, `-t c` type shortcuts, `-g *.c` globs, `-F` literal, `-w` word, `-C` context, `-x DIR` skip, `--sort count`, `--tail` last matches first, `--max-line-chars N` clips long lines around the match (default 240, 0 = whole); honours `.gitignore`, skips binaries/huge blobs; one byte-level regex pass per file on a thread pool, ~250 MB of source in ~2 s) | n/a (locating) |
| `find`     | globs + dirs                   | which files exist: sorted paths with sizes (`find "*.c" -p src`, path globs like `src/*/*.h`, `-t cmake`); the controlled replacement for `find`/Glob | n/a (locating) |
| `clean`    | any text                       | character-level cleaned text (see above)            | noise-dependent   |
| `log`      | any log file or stdin          | unique line patterns with counts (timestamps/hex/UUIDs masked) | 90–99 % |
| `build`    | gcc/clang/msvc/cmake/make/ninja/python output | deduped errors + warnings only       | 95–99 % |
| `test`     | JUnit XML, pytest or ctest text | totals + failing tests + first assertion lines     | 90–99 % |
| `skeleton` | source file (.py exact, C/C++ heuristic, other generic) | signatures with line numbers, no bodies | ~95 % |
| `slice`    | any file                       | only lines matching a regex (+context) or a line range | depends on query |
| `json`     | JSON / JSONL                   | bounded schema tree with types, counts, samples     | 50–99 % |
| `csv`      | CSV / TSV                      | shape + per-column type/distinct stats + sample rows | grows with rows  |
| `diff`     | unified diff (e.g. `git diff`) | per-file stats + hunk headers; `--full GLOB` for full hunks | ~90 % |

Every command:

- prints a `# distill:<cmd> | input ~X tok -> output ~Y tok | saved Z%` header,
  so savings are measurable per call (for `clean` this goes to stderr so
  stdout stays pipeable);
- accepts `--max-tokens N` (default 4000; `clean` defaults to uncapped) —
  output is hard-capped with an explicit truncation marker, never a silent cut;
- reads `-` as stdin, so build/test/diff output can be piped directly;
- writes to a file instead of stdout with `-o PATH`, or `--save` to put the
  result in `output\<input-stem>.<cmd>.txt` (subfolder created automatically;
  the console still shows the token header and the written path).

## GUI

```powershell
python tools\text_distiller\distill_gui.py
```

One window, two tabs, all options as checkboxes — no CLI flags to remember:

- **Search repo** — type the text to find, pick the folder (**Browse…**),
  optionally restrict file types (`*.c;*.h`), tick options (ignore case,
  whole word, list files only, include excluded dirs, context lines) and
  press **Search**. Answers "which files contain this?" without any grep
  install.
- **Distill pasted text** — paste into the input pane (or **Open file…**),
  leave **Auto detect** selected (the default — the output's first line says
  what was detected and why), or pick what the text is (log / build output /
  test output / messy text / source code / JSON / CSV / diff), tick options
  (errors only, mask numbers, most-frequent-first, strip ANSI colors —
  applied only when the chosen command supports them), press **Distill**.
  *Filename hint* drives `skeleton`'s language detection for pasted code
  (e.g. `foo.c`).

F5 runs the active tab. **Save output** writes the output pane to the
`output\` subfolder. The GUI is a thin shell over the CLI — every button
builds the equivalent `distill.py` command line, so GUI and CLI can never
behave differently.

## Composing the layers

`log`, `build`, `test`, `slice`, and `diff` accept `--clean`: a
structure-preserving pre-pass that strips ANSI escapes and control characters
before parsing (compilers and test runners often emit color codes that would
otherwise hide matches from the parsers). It deliberately does *not* drop
lines or reflow text — downstream parsers rely on line structure. For the
full aggressive clean, pipe explicitly:

```powershell
Get-Content raw.log | python tools\text_distiller\distill.py clean - | python tools\text_distiller\distill.py log -
```

## Examples

```powershell
# What would it cost to read this directory? (run BEFORE any Read)
python tools\text_distiller\distill.py budget src --max-tokens 1000

# Which files mention this symbol? (locate, don't browse -- no grep install needed)
python tools\text_distiller\distill.py search "can_init" src -l
python tools\text_distiller\distill.py search -w bms_transition -t c -C 2
python tools\text_distiller\distill.py search -F "a[0]" src -x build --sort count

# Which files exist? (replaces find / glob; .gitignore-aware, sorted, sized)
python tools\text_distiller\distill.py find "*.c" -p src
python tools\text_distiller\distill.py find "bsw/*/include/*.h" -p firmware

# Build loop: agent sees 200 tokens of errors instead of 50k of compiler spew
cmake --build build 2>&1 | python tools\text_distiller\distill.py build - --clean

# Test loop
python -m pytest --junitxml=report.xml; python tools\text_distiller\distill.py test report.xml

# Log triage: errors only, repeats collapsed
python tools\text_distiller\distill.py log bench.log --level error --sort-count

# Understand a file cheaply: outline first, then read only what matters
python tools\text_distiller\distill.py skeleton src\bms_state.c
python tools\text_distiller\distill.py slice src\bms_state.c -p "bms_transition" -c 8

# Review a change without dumping the whole diff
git diff | python tools\text_distiller\distill.py diff - --full "src/bms*"

# Data files: schema instead of content
python tools\text_distiller\distill.py json telemetry.jsonl
python tools\text_distiller\distill.py csv registers.csv
```

### PowerShell 5.1 caveat

`<cmd> 2>&1 | distill.py build -` works in bash/cmd but **not** in Windows
PowerShell 5.1, which wraps native stderr in ErrorRecords and mangles the
lines before they reach the pipe (errors silently vanish from the summary).
In PowerShell, capture to a file first:

```powershell
cmd /c "your-build-command 2>&1" | python tools\text_distiller\distill.py build -
# or: your-build-command 2>&1 | Out-File build.log; distill.py build build.log
```

## Rules of thumb for agents

1. Never `Read` a file before `budget` says it is cheap (< ~2k tokens).
2. Anything marked `!` in `budget` output goes through a distiller, not `Read`.
3. "Which file contains X?" is answered by `search X -l`, never by reading
   files one by one. After two failed patterns, search a shorter substring
   with `-F` — don't keep guessing variants. "Which files exist?" is
   `find`. These two are the only search path (see "Read policy" below).
4. `skeleton` → `slice` to understand a source file; before editing it,
   `Read` the real file whole (never edit from a skeleton or slice alone).
5. Pipe build/test output through `build`/`test` (with `--clean` if the tool
   emits color) before showing it to a model.
6. If a distiller saved < 30 %, the input was already small — just read it.

## Determinism contract

- No wall-clock time, no randomness, no environment-dependent output.
- Stable ordering: first-seen order, or an explicit sort key with stable ties.
- UTF-8 input with `errors="replace"`; output is plain ASCII-safe text.

## Read policy

Policy P2, the whole-file mandate. The user-level PreToolUse hook
`~/.claude/hooks/enforce_full_reads.py` blocks the Grep and Glob tools, the
Explore agent, `Read` with offset or limit, and shell `grep`, `rg`, `find`,
`head`, `tail`, `sed -n`, `awk NR`, `git grep`, `git ls-files` and wildcard
`ls` (also inside `bash -c`). Locate with `distill.py search` or `find`;
`skeleton`, `slice` and `budget` help decide what to read; then `Read` the
chosen files whole, at any size. Exceptions: `tail -f` on a `*.log` file,
and lines in `~/.claude/hooks/full-read-allowlist.txt` (ask the user before
adding one). The project hook `distill_hook.py` is retired and no longer
registered. Without the user-level hook these rules are advisory.
Policy source of truth: ~/.claude/hooks/read_policy.py

`distill_hook.py` stays in this folder for reference only: it denied whole
reads over 8,000 bytes, which contradicts the whole-file mandate, so no
settings file registers it. Harnesses without hooks need their own
mechanism: for tool-only or hosted models, grant *only* the MCP server's
tools (below) and no filesystem read tool, so every input arrives distilled.

## Use as an MCP server (models call the tools directly)

The same functions are exposed as an MCP stdio server — still zero-install,
because `distill_mcp.py` speaks MCP's newline-delimited JSON-RPC itself
instead of requiring the MCP SDK. Register it in Claude Code with a
`.mcp.json` at the repo root:

```json
{
  "mcpServers": {
    "text-distiller": {
      "command": "python",
      "args": ["tools/text_distiller/distill_mcp.py"]
    }
  }
}
```

Five tools, deliberately few and small-schema (schemas ride along in every
model request): `search_repo`, `find_files`, `distill_text` (kind defaults
to `auto`), `distill_file`, `token_budget`. Every result is token-capped
server-side.

The MCP tools expose a subset of the CLI options (kept small on purpose,
since schemas cost tokens on every request):

| MCP tool | CLI options it does not expose |
|---|---|
| `search_repo` | several paths in one call, `--max-per-file`, `--tail`, `--max-line-chars`, `--sort`, `--max-filesize`, `--exclude`, `--no-ignore`, `--no-default-excludes` |
| `find_files` | several `--path` dirs in one call, `--no-sizes`, `--exclude`, `--no-ignore`, `--no-default-excludes` |
| all tools | `-o`, `--save`, `--no-persist` (file output is a CLI concern; results come back in-band, capped by `max_tokens`) |

When to use which shell: agents that can run shell commands should keep
using the CLI (zero schema tax); the MCP server is for harnesses or hosted
models that can only call tools. Architecture note: `distiller/api.py` is
the shared layer — CLI, GUI, and MCP are all thin shells over it, so adding
a capability there lights it up everywhere.

## Tests

```powershell
# distill layer (74 tests, includes clean-integration tests; pytest, because
# the tree-walking tests use the tmp_path fixture)
python -m pytest tools\text_distiller\tests -q

# cleaning layer (5 tests)
python -m unittest discover -s tools\text_distiller -p "test_*.py"
```

## Layout

```
tools/text_distiller/
  distill.py              unified CLI entry point
  distill_gui.py          tkinter GUI (thin shell over the CLI)
  distill_mcp.py          MCP stdio server (thin shell over distiller/api.py)
  distill_hook.py         retired Read-gate hook, not registered (see Read policy)
  deploy_check.ps1        deployment self-check (see DEPLOY.md)
  distiller/              package: core, api, detect, logs, build, testreport,
                          skeleton, slicer, jsondata, tabular, diffs, budget,
                          search, ignore, cli
  tests/test_distiller.py distill-layer tests
  text_distiller.py       character-level cleaner (standalone + imported by
                          `distill.py clean` / `--clean`)
  test_text_distiller.py  cleaner tests
  TOKEN_ECONOMY_PLAYBOOK.md  how to combine this with agents/models/MCP/OSS tools
```

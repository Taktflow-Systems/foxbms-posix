#!/usr/bin/env python3
"""RETIRED 2026-09-13: no settings file registers this hook any more.

It denied whole reads over 8,000 bytes, which contradicts read policy P2
(the whole-file mandate). Policy source of truth: ~/.claude/hooks/read_policy.py
The text below describes the behaviour it had while registered.

PreToolUse hook: enforce distilled input for oversized file reads.

Registered on the Read tool in .claude/settings.json. The harness runs this
before every Read; we deny raw reads of large text files and tell the model
the exact distill command to use instead. Allowed through:

- small files (<= DISTILL_HOOK_MAX_BYTES, default 8000 bytes ~ 2k tokens) --
  distilling those would cost more than it saves
- targeted windowed reads (limit <= 250 lines) -- that IS the slice discipline
- images / PDFs / notebooks -- Read handles them natively, the distiller can't
- files inside an output/ folder -- already-distilled artifacts
- missing files -- let Read produce its own error

Zero dependencies, stdin JSON in, decision JSON on stdout (empty = allow).
"""

from __future__ import annotations

import json
import os
import sys

MAX_BYTES = int(os.environ.get("DISTILL_HOOK_MAX_BYTES", "8000"))
WINDOW_LIMIT = 250
NATIVE_READ_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp",
                    ".svg", ".pdf", ".ipynb"}


def decide(payload: dict, max_bytes: int = MAX_BYTES) -> dict | None:
    """Return None to allow the Read, or a PreToolUse deny decision."""
    if payload.get("tool_name") != "Read":
        return None
    tool_input = payload.get("tool_input") or {}
    path = tool_input.get("file_path") or ""
    if not path:
        return None
    if os.path.splitext(path)[1].lower() in NATIVE_READ_EXTS:
        return None
    limit = tool_input.get("limit")
    if isinstance(limit, (int, float)) and limit <= WINDOW_LIMIT:
        return None
    if os.path.basename(os.path.dirname(path)).lower() == "output":
        return None
    try:
        size = os.path.getsize(path)
    except OSError:
        return None
    if size <= max_bytes:
        return None

    reason = (
        f"Raw read blocked: {path} is {size} bytes (~{size // 4} tokens); "
        f"this site requires distilled input for files over {max_bytes} bytes. "
        f"Use one of:\n"
        f"  python tools/text_distiller/distill.py auto \"{path}\"\n"
        f"  python tools/text_distiller/distill.py skeleton \"{path}\"  "
        f"(code: outline, then slice)\n"
        f"  python tools/text_distiller/distill.py slice \"{path}\" -p \"<regex>\" -C 5\n"
        f"  python tools/text_distiller/distill.py search \"<regex>\" . -l  "
        f"(locate instead of read)\n"
        f"  python tools/text_distiller/distill.py find \"*.c\" -p .  "
        f"(list files instead of globbing)\n"
        f"A windowed re-Read (limit<={WINDOW_LIMIT}) passes this gate but is "
        f"blocked where the global enforce_full_reads hook is installed."
    )
    return {
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": reason,
        }
    }


def main() -> int:
    try:
        sys.stdin.reconfigure(encoding="utf-8-sig", errors="replace")
    except (AttributeError, ValueError):
        pass
    try:
        payload = json.load(sys.stdin)
    except ValueError:
        return 0  # unparseable input: never break the harness, allow
    try:
        decision = decide(payload)
    except Exception as exc:  # in-band like the MCP server: an error string, never a traceback
        decision = {"systemMessage": f"error: distill_hook: {' '.join(str(exc).split())}"}
    if decision is not None:
        print(json.dumps(decision))
    return 0


if __name__ == "__main__":
    sys.exit(main())

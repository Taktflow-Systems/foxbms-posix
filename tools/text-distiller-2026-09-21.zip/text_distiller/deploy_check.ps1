# Verifies the text_distiller deployment. Run from the project root:
#   powershell -File tools\text_distiller\deploy_check.ps1
$ErrorActionPreference = 'Continue'
$fail = 0

"== python =="
python --version
if ($LASTEXITCODE -ne 0) { "FAIL: python not on PATH"; exit 1 }

"== distill-layer tests =="
python -m unittest discover -s tools\text_distiller\tests
if ($LASTEXITCODE -ne 0) { $fail = 1 }

"== cleaner tests =="
python -m unittest discover -s tools\text_distiller -p "test_*.py"
if ($LASTEXITCODE -ne 0) { $fail = 1 }

"== hook pipe-test (expect a deny JSON below) =="
$probe = Join-Path $env:TEMP "distill_deploy_probe.txt"
"x" * 20000 | Set-Content -Path $probe -Encoding ascii
$payload = '{"tool_name":"Read","tool_input":{"file_path":"' + ($probe -replace '\\', '/') + '"}}'
$result = $payload | python tools\text_distiller\distill_hook.py
Remove-Item $probe -Force
if ($result -match '"permissionDecision": "deny"') { "ok: hook denies oversized read" }
else { "FAIL: hook did not deny ($result)"; $fail = 1 }

"== config files =="
foreach ($f in '.claude\settings.json', '.claude\skills\distill\SKILL.md', '.mcp.json', 'CLAUDE.md') {
    if (Test-Path $f) { "ok: $f" } else { "FAIL: missing $f"; $fail = 1 }
}

if ($fail -eq 0) { "`nDEPLOYMENT OK" } else { "`nDEPLOYMENT HAS FAILURES"; exit 1 }

#!/usr/bin/env python3
"""Entry point -- run from anywhere, no install needed:

    python tools\\text_distiller\\distill.py <command> [options]
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass
    from distiller.cli import main
    sys.exit(main())
